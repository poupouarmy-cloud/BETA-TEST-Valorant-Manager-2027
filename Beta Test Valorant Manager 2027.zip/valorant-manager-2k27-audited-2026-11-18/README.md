# VALORANT MANAGER 2027

A browser based VALORANT esports management simulation. The application runs locally and does not require a Gemini API key.

## Run locally

Requires Node.js and npm.

1. Run `npm install` once to install the small local web server dependency.
2. Run `npm start`.
3. Open `http://localhost:3000` in a modern browser.

You can also open `index.html` directly in a modern browser. The game stores careers in that browser's local storage. Use **Settings → Export save** to keep a portable JSON backup, and **Import save** to restore one.

## Audio

The game includes the supplied *If The Sun Burns Out Tonight* instrumental as its default local soundtrack, soft differentiated interface sounds, and an original synthesized fallback score. Playback starts after the first interaction to respect browser autoplay rules. The floating **Audio** control stays available on every screen; it can pause or resume the music and adjust music and effect volumes independently. The same options are also in **Settings → Audio & sound**. You can select another local instrumental file there; it stays in this browser's storage and is not streamed from an external site.

## Tournament presentation

Winning a VCT trophy opens an animated celebration with original trophy artwork, and the Hall of Fame uses the matching trophy image. The first in-game season keeps its existing venue setup. Later global-event seasons choose three distinct cities from confirmed VALORANT Esports host locations and move each event to a different city from the prior season. A Champions title permanently bypasses Open Qualifiers for regional events; another major trophy grants that bypass for the following season. Masters and Champions qualification still depends on event results.

The venue pool follows Riot's published event locations, including the [VCT 2027 season](https://valorantesports.com/en-US/season/117246370678200773), [2026 global events](https://valorantesports.com/en-US/news/first-look-at-valorant-champions-tour-2026), [2025 season locations](https://valorantesports.com/en-US/news/vct-2025-season-wrap-up), and [Masters Madrid 2024](https://valorantesports.com/en-US/news/masters-madrid-tickets-on-sale-january-12/).

## Checks

Run `npm test` to execute the career and simulation checks.
