const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

function loadGameSandbox() {
  const storage = {};
  const sandbox = {
    console,
    Date,
    Math,
    JSON,
    Number,
    String,
    Boolean,
    Array,
    Object,
    RegExp,
    Error,
    parseInt,
    parseFloat,
    isNaN,
    setTimeout,
    clearTimeout,
    navigator: { language: 'en-US' },
    localStorage: {
      getItem: (k) => (Object.prototype.hasOwnProperty.call(storage, k) ? storage[k] : null),
      setItem: (k, v) => { storage[k] = String(v); },
      removeItem: (k) => { delete storage[k]; }
    },
    document: {
      documentElement: { lang: 'en' },
      body: null
    }
  };
  sandbox.window = sandbox;
  sandbox.self = sandbox;
  vm.createContext(sandbox);

  const files = [
    'js/i18n.js',
    'js/lang/fr.js',
    'js/lang/es.js',
    'js/lang/pt.js',
    'js/lang/ko.js',
    'js/lang/ja.js',
    'js/lang/zh.js',
    'js/lang/complete.js',
    'js/player-photos.js',
    'js/core.js',
    'js/data.js',
    'js/engine.js',
    'js/competition.js',
    'js/game.js',
    'js/ui.js',
    'js/views.js'
  ];
  for (const f of files) {
    const code = fs.readFileSync(path.join(process.cwd(), f), 'utf8');
    vm.runInContext(code, sandbox, { filename: f });
  }
  return sandbox;
}

test('2027 Competitive Map Pool, Veto & Stats Integrity', () => {
  const sb = loadGameSandbox();
  const { Core, Engine, Game } = sb;

  assert.deepEqual(
    Array.from(Core.ACTIVE_MAP_POOL_2027),
    ['Abyss', 'Bind', 'Corrode', 'Haven', 'Lotus', 'Summit', 'Sunset']
  );

  const s = Game.newCareer({
    managerName: 'Audit Mgr',
    mode: 'existing',
    clubId: 'sentinels',
    difficulty: 'Normal'
  });

  assert.deepEqual(Array.from(s.settings.mapPool), Array.from(Core.ACTIVE_MAP_POOL_2027));
  for (const reserve of Core.RESERVE_MAPS) {
    assert.equal(s.settings.mapPool.includes(reserve), false, `Reserve map ${reserve} should not be in active 2027 pool`);
  }

  // setMapPool rejects non-7 map pools
  const badRes = Game.setMapPool(['Abyss', 'Bind', 'Haven']);
  assert.equal(badRes.ok, false);

  // Veto & simulated series only pick from active 2027 competitive pool
  const userOrg = Game.org();
  const oppOrg = Object.values(s.orgs).find((o) => !o.isUser && o.partner && o.roster && o.roster.length >= 5);
  assert.ok(oppOrg);

  const ser = Engine.simulateSeries(s, userOrg, oppOrg, { bo: 3, tag: 'test-veto' });
  assert.ok(ser.maps.length >= 2);
  for (const m of ser.maps) {
    assert.ok(s.settings.mapPool.includes(m.map), `Simulated map ${m.map} must be in active pool`);
    assert.equal(Core.RESERVE_MAPS.includes(m.map), false);
  }

  // applySeriesEffects records mapStats
  sb.Competition.applySeriesEffects(s, null, ser, { tag: 'test' });
  const playedMapsCount = Object.values(userOrg.mapStats || {}).reduce((acc, x) => acc + (x.played || 0), 0);
  assert.ok(playedMapsCount >= ser.maps.length);
});

test('Time progression and all 6 time-skip modes simulate intermediate events', () => {
  const sb = loadGameSandbox();
  const { Game } = sb;

  const s = Game.newCareer({
    managerName: 'Skip Tester',
    mode: 'existing',
    clubId: 'fnatic',
    difficulty: 'Normal'
  });

  const d0 = s.date;
  const rDay = Game.skipTime('day');
  assert.equal(rDay.ok, true);
  assert.equal(rDay.days, 1);
  assert.notEqual(s.date, d0);

  const d1 = s.date;
  const rWeek = Game.skipTime('week');
  assert.equal(rWeek.ok, true);
  assert.ok(rWeek.days >= 1 && rWeek.days <= 7);
  assert.ok(s.date > d1);

  const rMatch = Game.skipTime('match');
  assert.equal(rMatch.ok, true);
  if (rMatch.pendingMatch) {
    assert.ok(s.pendingMatch);
    const played = Game.resolveMatch();
    assert.ok(played);
  }

  const rEvent = Game.skipTime('event');
  assert.equal(rEvent.ok, true);

  const rSplit = Game.skipTime('split', { autoResolveMatches: true });
  assert.equal(rSplit.ok, true);
  assert.ok(rSplit.days >= 1);

  const rSeason = Game.skipTime('season', { autoResolveMatches: true });
  assert.equal(rSeason.ok, true);
  assert.equal(rSeason.seasonComplete, true);
});

test('Multi-season continuity, custom logo persistence, and Game.selfTest', () => {
  const sb = loadGameSandbox();
  const { Game } = sb;

  // Run built-in 3-season continuity verification
  const stRes = Game.selfTest(3);
  assert.equal(stRes.ok, true, 'SelfTest failed: ' + (stRes.errors || []).join('; '));

  // Create new club with customLogo & verify persistence through season transition & export/import
  const logoPng = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==';
  const s = Game.newCareer({
    managerName: 'Logo Owner',
    mode: 'new',
    region: 'EMEA',
    sub: 'Europe',
    orgName: 'Atlas Pulse',
    orgShort: 'ATP',
    colors: ['#ff4655', '#10141c'],
    customLogo: logoPng
  });

  assert.equal(Game.org().customLogo, logoPng);
  const poolBefore = s.settings.mapPool.slice();

  Game.skipTime('season', { autoResolveMatches: true });
  assert.equal(sb.Competition.seasonComplete(s), true);
  const tr = Game.seasonTransition();
  assert.ok(tr && tr.nextSeason === 2028);
  assert.equal(Game.org().customLogo, logoPng, 'Custom logo must survive season transition');
  assert.equal(s.settings.mapPool.length, 7);
  assert.notDeepEqual(Array.from(s.settings.mapPool), Array.from(poolBefore), 'Map pool should rotate cleanly between seasons');

  const json = JSON.stringify(s);
  const imported = Game.importSave(json);
  assert.equal(imported.orgs[imported.clubId].customLogo, logoPng);
  assert.equal(imported.season, 2028);
});

test('Transfer market selling, incoming offers, accept/counter/reject & 5-player minimum', () => {
  const sb = loadGameSandbox();
  const { Engine, Game } = sb;

  const s = Game.newCareer({
    managerName: 'GM Seller',
    mode: 'existing',
    clubId: 'sentinels',
    difficulty: 'Normal'
  });

  const org = Game.org();
  // Sign 1 cheap free agent so roster has > 5 players
  const fa = Game.freeAgents().sort((a, b) => a.level - b.level)[0];
  assert.ok(fa);
  const dem = Game.demand(fa.id);
  const buy = Game.makeOffer(fa.id, { fee: 0, wage: dem.wage * 1.15, years: 2, playingTime: 'rotation' });
  assert.equal(buy.ok, true, 'Failed to sign depth FA: ' + buy.reason);

  const target = Game.roster(org).sort((a, b) => a.level - b.level)[0];
  const askPrice = Math.max(25000, Engine.valueFor(target));
  const listRes = Game.listPlayer(target.id, true, askPrice);
  assert.equal(listRes.ok, true);
  assert.equal(target.transferListed, true);
  assert.equal(target.askingPrice, askPrice);

  // Advance until an incoming offer arrives (or use directly generated one if triggered on listPlayer)
  for (let i = 0; i < 4 && !(s.incomingOffers || []).length; i++) {
    Game.skipTime('week', { autoResolveMatches: true });
  }
  assert.ok((s.incomingOffers || []).length > 0, 'Listing a player should generate incoming transfer offers');

  const firstOffer = s.incomingOffers[0];
  const budgetBefore = org.budget;

  // Test reject
  if (s.incomingOffers.length > 1) {
    const rej = Game.respondIncomingOffer(s.incomingOffers[1].id, 'reject');
    assert.equal(rej.ok, true);
    assert.equal(rej.decision, 'reject');
  }

  // Test modest counter-offer (accepted or revised), then accept
  const modestCounter = Math.round(firstOffer.fee * 1.05);
  const cnt = Game.respondIncomingOffer(firstOffer.id, 'counter', modestCounter);
  if (cnt.ok && cnt.decision === 'revised') {
    const acc = Game.respondIncomingOffer(firstOffer.id, 'accept');
    assert.equal(acc.ok, true);
    assert.ok(org.budget > budgetBefore, 'Budget must increase after selling player');
  } else if (cnt.ok && cnt.decision === 'accept') {
    assert.ok(org.budget > budgetBefore, 'Budget must increase after accepted counter');
  }

  // Unlist test on remaining starter
  const rem = Game.roster(org)[0];
  Game.listPlayer(rem.id, true, 50000);
  assert.equal(rem.transferListed, true);
  Game.listPlayer(rem.id, false);
  assert.equal(rem.transferListed, false);
});

test('Financial breakdown KPIs, categories, and warnings accuracy', () => {
  const sb = loadGameSandbox();
  const { Game } = sb;

  const s = Game.newCareer({
    managerName: 'CFO Test',
    mode: 'existing',
    clubId: 'team_heretics',
    difficulty: 'Normal'
  });

  const fbInit = Game.financeBreakdown();
  assert.ok(fbInit);
  assert.equal(typeof fbInit.budget, 'number');
  assert.equal(typeof fbInit.monthlyIncome, 'number');
  assert.equal(typeof fbInit.monthlyExpenses, 'number');
  assert.equal(fbInit.monthlyNet, fbInit.monthlyIncome - fbInit.monthlyExpenses);
  assert.equal(fbInit.remainingPayrollBudget, fbInit.payrollCap - fbInit.annualPayroll);

  // When all active sponsors expire/clear, no_sponsors warning triggers
  s.sponsorContracts = [];
  const fb = Game.financeBreakdown();
  assert.ok(fb.warnings.some((w) => w.code === 'no_sponsors'));

  // Sign a sponsor -> no_sponsors warning disappears & monthlyIncome increases
  const offerId = s.sponsorOffers[0].id;
  const sp = Game.signSponsor(offerId);
  assert.equal(sp.ok, true);
  const fb2 = Game.financeBreakdown();
  assert.equal(fb2.warnings.some((w) => w.code === 'no_sponsors'), false);
  assert.ok(fb2.monthlyIncome > fb.monthlyIncome);
});

test('French I18N covers new map pool, time skips, selling, finances & injuries cleanly', () => {
  const sb = loadGameSandbox();
  const { I18N } = sb;
  I18N.set('fr');

  const exactChecks = [
    ['Zhangjiajie cliffside with droppable walls and tight chokes. Space control decides retakes.', 'Falaise de Zhangjiajie'],
    ['ACTIVE 2027 COMPETITIVE ROTATION (7/7)', 'ROTATION COMPÉTITIVE ACTIVE 2027 (7/7)'],
    ['RESERVE / OUT OF ROTATION', 'RÉSERVE / HORS ROTATION'],
    ['Split 1 — Kickoff & Masters 1', 'Split 1 — Kickoff et Masters 1'],
    ['End of Split', 'Fin de phase'],
    ['End of Season', 'Fin de saison'],
    ['Incoming offers', 'Offres entrantes'],
    ['Transfer list', 'Mettre en vente'],
    ['Confirm Long Simulation', 'Confirmer la simulation longue'],
    ['Simulation Summary', 'Résumé de la simulation'],
    ['Available budget', 'Budget disponible'],
    ['Remaining payroll budget', 'Marge salariale restante'],
    ['Negative cash balance', 'Trésorerie négative'],
    ['Custom club logo (PNG, JPG or WEBP)', 'Logo personnalisé du club'],
    ['Overview & Player Attributes', 'Vue d’ensemble et attributs'],
    ['Wrist strain', 'Entorse du poignet']
  ];
  for (const [en, expectedSubstr] of exactChecks) {
    const tr = I18N.text(en);
    assert.notEqual(tr, en, `Untranslated string: "${en}"`);
    assert.ok(tr.includes(expectedSubstr), `Unexpected translation for "${en}": "${tr}"`);
  }

  const patternChecks = [
    ['OPEN CIRCUIT · Pacific · SEASON 2027', 'CIRCUIT OUVERT · Pacific · SAISON 2027'],
    ['7 COMPETITIVE MAPS ACTIVE', '7 CARTES COMPÉTITIVES ACTIVES'],
    ['balanced · 67% (2W–1L)', 'équilibrée · 67 % (2V–1D)'],
    ['CURRENT DATE · 15 févr. 2027 · Split 1 — Kickoff & Masters 1', 'DATE ACTUELLE · 15 févr. 2027 · Split 1 — Kickoff et Masters 1'],
    ['Start Season 2028', 'Commencer la saison 2028'],
    ['INJ 5d', 'BLS 5j']
  ];
  for (const [en, expected] of patternChecks) {
    const tr = I18N.text(en);
    assert.equal(tr, expected, `Pattern mismatch for "${en}"`);
  }
});

test('Live rosters follow the career save, transfers, and AI activity on the calendar', () => {
  const sb = loadGameSandbox();
  const { Game } = sb;
  const state = Game.newCareer({
    managerName: 'Roster Audit', mode: 'existing', clubId: 'sentinels',
    difficulty: 'Normal', seed: 424242, noSave: true
  });
  const start = Game.liveRosters();
  const activeOrgCount = Object.values(state.orgs).filter((org) => org.status !== 'inactive').length;
  assert.equal(start.date, state.date);
  assert.equal(start.teams.length, activeOrgCount);
  assert.ok(start.teams.length > 32, 'Directory should include active partners and open-circuit organizations');

  const userTeam = start.teams.find((team) => team.id === state.clubId);
  assert.ok(userTeam);
  assert.equal(userTeam.starters.length, 5);
  for (const player of userTeam.starters.concat(userTeam.reserves)) {
    assert.equal(player.org, state.clubId);
    assert.equal(!!player.retired, false);
    assert.equal(!!player.academy, false);
  }

  const freeAgent = Game.freeAgents().sort((a, b) => a.level - b.level)[0];
  const demand = Game.demand(freeAgent.id);
  const signing = Game.makeOffer(freeAgent.id, {
    fee: 0, wage: demand.wage * 1.2, years: 2, playingTime: 'rotation'
  });
  assert.equal(signing.ok, true);
  const afterSigning = Game.liveRosters();
  assert.ok(afterSigning.teams.find((team) => team.id === state.clubId).roster.some((player) => player.id === freeAgent.id));

  const aiOrg = Object.values(state.orgs).find((org) => !org.isUser && org.partner && org.roster.length >= 5);
  assert.ok(aiOrg);
  while (aiOrg.roster.length > 4) {
    const releasedId = aiOrg.roster.pop();
    aiOrg.lineup = aiOrg.lineup.filter((id) => id !== releasedId);
    state.players[releasedId].org = null;
    state.players[releasedId].status = 'free agent';
  }

  let guard = 0;
  while (state.date < '2027-06-01' && guard < 250) {
    if (state.pendingMatch) Game.resolveMatch();
    else Game.advance(1);
    guard++;
  }
  assert.equal(state.date, '2027-06-01');
  const aiMove = state.transferHistory.find((move) => move.date === '2027-06-01' && state.orgs[move.to] && !state.orgs[move.to].isUser);
  assert.ok(aiMove, 'AI-controlled organizations must complete transfers in the June window');
  const afterAiTransfer = Game.liveRosters();
  assert.equal(afterAiTransfer.date, state.date);
  assert.ok(afterAiTransfer.teams.find((team) => team.id === aiMove.to).roster.some((player) => player.id === aiMove.playerId));
  assert.ok(afterAiTransfer.teams.find((team) => team.id === aiOrg.id).roster.length >= 5, 'AI should repair the deliberately short roster');
  assert.ok(afterAiTransfer.updates.some((update) => update.type === 'transfer' && update.date === state.date));
});

test('Roster navigation labels and placeholders are translated across available languages', () => {
  const { I18N } = loadGameSandbox();
  const rosterKeys = [
    'Live rosters', 'Live Team Rosters', 'Find a team', 'All organizations', 'All regions', 'All leagues', 'All competitions',
    'Search teams or players', 'Apply filters', 'Clear filters', 'Showing {shown} of {total} organizations',
    'Career date: {date} · Rosters reflect this save', 'Current organization', 'Current competition',
    'No current competition', 'Starting five', 'Substitutes and reserves', 'Coaches and staff',
    'Organizations and teams', 'Recent transfers and roster changes', 'No starting lineup recorded.',
    'No reserve players.', 'No staff assigned.', 'No organizations match these filters.',
    'No roster changes recorded yet.', 'Contract details unavailable', 'Expires after season {season}',
    'Contract through {season}', 'No agents listed', 'Expiring', 'Under contract',
    '{count} starters', '{count} reserves', '{count} staff', 'Injured · {days}d',
    'Open Circuit · Americas', 'Open Circuit · EMEA', 'Open Circuit · Pacific', 'Open Circuit · China'
  ];
  for (const language of ['fr', 'es', 'pt', 'ko', 'ja', 'zh']) {
    I18N.set(language);
    assert.notEqual(I18N.text('Live rosters'), 'Live rosters', `${language} navigation label is untranslated`);
    for (const key of rosterKeys) {
      const vars = { date: '4 Jan 2027', shown: 4, total: 20, season: 2028, count: 3, days: 5 };
      assert.notEqual(I18N.t(key, vars), key, `${language} untranslated key: ${key}`);
    }
    assert.ok(I18N.t('Contract through {season}', { season: 2028 }).includes('2028'));
  }
  I18N.set('unsupported-language');
  assert.equal(I18N.get(), 'en', 'Unknown language must safely fall back to English');
});

test('Live roster page renders every team and applies organization, region, league, competition, and search filters', () => {
  const sb = loadGameSandbox();
  const { Game, Views, UI } = sb;
  const state = Game.newCareer({
    managerName: 'Roster View Audit', mode: 'existing', clubId: 'sentinels',
    difficulty: 'Normal', seed: 314159, noSave: true
  });
  const directory = Game.liveRosters();
  const countCards = (markup) => (markup.match(/<details class="roster-team">/g) || []).length;

  let markup = Views.rosters();
  assert.equal(countCards(markup), directory.teams.length);
  assert.ok(markup.includes(`Career date: ${sb.Core.fmtDate(state.date, true)}`));
  for (const key of ['org', 'region', 'league', 'competition', 'search']) {
    assert.ok(markup.includes(`data-roster-filter="${key}"`), `Missing ${key} roster filter`);
  }
  assert.ok(markup.includes('Starting five'));
  assert.ok(markup.includes('Substitutes and reserves'));
  assert.ok(markup.includes('Coaches and staff'));

  UI.filters.rosters.region = 'Americas';
  markup = Views.rosters();
  assert.equal(countCards(markup), directory.teams.filter((team) => team.org.region === 'Americas').length);

  UI.filters.rosters = { org: 'sentinels', region: 'all', league: 'all', competition: 'all', search: '' };
  markup = Views.rosters();
  assert.equal(countCards(markup), 1);
  assert.ok(markup.includes('Sentinels'));

  const comp = directory.competitions.find((item) => item.teams && item.teams.length > 0);
  assert.ok(comp);
  UI.filters.rosters = { org: 'all', region: 'all', league: 'all', competition: comp.id, search: '' };
  markup = Views.rosters();
  assert.equal(countCards(markup), directory.teams.filter((team) => team.competitions.some((item) => item.id === comp.id)).length);

  const targetPlayer = directory.teams[0].starters[0];
  UI.filters.rosters = { org: 'all', region: 'all', league: 'all', competition: 'all', search: targetPlayer.nick };
  markup = Views.rosters();
  assert.ok(countCards(markup) >= 1);
  assert.ok(markup.includes(targetPlayer.nick));
});

test('Player portraits load only verified local images and use a clean generated fallback', () => {
  const sb = loadGameSandbox();
  const { Core, Game } = sb;
  const photos = sb.PLAYER_PHOTOS;
  const photoPaths = [...new Set([
    ...Object.values(photos.byNick || {}),
    ...Object.values(photos.byPlayer || {})
  ])];
  assert.ok(photoPaths.length >= 80, 'Expected broad local portrait coverage');
  for (const relativePath of photoPaths) {
    const file = path.join(process.cwd(), relativePath);
    assert.ok(fs.existsSync(file), `Portrait mapping points to a missing file: ${relativePath}`);
    const image = fs.readFileSync(file);
    assert.ok(image.readUInt32BE(16) >= 128 && image.readUInt32BE(20) >= 128, `Portrait is too small: ${relativePath}`);
  }

  const state = Game.newCareer({
    managerName: 'Portrait Audit', mode: 'existing', clubId: 'sentinels',
    difficulty: 'Normal', seed: 271828, noSave: true
  });
  const mappedPlayers = Object.values(state.players).filter((player) => player.photo && player.photo.indexOf('assets/players/') === 0);
  assert.ok(mappedPlayers.length >= 50, 'New careers should receive available real player portraits immediately');

  const fallback = Core.portrait({ id: 'unmapped-player', photo: null }, { colors: ['#ff4655'] });
  assert.ok(fallback.indexOf('data:image/svg+xml') === 0);
  const stale = { id: 'portrait-audit-stale', nick: 'not-in-photo-index', name: 'Unmapped', cc: 'us', org: null, sim: false, photo: 'assets/players/not-included.png' };
  state.players[stale.id] = stale;
  Game.migrate(state);
  assert.equal(stale.photo, null, 'Missing legacy portrait paths should migrate to the procedural fallback');
});

test('Global venues rotate after the preserved first season and major champions skip Kickoff qualifiers', () => {
  const sb = loadGameSandbox();
  const { Competition, Game } = sb;
  const first = Competition.plan(2027);
  assert.equal(first.find((event) => event.key === 'masters1').city, 'Seoul');
  assert.equal(first.find((event) => event.key === 'masters2').city, 'TBD');
  assert.equal(first.find((event) => event.key === 'champions').city, 'Seoul');

  const venuesByYear = (year) => {
    const plan = Competition.plan(year);
    return Object.fromEntries(['masters1', 'masters2', 'champions'].map((key) => [key, plan.find((event) => event.key === key).city]));
  };
  for (const year of [2028, 2029, 2030]) {
    const current = venuesByYear(year), prior = venuesByYear(year - 1);
    assert.equal(new Set(Object.values(current)).size, 3, `${year} global events should use separate cities`);
    for (const key of ['masters1', 'masters2', 'champions']) {
      assert.notEqual(current[key], prior[key], `${key} must move to a new city in ${year}`);
    }
  }

  const state = Game.newCareer({
    managerName: 'Direct Entry Audit', mode: 'new', region: 'Americas', sub: 'North America',
    orgName: 'Direct Entry', orgShort: 'DRE', difficulty: 'Normal', seed: 4112027, noSave: true
  });
  assert.equal(state.orgs[state.clubId].partner, false);
  state.championsTitleHolder = true;
  sb.Competition.initSeason(state);
  assert.deepEqual(Array.from(state.qualifiers.kickoff.Americas), [state.clubId]);
  assert.deepEqual(Array.from(state.qualifiers.cup1.Americas), [state.clubId]);
  assert.deepEqual(Array.from(state.qualifiers.cup2.Americas), [state.clubId]);
  const kickoffOQs = Object.values(state.comps).filter((comp) => comp.type === 'oq' && comp.cycle === 'kickoff');
  assert.ok(kickoffOQs.length > 0);
  assert.ok(kickoffOQs.every((comp) => !comp.teams.includes(state.clubId)), 'Title holder should be removed from Kickoff OQs');
  sb.Competition.ensureSchedule(state, '2027-01-12');
  const kickoff = Object.values(state.comps).find((comp) => comp.type === 'kickoff' && comp.region === 'Americas');
  assert.ok(kickoff && kickoff.teams.includes(state.clubId), 'Title holder should enter Kickoff directly');
  const cupQualifiers = sb.Competition.createOQ(state, state.seasonPlan.find((event) => event.key === 'oq2'));
  assert.ok(cupQualifiers.length > 0);
  assert.ok(cupQualifiers.every((comp) => !comp.teams.includes(state.clubId)), 'Title holder should skip Cup Open Qualifiers too');
  sb.Competition.ensureSchedule(state, '2027-04-02');
  const cup = Object.values(state.comps).find((comp) => comp.type === 'cup' && comp.region === 'Americas' && comp.key === 'cup1_Americas');
  assert.ok(cup && cup.teams.includes(state.clubId), 'Title holder should enter the regional Cup directly');
});

test('Audio dock and trophy celebrations render local controls, artwork, and all-language copy', () => {
  const sb = loadGameSandbox();
  const { Game, I18N, UI } = sb;
  Game.newCareer({ managerName: 'Audio Audit', mode: 'existing', clubId: 'sentinels', difficulty: 'Normal', noSave: true });
  const dock = { innerHTML: '', querySelectorAll: () => [] };
  const modal = { innerHTML: '', classList: { add() {}, remove() {} } };
  sb.document.getElementById = (id) => id === 'audio-dock' ? dock : id === 'modal-root' ? modal : null;
  sb.VgmAudio = sb.window.VgmAudio = { getSettings: () => ({
    musicEnabled: true, sfxEnabled: true, musicVolume: 0.3, sfxVolume: 0.45,
    currentTrackName: 'If The Sun Burns Out Tonight (Official Instrumental)'
  }) };

  const copyKeys = ['Audio controls', 'Music', 'Pause music', 'Resume music', 'Music volume', 'Sound effects', 'Effects volume',
    'Trophy unlocked', 'WORLD CHAMPION', 'GLOBAL TITLE', 'VCT TITLE', 'CHAMPIONSHIP SECURED', 'Next trophy',
    'Direct VCT event entry', 'Your major-trophy title grants direct entry to Kickoff and both Cups this season; Open Qualifiers are skipped.',
    'As reigning Champions, your club bypasses Open Qualifiers for Kickoff and both Cups. Masters and Champions places are still earned by competition results.',
    'City', 'Available any time in Settings', 'A negative budget and a broken roster add pressure even when results are good.',
    'News records what changed in the world and why it matters to you. Transfer stories show the direction of the market; competition results update reputation and ranking points; board notes warn you before a review.',
    'Advance time. The next Open Qualifier or competition window will appear automatically.', 'Cup 1 Open Qualifiers', 'Cup 2 Open Qualifiers',
    'No fixture scheduled. Advance time to continue the calendar.', 'No matches yet. The first fixture will appear in the top bar.',
    'Several credible players are without a team after the partnership cuts. Recruitment is available from day one; wages are annual and the budget is cash on hand.',
    'Open tactical & management guide for this section.', 'Upload a custom PNG, JPG or WEBP club logo. Persists in your career save.',
    'No local saves. Use Save now or export a JSON backup.', 'Starting five valid and every role covered.',
    'Win a Masters playoff series.', 'Secure a Champions 2027 spot.',
    'Slow, information-first, retake-heavy. Concedes early map control.',
    'Active 7-map competitive rotation is locked for this season and rotates only between seasons.',
    'Transfer-listed players in your club attract weekly AI bids based on market value and asking price.',
    'Open Qualifiers feed Kickoff and both Cups. Non-partners have no other route in.',
    'Sponsors + commercial revenue', 'Projected monthly cashflow', 'Remaining payroll budget',
    'Training runs automatically every week', 'The board is behind the project',
    'Reach the Masters playoffs', 'Coordination and communication training raise the floor of every map. A rebuilt roster needs repeated weeks together.'];
  for (const language of ['fr', 'es', 'pt', 'ko', 'ja', 'zh']) {
    I18N.set(language);
    for (const key of copyKeys) assert.notEqual(I18N.text(key), key, `${language} untranslated copy: ${key}`);
    assert.notEqual(I18N.text('North America Open Qualifier · 2027'), 'North America Open Qualifier · 2027', `${language} qualifier name is untranslated`);
    assert.notEqual(I18N.text('Showing 5 of 20 organizations'), 'Showing 5 of 20 organizations', `${language} organization count is untranslated`);
    assert.notEqual(I18N.text('Career date: 4 Jan 2027 · Rosters reflect this save'), 'Career date: 4 Jan 2027 · Rosters reflect this save', `${language} roster date is untranslated`);
    assert.notEqual(I18N.text('Average wage $268K'), 'Average wage $268K', `${language} average wage is untranslated`);
    assert.notEqual(I18N.text('• Qualify for a Masters event — bonus $85K'), '• Qualify for a Masters event — bonus $85K', `${language} objective reward is untranslated`);
    assert.notEqual(I18N.text('• Win a VCT tournament — bonus $94K'), '• Win a VCT tournament — bonus $94K', `${language} tournament reward is untranslated`);
    assert.notEqual(I18N.text('Open Circuit Americas'), 'Open Circuit Americas', `${language} circuit label is untranslated`);
    assert.notEqual(I18N.text('market · 23 Nov 2026'), 'market · 23 Nov 2026', `${language} news category is untranslated`);
    assert.notEqual(I18N.text('$1.33M total · $111K per quarter · expires 22 Jan 2027'), '$1.33M total · $111K per quarter · expires 22 Jan 2027', `${language} contract summary is untranslated`);
    assert.notEqual(I18N.text('0 objectives achieved · 4 active · 0 failed. Confidence is 70/100; critical failures cost far more than minor misses.'), '0 objectives achieved · 4 active · 0 failed. Confidence is 70/100; critical failures cost far more than minor misses.', `${language} objectives summary is untranslated`);
    assert.notEqual(I18N.text('24 Nov 2026 → 20 Dec 2026 · 4 teams · Americas'), '24 Nov 2026 → 20 Dec 2026 · 4 teams · Americas', `${language} event schedule is untranslated`);
    assert.notEqual(I18N.text('24 Nov 2026 · 4 teams · bracket'), '24 Nov 2026 · 4 teams · bracket', `${language} bracket summary is untranslated`);
    assert.notEqual(I18N.text('OVR 84 · POT 99 · $261K/yr'), 'OVR 84 · POT 99 · $261K/yr', `${language} player rating summary is untranslated`);
    assert.notEqual(I18N.text('Chet · United States'), 'Chet · United States', `${language} staff country label is untranslated`);
  }
  I18N.set('es');
  const intro = 'You take charge on 23 Nov 2026. As a 2027 VCT partner you enter Kickoff automatically. Use the next weeks to build chemistry, shape tactics and prepare the map pool. Open the Objectives page to see what the board expects.';
  const translatedIntro = I18N.text(intro);
  assert.ok(sb.Views.news().includes(translatedIntro.slice(0, 40)), 'Featured news excerpts should translate before shortening');
  I18N.set('fr');
  UI.renderAudioDock();
  assert.ok(dock.innerHTML.includes('data-change="audioVolume"'));
  assert.ok(dock.innerHTML.includes('Commandes audio'));
  assert.ok(dock.innerHTML.includes('Mettre la musique en pause'));

  UI.enqueueTrophies([
    { name: 'Champions Austin 2028', season: 2028, type: 'champions', city: 'Austin' },
    { name: 'VCT Cup 1 2028', season: 2028, type: 'cup', city: 'London' }
  ]);
  assert.ok(modal.innerHTML.includes('assets/trophies/champions.svg'));
  assert.ok(modal.innerHTML.includes('trophy-celebration'));
  UI.act('nextTrophyCelebration', null);
  assert.ok(modal.innerHTML.includes('assets/trophies/regional.svg'));
  assert.ok(fs.existsSync(path.join(process.cwd(), 'assets/trophies/champions.svg')));
  assert.ok(fs.existsSync(path.join(process.cwd(), 'assets/trophies/masters.svg')));
  assert.ok(fs.existsSync(path.join(process.cwd(), 'assets/trophies/regional.svg')));
});
