/* =====================================================================
   VALORANT MANAGER 2027 — GAME / CAREER LAYER
   Career creation, roster materialisation, calendar advancement,
   AI world, transfers, season rollover, saves and self-tests.
   ===================================================================== */
var Game = (function () {
  'use strict';
  var C = Core;

  var G = {
    state: null,
    lastSaveAt: 0
  };

  var DEFAULT_POOL = C.ACTIVE_MAP_POOL_2027.slice();

  /* ------------------------------------------------------------------
     SMALL HELPERS
  ------------------------------------------------------------------ */
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function slug(s) {
    return String(s || 'org').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 34) || 'org';
  }
  function pickRegionSub(region) {
    var r = C.REGIONS.filter(function (x) { return x.id === region; })[0] || C.REGIONS[0];
    return r.subs[0];
  }
  function natForSub(sub) {
    var map = {
      'North America': 'us', 'Latin America North': 'mx', 'Latin America South': 'ar', 'Brazil': 'br',
      'Europe': 'gb', 'Türkiye': 'tr', 'MENA': 'ma', 'South Korea': 'kr', 'Japan': 'jp',
      'Thailand': 'th', 'Indonesia': 'id', 'Vietnam': 'vn', 'Southeast Asia': 'sg', 'South Asia': 'in',
      'Oceania': 'au', 'China': 'cn'
    };
    return map[sub] || 'us';
  }
  function natForRegion(region, rng) {
    var pools = {
      Americas: ['us', 'us', 'ca', 'br', 'br', 'ar', 'mx', 'cl'],
      EMEA: ['gb', 'fr', 'de', 'es', 'tr', 'ru', 'se', 'pl', 'ua', 'ma'],
      Pacific: ['kr', 'kr', 'jp', 'th', 'id', 'vn', 'sg', 'ph', 'in', 'au'],
      China: ['cn', 'cn', 'cn', 'cn', 'tw', 'hk']
    };
    return rng.pick(pools[region] || ['us']);
  }
  function diff(a, b) { return C.diffDays(a, b); }

  function addNews(state, type, title, body, opts) {
    opts = opts || {};
    state.news.unshift({
      id: 'n_' + Date.now().toString(36) + Math.floor(Math.random() * 9999),
      date: state.date, type: type, title: title, body: body,
      orgId: opts.orgId || null, importance: opts.importance || 2,
      read: !!opts.read, compId: opts.compId || null
    });
    if (state.news.length > 260) state.news.length = 260;
    return state.news[0];
  }

  function addPlayer(state, p) {
    var base = p.id, n = 2;
    while (state.players[p.id]) { p.id = base + '_' + n; n++; }
    state.players[p.id] = p;
    return p;
  }

  function emptyOrg(org) {
    var o = clone(org);
    o.roster = []; o.lineup = []; o.staff = [];
    o.facilities = o.facilities || { training: 2, recovery: 2, analysis: 2, academy: 2 };
    o.mapPrep = o.mapPrep || {};
    o.mapStats = o.mapStats || {};
    o.chemistry = o.chemistry != null ? o.chemistry : 62;
    o.form = [];
    o.playstyle = o.playstyle || 'Balanced';
    o.points = o.points != null ? o.points : Math.round((o.rep || 50) * 12);
    o.isUser = false;
    o.seasonWins = 0; o.seasonLosses = 0;
    return o;
  }

  function genStaffFromSpec(spec, state) {
    var rng = C.RNG('staff|' + spec.nick + '|' + spec.org);
    var base = Engine.genStaff(rng, { role: spec.role, cc: spec.cc, org: spec.org, grade: spec.grade });
    base.nick = spec.nick;
    base.name = spec.name;
    base.cc = spec.cc;
    base.grade = spec.grade;
    base.conf = spec.conf || 'SIM';
    base.note = spec.note || '';
    base.sim = spec.conf ? false : true;
    base.salary = Math.round(45000 + spec.grade * spec.grade * 2600);
    return base;
  }

  function userLineup(state, org) {
    var roster = (org.roster || []).map(function (id) { return state.players[id]; }).filter(Boolean);
    if (!roster.length) return [];
    var chosen = [], used = {};
    C.ROLES.forEach(function (role) {
      var best = roster.filter(function (p) { return p.role === role && !used[p.id]; })
        .sort(function (a, b) { return b.level - a.level; })[0];
      if (best) { chosen.push(best.id); used[best.id] = 1; }
    });
    roster.filter(function (p) { return !used[p.id]; }).sort(function (a, b) { return b.level - a.level; })
      .forEach(function (p) { if (chosen.length < 5) { chosen.push(p.id); used[p.id] = 1; } });
    return chosen.slice(0, 5);
  }

  function assignFiller(state, org, role, rng, academy) {
    var tier = C.clamp(4.0 + (org.rep || 60) / 32, 3.2, 8.1) + rng.float(-0.7, 0.5);
    if (academy) tier -= 1.1;
    var p = Engine.genPlayer(rng, {
      cc: natForRegion(org.region, rng), role: role, age: academy ? rng.int(16, 19) : rng.int(18, 24),
      tier: tier, org: org.id, season: state.season, sim: true, academy: !!academy
    });
    p.conf = 'SIM';
    p.note = 'Fictional filler generated to complete the ' + org.name + ' roster. Replace or develop.';
    p.src = 'Generated';
    p.wage = Math.round(p.wage * (org.tier === 'partner' ? 1.05 : 0.9));
    p.value = Engine.valueFor(p);
    addPlayer(state, p);
    if (academy) {
      p.academy = true;
      p.status = 'academy';
      state.academy[org.id] = state.academy[org.id] || [];
      state.academy[org.id].push(p.id);
    } else {
      org.roster.push(p.id);
      org.lineup = userLineup(state, org);
    }
    return p;
  }

  function ensureRoleCoverage(state, org, rng) {
    var counts = {};
    C.ROLES.forEach(function (r) { counts[r] = 0; });
    (org.roster || []).forEach(function (id) { var p = state.players[id]; if (p) counts[p.role] = (counts[p.role] || 0) + 1; });
    C.ROLES.forEach(function (role) {
      if (!counts[role]) assignFiller(state, org, role, rng, false);
    });
    org.lineup = userLineup(state, org);
  }

  /* ------------------------------------------------------------------
     CAREER CREATION
  ------------------------------------------------------------------ */
  G.newCareer = function (opts) {
    opts = opts || {};
    var rng = C.RNG('career|' + (opts.seed || Date.now()) + '|' + (opts.managerName || 'manager'));
    var difficulty = C.DIFFICULTY[opts.difficulty] ? opts.difficulty : 'Normal';
    var diff = C.DIFFICULTY[difficulty];
    var season = 2027;
    var start = Competition.seasonStart(season);
    var id = C.uid('save', rng);

    var state = {
      id: id, name: opts.saveName || ((opts.managerName || 'Manager') + ' · ' + season),
      version: C.VERSION, season: season, seasonStart: start, date: start,
      difficulty: difficulty, guided: opts.guided !== false, mode: opts.mode || 'existing',
      clubId: null,
      manager: {
        name: opts.managerName || 'Alex Mercer', nat: opts.managerNat || 'gb', age: opts.managerAge || 34,
        rep: 55, xp: 0, wins: 0, losses: 0, confidence: 65,
        trophies: [], boardNotes: []
      },
      orgs: {}, players: {}, staff: {}, academy: {},
      comps: {}, qualifiers: { kickoff: {}, cup1: {}, cup2: {}, masters1: {}, masters2: {}, champions: {}, lcq: {} },
      flags: {}, news: [], objectives: [], transferHistory: [],
      history: { seasons: [], competitions: [], champions: [], awards: [], retirees: [] },
      settings: {
        mapPool: C.normalizePool(opts.mapPool || DEFAULT_POOL), autoSave: true, notifications: true,
        tips: opts.guided !== false, reducedMotion: false
      },
      mapPrefs: { picks: [], bans: [] },
      trainingPlan: { primary: 'coordination', secondary: 'aim', intensity: 'normal' },
      trainingReports: [], trainingWeeks: 0,
      matchCounter: 1, lastReport: null, pendingMatch: null, pendingCompId: null,
      financeLedger: [], sponsorOffers: [], sponsorContracts: [], staffMarket: [], scoutReports: {},
      incomingOffers: [], lastSeasonSummary: null,
      userMatches: [], lastSaved: null, lastAutoSave: null,
      seed: opts.seed || Date.now()
    };
    state.flags = {
      oqStage: 0, kickoffPos: null, kickoffQualified: false, masters1Qualified: false,
      bestCupPos: null, mastersPlayoffWin: 0, masters2Qualified: false, championsQualified: false,
      prospectsSigned: 0, sameLineupStreak: 0, seasonEarnings: 0, budgetPositive: 0, sponsorValue: 0,
      pacificPlayoffDone: false, sponsorLegacyMigrated: false
    };

    /* ----- organisations ----- */
    DB.ORGS.forEach(function (o) { state.orgs[o.id] = emptyOrg(o); });

    var userOrg = null;
    if (opts.mode === 'new') {
      var region = opts.region || 'Americas';
      var sub = opts.sub || pickRegionSub(region);
      var baseId = slug(opts.orgName || 'New Organisation');
      var oid = baseId, k = 2;
      while (state.orgs[oid]) { oid = baseId + '-' + k; k++; }
      var budget = Math.round(280000 * diff.money);
      userOrg = emptyOrg({
        id: oid, name: opts.orgName || 'New Organisation', short: (opts.orgShort || 'NEW').toUpperCase().slice(0, 5),
        region: region, sub: sub, country: natForSub(sub), city: opts.city || 'Home City',
        colors: opts.colors || ['#ff4655', '#0b0d11'], logo: null, customLogo: opts.customLogo || null,
        partner: false, tier: 'challenger',
        rep: 58, budget: budget, sponsor: 120000, rosterStatus: 'SIM', source: 'New project',
        notes: 'New organisation entering the 2027 open circuit.', titles: []
      });
      state.orgs[oid] = userOrg;
    } else {
      userOrg = state.orgs[opts.clubId] || state.orgs['sentinels'] || state.orgs[Object.keys(state.orgs)[0]];
      if (opts.customLogo) userOrg.customLogo = opts.customLogo;
    }
    state.clubId = userOrg.id;
    userOrg.isUser = true;
    userOrg.budget = Math.round((userOrg.budget || 1000000) * diff.money);
    userOrg.sponsor = Math.round((userOrg.sponsor || 200000) * (userOrg.partner ? 1 : 0.8));
    userOrg.facilities = userOrg.facilities || { training: 2, recovery: 2, analysis: 2, academy: 2 };
    if (opts.mode !== 'new') {
      userOrg.facilities = {
        training: 2 + Math.round((userOrg.rep || 60) / 30),
        recovery: 2 + Math.round((userOrg.rep || 60) / 34),
        analysis: 2 + Math.round((userOrg.rep || 60) / 32),
        academy: 2 + Math.round((userOrg.rep || 60) / 36)
      };
    }
    C.ROLES.length; // keep roles referenced

    /* ----- materialise real players ----- */
    DB.PLAYERS.forEach(function (spec) {
      var org = spec.org ? state.orgs[spec.org] : null;
      var isInactive = org && org.status === 'inactive';
      var p = Engine.fromSpec(spec, season);
      if (!org || isInactive) { p.org = null; p.status = 'free agent'; }
      else { p.org = org.id; p.status = 'starter'; }
      p.conf = spec.conf || (spec.org ? 'UNKNOWN' : 'FREE AGENT');
      p.note = spec.note || '';
      p.captain = !!spec.captain;
      p.igl = !!spec.igl;
      p.src = org ? (org.source || null) : 'Free agent';
      addPlayer(state, p);
      if (p.org && state.orgs[p.org]) state.orgs[p.org].roster.push(p.id);
    });

    /* ----- real staff ----- */
    DB.STAFF.forEach(function (spec) {
      var org = spec.org ? state.orgs[spec.org] : null;
      if (!org || org.status === 'inactive') return;
      var s = genStaffFromSpec(spec, state);
      var base = s.id, n = 2;
      while (state.staff[s.id]) { s.id = base + '_' + n; n++; }
      state.staff[s.id] = s;
      org.staff.push(s.id);
    });

    /* ----- fill rosters, academies, coaches ----- */
    Object.keys(state.orgs).forEach(function (oid) {
      var org = state.orgs[oid];
      if (org.status === 'inactive') return;
      var rr = C.RNG('fill|' + oid + '|' + state.seed);
      while (org.roster.length < 5) assignFiller(state, org, C.ROLES[org.roster.length % 4], rr, false);
      ensureRoleCoverage(state, org, rr);

      state.academy[org.id] = state.academy[org.id] || [];
      var acadTarget = org.partner ? rr.int(2, 3) : rr.int(1, 2);
      if (org.isUser && opts.mode === 'new') acadTarget = 3;
      while (state.academy[org.id].length < acadTarget) assignFiller(state, org, rr.pick(C.ROLES), rr, true);

      if (!org.staff.length || !org.staff.some(function (id) { return state.staff[id] && /Coach/i.test(state.staff[id].role); })) {
        var coach = Engine.genStaff(rr, { role: 'Head Coach', cc: natForRegion(org.region, rr), org: org.id, grade: 4.8 + (org.rep || 60) / 26 });
        coach.salary = Math.round(40000 + coach.grade * coach.grade * 2200);
        var b = coach.id, m = 2;
        while (state.staff[coach.id]) { coach.id = b + '_' + m; m++; }
        state.staff[coach.id] = coach;
        org.staff.push(coach.id);
      }

      org.mapPrep = org.mapPrep || {};
      state.settings.mapPool.forEach(function (mp) {
        org.mapPrep[mp] = C.clamp(48 + (org.rep || 60) * 0.16 + rr.float(-6, 8), 30, 88);
      });
      org.chemistry = C.clamp((org.chemistry || 62) + rr.float(-7, 7), 35, 88);
      org.playstyle = rr.pick(['Balanced', 'Aggressive', 'Defensive', 'Fast-paced', 'Methodical', 'Map control', 'Adaptable']);
      org.points = Math.round((org.rep || 50) * 14 + rr.int(0, 120));
      org.lineup = userLineup(state, org);
    });

    /* ----- free agents / staff market ----- */
    var faRng = C.RNG('free|' + state.seed);
    for (var i = 0; i < 26; i++) {
      var fa = Engine.genPlayer(faRng, {
        cc: faRng.pick(Object.keys(C.COUNTRIES)), role: faRng.pick(C.ROLES), age: faRng.int(18, 29),
        tier: faRng.float(3.2, 7.1), season: season, sim: true, scouted: true
      });
      fa.org = null; fa.status = 'free agent'; fa.conf = 'SIM';
      fa.note = 'Fictional free agent generated by the market. Upgrade or replace via transfers.';
      fa.src = 'Free agent market';
      addPlayer(state, fa);
    }
    for (var s = 0; s < 10; s++) {
      var st = Engine.genStaff(C.RNG('sm|' + s + '|' + state.seed), {
        role: st_role(s), cc: faRng.pick(Object.keys(C.COUNTRIES)), grade: faRng.float(5.4, 8.4)
      });
      st.salary = Math.round(45000 + st.grade * st.grade * 2400);
      st.org = null;
      state.staff[st.id] = st;
      state.staffMarket.push(st.id);
    }
    function st_role(n) { return ['Head Coach', 'Assistant Coach', 'Analyst', 'Performance Coach', 'Scout'][n % 5]; }

    /* ----- user-specific setup ----- */
    state.manager.confidence = 62 + (userOrg.rep > 85 ? 8 : 0);
    state.manager.rep = C.clamp(Math.round(38 + userOrg.rep * 0.35), 35, 78);
    state.objectives = Engine.generateObjectives(state, userOrg);
    ensureLegacySponsorContract(state, userOrg);
    syncSponsorValue(state, userOrg);
    generateSponsors(state, true);
    state.financeLedger.unshift({ date: state.date, total: 0, lines: [], note: 'Career started' });

    Competition.initSeason(state);
    Competition.ensureSchedule(state, state.date);

    addNews(state, 'user', 'Welcome to ' + userOrg.name,
      'You take charge on ' + C.fmtDate(state.date) + '. ' + (userOrg.partner
        ? 'As a 2027 VCT partner you enter Kickoff automatically. Use the next weeks to build chemistry, shape tactics and prepare the map pool.'
        : 'As a non-partner organisation you must earn your place through the Open Qualifier. Your first matches begin almost immediately.') +
      ' Open the Objectives page to see what the board expects.', { orgId: userOrg.id, importance: 5 });
    addNews(state, 'world', 'VCT 2027 season structure confirmed',
      'Kickoff: 12 teams (8 partners + 4 Open Qualifiers; China adds two visitors). Top three per region reach Masters Seoul. Cups replace league play. The season ends at Champions. Sources: official VCT announcements; detailed brackets marked SIMULATED in Competition Rules.',
      { importance: 3 });
    var contested = (userOrg.roster || []).map(function (pid) { return state.players[pid]; }).filter(function (p) { return p && (p.conf === 'RUMORED' || p.conf === 'REPORTED' || p.conf === 'UNKNOWN'); });
    if (contested.length) {
      addNews(state, 'squad', 'Roster confidence check',
        contested.map(function (p) { return p.nick + ' (' + p.conf + ')'; }).join(', ') + ' are not fully confirmed in the 17 Nov 2026 snapshot. Treat them as unverified until an official announcement. In-game they are available, but the source label remains visible on their profile.',
        { orgId: userOrg.id, importance: 3 });
    }
    addNews(state, 'market', 'Free agent market open',
      'Several credible players are without a team after the partnership cuts. Recruitment is available from day one; wages are annual and the budget is cash on hand.', { importance: 2 });

    applyPlayerPhotos(state);
    G.state = state;
    if (!opts.noSave) G.save();
    return state;
  };

  /* ------------------------------------------------------------------
     SAVE / LOAD
  ------------------------------------------------------------------ */
  G.setActive = function (state) {
    migrate(state);
    G.state = state;
    return state;
  };
  G.saves = function () { return Core.Store.list(); };
  G.hasAnySave = function () { return Core.Store.hasAny(); };

  function applyPlayerPhotos(state) {
    var photos = (typeof window !== 'undefined' && window.PLAYER_PHOTOS) || (typeof PLAYER_PHOTOS !== 'undefined' ? PLAYER_PHOTOS : {});
    var fixes = (typeof window !== 'undefined' && window.PLAYER_NAME_FIXES_BY_NICK) || (typeof PLAYER_NAME_FIXES_BY_NICK !== 'undefined' ? PLAYER_NAME_FIXES_BY_NICK : {});
    var validPhotos = Object.create(null);
    ['byPlayer', 'byNick'].forEach(function (group) {
      Object.keys(photos[group] || {}).forEach(function (key) {
        var src = photos[group][key];
        if (typeof src === 'string' && src.indexOf('assets/players/') === 0) validPhotos[src] = true;
      });
    });
    Object.keys(state.players || {}).forEach(function (pid) {
      var p = state.players[pid];
      if (!p || p.sim) return;
      var nk = String(p.nick || '').toLowerCase();
      if (fixes[nk]) p.name = fixes[nk];
      if (typeof p.photo === 'string' && p.photo.indexOf('assets/players/') === 0 && !validPhotos[p.photo]) p.photo = null;
      var ok = String(p.org || '').toLowerCase();
      var mapped = (photos.byPlayer && photos.byPlayer[nk + '|' + ok]) || (photos.byNick && photos.byNick[nk]) || null;
      if (p.photo && p.photo.indexOf('brawk-2172.png') >= 0) p.photo = null;
      if (!p.photo && mapped && validPhotos[mapped]) p.photo = mapped;
    });
  }

  function migrate(state) {
    state.settings = state.settings || {};
    state.settings.mapPool = C.normalizePool(state.settings.mapPool);
    if (state.settings.autoSave == null) state.settings.autoSave = true;
    if (state.settings.notifications == null) state.settings.notifications = true;
    if (state.settings.tips == null) state.settings.tips = true;
    state.flags = state.flags || {};
    ['oqStage', 'prospectsSigned', 'sameLineupStreak', 'seasonEarnings', 'mastersPlayoffWin'].forEach(function (k) { if (state.flags[k] == null) state.flags[k] = 0; });
    state.history = state.history || { seasons: [], competitions: [], champions: [], awards: [], retirees: [] };
    ['seasons', 'competitions', 'champions', 'awards', 'retirees'].forEach(function (k) { if (!state.history[k]) state.history[k] = []; });
    state.news = state.news || [];
    state.objectives = state.objectives || [];
    state.transferHistory = state.transferHistory || [];
    state.financeLedger = state.financeLedger || [];
    state.sponsorContracts = state.sponsorContracts || [];
    state.sponsorContracts.forEach(function (c) {
      c.objectives = c.objectives || [];
      c.freq = SPONSOR_FREQ[c.freq] ? c.freq : 'monthly';
      c.periods = c.periods || Math.max(1, (c.years || 1) * sponsorFreq(c.freq).ppy);
      c.total = c.total || (c.annual || 0) * (c.years || 1);
      c.periodAmount = c.periodAmount || Math.round((c.annual || 0) / sponsorFreq(c.freq).ppy);
      c.paid = c.paid || 0;
      c.payments = c.payments || 0;
      c.status = c.status || 'active';
      c.nextPayment = c.nextPayment || sponsorNextDate(state.date, c.freq);
      c.end = c.end || sponsorEndDate(c.start || state.date, c.freq, c.periods);
    });
    state.sponsorOffers = state.sponsorOffers || [];
    state.incomingOffers = state.incomingOffers || [];
    state.staffMarket = state.staffMarket || [];
    state.trainingReports = state.trainingReports || [];
    state.userMatches = state.userMatches || [];
    state.academy = state.academy || {};
    state.trainingPlan = state.trainingPlan || { primary: 'coordination', secondary: 'aim', intensity: 'normal' };
    state.mapPrefs = state.mapPrefs || { picks: [], bans: [] };
    state.mapPrefs.picks = (state.mapPrefs.picks || []).filter(function (m) { return state.settings.mapPool.indexOf(m) >= 0; }).slice(0, 3);
    state.mapPrefs.bans = (state.mapPrefs.bans || []).filter(function (m) { return state.settings.mapPool.indexOf(m) >= 0; }).slice(0, 3);
    state.matchCounter = state.matchCounter || 1;
    state.manager = state.manager || { name: 'Manager', nat: 'gb', age: 34, rep: 55, xp: 0, wins: 0, losses: 0, confidence: 65, trophies: [], boardNotes: [] };
    state.manager.trophies = state.manager.trophies || [];
    state.manager.boardNotes = state.manager.boardNotes || [];
    if (!state.seasonStart) state.seasonStart = Competition.seasonStart(state.season);
    Object.keys(state.orgs || {}).forEach(function (oid) {
      var o = state.orgs[oid];
      if (!o) return;
      o.mapStats = o.mapStats || {};
      o.mapPrep = o.mapPrep || {};
      state.settings.mapPool.forEach(function (mp) { if (o.mapPrep[mp] == null) o.mapPrep[mp] = 52; });
    });
    var migOrg = state.orgs && state.orgs[state.clubId];
    if (migOrg) {
      ensureLegacySponsorContract(state, migOrg);
      syncSponsorValue(state, migOrg);
    }
    applyPlayerPhotos(state);
    return state;
  }

  function compactSeries(series) {
    if (!series || !series.maps) return;
    series.maps.forEach(function (m) {
      if (!m) return;
      if (m.ratings) delete m.ratings;
      if (m.stats) {
        for (var id in m.stats) { if (m.stats[id]) delete m.stats[id].p; }
      }
    });
  }
  function round1(n) {
    return typeof n === 'number' && isFinite(n) ? Math.round(n * 10) / 10 : n;
  }
  function compactPlayerNumbers(p) {
    if (!p) return;
    ['form', 'morale', 'fatigue'].forEach(function (k) { if (typeof p[k] === 'number') p[k] = round1(p[k]); });
    if (p.attrs) { for (var a in p.attrs) p.attrs[a] = round1(p.attrs[a]); }
    if (p.roleAttrs) { for (var r in p.roleAttrs) p.roleAttrs[r] = round1(p.roleAttrs[r]); }
  }
  function compactState(state) {
    if (!state) return state;
    compactSeries(state.lastReport);
    // Simulation caches full player objects on each org; they are rebuilt on
    // demand and must never be persisted (they duplicate the player database).
    var orgs = state.orgs || {};
    Object.keys(orgs).forEach(function (oid) { if (orgs[oid]) delete orgs[oid]._cachePlayers; });
    var players = state.players || {};
    Object.keys(players).forEach(function (pid) { compactPlayerNumbers(players[pid]); });
    var comps = state.comps || {};
    Object.keys(comps).forEach(function (cid) {
      var c = comps[cid];
      if (!c) return;
      ['swiss', 'playoffs', 'bracket'].forEach(function (key) {
        var block = c[key];
        if (!block || !block.rounds) return;
        block.rounds.forEach(function (r) {
          (r.matches || []).forEach(function (m) { compactSeries(m.result); });
        });
      });
      (c.matches || []).forEach(function (m) { compactSeries(m.result); });
    });
    return state;
  }

  G.save = function (silent) {
    var state = G.state;
    if (!state) return false;
    if (state.__headless) return true;
    compactState(state);
    state.lastSaved = Date.now();
    var ok = Core.Store.save(state);
    G.lastSaveAt = Date.now();
    if (!ok && !silent) {
      // no UI dependency here; caller can show a toast
      return false;
    }
    return ok;
  };
  G.load = function (id) {
    var state = Core.Store.load(id);
    if (!state) return null;
    G.state = compactState(migrate(state));
    return G.state;
  };
  G.loadAutosave = function () {
    var state = Core.Store.autosave();
    if (!state) return null;
    G.state = compactState(migrate(state));
    return G.state;
  };
  G.remove = function (id) { Core.Store.remove(id); };
  G.exportSave = function () {
    if (!G.state) return;
    Core.download('vgm27-' + slug(G.state.name) + '.json', JSON.stringify(G.state, null, 2));
  };
  G.importSave = function (text) {
    var state = JSON.parse(text);
    if (!state || !state.clubId || !state.orgs || !state.players) throw new Error('Not a valid VALORANT MANAGER save file.');
    if (!state.id) state.id = C.uid('save');
    if (Core.Store.load(state.id)) state.id = state.id + '_' + Date.now().toString(36);
    state.id = state.id;
    state.name = state.name || 'Imported career';
    G.state = compactState(migrate(state));
    Core.Store.save(G.state);
    return G.state;
  };

  /* ------------------------------------------------------------------
     CURRENT CLUB ACCESSORS
  ------------------------------------------------------------------ */
  G.org = function () { return G.state ? G.state.orgs[G.state.clubId] : null; };
  G.player = function (id) { return G.state && G.state.players[id]; };
  G.lineup = function (org) {
    org = org || G.org();
    if (!org) return [];
    return (org.lineup || []).map(function (id) { return G.state.players[id]; }).filter(Boolean);
  };
  G.roster = function (org) {
    org = org || G.org();
    if (!org) return [];
    return (org.roster || []).map(function (id) { return G.state.players[id]; }).filter(function (p) { return p && !p.retired; });
  };
  G.liveRosters = function () {
    var state = G.state;
    if (!state) return { date: null, season: null, teams: [], competitions: [], updates: [] };
    var players = state.players || {};
    var comps = Object.keys(state.comps || {}).map(function (id) { return state.comps[id]; })
      .filter(function (comp) { return comp && Array.isArray(comp.teams) && comp.teams.length; })
      .sort(function (a, b) {
        var ad = a.startDate || a.endDate || '';
        var bd = b.startDate || b.endDate || '';
        return ad < bd ? -1 : ad > bd ? 1 : String(a.name || '').localeCompare(String(b.name || ''));
      });
    var rosterByOrg = Object.create(null);
    Object.keys(players).forEach(function (pid) {
      var player = players[pid];
      if (!player || !player.org || player.retired || player.academy || player.status === 'academy') return;
      if (!rosterByOrg[player.org]) rosterByOrg[player.org] = [];
      rosterByOrg[player.org].push(player);
    });
    var teams = Object.keys(state.orgs || {}).map(function (id) {
      var org = state.orgs[id];
      if (!org || org.status === 'inactive') return null;
      var roster = rosterByOrg[id] || [];
      var byId = {};
      roster.forEach(function (p) { byId[p.id] = p; });
      var starters = (org.lineup || []).map(function (pid) { return byId[pid]; }).filter(Boolean).slice(0, 5);
      var starterIds = {};
      starters.forEach(function (p) { starterIds[p.id] = true; });
      roster.slice().sort(function (a, b) { return (b.level || 0) - (a.level || 0); }).some(function (p) {
        if (starters.length >= 5) return true;
        if (!starterIds[p.id]) { starters.push(p); starterIds[p.id] = true; }
        return false;
      });
      var reserves = roster.filter(function (p) { return !starterIds[p.id]; })
        .sort(function (a, b) { return (b.level || 0) - (a.level || 0); });
      var staffIds = org.staff || [];
      var staff = staffIds.map(function (staffId) { return (state.staff || {})[staffId]; }).filter(Boolean);
      if (!staff.length) {
        staff = Object.keys(state.staff || {}).map(function (staffId) { return state.staff[staffId]; })
          .filter(function (member) { return member && member.org === id; });
      }
      var league = (org.partner ? 'VCT ' : 'Open Circuit ') + (org.region || 'Unassigned');
      var competitions = comps.filter(function (comp) { return comp.teams.indexOf(id) >= 0; });
      return {
        id: id, org: org, league: league, roster: roster, starters: starters, reserves: reserves,
        staff: staff, competitions: competitions
      };
    }).filter(Boolean).sort(function (a, b) {
      return String(a.org.region || '').localeCompare(String(b.org.region || '')) ||
        String(a.org.name || '').localeCompare(String(b.org.name || ''));
    });
    var updates = [];
    (state.transferHistory || []).forEach(function (move, index) {
      updates.push({
        id: 'transfer-' + index, date: move.date, type: 'transfer',
        title: (move.nick || (players[move.playerId] && players[move.playerId].nick) || 'Player') + ' · ' + (move.fromName || 'Free agent') + ' → ' + (move.toName || (state.orgs[move.to] && state.orgs[move.to].short) || 'Team'),
        body: move.fee ? C.money(move.fee) : 'Free transfer', from: move.from, to: move.to
      });
    });
    (state.news || []).forEach(function (item) {
      if (!item || ['academy', 'squad', 'market'].indexOf(item.type) < 0) return;
      updates.push({ id: item.id, date: item.date, type: item.type, title: item.title, body: item.body, orgId: item.orgId });
    });
    updates.sort(function (a, b) { return String(b.date || '').localeCompare(String(a.date || '')); });
    return { date: state.date, season: state.season, teams: teams, competitions: comps, updates: updates.slice(0, 16) };
  };
  G.academyList = function (org) {
    org = org || G.org();
    if (!org) return [];
    return (G.state.academy[org.id] || []).map(function (id) { return G.state.players[id]; }).filter(Boolean);
  };
  G.freeAgents = function () {
    return Object.keys(G.state.players).map(function (id) { return G.state.players[id]; })
      .filter(function (p) { return p && !p.org && !p.retired && !p.academy; });
  };
  G.staffFree = function () {
    return (G.state.staffMarket || []).map(function (id) { return G.state.staff[id]; }).filter(Boolean);
  };
  G.coach = function (org) {
    org = org || G.org();
    var list = (org.staff || []).map(function (id) { return G.state.staff[id]; }).filter(Boolean);
    return list.sort(function (a, b) { return b.grade - a.grade; })[0] || null;
  };
  G.payroll = function (org) {
    org = org || G.org();
    return (org.roster || []).reduce(function (sum, id) { var p = G.state.players[id]; return sum + (p && !p.retired ? p.wage : 0); }, 0);
  };
  G.teamRating = function (org) { return Engine.teamRating(G.state, org || G.org(), {}); };
  G.balance = function () { return Engine.roleBalance(G.roster()); };

  /* ------------------------------------------------------------------
     ACTIONS
  ------------------------------------------------------------------ */
  G.setPlaystyle = function (style) {
    var org = G.org();
    if (!org || !C.STYLE_INFO[style]) return false;
    org.playstyle = style;
    G.save(true);
    return true;
  };

  G.setLineup = function (ids) {
    var org = G.org();
    if (!org) return { ok: false, reason: 'No club.' };
    ids = (ids || []).filter(function (id) { var p = G.state.players[id]; return p && p.org === org.id && !p.retired; });
    var unique = [];
    ids.forEach(function (id) { if (unique.indexOf(id) < 0) unique.push(id); });
    if (unique.length !== 5) return { ok: false, reason: 'A starting lineup must contain exactly five players.' };
    org.lineup = unique;
    G.save(true);
    return { ok: true };
  };
  G.autoLineup = function () {
    var org = G.org();
    org.lineup = userLineup(G.state, org);
    G.save(true);
    return org.lineup;
  };
  G.swapLineup = function (outId, inId) {
    var org = G.org();
    var idx = (org.lineup || []).indexOf(outId);
    if (idx < 0) return { ok: false, reason: 'Player is not in the starting five.' };
    if (org.lineup.indexOf(inId) >= 0) return { ok: false, reason: 'Player is already starting.' };
    var p = G.state.players[inId];
    if (!p || p.org !== org.id) return { ok: false, reason: 'Player is not in your squad.' };
    org.lineup[idx] = inId;
    G.save(true);
    return { ok: true };
  };
  G.setCaptain = function (id) {
    var org = G.org();
    G.roster(org).forEach(function (p) { p.captain = (p.id === id); });
    G.save(true);
  };
  G.setAgent = function (playerId, agent) {
    var p = G.state.players[playerId];
    if (!p || !C.AGENTS[agent] || C.AGENTS[agent] !== p.role) return { ok: false, reason: 'That agent does not fit the player role.' };
    p.agents = [agent].concat((p.agents || []).filter(function (a) { return a !== agent; })).slice(0, 3);
    p.agentFamiliarity[agent] = Math.max(p.agentFamiliarity[agent] || 30, 45);
    G.save(true);
    return { ok: true };
  };
  G.setTrainingPlan = function (plan) {
    var s = G.state;
    s.trainingPlan = {
      primary: plan.primary || s.trainingPlan.primary,
      secondary: plan.secondary === undefined ? s.trainingPlan.secondary : plan.secondary,
      intensity: plan.intensity || s.trainingPlan.intensity
    };
    G.save(true);
  };
  G.runTrainingWeek = function () {
    var report = Engine.runTraining(G.state, G.state.trainingPlan);
    G.state.trainingReports.unshift(report);
    if (G.state.trainingReports.length > 24) G.state.trainingReports.length = 24;
    var top = report.team.best[0];
    addNews(G.state, 'training', 'Training week completed',
      (top ? top.nick + ' improved the most (+' + top.delta + '). ' : '') +
      'Chemistry ' + report.team.chemistryBefore + '→' + report.team.chemistryAfter + ' · average fatigue ' + report.team.avgFatigue + '%. ' +
      report.notes[0], { orgId: G.state.clubId, importance: 2 });
    G.save(true);
    return report;
  };

  G.demand = function (playerId) {
    var p = G.state.players[playerId];
    if (!p) return null;
    return {
      wage: Engine.wageDemand(p, G.org()),
      fee: p.org ? Engine.askingPrice(p) : 0,
      value: Engine.valueFor(p)
    };
  };
  G.makeOffer = function (playerId, offer) {
    var s = G.state, p = s.players[playerId], org = G.org();
    if (!p || !org) return { ok: false, reason: 'Invalid player.' };
    if (p.org === org.id) return { ok: false, reason: 'Player is already in your squad.' };
    offer = offer || {};
    var fee = Math.max(0, Math.round(offer.fee || 0));
    var wage = Math.max(0, Math.round(offer.wage || 0));
    var years = C.clamp(Math.round(offer.years || 2), 1, 4);
    var signingBonus = Math.round(wage * 0.1);
    if (fee + signingBonus > org.budget) {
      return { ok: false, reason: 'The transfer fee plus the signing bonus (' + C.money(fee + signingBonus) + ') exceeds your available budget (' + C.money(org.budget) + ').' };
    }
    if (wage > Engine.wageDemand(p, org) * 2.4) {
      return { ok: false, reason: 'The wage is far above the player expectation and would break the structure. Reduce it and try again.' };
    }
    var verdict = Engine.acceptOffer(s, p, org, { fee: fee, wage: wage, playingTime: offer.playingTime || 'starter' });
    if (!verdict.accepted) {
      return {
        ok: false, reason: verdict.reasons.join(' '), verdict: verdict,
        counter: verdict.counterWage ? { wage: verdict.counterWage, fee: verdict.counterFee } : null
      };
    }
    Engine.completeTransfer(s, p, org, { fee: fee, wage: wage, signingBonus: signingBonus });
    p.contractEnd = s.season + years;
    p.status = 'starter';
    org.lineup = userLineup(s, org);
    if (p.age <= 21 && Engine.potentialStars(p) >= 4) s.flags.prospectsSigned = (s.flags.prospectsSigned || 0) + 1;
    addNews(s, 'transfer', 'SIGNED: ' + p.nick + ' (' + p.role + ')',
      org.name + ' complete the signing of ' + p.nick + '. Fee ' + C.money(fee) + ', signing bonus ' + C.money(signingBonus) + ', wage ' + C.money(wage) + '/yr, contract to ' + p.contractEnd + '.',
      { orgId: org.id, importance: 4 });
    G.updateObjectives();
    G.save(true);
    return { ok: true, player: p, verdict: verdict, signingBonus: signingBonus };
  };
  G.renewContract = function (playerId, wage, years) {
    var s = G.state, p = s.players[playerId], org = G.org();
    if (!p || p.org !== org.id) return { ok: false, reason: 'Player is not in your squad.' };
    var demand = Engine.wageDemand(p, org);
    if (wage < demand * 0.94) return { ok: false, reason: p.nick + ' wants at least ' + C.money(demand) + ' per year.' };
    p.wage = Math.round(wage);
    p.contractEnd = s.season + C.clamp(years || 2, 1, 4);
    p.morale = C.clamp(p.morale + 6, 0, 100);
    addNews(s, 'squad', 'Contract extended: ' + p.nick, p.nick + ' signs until ' + p.contractEnd + ' on ' + C.money(p.wage) + '/yr.', { orgId: org.id, importance: 2 });
    G.save(true);
    return { ok: true };
  };
  G.setOrgLogo = function (dataUrl) {
    var org = G.org();
    if (!org) return false;
    org.customLogo = dataUrl || null;
    G.save(true);
    return true;
  };
  G.listPlayer = function (playerId, listed, askingPrice) {
    var s = G.state, org = G.org(), p = s && s.players[playerId];
    if (!p || !org || p.org !== org.id || p.retired) return { ok: false, reason: 'Player is not in your squad.' };
    p.transferListed = !!listed;
    if (p.transferListed) {
      var est = Engine.valueFor(p);
      p.askingPrice = Math.max(10000, Math.round(askingPrice != null ? askingPrice : Math.max(est, Engine.askingPrice(p))));
      addNews(s, 'transfer', 'Transfer listed: ' + p.nick,
        org.name + ' placed ' + p.nick + ' (' + p.role + ', OVR ' + p.level + ') on the transfer list at ' + C.money(p.askingPrice) + '.',
        { orgId: org.id, importance: 2 });
      generateIncomingOffers(s, C.RNG('list|' + p.id + '|' + s.date), p);
    } else {
      delete p.askingPrice;
    }
    G.save(true);
    return { ok: true, listed: p.transferListed, askingPrice: p.askingPrice || 0 };
  };
  G.respondIncomingOffer = function (offerId, decision, counterFee) {
    var s = G.state, org = G.org();
    if (!s || !org) return { ok: false, reason: 'No active career.' };
    s.incomingOffers = s.incomingOffers || [];
    var idx = -1;
    for (var i = 0; i < s.incomingOffers.length; i++) if (s.incomingOffers[i].id === offerId) { idx = i; break; }
    if (idx < 0) return { ok: false, reason: 'Offer has expired or been withdrawn.' };
    var offer = s.incomingOffers[idx];
    var p = s.players[offer.playerId], buyer = s.orgs[offer.buyerOrgId];
    if (!p || p.org !== org.id || !buyer || buyer.status === 'inactive') {
      s.incomingOffers.splice(idx, 1);
      G.save(true);
      return { ok: false, reason: 'Offer is no longer valid.' };
    }
    if (decision === 'reject') {
      s.incomingOffers.splice(idx, 1);
      addNews(s, 'transfer', 'Offer rejected: ' + p.nick,
        org.name + ' turned down ' + C.money(offer.fee) + ' from ' + buyer.name + ' for ' + p.nick + '.',
        { orgId: org.id, importance: 2 });
      G.save(true);
      return { ok: true, decision: 'reject' };
    }
    if (decision === 'counter') {
      counterFee = Math.max(10000, Math.round(counterFee || offer.fee));
      offer.counters = (offer.counters || 0) + 1;
      if (counterFee <= (offer.maxFee || offer.fee * 1.15) && counterFee <= (buyer.budget || 0)) {
        offer.fee = counterFee;
        decision = 'accept';
      } else if (offer.counters <= 2 && counterFee <= (offer.maxFee || offer.fee) * 1.25 && (offer.maxFee || offer.fee) > offer.fee) {
        offer.fee = Math.min(buyer.budget || offer.fee, Math.round((offer.fee + (offer.maxFee || offer.fee * 1.1)) / 2));
        G.save(true);
        return { ok: true, decision: 'revised', fee: offer.fee, reason: buyer.name + ' countered back at ' + C.money(offer.fee) + '.' };
      } else {
        s.incomingOffers.splice(idx, 1);
        addNews(s, 'transfer', 'Talks collapsed: ' + p.nick,
          buyer.name + ' walked away after your ' + C.money(counterFee) + ' counter-demand for ' + p.nick + '.',
          { orgId: org.id, importance: 2 });
        G.save(true);
        return { ok: false, walked: true, reason: buyer.name + ' ended talks and withdrew their offer.' };
      }
    }
    if (decision === 'accept') {
      if ((org.roster || []).length <= 5 && !(s.academy[org.id] || []).length) {
        return { ok: false, reason: 'Keep at least 5 players on the active roster or sign/promote a replacement before selling ' + p.nick + '.' };
      }
      var newWage = Math.max(p.wage, Engine.wageDemand(p, buyer));
      Engine.completeTransfer(s, p, buyer, { fee: offer.fee, wage: newWage });
      p.contractEnd = s.season + 2;
      s.incomingOffers = s.incomingOffers.filter(function (o) { return o.id !== offer.id && o.playerId !== p.id; });
      if ((org.roster || []).length < 5 && (s.academy[org.id] || []).length) {
        var gradId = s.academy[org.id][0];
        if (gradId) G.promoteAcademy(gradId);
      }
      org.lineup = userLineup(s, org);
      addNews(s, 'transfer', 'SOLD: ' + p.nick + ' joins ' + buyer.name,
        org.name + ' sold ' + p.nick + ' to ' + buyer.name + ' for ' + C.money(offer.fee) + '. The transfer fee has been credited to your budget.',
        { orgId: org.id, importance: 4 });
      G.updateObjectives();
      G.save(true);
      return { ok: true, decision: 'accept', fee: offer.fee, buyer: buyer.name, player: p };
    }
    return { ok: false, reason: 'Invalid offer action.' };
  };
  G.releasePlayer = function (playerId) {
    var s = G.state, org = G.org(), p = s.players[playerId];
    if (!p || p.org !== org.id) return { ok: false, reason: 'Player is not in your squad.' };
    if ((org.roster || []).length <= 5) return { ok: false, reason: 'You must retain at least 5 active players in the roster. Sign or promote a replacement before releasing ' + p.nick + '.' };
    var severance = Math.round(p.wage * 0.22);
    if (severance > org.budget) return { ok: false, reason: 'You cannot fund the severance package (' + C.money(severance) + ').' };
    org.roster = (org.roster || []).filter(function (id) { return id !== playerId; });
    org.lineup = (org.lineup || []).filter(function (id) { return id !== playerId; });
    C.recordTransaction(s, org.id, 'Severance — ' + p.nick, -severance, {
      type: 'severance', category: 'squad',
      lines: [{ label: 'Severance package — ' + p.nick, value: -severance }]
    });
    p.org = null; p.status = 'free agent'; p.contractEnd = s.season; p.transferListed = false; delete p.askingPrice;
    addNews(s, 'transfer', 'RELEASED: ' + p.nick, p.nick + ' leaves ' + org.name + ' by mutual agreement. Severance ' + C.money(severance) + '.', { orgId: org.id, importance: 2 });
    org.lineup = userLineup(s, org);
    G.save(true);
    return { ok: true, severance: severance };
  };
  G.promoteAcademy = function (playerId) {
    var s = G.state, org = G.org(), p = s.players[playerId];
    if (!p || !p.academy) return { ok: false, reason: 'Player is not in the academy.' };
    var acad = s.academy[org.id] || [];
    s.academy[org.id] = acad.filter(function (id) { return id !== playerId; });
    delete p.academy;
    p.status = 'starter';
    p.wage = Engine.wageFor(p);
    p.org = org.id;
    if (org.roster.indexOf(p.id) < 0) org.roster.push(p.id);
    addNews(s, 'academy', 'Academy graduate promoted: ' + p.nick, p.nick + ' (' + p.age + ', ' + p.role + ', OVR ' + p.level + ') joins the first team.', { orgId: org.id, importance: 3 });
    G.save(true);
    return { ok: true };
  };
  G.demoteToAcademy = function (playerId) {
    var s = G.state, org = G.org(), p = s.players[playerId];
    if (!p || p.org !== org.id) return { ok: false, reason: 'Player is not in your squad.' };
    if (p.age > 21) return { ok: false, reason: 'Only players aged 21 or younger can be assigned to the academy.' };
    org.roster = org.roster.filter(function (id) { return id !== playerId; });
    org.lineup = org.lineup.filter(function (id) { return id !== playerId; });
    p.academy = true; p.status = 'academy'; p.transferListed = false; delete p.askingPrice;
    s.academy[org.id] = s.academy[org.id] || [];
    if (s.academy[org.id].indexOf(p.id) < 0) s.academy[org.id].push(p.id);
    G.save(true);
    return { ok: true };
  };

  G.hireStaff = function (staffId) {
    var s = G.state, org = G.org(), st = s.staff[staffId];
    if (!st) return { ok: false, reason: 'Staff member not found.' };
    if (st.org && st.org !== org.id) return { ok: false, reason: 'Staff member is under contract elsewhere.' };
    var fee = Math.round(st.salary * 0.25);
    if (fee > org.budget) return { ok: false, reason: 'Signing fee of ' + C.money(fee) + ' exceeds the budget.' };
    C.recordTransaction(s, org.id, 'Staff signing fee — ' + st.nick, -fee, {
      type: 'staff', category: 'staff',
      lines: [{ label: 'Staff signing fee — ' + st.name, value: -fee }]
    });
    st.org = org.id;
    if ((org.staff || []).indexOf(st.id) < 0) org.staff.push(st.id);
    s.staffMarket = (s.staffMarket || []).filter(function (id) { return id !== staffId; });
    addNews(s, 'staff', 'Staff appointed: ' + st.nick, st.role + ' ' + st.name + ' joins ' + org.name + ' (grade ' + st.grade + '/10).', { orgId: org.id, importance: 2 });
    G.save(true);
    return { ok: true };
  };
  G.fireStaff = function (staffId) {
    var s = G.state, org = G.org(), st = s.staff[staffId];
    if (!st || st.org !== org.id) return { ok: false, reason: 'Staff member is not at your club.' };
    var comp = Math.round(st.salary * 0.3);
    if (comp > org.budget) return { ok: false, reason: 'Compensation of ' + C.money(comp) + ' exceeds the budget.' };
    C.recordTransaction(s, org.id, 'Staff compensation — ' + st.nick, -comp, {
      type: 'staff', category: 'staff',
      lines: [{ label: 'Staff release compensation — ' + st.name, value: -comp }]
    });
    org.staff = org.staff.filter(function (id) { return id !== staffId; });
    st.org = null;
    s.staffMarket.push(st.id);
    G.save(true);
    return { ok: true };
  };
  G.upgradeFacility = function (key) {
    var s = G.state, org = G.org();
    if (!org.facilities || org.facilities[key] == null) return { ok: false, reason: 'Unknown facility.' };
    var level = org.facilities[key];
    if (level >= 5) return { ok: false, reason: 'Facility is already at maximum level.' };
    var cost = Math.round(140000 * Math.pow(1.65, level - 1));
    if (cost > org.budget) return { ok: false, reason: 'Upgrade costs ' + C.money(cost) + '. Your budget is ' + C.money(org.budget) + '.' };
    C.recordTransaction(s, org.id, 'Facility upgrade — ' + key, -cost, {
      type: 'facilities', category: 'facilities',
      lines: [{ label: 'Facility upgrade — ' + key + ' (level ' + (level + 1) + ')', value: -cost }]
    });
    org.facilities[key] = level + 1;
    addNews(s, 'facilities', 'Facility upgraded: ' + key, org.name + ' invested ' + C.money(cost) + ' to bring the ' + key + ' facility to level ' + (level + 1) + '.', { orgId: org.id, importance: 2 });
    G.save(true);
    return { ok: true, cost: cost };
  };
  /* ------------------------------------------------------------------
     SPONSORSHIP CONTRACTS
     A signed sponsor is a real contract: total value, payment schedule,
     paid/remaining amounts, performance objectives and a renewal lifecycle.
     Payments are credited exactly once, on their due date, through
     Core.recordTransaction so the balance and the ledger stay in sync.
  ------------------------------------------------------------------ */
  var SPONSOR_FREQ = {
    monthly: { ppy: 12, months: 1, label: 'month' },
    quarterly: { ppy: 4, months: 3, label: 'quarter' },
    weekly: { ppy: 52, months: 0, label: 'week' }
  };
  function sponsorFreq(freq) { return SPONSOR_FREQ[freq] || SPONSOR_FREQ.monthly; }
  function sponsorNextDate(date, freq) {
    var f = sponsorFreq(freq);
    return f.months ? C.addMonths(date, f.months) : C.addDays(date, 7);
  }
  function sponsorEndDate(start, freq, periods) {
    var f = sponsorFreq(freq);
    return f.months ? C.addMonths(start, f.months * periods) : C.addDays(start, 7 * periods);
  }
  function sponsorPaymentAmount(c) {
    var remaining = Math.max(0, (c.total || 0) - (c.paid || 0));
    if (remaining <= 0) return 0;
    if ((c.payments || 0) >= (c.periods || 1) - 1) return remaining;
    return Math.min(remaining, c.periodAmount || Math.round((c.annual || 0) / sponsorFreq(c.freq).ppy));
  }
  function activeSponsorContracts(state, orgId) {
    return (state.sponsorContracts || []).filter(function (c) {
      return c.orgId === orgId && c.status === 'active';
    });
  }
  function sponsorAnnualTotal(state, orgId) {
    return activeSponsorContracts(state, orgId).reduce(function (n, c) { return n + (c.annual || 0); }, 0);
  }
  function syncSponsorValue(state, org) {
    if (!org) return;
    org.sponsor = Math.round(sponsorAnnualTotal(state, org.id));
    if (org.isUser) state.flags.sponsorValue = org.sponsor;
  }
  function makeSponsorObjectives(org, annual, rng) {
    var rep = org.rep || 60;
    var out = [];
    if (rep >= 84) {
      out.push({ id: 'win', type: 'win', label: 'Win a VCT tournament', bonus: Math.round(annual * 0.25), status: 'pending' });
    } else if (rep >= 72) {
      out.push({ id: 'top3', type: 'top3', label: 'Finish top three at a regional event', bonus: Math.round(annual * 0.15), status: 'pending' });
    } else {
      out.push({ id: 'playoffs', type: 'playoffs', label: 'Reach the playoffs of a VCT event', bonus: Math.round(annual * 0.12), status: 'pending' });
    }
    if (rep >= 78) {
      out.push({ id: 'masters', type: 'masters', label: 'Qualify for a Masters event', bonus: Math.round(annual * 0.18), status: 'pending' });
    } else {
      var target = rep >= 70 ? 4 : 6;
      out.push({ id: 'rank', type: 'rank', target: target, label: 'Stay in the regional top ' + target, bonus: Math.round(annual * 0.1), status: 'pending', atEnd: true });
    }
    return out;
  }
  function buildSponsorContract(state, org, offer) {
    var freq = SPONSOR_FREQ[offer.freq] ? offer.freq : 'monthly';
    var f = sponsorFreq(freq);
    var years = C.clamp(Math.round(offer.years || 1), 1, 3);
    var annual = Math.max(1000, Math.round(offer.value || 0));
    var periods = years * f.ppy;
    var start = state.date;
    var contract = {
      id: 'sc_' + (offer.id || C.uid('sp')) + '_' + Math.floor(Math.random() * 1e5).toString(36),
      offerId: offer.id || null,
      orgId: org.id,
      name: offer.name || 'Sponsor',
      desc: offer.desc || '',
      req: offer.req || '',
      freq: freq,
      annual: annual,
      years: years,
      total: annual * years,
      periods: periods,
      periodAmount: Math.round(annual / f.ppy),
      paid: 0,
      payments: 0,
      bonusesPaid: 0,
      start: start,
      end: sponsorEndDate(start, freq, periods),
      nextPayment: sponsorNextDate(start, freq),
      status: 'active',
      signed: start,
      renewalWarned: false,
      objectives: (offer.objectives && offer.objectives.length)
        ? JSON.parse(JSON.stringify(offer.objectives))
        : makeSponsorObjectives(org, annual),
      legacy: !!offer.legacy,
      renewalOf: offer.renewalOf || null
    };
    return contract;
  }
  function regionalRank(state, org) {
    var peers = Object.keys(state.orgs).map(function (id) { return state.orgs[id]; }).filter(function (o) {
      return o && o.status !== 'inactive' && o.region === org.region;
    });
    peers.sort(function (a, b) { return (b.points || 0) - (a.points || 0); });
    for (var i = 0; i < peers.length; i++) if (peers[i].id === org.id) return i + 1;
    return peers.length + 1;
  }
  function sponsorObjectiveMet(state, org, o) {
    var comps = Object.keys(state.comps || {}).map(function (id) { return state.comps[id]; }).filter(function (c) {
      return c && c.status === 'done' && c.placements;
    });
    switch (o.type) {
      case 'playoffs':
        return comps.some(function (c) { var pos = c.placements[org.id]; return pos != null && pos <= 8; });
      case 'top3':
        return comps.some(function (c) { var pos = c.placements[org.id]; return pos != null && pos <= 3; }) ||
          (state.flags.kickoffPos != null && state.flags.kickoffPos <= 3) ||
          (state.flags.bestCupPos != null && state.flags.bestCupPos <= 3);
      case 'win':
        return comps.some(function (c) { return c.champion === org.id; }) ||
          (state.manager.trophies || []).some(function (t) { return t.season === state.season; });
      case 'masters':
        return !!(state.flags.masters1Qualified || state.flags.masters2Qualified);
      case 'rank':
        return regionalRank(state, org) <= (o.target || 6);
      default:
        return false;
    }
  }
  function evaluateSponsorContract(state, org, c, final) {
    var done = 0, failed = 0;
    (c.objectives || []).forEach(function (o) {
      if (o.status === 'pending' && o.type === 'rank' && !final) return;
      if (o.status === 'pending' && sponsorObjectiveMet(state, org, o)) {
        o.status = 'done';
        o.completed = state.date;
        c.bonusesPaid = (c.bonusesPaid || 0) + (o.bonus || 0);
        if (o.bonus > 0) {
          C.recordTransaction(state, org.id, 'Sponsor bonus — ' + c.name + ': ' + o.label, o.bonus, {
            type: 'sponsor_bonus', category: 'sponsorship', contractId: c.id,
            lines: [{ label: 'Sponsor bonus — ' + c.name + ' (' + o.label + ')', value: o.bonus }]
          });
          addNews(state, 'finance', 'Sponsor bonus paid: ' + c.name,
            o.label + ' has been achieved. ' + c.name + ' pay a bonus of ' + C.money(o.bonus) + '. The amount is already in your budget and ledger.',
            { orgId: org.id, importance: 3 });
        }
      } else if (o.status === 'pending' && final) {
        o.status = 'failed';
      }
      if (o.status === 'done') done++;
      if (o.status === 'failed') failed++;
    });
    if (final && failed > 0) {
      var penalty = Math.min(2, failed);
      org.rep = C.clamp((org.rep || 50) - penalty, 30, 99);
      addNews(state, 'finance', 'Sponsor objectives missed: ' + c.name,
        failed + ' contractual objective(s) were not met. ' + c.name + ' reduce their renewal offer and your reputation falls by ' + penalty + '. Winning matches and qualifying for international events protect commercial income.',
        { orgId: org.id, importance: failed > 1 ? 4 : 3 });
    }
    c.objectivesDone = done;
    c.objectivesFailed = failed;
    return { done: done, failed: failed };
  }
  function evaluateSponsorObjectives(state, org, final) {
    if (!org) return;
    activeSponsorContracts(state, org.id).forEach(function (c) {
      evaluateSponsorContract(state, org, c, !!final);
    });
  }
  function finishSponsorContract(state, org, c) {
    if (c.status !== 'active') return;
    var verdict = evaluateSponsorContract(state, org, c, true);
    c.status = 'expired';
    c.ended = state.date;
    addNews(state, 'finance', 'Sponsorship ended: ' + c.name,
      'The ' + c.years + '-year agreement with ' + c.name + ' has reached its end on ' + C.fmtDate(c.end) + '. Total received: ' + C.money(c.paid) + ' in instalments' + (c.bonusesPaid ? ' plus ' + C.money(c.bonusesPaid) + ' in bonuses' : '') + '.',
      { orgId: org.id, importance: 3 });
    var rng = C.RNG('renewal|' + c.id + '|' + state.date);
    var withdrawn = verdict.failed >= 2 || (org.rep || 50) < 45;
    if (withdrawn) {
      c.renewalDeclined = true;
      addNews(state, 'finance', 'Sponsor withdraws: ' + c.name,
        c.name + ' will not renew after missed objectives. No further payments are scheduled. Reach the playoffs and protect your regional ranking to rebuild commercial confidence.',
        { orgId: org.id, importance: 4 });
      return;
    }
    var factor = 1 + verdict.done * 0.08 - verdict.failed * 0.05 + rng.float(-0.03, 0.05) + ((org.rep || 60) - 70) / 400;
    var value = Math.max(60000, Math.round((c.annual * C.clamp(factor, 0.8, 1.35)) / 1000) * 1000);
    var years = C.clamp(c.years || 1, 1, 3);
    var renewal = {
      id: 'ren_' + c.id + '_' + state.season,
      name: c.name,
      value: value,
      years: years,
      freq: c.freq,
      desc: 'Renewal offer after a ' + (verdict.done ? verdict.done + ' objective(s) met' : 'contract without bonuses') + '.',
      req: 'Performance review',
      renewal: true,
      renewalOf: c.id,
      previousValue: c.annual,
      expires: C.addDays(state.date, 45),
      negotiated: false,
      objectives: makeSponsorObjectives(org, value, rng)
    };
    state.sponsorOffers = state.sponsorOffers || [];
    if (!state.sponsorOffers.some(function (o) { return o.id === renewal.id; })) state.sponsorOffers.push(renewal);
    addNews(state, 'finance', 'Renewal offer: ' + c.name,
      c.name + ' propose ' + C.money(value) + ' per year for ' + years + ' more year(s), payable every ' + sponsorFreq(c.freq).label + '. The offer expires on ' + C.fmtDate(renewal.expires) + '. Open Finances to accept or negotiate.',
      { orgId: org.id, importance: 4 });
  }
  function processSponsorPayments(state) {
    var org = state.orgs[state.clubId];
    if (!org) return;
    (state.sponsorContracts || []).forEach(function (c) {
      if (c.orgId !== org.id || c.status !== 'active') return;
      var guard = 0;
      while (c.status === 'active' && state.date >= c.nextPayment && (c.payments || 0) < c.periods && guard++ < 400) {
        var amount = sponsorPaymentAmount(c);
        if (amount > 0) {
          C.recordTransaction(state, org.id, 'Sponsorship payment — ' + c.name, amount, {
            type: 'sponsor', category: 'sponsorship', contractId: c.id,
            lines: [{ label: 'Sponsorship — ' + c.name + ' (' + ((c.payments || 0) + 1) + '/' + c.periods + ')', value: amount }]
          });
          c.paid = (c.paid || 0) + amount;
          c.payments = (c.payments || 0) + 1;
          addNews(state, 'finance', 'Sponsorship payment received',
            c.name + ' paid ' + C.money(amount) + ' (' + c.payments + ' of ' + c.periods + ' instalments). ' +
            (c.payments < c.periods
              ? 'The next payment is due on ' + C.fmtDate(sponsorNextDate(c.nextPayment, c.freq)) + '.'
              : 'The contract is now complete.'),
            { orgId: org.id, importance: 2 });
        } else {
          c.payments = c.periods;
        }
        if (c.payments < c.periods) c.nextPayment = sponsorNextDate(c.nextPayment, c.freq);
        else finishSponsorContract(state, org, c);
      }
      if (c.status === 'active' && !c.renewalWarned && C.diffDays(state.date, c.end) <= 30) {
        c.renewalWarned = true;
        addNews(state, 'finance', 'Sponsorship expiring: ' + c.name,
          c.name + ' expires on ' + C.fmtDate(c.end) + '. ' + C.money(Math.max(0, c.total - c.paid)) + ' of scheduled revenue is still to be paid. Review the renewal terms in Finances before the deadline.',
          { orgId: org.id, importance: 3 });
      }
    });
    state.sponsorOffers = (state.sponsorOffers || []).filter(function (o) {
      if (o.expires && state.date > o.expires) {
        addNews(state, 'finance', 'Sponsor offer expired: ' + o.name,
          'The offer from ' + o.name + ' expired on ' + C.fmtDate(o.expires) + '. Advance commercial talks earlier: open Finances and sign or negotiate before the deadline.',
          { orgId: org.id, importance: 2 });
        return false;
      }
      return true;
    });
    syncSponsorValue(state, org);
  }
  function ensureLegacySponsorContract(state, org) {
    if (!org || state.flags.sponsorLegacyMigrated) return null;
    state.flags.sponsorLegacyMigrated = true;
    var has = (state.sponsorContracts || []).some(function (c) { return c.orgId === org.id; });
    if (has || !org.sponsor) return null;
    var annual = Math.round(org.sponsor);
    if (annual <= 0) return null;
    var contract = buildSponsorContract(state, org, {
      id: 'legacy_' + state.season,
      name: 'Existing title sponsor',
      value: annual,
      years: 1,
      freq: 'monthly',
      desc: 'The commercial agreement inherited when you took charge.',
      req: 'Existing agreement',
      legacy: true
    });
    state.sponsorContracts = state.sponsorContracts || [];
    state.sponsorContracts.push(contract);
    return contract;
  }
  G.sponsorContractsFor = function (orgId) {
    var s = G.state;
    if (!s) return [];
    return (s.sponsorContracts || []).filter(function (c) { return c.orgId === (orgId || s.clubId); });
  };
  G.sponsorSummary = function () {
    var s = G.state, org = G.org();
    if (!s || !org) return null;
    var all = G.sponsorContractsFor(org.id);
    var active = all.filter(function (c) { return c.status === 'active'; });
    var received = all.reduce(function (n, c) { return n + (c.paid || 0); }, 0);
    var bonuses = all.reduce(function (n, c) { return n + (c.bonusesPaid || 0); }, 0);
    var remaining = active.reduce(function (n, c) { return n + Math.max(0, c.total - c.paid); }, 0);
    var upcoming = 0, nextDate = null;
    active.forEach(function (c) {
      if (!c.nextPayment) return;
      if (!nextDate || c.nextPayment < nextDate) nextDate = c.nextPayment;
      if (C.diffDays(s.date, c.nextPayment) <= 30) upcoming += sponsorPaymentAmount(c);
    });
    return {
      active: active, all: all, annual: active.reduce(function (n, c) { return n + (c.annual || 0); }, 0),
      received: received, bonuses: bonuses, remaining: remaining, upcoming: upcoming,
      nextDate: nextDate, totalValue: all.reduce(function (n, c) { return n + (c.total || 0); }, 0),
      weeklyAverage: active.reduce(function (n, c) { return n + (c.annual || 0); }, 0) / 52
    };
  };
  G.signSponsor = function (offerId) {
    var s = G.state, org = G.org();
    var offer = (s.sponsorOffers || []).filter(function (o) { return o.id === offerId; })[0];
    if (!offer) return { ok: false, reason: 'Offer has expired. Advance the market or negotiate a renewal first.' };
    if (offer.expires && s.date > offer.expires) return { ok: false, reason: 'This offer expired on ' + C.fmtDate(offer.expires) + '.' };
    var duplicate = activeSponsorContracts(s, org.id).some(function (c) { return c.name === offer.name; });
    if (duplicate) return { ok: false, reason: offer.name + ' is already an active sponsor. Wait for the renewal offer instead of duplicating the contract.' };
    var contract = buildSponsorContract(s, org, offer);
    s.sponsorContracts = s.sponsorContracts || [];
    s.sponsorContracts.push(contract);
    s.sponsorOffers = (s.sponsorOffers || []).filter(function (o) { return o.id !== offerId; });
    syncSponsorValue(s, org);
    var firstAmount = sponsorPaymentAmount(contract);
    addNews(s, 'finance', 'Sponsorship signed: ' + offer.name,
      org.name + ' signed a ' + C.money(contract.annual) + ' per year agreement with ' + offer.name + ' for ' + contract.years + ' year(s), a total of ' + C.money(contract.total) + '. ' +
      'You receive ' + C.money(firstAmount) + ' every ' + sponsorFreq(contract.freq).label + ', first on ' + C.fmtDate(contract.nextPayment) + '. The contract ends on ' + C.fmtDate(contract.end) + '. ' +
      'Objectives: ' + (contract.objectives || []).map(function (o) { return o.label + ' (bonus ' + C.money(o.bonus) + ')'; }).join('; ') + '.',
      { orgId: org.id, importance: 4 });
    G.updateObjectives();
    G.save(true);
    return { ok: true, contract: contract, annual: contract.annual, payment: firstAmount, nextPayment: contract.nextPayment, end: contract.end };
  };
  G.negotiateSponsor = function (offerId) {
    var s = G.state, org = G.org();
    var offer = (s.sponsorOffers || []).filter(function (o) { return o.id === offerId; })[0];
    if (!offer) return { ok: false, reason: 'Offer has expired.' };
    if (offer.negotiated) return { ok: false, reason: 'This offer has already been renegotiated. Sign it or wait for a better market.' };
    var rng = C.RNG('nego|' + offer.id + '|' + s.date);
    offer.negotiated = true;
    var chance = C.clamp(0.35 + ((org.rep || 60) - 60) / 150 + ((s.manager.confidence || 60) - 60) / 300, 0.15, 0.85);
    if (rng.chance(chance)) {
      var before = offer.value;
      var gain = 0.06 + rng.float(0, 0.08);
      offer.value = Math.round((before * (1 + gain)) / 1000) * 1000;
      offer.desc = 'Renegotiated upward from ' + C.money(before) + ' to ' + C.money(offer.value) + ' per year.';
      addNews(s, 'finance', 'Sponsor negotiation successful: ' + offer.name,
        'Your commercial team convinced ' + offer.name + ' to raise their offer from ' + C.money(before) + ' to ' + C.money(offer.value) + ' per year. Sign before ' + C.fmtDate(offer.expires) + ' to secure it.',
        { orgId: org.id, importance: 3 });
      G.save(true);
      return { ok: true, value: offer.value, before: before };
    }
    if (rng.chance(0.25)) {
      s.sponsorOffers = s.sponsorOffers.filter(function (o) { return o.id !== offerId; });
      addNews(s, 'finance', 'Sponsor walks away: ' + offer.name,
        offer.name + ' ended talks after an aggressive negotiation. Improve your reputation and results, then refresh the sponsor market.',
        { orgId: org.id, importance: 3 });
      G.save(true);
      return { ok: false, withdrawn: true, reason: offer.name + ' withdrew from negotiations. The offer is gone.' };
    }
    G.save(true);
    return { ok: false, reason: offer.name + ' refused to improve the terms. The original offer remains available.' };
  };
  G.setMapPool = function (pool) {
    var s = G.state;
    pool = (pool || []).filter(function (m) { return C.MAPS.some(function (x) { return x.name === m; }); });
    var unique = [];
    pool.forEach(function (m) { if (unique.indexOf(m) < 0) unique.push(m); });
    if (unique.length !== 7) return { ok: false, reason: 'The VALORANT competitive map pool must contain exactly 7 maps.' };
    s.settings.mapPool = unique;
    s.mapPrefs = s.mapPrefs || { picks: [], bans: [] };
    s.mapPrefs.picks = (s.mapPrefs.picks || []).filter(function (m) { return unique.indexOf(m) >= 0; }).slice(0, 3);
    s.mapPrefs.bans = (s.mapPrefs.bans || []).filter(function (m) { return unique.indexOf(m) >= 0; }).slice(0, 3);
    Object.keys(s.orgs).forEach(function (id) {
      var org = s.orgs[id];
      org.mapPrep = org.mapPrep || {};
      unique.forEach(function (m) { if (org.mapPrep[m] == null) org.mapPrep[m] = 52; });
    });
    G.save(true);
    return { ok: true };
  };
  G.setMapPrefs = function (kind, list) {
    var s = G.state;
    s.mapPrefs = s.mapPrefs || { picks: [], bans: [] };
    s.mapPrefs[kind] = list.filter(function (m) { return s.settings.mapPool.indexOf(m) >= 0; }).slice(0, 3);
    G.save(true);
  };
  G.markNewsRead = function (id) {
    var n = G.state.news.filter(function (x) { return x.id === id || id === 'all'; });
    n.forEach(function (x) { x.read = true; });
    G.save(true);
  };
  G.scoutPlayer = function (playerId) {
    var s = G.state, org = G.org(), p = s.players[playerId];
    if (!p) return { ok: false, reason: 'Player not found.' };
    if (s.scoutReports[playerId]) return { ok: true, already: true };
    var cost = 12000;
    if (cost > org.budget) return { ok: false, reason: 'Scouting costs ' + C.money(cost) + '.' };
    C.recordTransaction(s, org.id, 'Scouting report — ' + p.nick, -cost, {
      type: 'scouting', category: 'scouting',
      lines: [{ label: 'Scouting report — ' + p.nick, value: -cost }]
    });
    s.scoutReports[playerId] = {
      date: s.date, wage: Engine.wageDemand(p, org), fee: p.org ? Engine.askingPrice(p) : 0,
      note: p.sim ? 'Fictional prospect: treat the ceiling as an internal estimate.' : 'Confidence: ' + (p.conf || 'UNKNOWN') + '. Source: ' + (p.src || 'unlisted') + '.'
    };
    p.scouted = true;
    G.save(true);
    return { ok: true, cost: cost, report: s.scoutReports[playerId] };
  };

  /* ------------------------------------------------------------------
     OBJECTIVES / BOARD
  ------------------------------------------------------------------ */
  G.updateObjectives = function () {
    var s = G.state, org = G.org();
    if (!s || !org) return;
    evaluateSponsorObjectives(s, org, false);
    (s.objectives || []).forEach(function (obj) {
      if (obj.status === 'done' || obj.status === 'failed') return;
      Engine.objectiveProgress(s, obj, org);
      if (obj.done) {
        obj.status = 'done';
        s.manager.xp += 25;
        addNews(s, 'board', 'Objective complete: ' + obj.title, obj.success, { importance: 3, orgId: org.id });
      } else if (obj.deadline && s.date > obj.deadline) {
        obj.status = 'failed';
        addNews(s, 'board', 'Objective failed: ' + obj.title, obj.fail, { importance: 4, orgId: org.id });
      }
    });
    s.manager.confidence = Engine.boardConfidence(s, org);
    s.manager.levelInfo = Engine.managerLevel(s.manager.xp);
  };

  G.boardSummary = function () {
    var s = G.state, org = G.org();
    var objs = s.objectives || [];
    return {
      confidence: s.manager.confidence,
      done: objs.filter(function (o) { return o.status === 'done'; }).length,
      failed: objs.filter(function (o) { return o.status === 'failed'; }).length,
      active: objs.filter(function (o) { return o.status === 'active'; }).length,
      critical: objs.filter(function (o) { return o.status === 'active' && o.importance === 'critical'; })
    };
  };

  /* ------------------------------------------------------------------
     SPONSORS
  ------------------------------------------------------------------ */
  function generateSponsors(state, force) {
    var org = state.orgs[state.clubId];
    if (!org) return;
    var renewals = (state.sponsorOffers || []).filter(function (o) { return o.renewal; });
    var market = (state.sponsorOffers || []).filter(function (o) { return !o.renewal; });
    if (!force && market.length >= 3) return;
    var rng = C.RNG('sponsor|' + state.season + '|' + state.date + '|' + state.clubId);
    var activeNames = (state.sponsorContracts || []).filter(function (c) {
      return c.orgId === org.id && c.status === 'active';
    }).map(function (c) { return c.name; });
    var names = ['Redline Energy', 'Nexus Peripherals', 'Aegis Bank', 'Volt Athletics', 'HyperX Arena', 'Cipher Telecom', 'Vertex Motors', 'Northwind Logistics'];
    names = names.filter(function (n) { return activeNames.indexOf(n) < 0; });
    if (!names.length) names = ['Meridian Group', 'Atlas Systems', 'Pulse Media'];
    var offers = [];
    for (var i = 0; i < 3; i++) {
      var value = Math.round((150000 + (org.rep || 60) * 2200 + rng.int(0, 120000)) / 5000) * 5000;
      var freq = rng.chance(0.28) ? 'quarterly' : 'monthly';
      var years = (org.rep || 60) >= 82 ? rng.int(1, 3) : rng.int(1, 2);
      var req = (org.rep || 60) >= 85 ? 'Championship contender — top-four international expectations'
        : (org.rep || 60) >= 75 ? 'Playoff contention and a stable roster'
          : 'Regional visibility and commercial activity';
      var pick = rng.pick(names);
      names = names.filter(function (n) { return n !== pick; });
      if (!names.length) names = ['Meridian Group', 'Atlas Systems', 'Pulse Media'];
      offers.push({
        id: 'sp_' + state.season + '_' + state.date.replace(/-/g, '') + '_' + i,
        name: pick,
        value: value,
        years: years,
        freq: freq,
        desc: 'Pays every ' + sponsorFreq(freq).label + '.',
        req: req,
        expires: C.addDays(state.date, 60),
        negotiated: false,
        objectives: makeSponsorObjectives(org, value, rng)
      });
    }
    state.sponsorOffers = renewals.concat(offers);
  }
  G.refreshSponsors = function () {
    generateSponsors(G.state, true);
    G.save(true);
  };

  /* ------------------------------------------------------------------
     CALENDAR / ADVANCE
  ------------------------------------------------------------------ */
  function fixtureOnDate(state, date) {
    var f = Competition.userNextFixture(state);
    return f && f.date === date ? f : null;
  }
  function userHasCompToday(state, date) {
    var f = Competition.userNextFixture(state);
    return !!(f && f.date === date);
  }

  function dailyRecovery(state, outLog) {
    var org = state.orgs[state.clubId];
    if (org) {
      var ids = (org.roster || []).concat(state.academy[org.id] || []);
      ids.forEach(function (id) {
        var p = state.players[id];
        if (!p) return;
        var recLvl = (org.facilities && org.facilities.recovery) || 2;
        p.fatigue = C.clamp((p.fatigue || 10) - (p.academy ? 0.25 : 0.45) - recLvl * 0.07, 0, 100);
        if (p.fatigue < 12) p.form = C.clamp((p.form || 65) + 0.08, 20, 99);
        p.morale = C.clamp((p.morale || 65) + (65 - p.morale) * 0.006, 15, 99);
      });
    }
    var userCleared = false;
    Object.keys(state.players || {}).forEach(function (id) {
      var p = state.players[id];
      if (!p || p.retired || !p.injury) return;
      p.injury.days = (p.injury.days || 0) - 1;
      if (p.injury.days <= 0) {
        var oldInj = p.injury.reason || p.injury.type || 'strain';
        p.injury = null;
        if (org && p.org === org.id) {
          userCleared = true;
          if (outLog) outLog.recoveries.push({ nick: p.nick, type: oldInj });
          addNews(state, 'squad', 'Cleared to play: ' + p.nick,
            p.nick + ' has fully recovered from ' + oldInj.toLowerCase() + ' and is available for selection.',
            { orgId: org.id, importance: 3 });
        }
      }
    });
    if (userCleared && org) Competition.ensureLineup(state, org);
  }
  function weeklyWorld(state) {
    Object.keys(state.players).forEach(function (id) {
      var p = state.players[id];
      if (!p || p.retired) return;
      if (p.org && p.org !== state.clubId) p.fatigue = C.clamp((p.fatigue || 10) - 7, 0, 100);
    });
  }

  function contractWarnings(state) {
    var org = state.orgs[state.clubId];
    G.roster(org).forEach(function (p) {
      if (p.contractEnd <= state.season && !p.expiryWarned) {
        p.expiryWarned = true;
        addNews(state, 'squad', 'Contract expiring: ' + p.nick,
          p.nick + ' is out of contract at the end of ' + state.season + '. Renew now or lose the player to free agency.',
          { orgId: org.id, importance: 4 });
      }
    });
  }

  function generateIncomingOffers(state, rng, focusPlayer, outLog) {
    var org = state.orgs[state.clubId];
    if (!org) return 0;
    state.incomingOffers = (state.incomingOffers || []).filter(function (o) {
      var p = state.players[o.playerId];
      return p && p.org === org.id && (!o.expires || state.date <= o.expires);
    });
    if (state.incomingOffers.length >= 6) return 0;
    var candidates = focusPlayer ? [focusPlayer] : G.roster(org).filter(function (p) {
      return p.transferListed || (p.level >= 75 && rng.chance(0.18));
    });
    var buyers = Object.keys(state.orgs).map(function (id) { return state.orgs[id]; }).filter(function (o) {
      return o && !o.isUser && o.status !== 'inactive' && (o.budget || 0) >= 25000;
    });
    if (!candidates.length || !buyers.length) return 0;
    var created = 0;
    candidates.forEach(function (p) {
      if (state.incomingOffers.length >= 6) return;
      if (state.incomingOffers.filter(function (o) { return o.playerId === p.id; }).length >= 2) return;
      var prob = p.transferListed ? (focusPlayer ? 0.8 : 0.42) : 0.08;
      if (!rng.chance(prob)) return;
      var interested = buyers.filter(function (b) {
        if (state.incomingOffers.some(function (o) { return o.playerId === p.id && o.buyerOrgId === b.id; })) return false;
        var baseVal = p.transferListed && p.askingPrice ? p.askingPrice : Engine.valueFor(p);
        return (b.budget || 0) >= baseVal * 0.72;
      }).sort(function (a, b) { return (b.rep || 0) - (a.rep || 0); });
      if (!interested.length) return;
      var buyer = interested[rng.int(0, Math.min(4, interested.length - 1))];
      var refVal = p.transferListed && p.askingPrice ? p.askingPrice : Engine.valueFor(p);
      var fee = Math.max(15000, Math.round((refVal * (p.transferListed ? rng.float(0.84, 1.06) : rng.float(1.06, 1.32))) / 1000) * 1000);
      fee = Math.min(fee, Math.round(buyer.budget * 0.85));
      if (fee < 15000) return;
      var offer = {
        id: 'off_' + C.uid('o', rng),
        playerId: p.id,
        buyerOrgId: buyer.id,
        buyerName: buyer.name,
        buyerShort: buyer.short,
        fee: fee,
        maxFee: Math.min(Math.round(buyer.budget * 0.95), Math.round(fee * rng.float(1.12, 1.30))),
        created: state.date,
        expires: C.addDays(state.date, 18),
        counters: 0
      };
      state.incomingOffers.unshift(offer);
      created++;
      if (outLog) outLog.offersReceived.push({ nick: p.nick, buyerName: buyer.name, fee: fee });
      addNews(state, 'transfer', 'Incoming offer: ' + buyer.name + ' bid for ' + p.nick,
        buyer.name + ' offered ' + C.money(fee) + ' for ' + p.nick + ' (' + p.role + ', OVR ' + p.level + '). Open Transfers to accept, counter, or reject before ' + C.fmtDate(offer.expires) + '.',
        { orgId: org.id, importance: 4 });
    });
    return created;
  }

  function aiTransfers(state, rng) {
    var market = G.freeAgents().sort(function (a, b) { return b.level - a.level; });
    var signed = 0, newsCount = 0;
    var orgs = Object.keys(state.orgs).map(function (id) { return state.orgs[id]; }).filter(function (o) {
      return o.status !== 'inactive' && !o.isUser;
    }).sort(function (a, b) { return (b.rep || 0) - (a.rep || 0); });
    orgs.forEach(function (org) {
      // List surplus AI players
      if ((org.roster || []).length >= 7) {
        var extra = (org.roster || []).map(function (id) { return state.players[id]; }).filter(Boolean)
          .sort(function (a, b) { return a.level - b.level; })[0];
        if (extra && !extra.transferListed) {
          extra.transferListed = true;
          extra.askingPrice = Math.max(15000, Math.round(Engine.valueFor(extra) * 0.9));
        }
      }
      var need = (org.roster || []).length < 5 ? 2 : (org.rep > 80 && (org.roster || []).length < 7 && rng.chance(0.32) ? 1 : 0);
      if (!need) return;
      for (var i = 0; i < need; i++) {
        var listedTargets = Object.keys(state.players).map(function (id) { return state.players[id]; }).filter(function (p) {
          return p && !p.retired && p.org && p.org !== org.id && p.org !== state.clubId && p.transferListed && (org.budget || 0) > (p.askingPrice || 20000);
        }).sort(function (a, b) { return b.level - a.level; });
        var cand = listedTargets[0] && rng.chance(0.45) ? listedTargets[0] : market.filter(function (p) {
          return p.org == null && (org.budget || 0) > Engine.wageDemand(p, org) * 0.3;
        }).sort(function (a, b) {
          return (b.level - b.potential * 0.15) - (a.level - a.potential * 0.15);
        })[0];
        if (!cand) break;
        var demand = Engine.wageDemand(cand, org);
        var fee = cand.org ? (cand.askingPrice || Engine.askingPrice(cand)) : 0;
        if (fee > org.budget * 0.8) fee = 0;
        if (cand.org && fee === 0) continue;
        Engine.completeTransfer(state, cand, org, { fee: fee, wage: demand });
        cand.contractEnd = state.season + rng.int(1, 3);
        signed++;
        if (org.rep > 84 && newsCount < 3) {
          addNews(state, 'transfer', 'TRANSFER: ' + cand.nick + ' joins ' + org.name,
            'The ' + org.short + ' project adds ' + cand.nick + ' (' + cand.role + ', OVR ' + cand.level + ') on a ' + C.money(demand) + '/yr deal.',
            { importance: 2, orgId: org.id });
          newsCount++;
        }
      }
    });
    return signed;
  }

  function monthlyNews(state, rng) {
    var champ = state.orgs[rng.pick(Object.keys(state.orgs).filter(function (id) { return state.orgs[id].partner; }))];
    if (!champ) return;
    var activePool = (state.settings && state.settings.mapPool) || C.ACTIVE_MAP_POOL_2027;
    var m1 = activePool[0] || 'Abyss', m2 = activePool[activePool.length - 1] || 'Sunset';
    var topics = [
      { t: 'Power rankings update', b: champ.name + ' lead the regional eye test after the latest roster moves. Analysts point to their utility sequencing and depth.' },
      { t: 'Sponsorship market heats up', b: 'Two regional partners are negotiating new deals. Prize money and qualification payments remain the biggest swing factors for non-partner teams.' },
      { t: 'Map pool debate', b: 'Coaches are split on whether to prioritise ' + m1 + ' or ' + m2 + ' in the veto. Preparation strongly swings tight BO3 series.' },
      { t: 'Academy watch', b: 'Several 17-year-olds are pushing for first-team minutes. Academy graduates keep their low wage for one season after promotion.' }
    ];
    var x = rng.pick(topics);
    addNews(state, 'world', x.t, x.b, { importance: 1 });
  }

  function processDay(state, rng, outLog) {
    dailyRecovery(state, outLog);
    processSponsorPayments(state);
    var d = C.parseDate(state.date);
    if (d.getUTCDay() === 1) {
      var fin = Engine.weeklyFinance(state);
      state.financeLedger.unshift({ date: state.date, total: fin.total, lines: fin.lines, note: 'Weekly operations', type: 'operations', category: 'operations' });
      if (state.financeLedger.length > 120) state.financeLedger.length = 120;
      weeklyWorld(state);
      contractWarnings(state);
      if (state.trainOnDay) state.trainOnDay = false;
      generateIncomingOffers(state, rng, null, outLog);
    }
    if (diff(state.seasonStart, state.date) % 7 === 0 && diff(state.seasonStart, state.date) > 0 && !userHasCompToday(state, state.date)) {
      var report = Engine.runTraining(state, state.trainingPlan);
      state.trainingReports.unshift(report);
      if (state.trainingReports.length > 24) state.trainingReports.length = 24;
      if (outLog) {
        outLog.trainingRuns++;
      }
      if (report.injuries && report.injuries.length) {
        if (outLog) outLog.injuries = outLog.injuries.concat(report.injuries);
        Competition.ensureLineup(state, state.orgs[state.clubId]);
        report.injuries.forEach(function (inj) {
          addNews(state, 'squad', 'Injury setback: ' + inj.nick,
            inj.nick + ' suffered ' + String(inj.reason || inj.type || 'strain').toLowerCase() + ' in intense training and is sidelined for ' + inj.days + ' days. Adjust intensity or Recovery facilities.',
            { orgId: state.clubId, importance: 4 });
        });
      }
      if (report.notes && report.notes.length && rng.chance(0.5)) {
        addNews(state, 'training', 'Training report', report.notes[0], { importance: 1 });
      }
    }
    if (d.getUTCDate() === 1) {
      generateSponsors(state, false);
      monthlyNews(state, rng);
    }
    if (state.date.slice(5) >= '12-01' && state.date.slice(5) <= '12-15' && d.getUTCDate() === 1) {
      var n = aiTransfers(state, rng);
      if (n) addNews(state, 'market', 'Transfer window activity', n + ' signings completed as the December window opened.', { importance: 2 });
    }
    if (state.date.slice(5) >= '06-01' && state.date.slice(5) <= '06-15' && d.getUTCDate() === 1) {
      var n2 = aiTransfers(state, rng);
      if (n2) addNews(state, 'market', 'Mid-season signings', n2 + ' roster moves were completed across the ecosystem.', { importance: 2 });
    }
  }

  G.splitInfo = function (state) {
    state = state || G.state;
    if (!state) return { split: 1, name: 'Split 1 — Kickoff', endDate: '2027-04-05' };
    var y = state.season;
    if (state.date < y + '-04-05') return { split: 1, name: 'Split 1 — Kickoff & Masters 1', endDate: y + '-04-05' };
    if (state.date < y + '-07-10') return { split: 2, name: 'Split 2 — Cups & Masters 2', endDate: y + '-07-10' };
    return { split: 3, name: 'Split 3 — Finals & Champions', endDate: y + '-10-31' };
  };

  G.advance = function (days) {
    var s = G.state;
    if (!s) return { stopped: true, reason: 'No career loaded.' };
    if (s.pendingMatch) return { stopped: true, reason: 'match', pending: s.pendingMatch };
    days = days || 1;
    var focusDays = days === 'match' ? 220 : days;
    var done = 0, results = [], completions = [];
    var rng = C.RNG('advance|' + s.id + '|' + s.date + '|' + s.matchCounter);
    while (done < focusDays) {
      s.date = C.addDays(s.date, 1);
      done++;
      processDay(s, rng);
      var sim = Competition.simulateDate(s, s.date);
      if (sim.results && sim.results.length) results = results.concat(sim.results);
      if (sim.completed && sim.completed.length) completions = completions.concat(sim.completed);
      if (sim.pending) {
        s.pendingMatch = sim.pending;
        s.pendingCompId = sim.pending.compId;
        var pc = s.comps[sim.pending.compId];
        if (pc && sim.pending.stage == null) {
          if (sim.pending.phase === 'swiss' && pc.swiss.rounds[sim.pending.roundIndex]) sim.pending.stage = pc.swiss.rounds[sim.pending.roundIndex].name;
          else if (sim.pending.phase === 'playoffs' && pc.playoffs) sim.pending.stage = pc.playoffs.rounds[sim.pending.roundIndex].name;
          else if (pc.bracket) sim.pending.stage = pc.bracket.rounds[sim.pending.roundIndex].name;
        }
        break;
      }
      if (s.date >= (s.season + '-10-20') && Competition.seasonComplete(s)) {
        addNews(s, 'world', 'Season complete', 'All ' + s.season + ' competitions are finished. The board review and new season preparation follow.', { importance: 4 });
        break;
      }
      if (s.date >= (s.season + '-11-01')) break;
    }
    G.updateObjectives();
    var summary = { stopped: !!s.pendingMatch, pending: s.pendingMatch, days: done, results: results, completions: completions };
    G.save(true);
    if (G.onAdvance) G.onAdvance(summary);
    return summary;
  };

  G.skipTime = function (mode, opts) {
    var s = G.state;
    if (!s) return { ok: false, reason: 'No career loaded.' };
    opts = opts || {};
    var org = G.org();
    var fromDate = s.date, budgetStart = org ? org.budget : 0;
    var autoResolve = !!opts.autoResolveMatches;
    var splitTarget = G.splitInfo(s);
    var outLog = {
      ok: true, mode: mode, fromDate: fromDate, toDate: fromDate, days: 0,
      userMatches: [], aiMatchesCount: 0, trainingRuns: 0,
      injuries: [], recoveries: [], offersReceived: [],
      completions: [], budgetStart: budgetStart, budgetEnd: budgetStart,
      netFinance: 0, stopReason: null, pendingMatch: null, seasonComplete: false
    };
    var maxDays = mode === 'day' ? 1 : mode === 'week' ? 7 : mode === 'match' ? 240 : mode === 'event' ? 120 : 380;
    var rng = C.RNG('skip|' + mode + '|' + s.id + '|' + s.date + '|' + s.matchCounter);

    if (s.pendingMatch) {
      if (autoResolve) {
        var preSer = G.resolveMatch();
        if (preSer) {
          var preOppId = preSer.teamA === s.clubId ? preSer.teamB : preSer.teamA;
          var preComp = s.comps[preSer.compId];
          outLog.userMatches.push({
            comp: preComp ? preComp.short : 'Match', stage: preSer.stage || '',
            oppName: s.orgs[preOppId] ? s.orgs[preOppId].name : preOppId,
            score: (preSer.teamA === s.clubId ? preSer.scoreA : preSer.scoreB) + ':' + (preSer.teamA === s.clubId ? preSer.scoreB : preSer.scoreA),
            won: preSer.winner === s.clubId, date: preSer.date
          });
        }
      } else {
        outLog.pendingMatch = s.pendingMatch;
        outLog.stopReason = 'pending_match';
        return outLog;
      }
    }

    while (outLog.days < maxDays) {
      if (Competition.seasonComplete(s) && s.date >= (s.season + '-10-20')) {
        outLog.seasonComplete = true;
        outLog.stopReason = 'season_complete';
        break;
      }
      if (mode === 'split' && s.date >= splitTarget.endDate) {
        outLog.stopReason = 'split_complete';
        break;
      }
      if (s.date >= (s.season + '-11-01')) {
        outLog.seasonComplete = Competition.seasonComplete(s);
        outLog.stopReason = 'season_end';
        break;
      }
      s.date = C.addDays(s.date, 1);
      outLog.days++;
      var prevOffers = outLog.offersReceived.length;
      var prevInjuries = outLog.injuries.length;
      processDay(s, rng, outLog);
      var sim = Competition.simulateDate(s, s.date);
      if (sim.results && sim.results.length) outLog.aiMatchesCount += sim.results.length;
      if (sim.completed && sim.completed.length) {
        sim.completed.forEach(function (cid) {
          var comp = s.comps[cid];
          if (comp) outLog.completions.push({ id: cid, name: comp.name, championName: comp.champion && s.orgs[comp.champion] ? s.orgs[comp.champion].name : null });
        });
      }
      if (sim.pending) {
        s.pendingMatch = sim.pending;
        s.pendingCompId = sim.pending.compId;
        var pc = s.comps[sim.pending.compId];
        if (pc && sim.pending.stage == null) {
          if (sim.pending.phase === 'swiss' && pc.swiss.rounds[sim.pending.roundIndex]) sim.pending.stage = pc.swiss.rounds[sim.pending.roundIndex].name;
          else if (sim.pending.phase === 'playoffs' && pc.playoffs) sim.pending.stage = pc.playoffs.rounds[sim.pending.roundIndex].name;
          else if (pc.bracket) sim.pending.stage = pc.bracket.rounds[sim.pending.roundIndex].name;
        }
        if (autoResolve && (mode === 'split' || mode === 'season')) {
          var ser = G.resolveMatch();
          if (ser) {
            var oid = ser.teamA === s.clubId ? ser.teamB : ser.teamA;
            outLog.userMatches.push({
              comp: pc ? pc.short : 'Match', stage: ser.stage || '',
              oppName: s.orgs[oid] ? s.orgs[oid].name : oid,
              score: (ser.teamA === s.clubId ? ser.scoreA : ser.scoreB) + ':' + (ser.teamA === s.clubId ? ser.scoreB : ser.scoreA),
              won: ser.winner === s.clubId, date: ser.date
            });
          }
        } else {
          outLog.pendingMatch = s.pendingMatch;
          outLog.stopReason = 'pending_match';
          break;
        }
      }
      if (mode === 'event') {
        if (outLog.offersReceived.length > prevOffers) { outLog.stopReason = 'incoming_offer'; break; }
        if (outLog.injuries.length > prevInjuries) { outLog.stopReason = 'injury'; break; }
        if (sim.completed && sim.completed.length) { outLog.stopReason = 'competition_done'; break; }
      }
      if (Competition.seasonComplete(s) && s.date >= (s.season + '-10-20')) {
        outLog.seasonComplete = true;
        outLog.stopReason = 'season_complete';
        addNews(s, 'world', 'Season complete', 'All ' + s.season + ' competitions are finished. Open Season Review to prepare the next campaign.', { importance: 4 });
        break;
      }
      if ((mode === 'split' || mode === 'season') && org && org.budget < -600000 && !opts.ignoreInsolvency) {
        outLog.stopReason = 'financial_alert';
        break;
      }
    }
    G.updateObjectives();
    outLog.toDate = s.date;
    outLog.budgetEnd = org ? org.budget : 0;
    outLog.netFinance = outLog.budgetEnd - outLog.budgetStart;
    G.save(true);
    if (G.onAdvance) G.onAdvance(outLog);
    return outLog;
  };

  G.advanceToMatch = function () {
    var s = G.state;
    if (!s) return null;
    if (s.pendingMatch) return s.pendingMatch;
    var guard = 0;
    while (!s.pendingMatch && guard < 240) {
      var r = G.advance(7);
      guard += 7;
      if (r.stopped) break;
      if (s.date >= (s.season + '-11-01')) break;
    }
    return s.pendingMatch;
  };

  G.resolveMatch = function () {
    var s = G.state;
    if (!s || !s.pendingMatch) return null;
    var pending = s.pendingMatch;
    var comp = s.comps[pending.compId];
    // apply current tactics / lineup immediately before kick-off
    var org = G.org();
    Competition.ensureLineup(s, org);
    var series = Competition.playPending(s, pending);
    s.pendingMatch = null;
    s.pendingCompId = null;
    if (series) {
      // lineup streak objective
      var key = (org.lineup || []).slice().sort().join('|');
      if (s.flags.lastLineup === key) s.flags.sameLineupStreak = (s.flags.sameLineupStreak || 0) + 1;
      else { s.flags.lastLineup = key; s.flags.sameLineupStreak = 1; }
      s.userMatches.unshift({
        id: series.id, date: series.date, compId: comp ? comp.id : null, comp: comp ? comp.name : 'Competition',
        stage: series.stage || (pending.stage || ''), teamA: series.teamA, teamB: series.teamB,
        winner: series.winner, scoreA: series.scoreA, scoreB: series.scoreB,
        userWon: series.winner === s.clubId, bo: series.bo, maps: (series.maps || []).map(function (m) {
          return { map: m.map, scoreA: m.scoreA, scoreB: m.scoreB };
        })
      });
      if (s.userMatches.length > 80) s.userMatches.length = 80;
      s.manager.xp += series.winner === s.clubId ? 6 : 2;
      if (series.winner === s.clubId) s.flags.seasonWins = (s.flags.seasonWins || 0) + 1;
      else s.flags.seasonLosses = (s.flags.seasonLosses || 0) + 1;
      s.lastReport = series;
      addNews(s, 'user', series.winner === s.clubId ? 'Victory: ' + (comp ? comp.short : 'series') : 'Defeat: ' + (comp ? comp.short : 'series'),
        series.analysis ? series.analysis.verdict : 'Series complete.', { orgId: s.clubId, importance: 4, compId: comp ? comp.id : null });
    }
    G.updateObjectives();
    G.save(true);
    return series;
  };

  G.skipMatchSim = G.resolveMatch;

  /* ------------------------------------------------------------------
     FINANCIAL BREAKDOWN & WARNINGS
  ------------------------------------------------------------------ */
  G.financeBreakdown = function () {
    var s = G.state, org = G.org();
    if (!s || !org) return null;
    var sum = G.sponsorSummary() || { annual: 0, upcoming: 0, remaining: 0, active: [] };
    var annualPayroll = G.payroll(org);
    var annualStaff = (org.staff || []).reduce(function (n, id) {
      var st = s.staff[id];
      return n + (st ? (st.salary || 0) : 0);
    }, 0);
    var fac = org.facilities || {};
    var facSum = (fac.training || 1) + (fac.recovery || 1) + (fac.analysis || 1) + (fac.academy || 1);
    var weeklyOps = 4500 + facSum * 1800;
    var commercialWeekly = (org.partner ? 11500 : 3800) + Math.round((org.rep || 50) * 145);
    var monthlyIncome = Math.round((sum.annual || 0) / 12 + (commercialWeekly * 52) / 12);
    var monthlyPayroll = Math.round(annualPayroll / 12);
    var monthlyStaff = Math.round(annualStaff / 12);
    var monthlyOps = Math.round((weeklyOps * 52) / 12);
    var monthlyExpenses = monthlyPayroll + monthlyStaff + monthlyOps;
    var monthlyNet = monthlyIncome - monthlyExpenses;
    var payrollCap = Math.max(450000, Math.round(monthlyIncome * 12 * 0.72));
    var remainingPayrollBudget = payrollCap - annualPayroll;

    var incomeCategories = { sponsorship: 0, prize: 0, commercial: 0, transfers: 0, other: 0 };
    var expenseCategories = { payroll: 0, staff: 0, operations: 0, transfers: 0, facilities: 0, scouting: 0, severance: 0 };
    (s.financeLedger || []).forEach(function (entry) {
      var cat = entry.category || entry.type || '';
      var lines = entry.lines && entry.lines.length ? entry.lines : [{ label: entry.note, value: entry.total }];
      lines.forEach(function (l) {
        var v = l.value || 0;
        var lbl = String(l.label || '').toLowerCase();
        if (v >= 0) {
          if (cat === 'sponsorship' || lbl.indexOf('sponsor') >= 0) incomeCategories.sponsorship += v;
          else if (cat === 'prize' || lbl.indexOf('prize') >= 0) incomeCategories.prize += v;
          else if (cat === 'transfer' || lbl.indexOf('sale') >= 0) incomeCategories.transfers += v;
          else if (lbl.indexOf('commercial') >= 0 || lbl.indexOf('merch') >= 0) incomeCategories.commercial += v;
          else incomeCategories.other += v;
        } else {
          var av = Math.abs(v);
          if (lbl.indexOf('player wage') >= 0 || lbl.indexOf('signing bonus') >= 0) expenseCategories.payroll += av;
          else if (cat === 'staff' || lbl.indexOf('staff') >= 0) expenseCategories.staff += av;
          else if (cat === 'facilities' || lbl.indexOf('facility') >= 0) expenseCategories.facilities += av;
          else if (cat === 'scouting' || lbl.indexOf('scouting') >= 0) expenseCategories.scouting += av;
          else if (cat === 'severance' || lbl.indexOf('severance') >= 0) expenseCategories.severance += av;
          else if (cat === 'transfer' || lbl.indexOf('transfer fee') >= 0) expenseCategories.transfers += av;
          else expenseCategories.operations += av;
        }
      });
    });

    var warnings = [];
    if (org.budget < 0) {
      warnings.push({
        sev: 'bad', code: 'insolvent', page: 'finances',
        title: 'Negative cash balance',
        body: 'Club funds are below zero (' + C.money(org.budget) + '). Sign sponsors, sell surplus players in Transfers, or release high earners to stabilize cashflow.'
      });
    } else if (monthlyNet < 0 && org.budget / Math.max(1, -monthlyNet) < 2.5) {
      warnings.push({
        sev: 'warn', code: 'low_runway', page: 'finances',
        title: 'Low cash runway (< 3 months)',
        body: 'At your current monthly deficit (' + C.money(monthlyNet) + '/mo), reserves will run out within three months. Secure commercial deals in Finances or trim wages.'
      });
    }
    if (remainingPayrollBudget < 0) {
      warnings.push({
        sev: 'warn', code: 'over_cap', page: 'squad',
        title: 'Payroll above sustainable guideline',
        body: 'Player wages (' + C.money(annualPayroll) + '/yr) exceed the sustainable benchmark (' + C.money(payrollCap) + '/yr). Transfer-list high earners or increase sponsor income.'
      });
    }
    if (!(sum.active || []).length) {
      warnings.push({
        sev: 'warn', code: 'no_sponsors', page: 'finances',
        title: 'No active sponsorship deals',
        body: 'Commercial sponsor income is currently $0. Open Sponsorship Offers below to sign recurring revenue contracts.'
      });
    }

    return {
      budget: org.budget,
      balance: org.budget,
      monthlyIncome: monthlyIncome,
      monthlyExpenses: monthlyExpenses,
      monthlyNet: monthlyNet,
      annualPayroll: annualPayroll,
      annualStaff: annualStaff,
      payrollCap: payrollCap,
      remainingPayrollBudget: remainingPayrollBudget,
      sponsorshipAnnual: sum.annual || 0,
      sponsorshipNext30: sum.upcoming || 0,
      upcomingCommitments: monthlyExpenses,
      incomeCategories: incomeCategories,
      expenseCategories: expenseCategories,
      warnings: warnings
    };
  };

  /* ------------------------------------------------------------------
     SEASON ROLLOVER & MAP POOL ROTATION
  ------------------------------------------------------------------ */
  function rotateMapPool(state, rng) {
    var pool = C.normalizePool(state.settings && state.settings.mapPool);
    var reserves = C.MAPS.map(function (m) { return m.name; }).filter(function (name) { return pool.indexOf(name) < 0; });
    if (!reserves.length) return null;
    var outMap = rng.pick(pool);
    var inMap = rng.pick(reserves);
    var nextPool = pool.map(function (m) { return m === outMap ? inMap : m; });
    state.settings.mapPool = C.normalizePool(nextPool);
    state.mapPrefs = state.mapPrefs || { picks: [], bans: [] };
    state.mapPrefs.picks = (state.mapPrefs.picks || []).filter(function (m) { return state.settings.mapPool.indexOf(m) >= 0; });
    state.mapPrefs.bans = (state.mapPrefs.bans || []).filter(function (m) { return state.settings.mapPool.indexOf(m) >= 0; });
    Object.keys(state.orgs || {}).forEach(function (oid) {
      var o = state.orgs[oid];
      if (!o) return;
      o.mapPrep = o.mapPrep || {};
      if (o.mapPrep[inMap] == null) o.mapPrep[inMap] = 48;
    });
    return { out: outMap, in: inMap };
  }

  function endSeason(s) {
    processSponsorPayments(s);
    var oldSeason = s.season, newSeason = oldSeason + 1;
    var rng = C.RNG('end|' + s.id + '|' + oldSeason);
    var org = s.orgs[s.clubId];
    evaluateSponsorObjectives(s, org, false);
    var objs = s.objectives || [];
    var done = objs.filter(function (o) { return o.status === 'done'; }).length;
    var failed = objs.filter(function (o) { return o.status === 'failed' || (o.status === 'active' && !o.done); }).length;
    objs.forEach(function (o) { if (o.status === 'active') o.status = o.done ? 'done' : 'failed'; });

    var comps = Object.keys(s.comps).map(function (id) { return s.comps[id]; }).filter(function (c) { return c.status === 'done'; });
    var champs = comps.filter(function (c) { return c.type === 'champions'; })[0];
    var awards = Engine.seasonAwards(s, s.orgs, s.comps);
    var userTrophies = (s.manager.trophies || []).filter(function (t) { return t.season === oldSeason; });
    s.history.seasons.push({
      season: oldSeason, clubId: s.clubId, clubName: org.name, clubRep: org.rep,
      champion: champs ? champs.champion : null,
      championName: champs && s.orgs[champs.champion] ? s.orgs[champs.champion].name : null,
      kickoffPos: s.flags.kickoffPos || null,
      bestCupPos: s.flags.bestCupPos || null,
      championsQualified: !!s.flags.championsQualified,
      mastersPlayed: !!s.flags.masters1Qualified,
      budget: org.budget, confidence: s.manager.confidence,
      wins: s.manager.wins, losses: s.manager.losses,
      trophies: userTrophies.slice(),
      objectives: { done: done, failed: failed },
      awards: { mvp: awards.mvp, risingStar: awards.risingStar }
    });
    s.history.awards.push({ season: oldSeason, mvp: awards.mvp, risingStar: awards.risingStar });
    s.manager.xp += done * 40 + userTrophies.length * 35;
    s.manager.rep = C.clamp((s.manager.rep || 50) + done * 0.7 + userTrophies.length * 1.6 - failed * 0.5, 30, 99);
    s.manager.age += 1;
    if (done === 0 && failed > 1) {
      s.manager.confidence = Math.max(5, s.manager.confidence - 10);
      s.manager.boardNotes.push({ season: oldSeason, note: 'No objectives achieved. The board demands a credible plan next season.' });
    }

    // retirements, ageing, stat archiving
    var retiredCount = 0;
    Object.keys(s.players).forEach(function (id) {
      var p = s.players[id];
      if (!p || p.retired) return;
      if (p.stats && p.stats.maps > 0) {
        p.history = p.history || [];
        p.history.push({
          season: oldSeason, orgId: p.org,
          orgName: p.org && s.orgs[p.org] ? s.orgs[p.org].name : 'Free Agent',
          level: p.level, stats: clone(p.stats)
        });
      }
      p.stats = Engine.emptyStats();
      p.injury = null;
      p.expiryWarned = false;
      p.age += 1;
      var chance = p.age <= 26 ? 0.015 : p.age <= 28 ? 0.07 : p.age <= 30 ? 0.18 : p.age <= 32 ? 0.42 : p.age <= 34 ? 0.68 : 0.92;
      if ((!p.org && !p.academy && p.age >= 28 && rng.chance(chance)) || ((p.org || p.academy) && rng.chance(chance))) {
        var o = p.org ? s.orgs[p.org] : null;
        if (o) {
          o.roster = (o.roster || []).filter(function (x) { return x !== p.id; });
          o.lineup = (o.lineup || []).filter(function (x) { return x !== p.id; });
          if (s.academy[o.id]) s.academy[o.id] = s.academy[o.id].filter(function (x) { return x !== p.id; });
        }
        p.retired = true;
        p.status = 'retired';
        p.retiredSeason = oldSeason;
        p.org = null;
        p.transferListed = false;
        delete p.askingPrice;
        retiredCount++;
        s.history.retirees.push({
          playerId: p.id, nick: p.nick, name: p.name, role: p.role, cc: p.cc,
          age: p.age, peak: p.peak || p.level, org: o ? o.id : null, season: oldSeason,
          trophies: (p.awards || []).length
        });
        if (o && o.isUser) {
          addNews(s, 'squad', 'RETIREMENT: ' + p.nick,
            p.nick + ' retires at ' + p.age + ' after a career with a peak overall of ' + (p.peak || p.level) + '. The squad loses ' + (p.igl ? 'its in-game leader and ' : '') + 'a ' + p.role.toLowerCase() + '.',
            { orgId: o.id, importance: 4 });
        }
        return;
      }
      if (!p.org && !p.academy) return;
      if (p.age <= 22) {
        var boost = rng.float(0.2, 1.1);
        ['aim', 'mechanics', 'gamesense'].forEach(function (k) { p.attrs[k] = C.clamp(p.attrs[k] + boost * rng.float(0.4, 1.2), 20, 99); });
      } else if (p.age >= 28) {
        var drop = rng.float(0.2, 1.2) * (p.age >= 31 ? 1.6 : 1);
        ['mechanics', 'aim', 'consistency'].forEach(function (k) { p.attrs[k] = C.clamp(p.attrs[k] - drop * rng.float(0.4, 1.2), 20, 99); });
      }
      p.level = Engine.overall(p);
      p.peak = Math.max(p.peak || 0, p.level);
      p.wage = Engine.wageFor(p);
      p.value = Engine.valueFor(p);
      if (p.potential < p.level) p.potential = p.level;
      if (p.age > 30) p.potential = Math.max(p.level, p.potential - rng.int(0, 2));
    });

    // contracts
    Object.keys(s.players).forEach(function (id) {
      var p = s.players[id];
      if (!p || p.retired || !p.org) return;
      if (p.contractEnd <= oldSeason) {
        var o = s.orgs[p.org];
        if (!o) { p.org = null; return; }
        var renew = o.isUser ? false : rng.chance(o.rep > 80 ? 0.72 : 0.52);
        if (renew) {
          p.contractEnd = newSeason + rng.int(1, 3);
          p.wage = Engine.wageFor(p);
        } else {
          o.roster = (o.roster || []).filter(function (x) { return x !== p.id; });
          o.lineup = (o.lineup || []).filter(function (x) { return x !== p.id; });
          if (s.academy[o.id]) s.academy[o.id] = s.academy[o.id].filter(function (x) { return x !== p.id; });
          p.org = null;
          p.status = 'free agent';
          p.contractEnd = newSeason;
          p.transferListed = false; delete p.askingPrice;
          if (o.isUser) {
            addNews(s, 'squad', 'DEPARTURE: ' + p.nick, p.nick + ' leaves as a free agent after failing to agree a new contract. Renew contracts earlier next time.', { orgId: o.id, importance: 4 });
          }
        }
      }
    });

    // youth intake
    var youthCount = 0;
    Object.keys(s.orgs).forEach(function (oid) {
      var o = s.orgs[oid];
      if (o.status === 'inactive') return;
      var rr = C.RNG('youth|' + oid + '|' + newSeason);
      s.academy[o.id] = s.academy[o.id] || [];
      var acadLvl = (o.facilities && o.facilities.academy) || 2;
      var count = o.isUser ? (acadLvl >= 4 ? 4 : 3) : (o.partner ? 2 : 1);
      for (var i = 0; i < count; i++) {
        var y = Engine.genPlayer(rr, {
          cc: natForSub(o.sub) || natForRegion(o.region, rr), role: rr.pick(C.ROLES), age: rr.int(16, 18),
          tier: rr.float(3.0, 5.2) + (o.rep || 60) / 70 + (acadLvl - 2) * 0.18, org: o.id, season: newSeason, academy: true, sim: true
        });
        y.conf = 'SIM';
        y.note = 'Generated youth intake for ' + o.name + '.';
        y.src = 'Academy intake';
        y.academy = true; y.status = 'academy';
        addPlayer(s, y);
        s.academy[o.id].push(y.id);
        youthCount++;
        if (s.academy[o.id].length > 12) {
          var oldest = s.academy[o.id].map(function (id2) { return s.players[id2]; }).filter(Boolean).sort(function (a, b) { return b.age - a.age; })[0];
          if (oldest) { s.academy[o.id] = s.academy[o.id].filter(function (x) { return x !== oldest.id; }); delete s.players[oldest.id]; }
        }
      }
      if (o.isUser) {
        var bestY = s.academy[o.id].map(function (id3) { return s.players[id3]; }).filter(Boolean)
          .sort(function (a, b) { return (b.potential || 0) - (a.potential || 0); })[0];
        if (bestY) addNews(s, 'academy', 'Youth intake: ' + bestY.nick + ' headlines the class',
          'New prospects joined the academy. ' + bestY.nick + ' (' + bestY.age + ', ' + bestY.role + ', potential ' + Engine.potentialStars(bestY) + ' stars) is the standout. Promote carefully: minutes at 18 accelerate development.',
          { orgId: o.id, importance: 3 });
      }
    });

    // academy level refresh
    Object.keys(s.academy).forEach(function (oid) {
      (s.academy[oid] || []).forEach(function (id) {
        var p = s.players[id];
        if (!p) return;
        p.level = Engine.overall(p);
      });
    });

    // AI squad repair
    Object.keys(s.orgs).forEach(function (oid) {
      var o = s.orgs[oid];
      if (o.status === 'inactive') return;
      var rr = C.RNG('repair|' + oid + '|' + newSeason);
      while ((o.roster || []).length < 5) assignFiller(s, o, C.ROLES[(o.roster || []).length % 4], rr, false);
      ensureRoleCoverage(s, o, rr);
    });

    // free agent refresh
    var faRng = C.RNG('fa-refresh|' + newSeason);
    for (var f = 0; f < 14; f++) {
      var fa = Engine.genPlayer(faRng, {
        cc: faRng.pick(Object.keys(C.COUNTRIES)), role: faRng.pick(C.ROLES), age: faRng.int(17, 27),
        tier: faRng.float(3.6, 7.4), season: newSeason, sim: true
      });
      fa.org = null; fa.status = 'free agent'; fa.conf = 'SIM';
      fa.note = 'Fictional free agent generated for the ' + newSeason + ' market.';
      fa.src = 'Free agent market';
      addPlayer(s, fa);
    }

    // sponsor / staff market refresh (fixed s.staff[st.id] bug!)
    var smRng = C.RNG('sm-refresh|' + newSeason);
    s.staffMarket = [];
    for (var sm = 0; sm < 8; sm++) {
      var st = Engine.genStaff(smRng, { role: ['Head Coach', 'Assistant Coach', 'Analyst', 'Performance Coach', 'Scout'][sm % 5], cc: smRng.pick(Object.keys(C.COUNTRIES)), grade: smRng.float(5.2, 8.6) });
      st.salary = Math.round(45000 + st.grade * st.grade * 2400);
      st.org = null;
      s.staff[st.id] = st;
      s.staffMarket.push(st.id);
    }

    // seasonal map pool rotation
    var mapRot = rotateMapPool(s, rng);

    // reset season-scoped stats while preserving rosters, cash, logos and history
    Object.keys(s.orgs).forEach(function (oid) {
      var o = s.orgs[oid];
      o.form = [];
      o.points = Math.round((o.rep || 50) * 12);
      o.seasonWins = 0; o.seasonLosses = 0;
      o.mapStats = {};
      o.lineup = userLineup(s, o);
    });

    s.history.champions = s.history.champions.filter(function (x) { return x.season !== oldSeason || champs; });
    s.manager.levelInfo = Engine.managerLevel(s.manager.xp);
    s.flags = {
      oqStage: 0, kickoffPos: null, kickoffQualified: false, masters1Qualified: false,
      bestCupPos: null, mastersPlayoffWin: 0, masters2Qualified: false, championsQualified: false,
      prospectsSigned: 0, sameLineupStreak: 0, seasonEarnings: 0, budgetPositive: 0, sponsorValue: 0,
      pacificPlayoffDone: false, lastLineup: null, seasonWins: 0, seasonLosses: 0, sponsorLegacyMigrated: true
    };
    s.season = newSeason;
    s.seasonStart = Competition.seasonStart(newSeason);
    s.date = s.seasonStart;
    s.comps = {};
    s.qualifiers = { kickoff: {}, cup1: {}, cup2: {}, masters1: {}, masters2: {}, champions: {}, lcq: {} };
    s.pendingMatch = null;
    s.lastReport = null;
    s.incomingOffers = [];
    s.trainingReports = [];
    s.trainingWeeks = 0;
    s.matchCounter = 1;
    s.sponsorOffers = [];
    generateSponsors(s, true);
    syncSponsorValue(s, s.orgs[s.clubId]);
    Competition.initSeason(s);
    Competition.ensureSchedule(s, s.date);
    s.objectives = Engine.generateObjectives(s, s.orgs[s.clubId]);
    s.manager.confidence = Engine.boardConfidence(s, s.orgs[s.clubId]);
    s.lastSeasonSummary = {
      season: oldSeason,
      nextSeason: newSeason,
      championName: champs && s.orgs[champs.champion] ? s.orgs[champs.champion].name : null,
      userTrophies: userTrophies.slice(),
      objsDone: done,
      objsFailed: failed,
      confidence: s.manager.confidence,
      retiredCount: retiredCount,
      youthCount: youthCount,
      mapRotation: mapRot,
      budget: org.budget,
      payroll: G.payroll(org)
    };
    s.financeLedger.unshift({ date: s.date, total: 0, lines: [], note: 'Season ' + newSeason + ' begins' });

    addNews(s, 'world', 'Season ' + newSeason + ' begins',
      'The new VCT season opens on ' + C.fmtDate(s.date) + '. ' +
      (mapRot ? 'Map pool update: ' + mapRot.out + ' rotated out, ' + mapRot.in + ' entered active duty. ' : '') +
      'Contracts, retirements and youth intakes have reshaped every roster.',
      { importance: 5 });
    if (userTrophies.length) {
      addNews(s, 'trophy', 'Trophy cabinet: ' + userTrophies.length + ' title(s) in ' + oldSeason,
        userTrophies.map(function (t) { return t.name; }).join(', ') + ' are now part of your legacy.', { orgId: s.clubId, importance: 4 });
    }
  }

  G.seasonTransition = function () {
    var s = G.state;
    if (!s) return false;
    endSeason(s);
    G.save(true);
    return { ok: true, nextSeason: s.season, summary: s.lastSeasonSummary };
  };

  /* ------------------------------------------------------------------
     SELF-TEST
  ------------------------------------------------------------------ */
  G.selfTest = function (seasons) {
    seasons = seasons || 2;
    var results = { ok: true, checks: [], errors: [], seasons: [] };
    function check(name, pass, detail) {
      results.checks.push({ name: name, pass: !!pass, detail: detail || '' });
      if (!pass) results.ok = false;
    }
    try {
      var saved = G.state;
      var testState = G.newCareer({
        managerName: 'Test Manager', managerNat: 'gb', difficulty: 'Normal',
        mode: 'existing', clubId: 'sentinels', guided: false, seed: 424242, noSave: true
      });
      testState.__headless = true;
      check('Career created', !!testState && !!testState.clubId);
      check('32 partners present', Object.keys(testState.orgs).filter(function (id) { return testState.orgs[id].partner; }).length === 32,
        Object.keys(testState.orgs).filter(function (id) { return testState.orgs[id].partner; }).length + ' partners');
      check('Player database materialised', Object.keys(testState.players).length > 250, Object.keys(testState.players).length + ' players');
      check('User roster has five', G.roster(testState.orgs[testState.clubId]).length >= 5);
      check('Starting lineup valid', (testState.orgs[testState.clubId].lineup || []).length === 5);
      var startSeason = testState.season;
      for (var sn = 0; sn < seasons; sn++) {
        var guard = 0, matches = 0;
        while (guard < 380) {
          guard++;
          if (testState.pendingMatch) {
            var series = G.resolveMatch();
            if (series) matches++;
            else break;
          } else {
            G.advance(7);
          }
          if (testState.season !== startSeason + sn) break;
          if (testState.date >= (testState.season + '-11-01')) break;
        }
        check('Season ' + testState.season + ' progressed', testState.date > (testState.season + '-02-01'), testState.date);
        check('Season ' + testState.season + ' user matches simulated', matches > 0 || !testState.orgs[testState.clubId].partner, matches + ' matches');
        check('Season ' + testState.season + ' all rosters legal', Object.keys(testState.orgs).every(function (id) {
          var o = testState.orgs[id];
          if (o.status === 'inactive') return true;
          return (o.roster || []).length >= 5;
        }));
        check('Season ' + testState.season + ' has a Kickoff champion', Object.keys(testState.comps).some(function (id) {
          var c = testState.comps[id];
          return c.type === 'kickoff' && c.status === 'done' && !!c.champion;
        }));
        check('Season ' + testState.season + ' has a Champions champion', Object.keys(testState.comps).some(function (id) {
          var c = testState.comps[id];
          return c.type === 'champions' && c.status === 'done' && !!c.champion;
        }));
        results.seasons.push({ season: testState.season, date: testState.date, matches: matches, budget: testState.orgs[testState.clubId].budget, confidence: testState.manager.confidence });
        if (sn < seasons - 1) {
          G.seasonTransition();
          check('Transition to ' + testState.season + ' completed', testState.season === startSeason + sn + 1, 'season ' + testState.season);
        }
      }
      check('History recorded', testState.history.seasons.length >= 1, testState.history.seasons.length + ' seasons');
      check('No duplicate player ids', Object.keys(testState.players).length === Object.keys(testState.players).reduce(function (n, id) { return n + 1; }, 0));
      if (saved) G.state = saved;
    } catch (e) {
      results.ok = false;
      results.errors.push(String(e && e.stack || e));
    }
    return results;
  };

  G.DEFAULT_POOL = DEFAULT_POOL;
  G.migrate = migrate;
  return G;
})();
