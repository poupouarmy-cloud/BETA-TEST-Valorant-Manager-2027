/* =====================================================================
   VALORANT MANAGER 2027 — CENTRAL LOCALISATION ENGINE
   Classic script, no modules. The English source text is the lookup key,
   so a screen exists once and every language is served from one dictionary.
   Language packs register themselves through I18N.addPack().
   ===================================================================== */
var I18N = (function () {
  'use strict';

  var KEY = 'vgm27.lang';
  var LANGS = [
    { id: 'en', name: 'English', native: 'English', flag: '🇬🇧', short: 'EN' },
    { id: 'fr', name: 'French', native: 'Français', flag: '🇫🇷', short: 'FR' },
    { id: 'es', name: 'Spanish', native: 'Español', flag: '🇪🇸', short: 'ES' },
    { id: 'pt', name: 'Portuguese', native: 'Português', flag: '🇧🇷', short: 'PT' },
    { id: 'ko', name: 'Korean', native: '한국어', flag: '🇰🇷', short: 'KO' },
    { id: 'ja', name: 'Japanese', native: '日本語', flag: '🇯🇵', short: 'JA' },
    { id: 'zh', name: 'Chinese', native: '中文', flag: '🇨🇳', short: 'ZH' }
  ];

  var packs = { en: { strings: {}, patterns: [] } };
  var current = 'en';
  var chosen = false;
  var warned = {};

  var MONTHS = {
    en: { short: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], long: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'], days: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'], daysShort: ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'] },
    fr: { short: ['janv.', 'févr.', 'mars', 'avr.', 'mai', 'juin', 'juil.', 'août', 'sept.', 'oct.', 'nov.', 'déc.'], long: ['janvier', 'février', 'mars', 'avril', 'mai', 'juin', 'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'], days: ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'], daysShort: ['DIM', 'LUN', 'MAR', 'MER', 'JEU', 'VEN', 'SAM'] },
    es: { short: ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'], long: ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'], days: ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'], daysShort: ['DOM', 'LUN', 'MAR', 'MIÉ', 'JUE', 'VIE', 'SÁB'] },
    pt: { short: ['jan', 'fev', 'mar', 'abr', 'mai', 'jun', 'jul', 'ago', 'set', 'out', 'nov', 'dez'], long: ['janeiro', 'fevereiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'], days: ['domingo', 'segunda-feira', 'terça-feira', 'quarta-feira', 'quinta-feira', 'sexta-feira', 'sábado'], daysShort: ['DOM', 'SEG', 'TER', 'QUA', 'QUI', 'SEX', 'SÁB'] },
    ko: { short: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'], long: ['1월', '2월', '3월', '4월', '5월', '6월', '7월', '8월', '9월', '10월', '11월', '12월'], days: ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'], daysShort: ['일', '월', '화', '수', '목', '금', '토'] },
    ja: { short: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'], long: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'], days: ['日曜日', '月曜日', '火曜日', '水曜日', '木曜日', '金曜日', '土曜日'], daysShort: ['日', '月', '火', '水', '木', '金', '土'] },
    zh: { short: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'], long: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月', '十二月'], days: ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'], daysShort: ['日', '一', '二', '三', '四', '五', '六'] }
  };

  function langMeta(id) {
    for (var i = 0; i < LANGS.length; i++) if (LANGS[i].id === id) return LANGS[i];
    return LANGS[0];
  }
  function hasPack(id) { return !!packs[id] && !!packs[id].strings; }
  function addPack(id, pack) {
    pack = pack || {};
    var strings = pack.strings || {};
    var lower = {};
    for (var k in strings) {
      if (Object.prototype.hasOwnProperty.call(strings, k)) {
        var lk = k.toLowerCase();
        if (!Object.prototype.hasOwnProperty.call(lower, lk)) lower[lk] = strings[k];
      }
    }
    packs[id] = { strings: strings, lower: lower, patterns: pack.patterns || [], plural: pack.plural || {} };
  }
  function extendPack(id, strings, patterns) {
    var old = packs[id] || { strings: {}, patterns: [], plural: {} };
    var merged = {};
    for (var key in old.strings) if (Object.prototype.hasOwnProperty.call(old.strings, key)) merged[key] = old.strings[key];
    for (var next in (strings || {})) if (Object.prototype.hasOwnProperty.call(strings, next)) merged[next] = strings[next];
    // Project-level audit rules take precedence over broad legacy patterns.
    addPack(id, { strings: merged, patterns: (patterns || []).concat(old.patterns), plural: old.plural });
  }
  function load() {
    try {
      if (typeof localStorage !== 'undefined') {
        var v = localStorage.getItem(KEY);
        if (v && langMeta(v).id === v) { current = v; chosen = true; }
      }
    } catch (e) { }
    if (!chosen && typeof navigator !== 'undefined') {
      var nav = (navigator.language || 'en').slice(0, 2).toLowerCase();
      if (nav && hasPack(nav)) current = nav;
    }
    if (typeof document !== 'undefined' && document.documentElement) {
      document.documentElement.lang = current;
      document.documentElement.dir = 'ltr';
    }
  }
  function set(id) {
    if (!hasPack(id)) id = 'en';
    current = id;
    chosen = true;
    try { if (typeof localStorage !== 'undefined') localStorage.setItem(KEY, id); } catch (e) { }
    if (typeof document !== 'undefined' && document.documentElement) {
      document.documentElement.lang = id;
      document.documentElement.dir = 'ltr';
    }
    return current;
  }
  function hasChosen() { return chosen; }
  function get() { return current; }

  function norm(s) {
    return String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
  }
  function lookup(s) {
    var pack = packs[current];
    if (!pack) return null;
    var key = norm(s);
    if (!key) return null;
    if (Object.prototype.hasOwnProperty.call(pack.strings, key)) return pack.strings[key];
    // Labels are often rendered with a trailing colon by the view.
    if (/[:：]$/.test(key)) {
      var k2 = key.replace(/[:：]\s*$/, '');
      if (Object.prototype.hasOwnProperty.call(pack.strings, k2)) return pack.strings[k2] + (key.slice(-1) === '：' ? '：' : ':');
    }
    // Case-insensitive fallback for headings, badges, and short labels.
    if (key.length <= 90) {
      var low = key.toLowerCase();
      if (Object.prototype.hasOwnProperty.call(pack.strings, low)) return pack.strings[low];
      if (pack.lower && Object.prototype.hasOwnProperty.call(pack.lower, low)) return pack.lower[low];
    }
    return null;
  }
  function applyPatterns(s) {
    var pack = packs[current];
    if (!pack || !pack.patterns) return null;
    for (var i = 0; i < pack.patterns.length; i++) {
      var rule = pack.patterns[i];
      if (rule[0].test(s)) return s.replace(rule[0], rule[1]);
    }
    return null;
  }
  function text(s) {
    if (s == null) return s;
    if (current === 'en') return s;
    var raw = String(s);
    var m = /^(\s*)([\s\S]*?)(\s*)$/.exec(raw);
    if (!m) return raw;
    var core = m[2];
    if (!core) return raw;
    var tr = lookup(core);
    if (tr != null) return m[1] + tr + m[3];
    var pat = applyPatterns(core);
    if (pat != null) return m[1] + pat + m[3];
    return raw;
  }
  function t(key, vars) {
    var pack = packs[current] || packs.en;
    var s = pack.strings[key];
    if (s == null) s = (packs.en.strings || {})[key];
    if (s == null) s = key;
    if (vars) s = s.replace(/\{(\w+)\}/g, function (_, k) { return vars[k] != null ? vars[k] : ''; });
    return s;
  }
  function hasKey(key) { return !!(packs[current] && packs[current].strings[key]); }

  var SKIP = { SCRIPT: 1, STYLE: 1, CODE: 1, PRE: 1, TEXTAREA: 1, SVG: 1, PATH: 1 };
  function shouldSkip(el) {
    if (!el) return true;
    if (SKIP[el.tagName]) return true;
    if (el.getAttribute && el.getAttribute('data-no-i18n') != null) return true;
    if (el.closest && el.closest('[data-no-i18n]')) return true;
    return false;
  }
  function apply(root) {
    if (!root || current === 'en') return root;
    var doc = root.ownerDocument || document;
    if (root.nodeType === 3) {
      var nt = text(root.nodeValue);
      if (nt !== root.nodeValue) root.nodeValue = nt;
      return root;
    }
    // Attribute translations first (tooltips, placeholders, titles).
    var nodes = [];
    if (root.querySelectorAll) nodes = root.querySelectorAll('[data-tip],[title],[placeholder],[aria-label],input[type="button"],input[type="submit"]');
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (shouldSkip(el)) continue;
      ['data-tip', 'title', 'placeholder', 'aria-label'].forEach(function (a) {
        var v = el.getAttribute(a);
        if (v && /[A-Za-z]/.test(v)) {
          var nv = text(v);
          if (nv !== v) el.setAttribute(a, nv);
        }
      });
      if (el.tagName === 'INPUT' && (el.type === 'button' || el.type === 'submit')) {
        var iv = el.value; var inv = text(iv);
        if (inv !== iv) el.value = inv;
      }
    }
    // Text nodes.
    if (root.nodeType === 1 && !shouldSkip(root)) {
      var walker = doc.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode: function (node) {
          if (!node.nodeValue || !/[A-Za-z]/.test(node.nodeValue)) return NodeFilter.FILTER_REJECT;
          if (shouldSkip(node.parentElement)) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      });
      var cur;
      while ((cur = walker.nextNode())) {
        var nv2 = text(cur.nodeValue);
        if (nv2 !== cur.nodeValue) cur.nodeValue = nv2;
      }
    }
    return root;
  }

  function money(n) {
    if (n == null || isNaN(n)) return '$0';
    var neg = n < 0; n = Math.abs(n);
    var dec = current === 'fr' || current === 'es' || current === 'pt' ? ',' : '.';
    var s;
    if (n >= 1000000) s = '$' + (n / 1000000).toFixed(n >= 10000000 ? 1 : 2).replace('.', dec) + 'M';
    else if (n >= 1000) s = '$' + Math.round(n / 1000) + 'K';
    else s = '$' + Math.round(n);
    return (neg ? '-' : '') + s;
  }
  function moneyFull(n) {
    var neg = n < 0; n = Math.round(Math.abs(n));
    var sep = (current === 'fr' || current === 'es' || current === 'pt') ? ' ' : ',';
    return (neg ? '-' : '') + '$' + n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, sep);
  }
  function num(n) {
    if (n == null || isNaN(n)) return '0';
    var sep = (current === 'fr' || current === 'es' || current === 'pt') ? ' ' : ',';
    return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, sep);
  }
  function percent(n) {
    var dec = current === 'fr' ? ',' : '.';
    return String(n).replace('.', dec) + '%';
  }
  function ordinal(n) {
    if (current === 'fr') return n + (n === 1 ? 'er' : 'e');
    if (current === 'es') return n + 'º';
    if (current === 'pt') return n + 'º';
    var s = ['th', 'st', 'nd', 'rd'], v = n % 100;
    return n + (s[(v - 20) % 10] || s[v] || s[0]);
  }
  function fmtDate(isoStr, withYear) {
    if (!isoStr) return '—';
    var p = String(isoStr).split('-');
    var d = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2]));
    var m = (MONTHS[current] || MONTHS.en);
    if (current === 'ko' || current === 'ja' || current === 'zh') {
      var y = d.getUTCFullYear(), mo = d.getUTCMonth() + 1, day = d.getUTCDate();
      if (current === 'ko') return y + '년 ' + mo + '월 ' + day + '일';
      return y + '年' + mo + '月' + day + '日';
    }
    return d.getUTCDate() + ' ' + m.short[d.getUTCMonth()] + (withYear !== false ? ' ' + d.getUTCFullYear() : '');
  }
  function fmtDateLong(isoStr) {
    if (!isoStr) return '—';
    var p = String(isoStr).split('-');
    var d = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2]));
    var m = (MONTHS[current] || MONTHS.en);
    if (current === 'ko' || current === 'ja' || current === 'zh') {
      var y = d.getUTCFullYear(), mo = d.getUTCMonth() + 1, day = d.getUTCDate();
      if (current === 'ko') return y + '년 ' + mo + '월 ' + day + '일';
      return y + '年' + mo + '月' + day + '日';
    }
    return m.days[d.getUTCDay()] + ' ' + d.getUTCDate() + ' ' + m.long[d.getUTCMonth()] + ' ' + d.getUTCFullYear();
  }
  function monthShort(i) { var m = MONTHS[current] || MONTHS.en; return m.short[i]; }
  function monthLong(i) { var m = MONTHS[current] || MONTHS.en; return m.long[i]; }
  function weekday(i, short) { var m = MONTHS[current] || MONTHS.en; return short ? m.daysShort[i] : m.days[i]; }

  /* ---- country names -------------------------------------------------
     Intl.DisplayNames ships with every supported browser and gives a
     correct local name for each ISO region code without a second table. */
  var regionNames = null, regionLang = '';
  function countryName(cc) {
    if (!cc) return '-';
    var code = String(cc).toUpperCase();
    try {
      if (!regionNames || regionLang !== current) {
        regionNames = new Intl.DisplayNames([current], { type: 'region' });
        regionLang = current;
      }
      var n = regionNames.of(code);
      if (n && n !== code) return n;
    } catch (e) { }
    return code;
  }

  /* ---- structured match-analysis localisation -------------------------
     Engine.analyse attaches machine-readable codes + variables. When they
     exist we rebuild every sentence in the active language. Older saves
     without codes still fall back to the stored English text. */
  function causeText(c) {
    if (!c || !c.code) return c;
    var key = 'analysis.cause.' + c.code;
    var title = t(key + '.title', c.vars || {});
    var detail = t(key + '.detail', c.vars || {});
    if (title === key + '.title') return c;
    var out = {};
    for (var k in c) out[k] = c[k];
    out.title = title;
    out.detail = detail;
    if (c.fixes) out.fixes = c.fixes.map(function (f) {
      var nf = {}; for (var q in f) nf[q] = f[q];
      nf.label = t('analysis.fix.' + (f.code || f.label), f.vars || {});
      return nf;
    });
    return out;
  }
  function localizeAnalysis(a) {
    if (!a || current === 'en') return a;
    var out = {};
    for (var k in a) out[k] = a[k];
    if (a.causes) out.causes = a.causes.map(causeText);
    if (a.strengths) out.strengths = a.strengths.map(function (s) {
      if (!s || !s.code) return s;
      var v = t('analysis.strength.' + s.code, s.vars || {});
      return v === 'analysis.strength.' + s.code ? (s.text || '') : v;
    });
    if (a.won != null && a.scoreA != null) {
      out.headline = t('analysis.headline.' + (a.won ? 'victory' : 'defeat'), { scoreA: a.scoreA, scoreB: a.scoreB, maps: a.mapTxt || '' });
      var c1 = out.causes && out.causes[0] ? out.causes[0].title.toLowerCase() : t('analysis.fallback.review');
      var c2 = out.causes && out.causes[1] ? out.causes[1].title.toLowerCase() : '';
      if (a.won) {
        var scode = a.strengths && a.strengths[0] && a.strengths[0].code;
        var short = scode ? t('analysis.strength.short.' + scode) : t('analysis.strength.short.execution');
        if (short === 'analysis.strength.short.' + scode) short = t('analysis.strength.short.execution');
        out.verdict = t('analysis.verdict.win', { strength: short, risk: c1 });
      } else {
        out.verdict = t('analysis.verdict.loss', { cause: c1, second: c2 });
      }
    }
    return out;
  }

  load();
  return {
    LANGS: LANGS, addPack: addPack, extendPack: extendPack, hasPack: hasPack, langMeta: langMeta,
    load: load, set: set, get: get, hasChosen: hasChosen, detect: function () { return current; },
    t: t, hasKey: hasKey, text: text, apply: apply, lookup: lookup,
    money: money, moneyFull: moneyFull, num: num, percent: percent, ordinal: ordinal,
    fmtDate: fmtDate, fmtDateLong: fmtDateLong, monthShort: monthShort, monthLong: monthLong, weekday: weekday,
    countryName: countryName,
    localizeAnalysis: localizeAnalysis, causeText: causeText
  };
})();
window.I18N = I18N;
