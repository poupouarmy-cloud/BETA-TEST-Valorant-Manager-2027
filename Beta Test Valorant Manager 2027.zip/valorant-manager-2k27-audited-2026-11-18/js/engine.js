/* =====================================================================
   VALORANT MANAGER 2027 — SIMULATION ENGINE
   Ratings, chemistry, match simulation, training, economy, transfers,
   player generation, objectives and analysis.
   ===================================================================== */
var Engine = (function () {
  'use strict';
  var C = Core;

  var CORE_ATTRS = ['aim', 'mechanics', 'gamesense', 'positioning', 'decision', 'clutch', 'comms', 'teamplay', 'consistency', 'adaptability', 'mental', 'leadership'];
  var ROLE_ATTRS = {
    Duelist: ['entry', 'space', 'aggression', 'opening'],
    Initiator: ['info', 'utility', 'setup', 'sync'],
    Controller: ['smoke', 'mapctrl', 'timing', 'strategy'],
    Sentinel: ['setups', 'anchor', 'mapcover', 'discipline']
  };
  var ATTR_LABELS = {
    aim: 'Aim', mechanics: 'Mechanics', gamesense: 'Game Sense', positioning: 'Positioning', decision: 'Decision Making',
    clutch: 'Clutch', comms: 'Communication', teamplay: 'Teamplay', consistency: 'Consistency', adaptability: 'Adaptability',
    mental: 'Mental', leadership: 'Leadership', entry: 'Entry Fragging', space: 'Space Creation', aggression: 'Aggression',
    opening: 'Opening Duels', info: 'Info Gathering', utility: 'Utility Usage', setup: 'Setup Execution', sync: 'Synchronisation',
    smoke: 'Smoke Placement', mapctrl: 'Map Control', timing: 'Timing', strategy: 'Strategic Understanding',
    setups: 'Defensive Setups', anchor: 'Site Anchoring', mapcover: 'Map Coverage', discipline: 'Defensive Discipline'
  };

  var PERSONALITIES = [
    { id: 'Driven', desc: 'Trains hard, responds well to pressure.', growth: 1.12, morale: 1.0, loyalty: 1.0 },
    { id: 'Calm', desc: 'Stable under pressure. Low variance.', growth: 1.0, morale: 0.85, loyalty: 1.05 },
    { id: 'Volatile', desc: 'Brilliant but streaky. Needs managing.', growth: 1.06, morale: 1.35, loyalty: 0.85 },
    { id: 'Leader', desc: 'Lifts the room. Improves team chemistry.', growth: 1.0, morale: 0.9, loyalty: 1.15 },
    { id: 'Mercenary', desc: 'Motivated by money and ambition.', growth: 1.0, morale: 1.0, loyalty: 0.7 },
    { id: 'Perfectionist', desc: 'Hates losing. High ceiling, high maintenance.', growth: 1.1, morale: 1.2, loyalty: 0.95 },
    { id: 'Quiet', desc: 'Low maintenance, struggles to lead.', growth: 0.97, morale: 0.8, loyalty: 1.1 }
  ];

  function rngFor(seed) { return C.RNG(seed); }
  function clamp(v, a, b) { return C.clamp(v, a == null ? 0 : a, b == null ? 100 : b); }
  function sigmoid(x) { return 1 / (1 + Math.exp(-x)); }
  function attr(p, k) {
    if (!p) return 50;
    if (p.attrs && p.attrs[k] != null) return p.attrs[k];
    if (p.roleAttrs && p.roleAttrs[k] != null) return p.roleAttrs[k];
    return 50;
  }
  function roleAvg(p, keys) { var t = 0; for (var i = 0; i < keys.length; i++) t += attr(p, keys[i]); return t / keys.length; }

  /* ------------------------------------------------------------------
     PLAYER CREATION
  ------------------------------------------------------------------ */
  function pickAgents(rng, role) {
    var list = [];
    for (var a in C.AGENTS) if (C.AGENTS[a] === role) list.push(a);
    return rng.shuffle(list).slice(0, 3);
  }

  function buildPlayer(base, rng, opts) {
    opts = opts || {};
    var g = base.grade != null ? base.grade : rng.float(4.5, 7.5); // 0-10
    var role = base.role || rng.pick(C.ROLES);
    var age = base.age != null ? base.age : rng.int(18, 27);
    var center = 48 + g * 4.6; // grade 1 -> 52.6, 10 -> 94
    var spread = base.sim ? 7.5 : 5.8;
    var attrs = {};
    CORE_ATTRS.forEach(function (k) {
      var mod = 0;
      if (k === 'mental') mod = rng.float(-6, 3);
      if (k === 'leadership') mod = (base.igl ? 16 : 0) + rng.float(-10, 4);
      if (k === 'mechanics' || k === 'aim') mod = rng.float(-3, 6);
      if (k === 'consistency') mod = (age > 24 ? 3 : -1) + rng.float(-5, 5);
      attrs[k] = clamp(Math.round(center + mod + rng.float(-spread, spread)), 28, 99);
    });
    var roleAttrs = {};
    ROLE_ATTRS[role].forEach(function (k) { roleAttrs[k] = clamp(Math.round(center + rng.float(-spread + 1, spread + 2)), 30, 99); });
    var potentialGap = base.sim ? rng.float(3, 16) : rng.float(1, 11);
    if (age <= 19) potentialGap += rng.float(4, 12);
    else if (age <= 22) potentialGap += rng.float(2, 7);
    else if (age >= 28) potentialGap = rng.float(-3, 4);
    if (base.potential) potentialGap = base.potential - center;
    var potential = clamp(Math.round(center + potentialGap), Math.round(center), 99);
    var agents = base.agents && base.agents.length ? base.agents.slice() : pickAgents(rng, role);
    agents = agents.filter(function (a) { return C.AGENTS[a] === role; });
    if (!agents.length) agents = pickAgents(rng, role);
    var secondary = base.secondary || (rng.chance(0.45) ? rng.pick(C.ROLES.filter(function (r) { return r !== role; })) : null);
    var fam = {};
    C.AGENT_LIST.forEach(function (a) { fam[a] = C.AGENTS[a] === role ? rng.int(38, 62) : (secondary && C.AGENTS[a] === secondary ? rng.int(25, 45) : rng.int(5, 25)); });
    fam[agents[0]] = rng.int(78, 94);
    if (agents[1]) fam[agents[1]] = rng.int(62, 84);
    if (agents[2]) fam[agents[2]] = rng.int(52, 76);
    var pers = base.personality ? PERSONALITIES.filter(function (x) { return x.id === base.personality; })[0] : rng.weighted(PERSONALITIES, function (x) {
      return x.id === 'Leader' ? 0.6 : x.id === 'Volatile' ? 0.9 : 1;
    });
    var level = overall({ role: role, attrs: attrs, roleAttrs: roleAttrs, agents: agents, age: age });
    var p = {
      id: base.id || ('p_' + Math.abs(C.hash((base.nick || 'x') + '|' + role + '|' + (base.org || '') + '|' + (opts.salt || '0')))).toString(36),
      nick: base.nick || 'prospect', name: base.name || '', cc: base.cc || 'us', role: role, secondary: secondary,
      age: age, dob: base.dob || null, attrs: attrs, roleAttrs: roleAttrs, potential: potential,
      personality: pers.id, agents: agents, agentFamiliarity: fam,
      org: opts.org !== undefined ? opts.org : (base.org != null ? base.org : null),
      status: 'starter', form: 65 + rng.int(-6, 8), morale: 66 + rng.int(-8, 10), fatigue: rng.int(4, 20),
      level: level, peak: level, growth: 0, wage: 0, value: 0, contractEnd: opts.season || 2027,
      rep: clamp(Math.round((g - 4) * 14 + rng.int(-8, 8)), 5, 99), igl: !!base.igl, captain: !!base.captain,
      conf: base.conf || 'UNKNOWN', src: base.src || null, note: base.note || '',
      sim: !!base.sim, photo: base.photo || null, scouted: opts.scouted !== false,
      stats: emptyStats(), history: [], awards: [], joined: opts.date || '2027-01-04', tenure: 1, retired: false
    };
    p.wage = wageFor(p); p.value = valueFor(p);
    p.contractEnd = opts.season ? opts.season + (base.sim ? 1 : 1) : 2027;
    return p;
  }

  function emptyStats() {
    return { maps: 0, rounds: 0, kills: 0, deaths: 0, assists: 0, fk: 0, fd: 0, acs: 0, kd: 0, adr: 0, clutches: 0, mvps: 0, trophies: 0 };
  }

  function fromSpec(spec, season) {
    return buildPlayer(spec, C.RNG('spec|' + spec.nick + '|' + spec.org + '|' + spec.role), {
      org: spec.org || null, season: season || 2027, scouted: !!spec.org, date: '2027-01-04'
    });
  }

  var FIRST = {
    us: ['Tyler', 'Jordan', 'Marcus', 'Cameron', 'Dylan', 'Austin', 'Cole', 'Ryan', 'Zach', 'Elijah', 'Noah', 'Mason', 'Logan', 'Ethan', 'Bryce'],
    ca: ['Liam', 'Noah', 'Ethan', 'Lucas', 'Owen', 'Nathan', 'Tyson', 'Caleb', 'Aidan', 'Cole'],
    br: ['Lucas', 'Matheus', 'Gabriel', 'Rafael', 'Felipe', 'Diego', 'Bruno', 'Thiago', 'Vitor', 'Caio', 'Enzo'],
    ar: ['Mateo', 'Santiago', 'Lautaro', 'Thiago', 'Nicolás', 'Joaquín', 'Franco', 'Tomás', 'Agustín'],
    mx: ['Diego', 'Santiago', 'Emiliano', 'Mateo', 'Sebastián', 'Andrés', 'Iker'],
    gb: ['Oliver', 'Harry', 'Jack', 'George', 'Charlie', 'Alfie', 'Lewis', 'Callum', 'Kieran'],
    fr: ['Lucas', 'Hugo', 'Théo', 'Nathan', 'Enzo', 'Mathis', 'Alexis', 'Clément'],
    de: ['Leon', 'Finn', 'Jonas', 'Lukas', 'Maximilian', 'Felix', 'Niklas'],
    es: ['Alejandro', 'Pablo', 'Sergio', 'Adrián', 'Álvaro', 'Javier', 'Marc'],
    pt: ['João', 'Diogo', 'Rui', 'Tiago', 'Miguel', 'Duarte'],
    it: ['Lorenzo', 'Matteo', 'Alessandro', 'Marco', 'Davide'],
    se: ['Elias', 'Oscar', 'Hugo', 'Viktor', 'Emil', 'Linus'],
    no: ['Magnus', 'Sander', 'Emil', 'Mathias', 'Kristian'],
    dk: ['Magnus', 'Emil', 'Frederik', 'Oliver', 'Noah'],
    fi: ['Elias', 'Onni', 'Väinö', 'Eino', 'Leo'],
    pl: ['Kamil', 'Jakub', 'Mateusz', 'Patryk', 'Dawid', 'Michał'],
    cz: ['Martin', 'Jakub', 'Tomáš', 'Adam', 'Ondřej'],
    ru: ['Dmitry', 'Ilya', 'Nikita', 'Артём', 'Kirill', 'Maxim', 'Pavel', 'Timofey'],
    ua: ['Oleksandr', 'Andriy', 'Dmytro', 'Bohdan', 'Kirill'],
    tr: ['Emir', 'Kaan', 'Yusuf', 'Mert', 'Berk', 'Efe', 'Ege', 'Kerem', 'Arda'],
    kr: ['Min-jun', 'Ji-hoon', 'Seung-hyun', 'Hyun-min', 'Tae-yang', 'Jun-hyuk', 'Dong-hyun', 'Na-ra', 'Sang-jun'],
    jp: ['Haruto', 'Kaito', 'Sota', 'Ren', 'Yuto', 'Kazuki', 'Shota', 'Hiroshi'],
    cn: ['Wei', 'Haoran', 'Jun', 'Zeyang', 'Yuxuan', 'Jianing', 'Chen', 'Zihan', 'Xiang'],
    tw: ['Wei-ting', 'Chih-hao', 'Yu-hsuan', 'Ping-wei', 'Chia-hao'],
    id: ['Adi', 'Budi', 'Rizky', 'Fajar', 'Dimas', 'Reza', 'Monyet'],
    th: ['Nattapong', 'Kittisak', 'Thanawat', 'Jittana', 'Panyawat', 'Taned', 'Saran'],
    vn: ['Minh', 'Hùng', 'Duy', 'Khoa', 'Long', 'Thắng', 'Quang'],
    ph: ['Miguel', 'Paolo', 'Andre', 'Jayson', 'Rafael', 'Kier'],
    sg: ['Jing', 'Wei', 'Marcus', 'Ryan', 'Shawn'],
    my: ['Aiman', 'Haziq', 'Iskandar', 'Amir', 'Danish'],
    in: ['Aarav', 'Ishaan', 'Rohan', 'Arjun', 'Vivaan', 'Kabir', 'Aniket'],
    pk: ['Ali', 'Hamza', 'Bilal', 'Usman', 'Zain'],
    au: ['Jack', 'Lachlan', 'Cooper', 'Hunter', 'Mason', 'Declan'],
    nz: ['Liam', 'Jayden', 'Tane', 'Finn', 'Cooper'],
    ma: ['Yassine', 'Ayoub', 'Amine', 'Mehdi', 'Ilyas'],
    eg: ['Omar', 'Youssef', 'Karim', 'Ali', 'Hassan'],
    ae: ['Saeed', 'Rashid', 'Khalid', 'Faisal'],
    sa: ['Fahad', 'Abdullah', 'Saud', 'Turki'],
    kz: ['Alikhan', 'Dias', 'Timur', 'Nursultan'],
    lt: ['Dominykas', 'Lukas', 'Matas', 'Nojus'],
    ee: ['Kimmie', 'Markus', 'Rasmus', 'Karl'],
    rs: ['Maksim', 'Nikola', 'Luka', 'Stefan'],
    be: ['Sylvain', 'Louis', 'Arthur', 'Jules', 'Noah'],
    nl: ['Daan', 'Sem', 'Lars', 'Bram', 'Finn'],
    gr: ['Nikos', 'Giorgos', 'Kostas', 'Dimitris'],
    il: ['Noam', 'Ariel', 'Yonatan', 'Eitan'],
    mn: ['Temur', 'Bat-Erdene', 'Ankhbayar', 'Munkh'],
    hk: ['Ka-kit', 'Wai-lun', 'Chun-hei', 'Ho-yin']
  };
  var NICK_A = ['st', 'kr', 'vy', 'ne', 'ar', 'ze', 'ka', 'lo', 'my', 'ro', 'sa', 'vi', 'du', 'ax', 'no', 'ry', 'ka', 'sh', 'to', 'el'];
  var NICK_B = ['zz', 'zen', 'ko', 'ren', 'vis', 'tix', 'no', 'kei', 'sha', 'dex', 'vyn', 'x', 'ro', 'zen', 'a', 'ex', 'oo', 'ix', 'en', 'ur'];
  var NICK_C = ['', 'z', 'x', 'rr', 'n', 's', 'k', 'y', 'o', 'a', 'h'];
  var NICK_WORDS = ['fade', 'drift', 'cipher', 'venom', 'pulse', 'ember', 'nova', 'sonic', 'ghost', 'spark', 'void', 'raven', 'blade', 'frost', 'storm', 'echo', 'prism', 'neon', 'vertex', 'onyx', 'rune', 'shift', 'flare', 'orbit', 'toxin', 'wraith', 'helix', 'apex', 'null', 'zenith', 'quasar', 'glitch', 'haze', 'iron', 'jade', 'kilo', 'lunar', 'mirage', 'nectar', 'opal'];
  var NICK_PRE = ['dark', 'pro', 're', 'un', 'ze', 'ka', 'ex', 'aero', 'cyber', 'neo', 'hyper', 'lumi', 'sub', 'over', 'vice'];

  function genNick(rng, cc) {
    var styles = [
      function () { return rng.pick(NICK_WORDS) + (rng.chance(0.35) ? rng.int(1, 99) : ''); },
      function () { return rng.pick(NICK_PRE) + rng.pick(NICK_WORDS); },
      function () { return rng.pick(NICK_A) + rng.pick(NICK_B) + rng.pick(NICK_C); },
      function () { return rng.pick(NICK_PRE) + rng.pick(NICK_B); },
      function () { return rng.pick(NICK_WORDS).slice(0, 4) + rng.pick(NICK_C); }
    ];
    var n = rng.pick(styles)();
    return n.charAt(0).toUpperCase() + n.slice(1);
  }

  function genPlayer(rng, opts) {
    opts = opts || {};
    var cc = opts.cc || rng.pick(Object.keys(C.COUNTRIES));
    var role = opts.role || rng.pick(C.ROLES);
    var age = opts.age || rng.int(17, 24);
    var tier = opts.tier != null ? opts.tier : rng.float(3.6, 7.0);
    if (opts.elite && rng.chance(opts.elite)) tier = rng.float(7.2, 8.4);
    var first = rng.pick(FIRST[cc] || FIRST.us);
    var last = rng.pick(['Kim', 'Park', 'Lee', 'Chen', 'Wang', 'Silva', 'Santos', 'Garcia', 'Smith', 'Johnson', 'Martin', 'Rossi', 'Novak', 'Petrov', 'Yilmaz', 'Tanaka', 'Sato', 'Nguyen', 'Tran', 'Reyes', 'Santoso', 'Kumar', 'Khan', 'Brown', 'Miller', 'Dubois', 'Muller', 'Costa', 'Almeida', 'Ivanov']);
    var nick = opts.nick || genNick(rng, cc);
    var base = {
      nick: nick, name: (first + ' ' + last).trim(), cc: cc, role: role, age: age,
      grade: Math.max(2.5, tier + (opts.bonus || 0)), sim: opts.sim !== false,
      igl: rng.chance(0.14), personality: rng.pick(PERSONALITIES).id
    };
    var p = buildPlayer(base, rng, { org: opts.org || null, season: opts.season || 2027, scouted: opts.scouted !== false, salt: opts.salt || String(rng.int(0, 99999)) });
    if (opts.potential) p.potential = clamp(opts.potential, p.level, 99);
    if (opts.academy) { p.academy = true; p.wage = Math.round(p.wage * 0.35); p.value = Math.round(p.value * 0.5); }
    return p;
  }

  function genStaff(rng, opts) {
    opts = opts || {};
    var role = opts.role || 'Head Coach';
    var grade = opts.grade || rng.float(5.5, 8.2);
    var cc = opts.cc || rng.pick(Object.keys(C.COUNTRIES));
    var names = ['Alex', 'Sam', 'Chris', 'Daniel', 'Marco', 'Viktor', 'Sasha', 'Kenji', 'Minho', 'Lucas', 'Hugo', 'Oliver', 'Nikhil', 'Emre', 'Yannick', 'Rui', 'Tomas', 'Andre', 'Pavel', 'Jae'];
    var last = ['Reyes', 'Kowalski', 'Berger', 'Nakamura', 'Kim', 'Silva', 'Dubois', 'Smith', 'Ivanov', 'Yilmaz', 'Mendoza', 'Chen', 'Park', 'Rossi', 'Novak', 'Larsen', 'Petrov', 'Okafor', 'Haddad', 'Sato'];
    return {
      id: 's_' + Math.abs(C.hash(role + cc + rng.int(0, 999999))).toString(36),
      nick: rng.pick(['coach', 'analyst', 'scout', 'prep']) + rng.int(1, 99),
      name: rng.pick(names) + ' ' + rng.pick(last), cc: cc, role: role, age: rng.int(26, 47),
      grade: Math.round(grade * 10) / 10, org: opts.org || null,
      salary: Math.round(30000 + grade * grade * 900), conf: 'SIM', sim: true,
      attrs: {
        coaching: clamp(Math.round(grade * 10 + rng.int(-6, 6))), analysis: clamp(Math.round(grade * 10 + rng.int(-9, 9))),
        scouting: clamp(Math.round(grade * 10 + rng.int(-10, 10))), development: clamp(Math.round(grade * 10 + rng.int(-8, 8))),
        management: clamp(Math.round(grade * 10 + rng.int(-10, 10)))
      }
    };
  }

  /* ------------------------------------------------------------------
     RATINGS
  ------------------------------------------------------------------ */
  function overall(p) {
    if (!p) return 0;
    if (!p.attrs) return p.level || 50;
    var w = { aim: 0.15, mechanics: 0.11, gamesense: 0.14, positioning: 0.09, decision: 0.1, clutch: 0.06, comms: 0.05, teamplay: 0.07, consistency: 0.06, adaptability: 0.05, mental: 0.04, leadership: 0.03 };
    var sum = 0, tw = 0;
    for (var k in w) { sum += (p.attrs[k] || 50) * w[k]; tw += w[k]; }
    var core = sum / tw;
    var ra = roleAvg(p, ROLE_ATTRS[p.role] || []);
    return Math.round(core * 0.76 + ra * 0.24);
  }

  function potentialStars(p) { var d = p.potential - p.level; return d > 16 ? 5 : d > 11 ? 4 : d > 6 ? 3 : d > 2 ? 2 : 1; }

  function wageFor(p) {
    var base = Math.pow(Math.max(1, (p.level || 50) - 40), 2.0) * 1.68;
    var rep = 1 + (p.rep || 40) / 140;
    var ageMod = p.age < 20 ? 1.08 : p.age > 28 ? 0.92 : 1;
    return Math.max(24000, Math.round((base * rep * ageMod * 52) / 1000) * 1000);
  }
  function valueFor(p) {
    var base = Math.pow(Math.max(1, (p.level || 50) - 38), 2.05) * 320;
    var pot = 1 + Math.max(0, (p.potential || p.level || 50) - (p.level || 50)) / 26;
    var ageMod = p.age <= 19 ? 1.5 : p.age <= 22 ? 1.28 : p.age <= 25 ? 1.05 : p.age <= 28 ? 0.8 : 0.45;
    var rep = 0.78 + (p.rep || 40) / 115;
    return Math.max(20000, Math.round((base * pot * ageMod * rep) / 5000) * 5000);
  }

  function shareHistory(a, b) {
    var hist = (a.history || []).concat([{ org: a.org }]);
    for (var i = 0; i < hist.length; i++) {
      if (b.history && b.history.some(function (h) { return h.org === hist[i].org; })) return true;
      if (b.org && hist[i].org === b.org) return true;
    }
    return false;
  }

  function roleBalance(players) {
    var counts = { Duelist: 0, Initiator: 0, Controller: 0, Sentinel: 0 };
    players.forEach(function (p) {
      if (!p) return;
      counts[p.role] = (counts[p.role] || 0) + 1;
      if (counts[p.role] > 2 && p.secondary) counts[p.secondary] = (counts[p.secondary] || 0) + 0.5;
    });
    var score = 100, gaps = [], dups = [];
    C.ROLES.forEach(function (r) {
      if (counts[r] === 0) { score -= 22; gaps.push(r); }
      else if (counts[r] > 2) { score -= (counts[r] - 2) * 10; dups.push(r); }
    });
    var cover = 0;
    players.forEach(function (p) { if (p && p.secondary && (counts[p.role] > 1 || counts[p.role] === 0)) cover += 4; });
    score = clamp(score + Math.min(10, cover), 10, 100);
    return { score: Math.round(score), counts: counts, gaps: gaps, dups: dups };
  }

  function agentFit(p, map) {
    var meta = C.MAP_META[map]; if (!meta || !p) return 55;
    var main = (p.agents && p.agents[0]) || null;
    var fit = 55;
    if (main) {
      fit = 45 + (p.agentFamiliarity[main] || 60) * 0.5;
      if ((meta[p.role] || []).indexOf(main) >= 0) fit += 18;
      else if (p.agents[1] && (meta[p.role] || []).indexOf(p.agents[1]) >= 0) fit += 6;
    }
    return clamp(fit, 20, 99);
  }

  function teamRating(state, org, opts) {
    opts = opts || {};
    var ids = opts.lineup || org.lineup || org.roster || [];
    var players = ids.map(function (id) { return state.players[id]; }).filter(Boolean).slice(0, 5);
    while (players.length < 5) {
      var fillers = (org.roster || []).map(function (id) { return state.players[id]; }).filter(function (p) { return p && players.indexOf(p) < 0; });
      if (!fillers.length) break;
      players.push(fillers.shift());
    }
    if (!players.length) return zeroRating(org);
    var map = opts.map;
    var coach = (org.staff || []).map(function (id) { return state.staff[id]; }).filter(Boolean).sort(function (a, b) { return b.grade - a.grade; })[0] || null;
    var coachQuality = coach ? coach.attrs.coaching : 42;
    var style = opts.style || org.playstyle || 'Balanced';
    var st = C.STYLE_INFO[style] || C.STYLE_INFO.Balanced;
    var season = state.season || 2027;

    var skill = C.avg(players.map(function (p) { return overall(p); }));
    var form = C.avg(players.map(function (p) { return p.form || 65; }));
    var morale = C.avg(players.map(function (p) { return p.morale || 65; }));
    var fatigue = C.avg(players.map(function (p) { return p.fatigue || 10; }));
    var agent = C.avg(players.map(function (p) { return map ? agentFit(p, map) : C.avg(p.agents.map(function (a) { return p.agentFamiliarity[a] || 50; })); }));
    var bal = roleBalance(players);
    var chem = org.chemistry != null ? org.chemistry : 60;
    // tenure bonus
    var ten = 0;
    for (var i = 0; i < players.length; i++) for (var j = i + 1; j < players.length; j++) if (shareHistory(players[i], players[j])) ten += 1.6;
    chem = clamp(chem + Math.min(12, ten) - Math.max(0, 5 - players.length) * 5, 5, 100);
    var analysisBoost = org.facilities && org.facilities.analysis ? (org.facilities.analysis - 2) * 1.6 : 0;
    var prep = clamp((map && org.mapPrep ? (org.mapPrep[map] != null ? org.mapPrep[map] : 55) : 58) + analysisBoost, 15, 100);
    var injuryPenalty = players.filter(function (p) { return p && p.injury && p.injury.days > 0; }).length * 2.2;
    var fatiguePenalty = Math.max(0, (fatigue - 35) * 0.42) + injuryPenalty;
    var moraleBonus = (morale - 62) * 0.16;
    var formBonus = (form - 65) * 0.2;
    var diffMod = 0;
    var diff = state.difficulty || 'Normal';
    if (org.isUser) diffMod = diff === 'Beginner' ? 2.5 : diff === 'Expert' ? -1.5 : 0;
    else diffMod = (C.DIFFICULTY[diff] || C.DIFFICULTY.Normal).ai * 4 - 4;

    var base = skill * 0.50 + chem * 0.13 + bal.score * 0.08 + agent * 0.1 + coachQuality * 0.05 + prep * 0.09 + moraleBonus + formBonus - fatiguePenalty + diffMod;
    var mapObj = map ? C.MAPS.filter(function (m) { return m.name === map; })[0] : null;
    var attack = base + (st.atk || 0) * 0.85 + (mapObj && mapObj.type === 'attack' ? 2.5 : 0);
    var defense = base + (st.def || 0) * 0.85 + (mapObj && mapObj.type === 'defense' ? 2.5 : 0);
    return {
      overall: Math.round(clamp(base, 1, 99)), attack: clamp(attack, 1, 99), defense: clamp(defense, 1, 99),
      skill: Math.round(skill), chem: Math.round(chem), balance: bal, agent: Math.round(agent), coach: coachQuality,
      form: Math.round(form), morale: Math.round(morale), fatigue: Math.round(fatigue), prep: Math.round(prep),
      players: players, coachObj: coach, style: style, notes: []
    };
  }
  function zeroRating(org) {
    return { overall: 20, attack: 20, defense: 20, skill: 20, chem: 30, balance: { score: 30, gaps: [], counts: {} }, agent: 30, coach: 30, form: 50, morale: 50, fatigue: 20, prep: 30, players: [], style: 'Balanced', notes: ['No complete lineup available.'] };
  }

  function mapPrefsFor(state, map) {
    var pool = state.settings.mapPool;
    return pool;
  }

  /* ------------------------------------------------------------------
     MATCH SIMULATION
  ------------------------------------------------------------------ */
  function simMap(state, A, B, map, rng, opts) {
    var ra = teamRating(state, A, { map: map, lineup: opts.lineupA, style: opts.styleA });
    var rb = teamRating(state, B, { map: map, lineup: opts.lineupB, style: opts.styleB });
    var pa = ra.players, pb = rb.players;
    if (pa.length < 5 || pb.length < 5) return null;
    var stats = {};
    pa.concat(pb).forEach(function (p) { stats[p.id] = { p: p, k: 0, d: 0, a: 0, fk: 0, fd: 0, rounds: 0, acsSum: 0, clutch: 0 }; });
    var aStyle = C.STYLE_INFO[opts.styleA] || C.STYLE_INFO.Balanced;
    var bStyle = C.STYLE_INFO[opts.styleB] || C.STYLE_INFO.Balanced;
    var scoreA = 0, scoreB = 0, round = 0, sideA = 'attack';
    var lossA = 0, lossB = 0;
    var maxRounds = 44;
    var roundLog = [];

    while (round < maxRounds) {
      var aAtk = sideA === 'attack';
      var atkR = aAtk ? ra.attack : rb.attack;
      var defR = aAtk ? rb.defense : ra.defense;
      var atkSide = aAtk ? A : B;
      var defSide = aAtk ? B : A;
      var atkStyle = aAtk ? aStyle : bStyle;
      var defStyle = aAtk ? bStyle : aStyle;
      var loss = aAtk ? lossA : lossB;
      var eco = loss >= 2 ? -2.2 : loss === 1 ? -1.0 : 0.6;
      var styleEdge = (atkStyle.tempo * 0.25 + atkStyle.chaos * 0.2) - (defStyle.control * 0.22);
      var prepEdge = ((aAtk ? ra.prep : rb.prep) - (aAtk ? rb.prep : ra.prep)) * 0.08;
      var diff = (atkR - defR) * 0.92 + eco + styleEdge + prepEdge;
      // entry duel
      var atkEntry = bestAttr(atkSide, 'Duelist', 'entry');
      var defAnchor = bestAttr(defSide, 'Sentinel', 'anchor');
      var entryP = sigmoid((atkEntry - defAnchor) / 18) * 0.82 + 0.09;
      var entryWin = rng.next() < entryP;
      diff += entryWin ? 0.85 : -0.85;
      var pWin = sigmoid(diff / 6.8);
      pWin = clamp(pWin, 0.07, 0.93);
      var aWins = rng.next() < pWin;
      if (aWins) { scoreA++; lossA = 0; lossB++; } else { scoreB++; lossB = 0; lossA++; }

      // stats: 5-6 kills total per round
      var totalKills = rng.int(4, 7);
      var winner = aWins ? pa : pb, loser = aWins ? pb : pa;
      var killWinner = Math.max(2, Math.round(totalKills * (0.55 + rng.float(-0.06, 0.08))));
      var killLoser = Math.max(0, totalKills - killWinner);
      distributeKills(rng, winner, killWinner, stats, true, entryWin && (aWins ? aAtk : !aAtk));
      distributeKills(rng, loser, killLoser, stats, false, entryWin && (aWins ? !aAtk : aAtk));
      var attackerPlayers = aAtk ? pa : pb;
      var entrant = pickBy(rng, attackerPlayers, function (p) { return attr(p, 'entry') + attr(p, 'aim') * 0.4 + (p.role === 'Duelist' ? 18 : 0); });
      var defender = pickBy(rng, aAtk ? pb : pa, function (p) { return attr(p, 'anchor') + attr(p, 'aim') * 0.3 + (p.role === 'Sentinel' ? 16 : 0); });
      if (entryWin) {
        if (entrant && stats[entrant.id]) stats[entrant.id].fk++;
        if (defender && stats[defender.id]) stats[defender.id].fd++;
      } else {
        if (defender && stats[defender.id]) stats[defender.id].fk++;
        if (entrant && stats[entrant.id]) stats[entrant.id].fd++;
      }
      // clutch: close round
      if (rng.chance(0.16)) {
        var clutchTeam = rng.chance(0.5) ? pa : pb;
        var cp = pickBy(rng, clutchTeam, function (p) { return attr(p, 'clutch') + attr(p, 'mental') * 0.5; });
        if (cp && stats[cp.id]) stats[cp.id].clutch++;
      }
      roundLog.push({ n: round + 1, atk: aAtk ? 'A' : 'B', win: aWins ? 'A' : 'B', scoreA: scoreA, scoreB: scoreB });
      round++;
      if (round === 12 && sideA === 'attack') sideA = 'defense';
      else if (round === 24 && sideA === 'defense') sideA = 'attack';
      var done = (scoreA >= 13 || scoreB >= 13) && Math.abs(scoreA - scoreB) >= 2;
      if (done) break;
      if (scoreA === 12 && scoreB === 12 && round >= 24) {
        // overtime continues until 2-round lead, handled by loop
      }
    }
    pa.concat(pb).forEach(function (p) {
      var s = stats[p.id]; if (!s) return;
      s.rounds = round;
      s.acsSum = 145 + s.k * 8.6 + s.a * 4.6 + s.fk * 6 - s.d * 2.2 + rng.float(-16, 22);
      if (s.acsSum < 90) s.acsSum = 90 + rng.int(0, 30);
    });
    var mvp = null, best = -1;
    pa.concat(pb).forEach(function (p) {
      var s = stats[p.id]; if (!s) return;
      var score = s.acsSum + s.fk * 4 + s.clutch * 8;
      if (score > best) { best = score; mvp = p; }
    });
    return {
      map: map, scoreA: scoreA, scoreB: scoreB, winner: scoreA > scoreB ? 'A' : 'B',
      ratings: { A: ra, B: rb }, stats: stats, rounds: roundLog, mvp: mvp ? mvp.id : null,
      ot: round > 24, duration: 32 + round * 2 + rng.int(0, 8)
    };
  }

  function pickBy(rng, arr, wf) {
    if (!arr || !arr.length) return null;
    var total = 0; arr.forEach(function (x) { total += Math.max(1, wf(x)); });
    var r = rng.next() * total;
    for (var i = 0; i < arr.length; i++) { r -= Math.max(1, wf(arr[i])); if (r <= 0) return arr[i]; }
    return arr[arr.length - 1];
  }
  function bestAttr(org, role, k) {
    var P = (org._cachePlayers || []);
    var cand = P.filter(function (p) { return p.role === role; });
    if (!cand.length) cand = P;
    var best = 40;
    cand.forEach(function (p) { best = Math.max(best, attr(p, k) * 0.7 + attr(p, 'aim') * 0.3); });
    return best;
  }
  function distributeKills(rng, players, count, stats, won, wasEntryWinner) {
    if (!count) return;
    var weights = players.map(function (p) {
      var off = p.role === 'Duelist' ? 16 : p.role === 'Initiator' ? 7 : p.role === 'Controller' ? 1 : -4;
      return Math.max(6, attr(p, 'aim') * 0.45 + attr(p, 'mechanics') * 0.25 + off + rng.float(0, 22));
    });
    for (var i = 0; i < count; i++) {
      var total = 0; weights.forEach(function (w) { total += w; });
      var r = rng.next() * total, idx = 0;
      for (; idx < weights.length; idx++) { r -= weights[idx]; if (r <= 0) break; }
      idx = Math.min(idx, players.length - 1);
      var p = players[idx]; if (!p) continue;
      if (!stats[p.id]) stats[p.id] = { p: p, k: 0, d: 0, a: 0, fk: 0, fd: 0, rounds: 0, acsSum: 0, clutch: 0 };
      stats[p.id].k++;
      if (rng.chance(0.28)) {
        var mate = rng.pick(players);
        if (mate && stats[mate.id]) stats[mate.id].a++;
      }
      var victim = rng.pick(stats.__losers || []);
    }
    // deaths assigned to opponents by caller loop below (kept simple and balanced)
  }

  function applyDeaths(rng, mapResult, pa, pb) {
    var stats = mapResult.stats;
    pa.forEach(function (p) {
      var s = stats[p.id]; if (!s) return;
      s.d = Math.round((mapResult.scoreA + mapResult.scoreB) * 0.34) + rng.int(-2, 3);
      s.d = Math.max(4, s.d);
    });
    pb.forEach(function (p) {
      var s = stats[p.id]; if (!s) return;
      s.d = Math.round((mapResult.scoreA + mapResult.scoreB) * 0.34) + rng.int(-2, 3);
      s.d = Math.max(4, s.d);
    });
  }

  function finaliseMap(mapResult, rng, pa, pb) {
    var stats = mapResult.stats;
    pa.concat(pb).forEach(function (p) {
      var s = stats[p.id]; if (!s) return;
      if (s.d == null) s.d = Math.round((mapResult.scoreA + mapResult.scoreB) * 0.34) + rng.int(-3, 3);
      s.d = Math.max(3, s.d);
      s.rounds = mapResult.scoreA + mapResult.scoreB;
      s.kd = s.d ? s.k / s.d : s.k;
      s.acs = Math.round(s.acsSum / Math.max(1, s.rounds));
      s.adr = Math.round(105 + (s.k / Math.max(1, s.rounds)) * 95 + rng.float(-12, 18));
      delete s.acsSum;
    });
    // balanced sanity: total kills should be plausible
    var killsA = 0, killsB = 0;
    pa.forEach(function (p) { killsA += stats[p.id] ? stats[p.id].k : 0; });
    pb.forEach(function (p) { killsB += stats[p.id] ? stats[p.id].k : 0; });
    return mapResult;
  }

  var VETO_ORDERS = {
    bo1: ['ban', 'ban', 'ban', 'ban', 'ban', 'ban', 'decider'],
    bo3: ['ban', 'ban', 'pick', 'pick', 'ban', 'ban', 'decider'],
    bo5: ['ban', 'ban', 'pick', 'pick', 'pick', 'pick', 'decider']
  };

  function veto(state, A, B, bo, rng, userMapPrefs) {
    var pool = C.normalizePool(state.settings && state.settings.mapPool);
    var order = VETO_ORDERS['bo' + bo] || VETO_ORDERS.bo3;
    var prefsA = A.isUser ? (userMapPrefs || {}) : {};
    var prefsB = B.isUser ? (userMapPrefs || {}) : {};
    var picks = [], bans = [];
    var aTurn = rng.chance(0.5);
    var remaining = pool.slice();
    for (var i = 0; i < order.length; i++) {
      var action = order[i];
      if (action === 'decider') break;
      var who = aTurn ? A : B;
      var pref = aTurn ? prefsA : prefsB;
      var pick = null;
      if (pref && pref.bans && pref.bans.length && action === 'ban') {
        var pb = pref.bans.filter(function (m) { return remaining.indexOf(m) >= 0; })[0];
        if (pb) pick = pb;
      }
      if (!pick && pref && pref.picks && pref.picks.length) {
        var pp = pref.picks.filter(function (m) { return remaining.indexOf(m) >= 0; })[0];
        if (pp) pick = pp;
      }
      if (!pick) {
        var rated = remaining.map(function (m) {
          var r = teamRating(state, who, { map: m });
          var opp = teamRating(state, aTurn ? B : A, { map: m });
          return { m: m, v: action === 'ban' ? (r.overall - opp.overall) : (r.overall - opp.overall) + (r.prep - 55) * 0.2 };
        });
        rated.sort(function (x, y) { return action === 'ban' ? x.v - y.v : y.v - x.v; });
        pick = rated[0].m;
      }
      remaining = remaining.filter(function (m) { return m !== pick; });
      if (action === 'pick') picks.push(pick); else bans.push(pick);
      aTurn = !aTurn;
    }
    // fill picks to required count, then decider
    var need = bo === 1 ? 1 : bo === 3 ? 3 : 5;
    while (picks.length < need - 1 && remaining.length) {
      var m = remaining.shift();
      picks.push(m);
    }
    if (remaining.length) picks.push(remaining[0]);
    return { maps: picks.slice(0, need), bans: bans, pool: pool };
  }

  function simulateSeries(state, A, B, opts) {
    opts = opts || {};
    var bo = opts.bo || 3;
    var rng = C.RNG((state.id || '') + '|' + (A.id) + '|' + (B.id) + '|' + (state.date) + '|' + (opts.tag || '') + '|' + (state.matchCounter || 0));
    A._cachePlayers = (opts.lineupA || A.lineup || []).map(function (id) { return state.players[id]; }).filter(Boolean);
    B._cachePlayers = (opts.lineupB || B.lineup || []).map(function (id) { return state.players[id]; }).filter(Boolean);
    var styleA = opts.styleA || A.playstyle || 'Balanced';
    var styleB = opts.styleB || B.playstyle || 'Balanced';
    var vet = opts.veto || veto(state, A, B, bo, rng, state.mapPrefs);
    var maps = [];
    var winsA = 0, winsB = 0;
    var needed = Math.floor(bo / 2) + 1;
    for (var i = 0; i < vet.maps.length && winsA < needed && winsB < needed; i++) {
      var mr = simMap(state, A, B, vet.maps[i], rng, { lineupA: opts.lineupA, lineupB: opts.lineupB, styleA: styleA, styleB: styleB });
      if (!mr) break;
      finaliseMap(mr, rng, mr.ratings.A.players, mr.ratings.B.players);
      maps.push(mr);
      if (mr.winner === 'A') winsA++; else winsB++;
    }
    var result = {
      id: 'm_' + Date.now().toString(36) + Math.floor(Math.random() * 999),
      date: state.date, teamA: A.id, teamB: B.id, winner: winsA > winsB ? A.id : B.id,
      loser: winsA > winsB ? B.id : A.id, scoreA: winsA, scoreB: winsB, bo: bo,
      maps: maps, veto: vet, styleA: styleA, styleB: styleB, comp: opts.compName || opts.compId || 'Friendly',
      stage: opts.stage || '', isUser: !!(A.isUser || B.isUser),
      userWon: A.isUser ? winsA > winsB : winsB > winsA,
      analysis: null, mvp: null
    };
    result.analysis = analyse(state, A, B, result);
    result.mvp = pickSeriesMvp(state, result);
    // Keep saved careers compact: the report only needs per-player stat lines,
    // not the full player/rating snapshots used while simulating the maps.
    result.maps.forEach(function (m) {
      delete m.ratings;
      for (var sid in m.stats) { if (m.stats[sid]) delete m.stats[sid].p; }
    });
    // Simulation-only caches; never keep duplicate player objects in the career.
    delete A._cachePlayers;
    delete B._cachePlayers;
    return result;
  }

  function pickSeriesMvp(state, result) {
    var totals = {};
    result.maps.forEach(function (m) {
      for (var id in m.stats) {
        var s = m.stats[id];
        if (!totals[id]) totals[id] = { id: id, acs: 0, k: 0, d: 0, fk: 0, maps: 0 };
        totals[id].acs += s.acs || 0; totals[id].k += s.k; totals[id].d += s.d; totals[id].fk += s.fk; totals[id].maps++;
      }
    });
    var best = null;
    for (var id in totals) {
      var t = totals[id];
      if (!state.players[id] || (state.players[id].org !== result.winner)) continue;
      t.score = t.acs / t.maps + t.fk * 1.5;
      if (!best || t.score > best.score) best = t;
    }
    return best;
  }

  /* ------------------------------------------------------------------
     MATCH ANALYSIS — explain WHY
  ------------------------------------------------------------------ */
  function analyse(state, A, B, result) {
    var isA = A.isUser;
    var me = isA ? A : B, opp = isA ? B : A;
    var won = result.userWon;
    var mine = isA ? 'A' : 'B', theirs = isA ? 'B' : 'A';
    var ra = result.maps[0] ? result.maps[0].ratings[mine] : teamRating(state, me, {});
    var rb = result.maps[0] ? result.maps[0].ratings[theirs] : teamRating(state, opp, {});
    // aggregate player stats
    var agg = {};
    var myPlayers = ra.players || [];
    myPlayers.forEach(function (p) { agg[p.id] = { p: p, k: 0, d: 0, a: 0, fk: 0, fd: 0, acs: 0, maps: 0, clutch: 0 }; });
    var oppAgg = {};
    (rb.players || []).forEach(function (p) { oppAgg[p.id] = { p: p, k: 0, d: 0, a: 0, fk: 0, fd: 0, acs: 0, maps: 0 }; });
    result.maps.forEach(function (m) {
      var st = m.stats;
      for (var id in st) {
        var s = st[id];
        if (agg[id]) { agg[id].k += s.k; agg[id].d += s.d; agg[id].a += s.a; agg[id].fk += s.fk; agg[id].fd += s.fd; agg[id].acs += s.acs; agg[id].maps++; agg[id].clutch += s.clutch; }
        else if (oppAgg[id]) { oppAgg[id].k += s.k; oppAgg[id].d += s.d; oppAgg[id].a += s.a; oppAgg[id].fk += s.fk; oppAgg[id].acs += s.acs; oppAgg[id].maps++; }
      }
    });
    var myTot = { k: 0, d: 0, fk: 0, fd: 0, acs: 0, maps: 0, clutch: 0 };
    var opTot = { k: 0, d: 0, fk: 0, acs: 0 };
    for (var id in agg) { myTot.k += agg[id].k; myTot.d += agg[id].d; myTot.fk += agg[id].fk; myTot.fd += agg[id].fd; myTot.acs += agg[id].acs; myTot.maps += agg[id].maps; myTot.clutch += agg[id].clutch; }
    for (var id2 in oppAgg) { opTot.k += oppAgg[id2].k; opTot.d += oppAgg[id2].d; opTot.fk += oppAgg[id2].fk; opTot.acs += oppAgg[id2].acs; }
    var fkRate = myTot.fk + myTot.fd ? myTot.fk / (myTot.fk + myTot.fd) : 0.5;
    var causes = [];

    function addCause(sev, title, detail, fixes, code, vars) { causes.push({ severity: sev, title: title, detail: detail, fixes: fixes || [], code: code || null, vars: vars || null }); }

    var myLineup = ra.players || [];
    var controller = myLineup.filter(function (p) { return p.role === 'Controller'; })[0];
    var duelist = myLineup.filter(function (p) { return p.role === 'Duelist'; })[0];
    var sentinel = myLineup.filter(function (p) { return p.role === 'Sentinel'; })[0];

    if (ra.balance.gaps.length) {
      addCause('high', 'Role gap: no natural ' + ra.balance.gaps.join(' / '),
        'You fielded a lineup without a dedicated ' + ra.balance.gaps.join(' or ') + '. That forces someone out of position: utility coverage and site structure suffer all series.',
        [{ label: 'Fix lineup', page: 'squad' }, { label: 'Recruit role', page: 'recruitment' }],
        'role_gap', { roles: ra.balance.gaps.join(' / '), rolesOr: ra.balance.gaps.join(' or ') });
    }
    if (fkRate < 0.44 && myTot.fk + myTot.fd >= 6) {
      addCause('high', 'Opening duels lost',
        'You won only ' + Math.round(fkRate * 100) + '% of opening duels (' + myTot.fk + ' first kills vs ' + myTot.fd + ' first deaths). ' +
        (duelist ? duelist.nick + ' was the main entry and repeatedly lost the first contact, leaving your executes with fewer players and less utility.' : 'Without a reliable entry threat, every attack started a player down.'),
        [{ label: 'Entry training', page: 'training', focus: 'aim' }, { label: 'Adjust tactics', page: 'tactics' }, { label: 'Recruit duelist', page: 'recruitment' }],
        duelist ? 'opening_lost_player' : 'opening_lost', { rate: Math.round(fkRate * 100), fk: myTot.fk, fd: myTot.fd, player: duelist ? duelist.nick : '' });
    }
    if (ra.defense < rb.defense - 3) {
      addCause('high', 'Defensive structure was weaker',
        'Your defensive rating was ' + ra.defense.toFixed(0) + ' against ' + rb.defense.toFixed(0) + '. ' +
        (sentinel ? sentinel.nick + ' could not consistently hold the anchor, and rotations arrived late.' : 'Anchors were unstable and retakes were uncoordinated.') +
        ' Opponents converted post-plant rounds at a higher rate.',
        [{ label: 'Defensive training', page: 'training', focus: 'defense' }, { label: 'Review setups', page: 'tactics' }],
        sentinel ? 'defense_weak_player' : 'defense_weak', { def: ra.defense.toFixed(0), oppDef: rb.defense.toFixed(0), player: sentinel ? sentinel.nick : '' });
    }
    if (ra.chem < 58) {
      addCause('med', 'Coordination and chemistry below standard',
        'Team chemistry was only ' + ra.chem + '/100. Trades were late and utility was layered instead of sequenced. This is typical of a recently rebuilt roster.',
        [{ label: 'Team coordination', page: 'training', focus: 'coordination' }, { label: 'Squad overview', page: 'squad' }],
        'chemistry_low', { chem: ra.chem });
    }
    if (ra.fatigue > 45) {
      addCause('med', 'Fatigue affected the decider',
        'Average squad fatigue was ' + ra.fatigue + '%. Reaction time and clutch decision-making drop sharply above 45%. The series went long and your players faded.',
        [{ label: 'Reduce intensity', page: 'training' }, { label: 'Recovery facilities', page: 'facilities' }],
        'fatigue', { fatigue: ra.fatigue });
    }
    if (ra.agent < 62) {
      addCause('med', 'Agent familiarity too low',
        'Your agent-fit score was ' + ra.agent + '/100 on the selected maps. Players were on comfort picks that did not fit the map, so utility value was limited.',
        [{ label: 'Agent mastery', page: 'training', focus: 'agent' }, { label: 'Assign agents', page: 'tactics' }],
        'agent_fit', { agent: ra.agent });
    }
    if (ra.morale < 55) {
      addCause('med', 'Low morale',
        'Squad morale was ' + ra.morale + '/100. Players took fewer risks in clutch situations and comms became reactive.',
        [{ label: 'Mental preparation', page: 'training', focus: 'mental' }, { label: 'Squad talk', page: 'squad' }],
        'morale', { morale: ra.morale });
    }
    if (ra.prep < 52) {
      addCause('low', 'Map preparation was thin',
        'Map preparation on ' + result.maps.map(function (m) { return m.map; }).join(', ') + ' averaged ' + ra.prep + '/100. You were out-prepared in set plays.',
        [{ label: 'Prepare maps', page: 'tactics' }, { label: 'Map control training', page: 'training', focus: 'mapcontrol' }],
        'prep_thin', { maps: result.maps.map(function (m) { return m.map; }).join(', '), prep: ra.prep });
    }
    if (ra.coach < 55) {
      addCause('low', 'Coaching gap',
        'Your coaching quality was ' + ra.coach + '/100. Mid-series adjustments were slow, especially after losing the first map.',
        [{ label: 'Hire staff', page: 'staff' }],
        'coaching', { coach: ra.coach });
    }
    if (result.maps.length > 1 && !won && result.maps[0].winner === mine) {
      addCause('high', 'Opponent adapted after map one',
        'You won the opening map, then the opponent changed tempo and banned your comfort space. Your approach did not change in response, and rounds became predictable by map three.',
        [{ label: 'Switch playstyle', page: 'tactics' }, { label: 'Adaptability training', page: 'training', focus: 'mapcontrol' }],
        'adapted', null);
    }
    // best performer / weak link
    var ranked = Object.keys(agg).map(function (id) { return agg[id]; }).sort(function (a, b) { return (b.acs / Math.max(1, b.maps)) - (a.acs / Math.max(1, a.maps)); });
    if (ranked.length) {
      var best = ranked[0], worst = ranked[ranked.length - 1];
      if (worst.acs / Math.max(1, worst.maps) < 180) {
        addCause('low', 'Individual underperformance: ' + worst.p.nick,
          worst.p.nick + ' averaged only ' + Math.round(worst.acs / Math.max(1, worst.maps)) + ' ACS with ' + worst.k + ' kills across ' + worst.maps + ' map(s). That is below the level required at this tier.',
          [{ label: 'Player profile', page: 'squad', player: worst.p.id }, { label: 'Bench / replace', page: 'squad' }],
          'underperform', { player: worst.p.nick, acs: Math.round(worst.acs / Math.max(1, worst.maps)), kills: worst.k, maps: worst.maps });
      }
    }
    if (!causes.length) {
      addCause('low', won ? 'Margins were thin' : 'No single structural failure',
        won ? 'You won, but the series was decided by small execution edges rather than a dominant system. Set-play quality and opening-duel consistency remain the areas to protect.' :
          'The defeat was a collection of small deficits rather than one broken system. Review map vetoes and round-level decisions before changing the roster.',
        [{ label: 'Review tactics', page: 'tactics' }],
        won ? 'margins_thin' : 'no_failure', null);
    }

    var strengths = [];
    if (fkRate >= 0.56) strengths.push({ code: 'opening', text: 'Opening duels: ' + Math.round(fkRate * 100) + '% first-kill rate gave you man advantage before executes.', vars: { rate: Math.round(fkRate * 100) } });
    if (ra.chem >= 70) strengths.push({ code: 'coordination', text: 'Coordination: chemistry ' + ra.chem + '/100, trades arrived on time.', vars: { chem: ra.chem } });
    if (ra.defense > rb.defense + 3) strengths.push({ code: 'defense', text: 'Defensive structure: ' + ra.defense.toFixed(0) + ' vs ' + rb.defense.toFixed(0) + ' — anchors held and retakes were decisive.', vars: { def: ra.defense.toFixed(0), oppDef: rb.defense.toFixed(0) } });
    if (ra.attack > rb.attack + 3) strengths.push({ code: 'attack', text: 'Attack structure: ' + ra.attack.toFixed(0) + ' vs ' + rb.attack.toFixed(0) + ' — executes created clean post-plants.', vars: { atk: ra.attack.toFixed(0), oppAtk: rb.attack.toFixed(0) } });
    if (ranked.length) strengths.push({ code: 'best_player', text: ranked[0].p.nick + ' led the server at ' + Math.round(ranked[0].acs / Math.max(1, ranked[0].maps)) + ' ACS.', vars: { player: ranked[0].p.nick, acs: Math.round(ranked[0].acs / Math.max(1, ranked[0].maps)) } });

    // headline
    var headline;
    var mapTxt = result.maps.map(function (m) { return m.map + ' ' + (isA ? m.scoreA : m.scoreB) + '-' + (isA ? m.scoreB : m.scoreA); }).join(', ');
    if (won) headline = 'Victory ' + result.scoreA + '-' + result.scoreB + ' (' + mapTxt + ').';
    else headline = 'Defeat ' + result.scoreA + '-' + result.scoreB + ' (' + mapTxt + ').';
    var verdict;
    if (won) verdict = 'The win was built on ' + (strengths.length ? strengths[0].text.split(':')[0].toLowerCase() : 'execution') + '. It does not mean the squad is complete: ' + (causes[0] ? causes[0].title.toLowerCase() : 'review the details') + ' remains a risk against stronger opponents.';
    else verdict = 'You lost primarily because ' + (causes[0] ? causes[0].title.toLowerCase() : 'of small margins') + '. ' + (causes[1] ? 'Secondary factor: ' + causes[1].title.toLowerCase() + '.' : '') + ' The fixes below are linked to these causes.';

    return {
      headline: headline, verdict: verdict, causes: causes, strengths: strengths,
      won: won, scoreA: result.scoreA, scoreB: result.scoreB, mapTxt: mapTxt,
      metrics: {
        fkRate: Math.round(fkRate * 100), myKills: myTot.k, myDeaths: myTot.d, oppKills: opTot.k,
        acs: myTot.maps ? Math.round(myTot.acs / myTot.maps) : 0, chem: ra.chem, fatigue: ra.fatigue,
        attack: Math.round(ra.attack), defense: Math.round(ra.defense), oppAttack: Math.round(rb.attack), oppDefense: Math.round(rb.defense),
        agent: ra.agent, prep: ra.prep, coach: ra.coach, morale: ra.morale, balance: ra.balance.score, clutch: myTot.clutch
      },
      playerRanking: ranked.map(function (x) { return { id: x.p.id, nick: x.p.nick, acs: Math.round(x.acs / Math.max(1, x.maps)), k: x.k, d: x.d, fk: x.fk }; }),
      best: ranked.length ? ranked[0].p.id : null,
      worst: ranked.length ? ranked[ranked.length - 1].p.id : null
    };
  }

  /* ------------------------------------------------------------------
     TRAINING
  ------------------------------------------------------------------ */
  function trainingFactors(state, org, p) {
    var coach = (org.staff || []).map(function (id) { return state.staff[id]; }).filter(Boolean).sort(function (a, b) { return b.grade - a.grade; })[0];
    var coachQ = coach ? (coach.attrs.development || 60) : 42;
    var fac = org.facilities || { training: 1 };
    var facQ = 55 + (fac.training || 1) * 6;
    var ageMod = p.age <= 19 ? 1.42 : p.age <= 21 ? 1.28 : p.age <= 23 ? 1.12 : p.age <= 26 ? 0.95 : p.age <= 28 ? 0.75 : p.age <= 30 ? 0.55 : 0.32;
    var pers = PERSONALITIES.filter(function (x) { return x.id === p.personality; })[0] || PERSONALITIES[0];
    var gap = Math.max(0, p.potential - p.level);
    var gapMod = clamp(0.45 + gap / 14, 0.35, 1.7);
    return { coach: coachQ, facility: facQ, age: ageMod, personality: pers.growth, gap: gapMod, persObj: pers };
  }

  function runTraining(state, opts) {
    opts = opts || {};
    var org = state.orgs[state.clubId];
    var primary = C.TRAINING.filter(function (t) { return t.id === opts.primary; })[0] || C.TRAINING[8];
    var secondary = opts.secondary && opts.secondary !== 'none' ? C.TRAINING.filter(function (t) { return t.id === opts.secondary; })[0] : null;
    var intensity = opts.intensity || 'normal';
    var intMod = intensity === 'intense' ? 1.35 : intensity === 'light' ? 0.7 : 1;
    var fatAdd = intensity === 'intense' ? 18 : intensity === 'light' ? 6 : 11;
    var rng = C.RNG(state.id + '|train|' + state.date + '|' + primary.id + '|' + (secondary ? secondary.id : '') + '|' + state.trainingWeeks);
    var report = { week: state.week, season: state.season, primary: primary.id, secondary: secondary ? secondary.id : null, intensity: intensity, players: [], notes: [], injuries: [], date: state.date };
    var ids = (org.roster || []).concat(state.academy[org.id] || []);
    var chemGain = 0, fatigueTotal = 0, count = 0;
    ids.forEach(function (id) {
      var p = state.players[id];
      if (!p) return;
      if (p.injury && p.injury.days > 0) {
        p.fatigue = clamp((p.fatigue || 10) - 4, 0, 100);
        fatigueTotal += p.fatigue; count++;
        report.players.push({ id: p.id, nick: p.nick, role: p.role, delta: 0, level: p.level, before: p.level, fatigue: Math.round(p.fatigue), potential: p.potential, academy: !!p.academy, injured: true });
        return;
      }
      var f = trainingFactors(state, org, p);
      var before = { level: p.level, attrs: {}, roleAttrs: {} };
      CORE_ATTRS.forEach(function (k) { before.attrs[k] = p.attrs[k]; });
      ROLE_ATTRS[p.role].forEach(function (k) { before.roleAttrs[k] = p.roleAttrs[k]; });
      var boost = (f.coach / 70) * (f.facility / 72) * f.age * f.personality * f.gap * intMod;
      var gain = 0;
      primary.attrs.forEach(function (k) {
        var inc = rng.float(0.12, 0.42) * boost;
        if (p.attrs[k] != null) p.attrs[k] = clamp(p.attrs[k] + inc, 20, 99);
        else if (p.roleAttrs[k] != null) p.roleAttrs[k] = clamp(p.roleAttrs[k] + inc, 20, 99);
        gain += inc;
      });
      if (secondary) secondary.attrs.forEach(function (k) {
        var inc = rng.float(0.05, 0.2) * boost;
        if (p.attrs[k] != null) p.attrs[k] = clamp(p.attrs[k] + inc, 20, 99);
        else if (p.roleAttrs[k] != null) p.roleAttrs[k] = clamp(p.roleAttrs[k] + inc, 20, 99);
        gain += inc * 0.6;
      });
      // role-specific development
      var raK = rng.pick(ROLE_ATTRS[p.role]);
      p.roleAttrs[raK] = clamp(p.roleAttrs[raK] + rng.float(0.04, 0.22) * boost, 20, 99);
      // decline for veterans
      if (p.age >= 29 && rng.chance(0.25)) {
        var dk = rng.pick(['mechanics', 'aim', 'consistency']);
        p.attrs[dk] = clamp(p.attrs[dk] - rng.float(0.05, 0.22), 20, 99);
      }
      // agent mastery
      if (primary.id === 'agent' || (secondary && secondary.id === 'agent')) {
        var ag = p.agents[0];
        p.agentFamiliarity[ag] = clamp((p.agentFamiliarity[ag] || 60) + rng.float(0.5, 1.8) * intMod, 0, 100);
        if (p.agents[1]) p.agentFamiliarity[p.agents[1]] = clamp((p.agentFamiliarity[p.agents[1]] || 50) + rng.float(0.2, 0.9), 0, 100);
      }
      var fatigueAdd = fatAdd + rng.float(-3, 3) - (org.facilities && org.facilities.recovery ? org.facilities.recovery * 1.6 : 0);
      if (p.age >= 29) fatigueAdd += 2;
      p.fatigue = clamp(p.fatigue + fatigueAdd, 0, 100);
      p.form = clamp((p.form || 65) + rng.float(-1.4, 1.8) - (p.fatigue > 60 ? 1.2 : 0), 25, 99);
      if (primary.id === 'mental') p.morale = clamp((p.morale || 65) + rng.float(0.5, 2.4), 25, 99);
      if (primary.id === 'coordination' || primary.id === 'comms') p.morale = clamp((p.morale || 65) + rng.float(0, 1.2), 25, 99);
      p.level = overall(p);
      p.growth = Math.round((p.level - before.level) * 100) / 100;
      if (p.level > (p.peak || 0)) p.peak = p.level;
      p.wage = wageFor(p); p.value = valueFor(p);
      fatigueTotal += p.fatigue; count++;
      if (p.academy) {
        if (p.level >= 72 && p.age <= 21) report.notes.push(p.nick + ' is ready for first-team minutes.');
      }
      if (p.fatigue > 62 || (intensity === 'intense' && p.fatigue > 48)) {
        var recLvl = (org.facilities && org.facilities.recovery) || 2;
        var injChance = clamp(0.018 + (p.fatigue - 50) * 0.0025 - recLvl * 0.004, 0.005, 0.14);
        if (rng.chance(injChance)) {
          var reasons = ['Wrist strain', 'Shoulder stiffness', 'Hand fatigue', 'Back soreness', 'Illness'];
          var days = rng.int(4, 10);
          p.injury = { days: days, reason: rng.pick(reasons) };
          report.injuries.push({ id: p.id, nick: p.nick, days: days, reason: p.injury.reason });
          report.notes.push(p.nick + ' picked up a ' + p.injury.reason.toLowerCase() + ' (' + days + ' days out). Reduce intensity or upgrade the Recovery Suite.');
        }
      }
      report.players.push({
        id: p.id, nick: p.nick, role: p.role, delta: Math.round(gain * 100) / 100, level: p.level,
        before: before.level, fatigue: Math.round(p.fatigue), potential: p.potential, academy: !!p.academy
      });
    });
    // team effects
    var chemBase = primary.id === 'coordination' ? 2.6 : primary.id === 'comms' ? 1.7 : primary.id === 'mapcontrol' ? 1.0 : 0.5;
    if (secondary && secondary.id === 'coordination') chemBase += 1.1;
    org.chemistry = clamp((org.chemistry || 60) + chemBase * intMod, 0, 100);
    org.mapPrep = org.mapPrep || {};
    var prepGain = primary.id === 'attack' || primary.id === 'defense' || primary.id === 'mapcontrol' ? 2.4 : 0.5;
    state.settings.mapPool.forEach(function (m) {
      org.mapPrep[m] = clamp((org.mapPrep[m] || 55) + prepGain * rng.float(0.6, 1.2), 0, 100);
    });
    // evolve a random agent meta tile slightly
    org.trainingFatigue = Math.round(fatigueTotal / Math.max(1, count));
    report.team = {
      chemistryBefore: Math.round(org.chemistry - chemBase * intMod), chemistryAfter: Math.round(org.chemistry),
      avgFatigue: Math.round(fatigueTotal / Math.max(1, count)),
      best: report.players.slice().sort(function (a, b) { return b.delta - a.delta; }).slice(0, 3),
      concern: report.players.slice().sort(function (a, b) { return b.fatigue - a.fatigue; })[0]
    };
    // recommendations
    if (report.team.avgFatigue > 55) report.notes.push('Fatigue is high (' + report.team.avgFatigue + '%). Use a light week or invest in recovery facilities before the next series.');
    if (org.chemistry < 55) report.notes.push('Chemistry is low. Coordination or communication training would raise the floor more than individual aim work.');
    if (report.players.some(function (x) { return x.potential - x.level > 12 && x.delta < 0.15; })) report.notes.push('Some high-potential players barely improved — check facilities and coaching quality.');
    if (!report.notes.length) report.notes.push('Training was productive. Continue with the current plan or target the weakest phase of your game.');
    state.trainingWeeks = (state.trainingWeeks || 0) + 1;
    return report;
  }

  /* ------------------------------------------------------------------
     ECONOMY
  ------------------------------------------------------------------ */
  function weeklyFinance(state) {
    var lines = [];
    var total = 0;
    for (var id in state.orgs) {
      var org = state.orgs[id];
      if (org.status === 'inactive') continue;
      var playerWages = 0, staffWages = 0;
      (org.roster || []).forEach(function (pid) { var p = state.players[pid]; if (p && !p.retired) playerWages += p.wage / 52; });
      (org.staff || []).forEach(function (sid) { var s = state.staff[sid]; if (s) staffWages += s.salary / 52; });
      var wages = playerWages + staffWages;
      var academy = (state.academy[org.id] || []).reduce(function (s, pid) { var p = state.players[pid]; return s + (p ? p.wage / 52 : 0); }, 0);
      var facilities = (org.facilities ? (org.facilities.training + org.facilities.recovery + org.facilities.analysis + org.facilities.academy) * 140 : 560) / 52;
      var partnerStipend = org.partner ? 26000 : 0;
      var commercial = org.partner ? Math.max(2500, Math.round(4500 + ((org.rep || 70) - 65) * 140)) : Math.max(800, Math.round(1400 + ((org.rep || 55) - 45) * 65));
      var sponsor = org.isUser ? 0 : (org.sponsor || 0) / 52;
      var misc = org.partner ? 1600 : 450;
      var net = sponsor + partnerStipend + commercial - wages - academy - facilities - misc;
      org.budget = Math.round((org.budget || 0) + net);
      if (org.isUser) {
        lines = [
          { label: 'Partner stipend', value: partnerStipend },
          { label: 'Commercial & merch', value: commercial },
          { label: 'Player wages', value: -Math.round(playerWages) },
          { label: 'Staff wages', value: -Math.round(staffWages) },
          { label: 'Academy wages', value: -Math.round(academy) },
          { label: 'Facilities upkeep', value: -Math.round(facilities) },
          { label: 'Operations', value: -misc }
        ];
        total = net;
      }
    }
    return { lines: lines, total: Math.round(total) };
  }

  function monthlySponsor(state) {
    // annual sponsor deals pay weekly; here we refresh sponsor offers for the user
    return true;
  }

  /* ------------------------------------------------------------------
     TRANSFERS
  ------------------------------------------------------------------ */
  function wageDemand(p, org) {
    var demand = Math.round(wageFor(p) * (1 + (org && org.rep > 85 ? 0.16 : 0) + (p.rep > 70 ? 0.1 : 0)));
    return Math.max(24000, Math.round(demand / 1000) * 1000);
  }
  function askingPrice(p) {
    if (!p.org) return 0;
    if (p.transferListed && p.askingPrice != null) return Math.max(5000, Math.round(p.askingPrice / 5000) * 5000);
    return Math.round(valueFor(p) * 1.25 / 5000) * 5000;
  }

  function acceptOffer(state, p, buyingOrg, offer) {
    var sellingOrg = p.org ? state.orgs[p.org] : null;
    var score = 0;
    var reasons = [];
    var wage = offer.wage || 0;
    var fee = offer.fee || 0;
    var demand = wageDemand(p, buyingOrg);
    if (wage >= demand) { score += 34; reasons.push('The salary meets the player expectation.'); }
    else if (wage >= demand * 0.9) { score += 18; reasons.push('The salary is slightly below expectation but workable.'); }
    else { score -= 26; reasons.push('The salary offer is below the player expectation of ' + C.money(demand) + ' per year.'); }
    if (!sellingOrg) { score += 22; reasons.push('The player is a free agent and wants a project.'); }
    var repDiff = (buyingOrg.rep || 50) - (p.rep || 45) * 0.65;
    score += C.clamp(repDiff * 0.5, -22, 18);
    if ((buyingOrg.rep || 50) < 65) reasons.push('Club reputation is a concern for a player of this level.');
    if (offer.playingTime === 'starter') { score += 12; }
    else if (offer.playingTime === 'rotation') { score += 4; }
    else { score -= 5; reasons.push('The player expects a clearer starting role.'); }
    if (sellingOrg) {
      var squadSize = (sellingOrg.roster || []).length;
      var want = askingPrice(p);
      if (p.transferListed) { score += 10; reasons.push('The player is transfer-listed and available.'); }
      if (fee >= want * 1.15) { score += 30; reasons.push('The selling club accepts the fee immediately.'); }
      else if (fee >= want * (p.transferListed ? 0.85 : 0.9)) { score += 14; reasons.push('The selling club is open to the fee.'); }
      else { score -= 30; reasons.push('The selling club wants ' + C.money(want) + ' and rejected the fee.'); }
      if (squadSize <= 5 && !p.transferListed) { score -= 12; reasons.push('The selling club cannot afford to lose a starter.'); }
    }
    if (p.personality === 'Mercenary') score += wage > demand ? 10 : -8;
    if (p.personality === 'Leader' && buyingOrg.rep > 80) score += 5;
    if (p.personality === 'Volatile' && buyingOrg.rep < 60) score -= 6;
    if (p.contractEnd <= state.season && sellingOrg) score += 8;
    var accepted = score >= 28;
    var counter = 0;
    if (!accepted && score > 6) {
      counter = Math.round((p.org ? askingPrice(p) : 0) * 1.05 / 5000) * 5000;
      if (!p.org) counter = Math.round(demand * 1.1 / 1000) * 1000;
    }
    return { accepted: accepted, score: Math.round(score), reasons: reasons, counterWage: counter, counterFee: p.org ? counter : 0 };
  }

  function completeTransfer(state, p, toOrg, offer) {
    var fromOrg = p.org ? state.orgs[p.org] : null;
    var fee = Math.max(0, Math.round(offer.fee || 0));
    var signingBonus = Math.max(0, Math.round(offer.signingBonus || 0));
    if (fromOrg) {
      fromOrg.roster = (fromOrg.roster || []).filter(function (id) { return id !== p.id; });
      fromOrg.lineup = (fromOrg.lineup || []).filter(function (id) { return id !== p.id; });
      if (fromOrg.isUser) {
        if (fee > 0) C.recordTransaction(state, fromOrg.id, 'Transfer received — ' + p.nick, fee, {
          type: 'transfer', category: 'transfers', playerId: p.id,
          lines: [{ label: 'Transfer fee — ' + p.nick, value: fee }]
        });
      } else {
        fromOrg.budget = Math.round((fromOrg.budget || 0) + fee);
      }
    }
    if (p.academy) { delete p.academy; state.academy[fromOrg ? fromOrg.id : ''] = (state.academy[fromOrg ? fromOrg.id : ''] || []).filter(function (id) { return id !== p.id; }); }
    p.org = toOrg.id;
    p.status = 'starter';
    p.transferListed = false;
    delete p.askingPrice;
    p.wage = offer.wage || wageDemand(p, toOrg);
    p.value = valueFor(p);
    p.joined = state.date;
    p.tenure = 1;
    p.form = 68;
    toOrg.roster = (toOrg.roster || []);
    if (toOrg.roster.indexOf(p.id) < 0) toOrg.roster.push(p.id);
    if (toOrg.isUser) {
      if (fee > 0) C.recordTransaction(state, toOrg.id, 'Transfer paid — ' + p.nick, -fee, {
        type: 'transfer', category: 'transfers', playerId: p.id,
        lines: [{ label: 'Transfer fee — ' + p.nick, value: -fee }]
      });
      if (signingBonus > 0) C.recordTransaction(state, toOrg.id, 'Signing bonus — ' + p.nick, -signingBonus, {
        type: 'transfer', category: 'transfers', playerId: p.id,
        lines: [{ label: 'Signing bonus — ' + p.nick, value: -signingBonus }]
      });
    } else {
      toOrg.budget = Math.round((toOrg.budget || 0) - fee - signingBonus);
    }
    state.transferHistory.unshift({
      date: state.date, season: state.season, playerId: p.id, nick: p.nick, role: p.role,
      from: fromOrg ? fromOrg.id : null, fromName: fromOrg ? fromOrg.short : null,
      to: toOrg.id, toName: toOrg.short, fee: fee, wage: p.wage, signingBonus: signingBonus
    });
    if (fromOrg) fromOrg.aiNeeds = true;
    return true;
  }

  /* ------------------------------------------------------------------
     OBJECTIVES
  ------------------------------------------------------------------ */
  function generateObjectives(state, org) {
    var rep = org.rep, partner = org.partner, tier = org.tier;
    var objs = [];
    var deadline = state.season + '-12-15';
    function obj(cat, id, title, why, success, fail, target, metric, page, importance) {
      return { id: id, category: cat, title: title, why: why, success: success, fail: fail, target: target, metric: metric, page: page, importance: importance || 'normal', deadline: deadline, progress: 0, status: 'active' };
    }
    if (rep >= 88) {
      objs.push(obj('Sporting', 'kickoff_top3', 'Finish top three at Kickoff', 'You are one of the flagship organisations in your region. The board expects the new 12-team Kickoff format to end with a Masters Seoul qualification.', 'Qualify for Masters Seoul via a top-three Kickoff finish.', 'Board confidence falls sharply and the season is labelled a failure.', 3, 'kickoffPos', 'competitions', 'critical'));
      objs.push(obj('Sporting', 'masters_playoff', 'Reach the Masters playoffs', 'A partner of your stature is measured internationally, not only regionally.', 'Win a Masters playoff series.', 'Reputation stagnates and sponsor renewal becomes harder.', 1, 'mastersPlayoffWin', 'competitions', 'high'));
      objs.push(obj('Sporting', 'champions', 'Qualify for Champions', 'Champions is the minimum standard for an elite roster with your payroll.', 'Secure a Champions ' + (state.season || 2027) + ' spot.', 'The board will question the entire project.', 1, 'championsQualified', 'competitions', 'critical'));
      objs.push(obj('Financial', 'budget_positive', 'Keep the budget positive', 'Your wage bill is the largest in the region. The board will not cover repeated losses.', 'End the season with a positive balance.', 'Budget cuts in the next transfer window.', 0, 'budgetPositive', 'finances', 'high'));
    } else if (rep >= 80) {
      objs.push(obj('Sporting', 'kickoff_playoff', 'Reach the Kickoff playoffs', 'Your squad is competitive but not dominant. The board wants a playoff run and a chance at a Masters spot.', 'Finish in the top eight of Kickoff.', 'A bottom-four finish triggers a review.', 8, 'kickoffPos', 'competitions', 'high'));
      objs.push(obj('Sporting', 'cup_top4', 'Reach a Cup semi-final', 'The new Cup format is the fastest route to international points.', 'Finish top four in at least one regional Cup.', 'Missed international exposure.', 4, 'bestCupPos', 'competitions', 'high'));
      objs.push(obj('Squad', 'chemistry_65', 'Build a cohesive roster', 'Your rebuild needs evidence of coordination, not just individual talent.', 'Reach 65 team chemistry.', 'Recruitment strategy will be reviewed.', 65, 'chemistry', 'training', 'normal'));
      objs.push(obj('Financial', 'payroll_control', 'Control the payroll', 'The board set a wage ceiling for the season.', 'Keep annual payroll under $2.4M.', 'Financial restrictions next season.', 2400000, 'payroll', 'finances', 'normal'));
    } else if (rep >= 70) {
      objs.push(obj('Sporting', 'oq_kickoff', 'Qualify for VCT Kickoff', 'As a non-partner organisation, the Open Qualifier is your only route into the VCT proper. Everything else follows from it.', 'Win a place in Kickoff through the Open Qualifier.', 'The season becomes a developmental one.', 1, 'kickoffQualified', 'competitions', 'critical'));
      objs.push(obj('Sporting', 'oq_final', 'Reach the regional Open Qualifier final', 'A deep run builds reputation and proves the project is credible.', 'Reach the final stage of your regional qualifier.', 'Sponsors lose interest.', 2, 'oqStage', 'competitions', 'high'));
      objs.push(obj('Squad', 'sign_prospect', 'Sign one high-potential prospect', 'The board wants a sustainable project, not only short-term results.', 'Sign a player under 21 with 4+ potential stars.', 'Academy plan is questioned.', 1, 'prospectsSigned', 'recruitment', 'normal'));
      objs.push(obj('Squad', 'stable_five', 'Establish a stable starting five', 'Constant rotation prevents chemistry from developing.', 'Play five consecutive matches with the same lineup.', 'Team development stalls.', 5, 'sameLineupStreak', 'squad', 'normal'));
    } else {
      objs.push(obj('Sporting', 'oq_top_half', 'Finish in the top half of the Open Qualifier', 'You are building from the ground up. A respectable qualifier run is the first proof of concept.', 'Reach at least the second stage of your Open Qualifier.', 'The board reviews the project.', 2, 'oqStage', 'competitions', 'critical'));
      objs.push(obj('Squad', 'five_players', 'Build a complete five-player roster', 'You cannot compete without five contracted players in every role.', 'Contract at least five players with role coverage.', 'Forfeits and reputational damage.', 5, 'rosterSize', 'squad', 'critical'));
      objs.push(obj('Financial', 'stay_solvent', 'Stay financially solvent', 'A new organisation cannot absorb a negative balance for long.', 'End the season above $0.', 'Forced player sales.', 0, 'budgetPositive', 'finances', 'high'));
      objs.push(obj('Long-term', 'academy_start', 'Create an academy pipeline', 'Long-term success depends on developing your own talent.', 'Recruit at least two academy prospects.', 'Project lacks a future.', 2, 'academyCount', 'academy', 'normal'));
    }
    if (org.partner && rep < 84) objs.push(obj('Financial', 'sponsor', 'Sign a new sponsor', 'Commercial growth is part of the partnership agreement.', 'Secure a sponsor deal worth at least $350K/year.', 'Partnership review pressure.', 350000, 'sponsorValue', 'finances', 'normal'));
    return objs;
  }

  function objectiveProgress(state, obj, org) {
    var v = 0;
    switch (obj.metric) {
      case 'budgetPositive': v = org.budget > 0 ? 1 : 0; break;
      case 'chemistry': v = Math.round(org.chemistry || 0); break;
      case 'payroll': v = (org.roster || []).reduce(function (s, id) { var p = state.players[id]; return s + (p ? p.wage : 0); }, 0); break;
      case 'rosterSize': v = (org.roster || []).filter(function (id) { return state.players[id]; }).length; break;
      case 'academyCount': v = (state.academy[org.id] || []).length; break;
      case 'sponsorValue': v = org.sponsor || 0; break;
      case 'kickoffPos': v = state.flags.kickoffPos || 99; break;
      case 'kickoffQualified': v = state.flags.kickoffQualified ? 1 : 0; break;
      case 'oqStage': v = state.flags.oqStage || 0; break;
      case 'bestCupPos': v = state.flags.bestCupPos || 99; break;
      case 'mastersPlayoffWin': v = state.flags.mastersPlayoffWin || 0; break;
      case 'championsQualified': v = state.flags.championsQualified ? 1 : 0; break;
      case 'prospectsSigned': v = state.flags.prospectsSigned || 0; break;
      case 'sameLineupStreak': v = state.flags.sameLineupStreak || 0; break;
      default: v = 0;
    }
    var done = false;
    if (obj.metric === 'kickoffPos' || obj.metric === 'bestCupPos') done = v <= obj.target;
    else if (obj.metric === 'sponsorValue') done = v >= obj.target;
    else if (obj.metric === 'payroll' || obj.metric === 'budgetPositive') done = obj.metric === 'budgetPositive' ? v === 1 : v <= obj.target;
    else done = v >= obj.target;
    obj.progress = v;
    obj.done = done;
    return obj;
  }

  function boardConfidence(state, org) {
    var base = 55;
    var objs = state.objectives || [];
    var done = objs.filter(function (o) { return o.done; }).length;
    var fail = objs.filter(function (o) { return o.status === 'failed'; }).length;
    base += done * 9 - fail * 14;
    var form = (org.form || []).slice(-6);
    var wins = form.filter(function (x) { return x === 'W'; }).length;
    base += (wins - (form.length - wins)) * 2.2;
    if (org.budget < 0) base -= 15;
    if (org.budget < -1000000) base -= 15;
    var pat = (C.DIFFICULTY[state.difficulty] || C.DIFFICULTY.Normal).patience;
    if (base < 30) base = Math.round(30 + (base - 30) / pat);
    return Math.round(C.clamp(base, 0, 100));
  }

  /* ------------------------------------------------------------------
     SEASON AWARDS + HISTORY HELPERS
  ------------------------------------------------------------------ */
  function seasonAwards(state, orgs, comps) {
    var all = Object.keys(state.players).map(function (id) { return state.players[id]; }).filter(function (p) { return p.org && !p.retired; });
    var best = all.slice().sort(function (a, b) { return (b.level + (b.stats.mvps || 0)) - (a.level + (a.stats.mvps || 0)); })[0];
    var rising = all.filter(function (p) { return p.age <= 21; }).sort(function (a, b) { return (b.level + b.potential) - (a.level + a.potential); })[0];
    return {
      mvp: best ? best.id : null,
      risingStar: rising ? rising.id : null,
      season: state.season
    };
  }

  function managerLevel(xp) {
    var lvl = 1, need = 100;
    while (xp >= need) { xp -= need; lvl++; need = Math.round(need * 1.45); }
    return { level: lvl, progress: Math.round(xp / need * 100), next: need - xp };
  }

  return {
    CORE_ATTRS: CORE_ATTRS, ROLE_ATTRS: ROLE_ATTRS, ATTR_LABELS: ATTR_LABELS, PERSONALITIES: PERSONALITIES,
    overall: overall, potentialStars: potentialStars, wageFor: wageFor, valueFor: valueFor,
    roleBalance: roleBalance, teamRating: teamRating, agentFit: agentFit, buildPlayer: buildPlayer,
    fromSpec: fromSpec, genPlayer: genPlayer, genStaff: genStaff, genNick: genNick,
    simulateSeries: simulateSeries, simMap: simMap, analyse: analyse, veto: veto,
    runTraining: runTraining, trainingFactors: trainingFactors, weeklyFinance: weeklyFinance,
    wageDemand: wageDemand, askingPrice: askingPrice, acceptOffer: acceptOffer, completeTransfer: completeTransfer,
    generateObjectives: generateObjectives, objectiveProgress: objectiveProgress, boardConfidence: boardConfidence,
    seasonAwards: seasonAwards, managerLevel: managerLevel, emptyStats: emptyStats, shareHistory: shareHistory
  };
})();
