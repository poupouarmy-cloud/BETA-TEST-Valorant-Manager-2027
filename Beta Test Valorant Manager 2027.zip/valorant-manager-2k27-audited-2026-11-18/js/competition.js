/* =====================================================================
   VALORANT MANAGER 2027 — COMPETITION ENGINE
   Official 2027 structure where published, clearly-labelled simulation
   rules where Riot has not published a detailed format.
   ===================================================================== */
var Competition = (function () {
  'use strict';
  var C = Core;

  var REGION_NAMES = { Americas: 'VCT Americas', EMEA: 'VCT EMEA', Pacific: 'VCT Pacific', China: 'VCT China' };

  var RULES = {
    kickoff: {
      field: 'Americas/EMEA/Pacific: 8 partners + 4 Open Qualifiers (12 teams). China: 8 partners + 2 visitors + 2 Open Qualifiers (12 teams).',
      format: 'Swiss stage (3 rounds, Bo3) into a single-elimination top-8 bracket (Bo3, final Bo5).',
      qualification: 'Top three teams qualify for Masters Seoul as seeds 1-3. Partner status guarantees Kickoff entry only, not qualification beyond it.',
      status: 'OFFICIAL field and qualification; SIMULATED bracket format.',
      rewards: 'Non-partner qualification payment: $100,000. Prize pool: $250,000.'
    },
    cup: {
      field: '8 partners plus 4 Open Qualifier teams (China: 8 partners, 2 visitors, 2 Open Qualifier teams).',
      format: 'Swiss stage (3 rounds, Bo3) into a top-8 single-elimination bracket. Final Bo5.',
      qualification: 'Top four qualify for the next international event (Masters 2 for Cup 1, Champions for Cup 2).',
      status: 'OFFICIAL field principles ($100K qualification payment); SIMULATED bracket format.',
      rewards: 'Non-partner qualification payment: $100,000. Prize pool: $400,000.'
    },
    masters: {
      field: 'Masters Seoul: 12 teams, three per region from Kickoff. Masters 2: 16 teams, four per region from Cup 1.',
      format: 'Swiss stage into a top-8 single-elimination bracket. Final Bo5.',
      qualification: 'Champion and finalists earn world ranking points and reputation. Masters Seoul is official (20 Feb - 3 Mar 2027); Masters 2 venue unpublished.',
      status: 'OFFICIAL Seoul dates and 3-per-region qualification; SIMULATED bracket and Masters 2 details.',
      rewards: 'Non-partner qualification payment: $200,000. Prize pool: $1,000,000.'
    },
    champions: {
      field: '16 teams, four per region, qualified through Cup 2 performance.',
      format: 'Swiss stage (4 rounds) into a top-8 single-elimination bracket. Final Bo5.',
      qualification: 'Season-ending world championship. Winner is recorded in the Hall of Fame.',
      status: 'OFFICIAL Champions qualification route (performance-based); SIMULATED field size and bracket.',
      rewards: 'Non-partner qualification payment: $400,000. Prize pool: $2,250,000.'
    },
    oq: {
      field: 'Americas (NA, LAN, LAS, Brazil), EMEA (Europe x2, Türkiye, MENA), Pacific (8 sub-regions into a 4-slot playoff), China (2 slots).',
      format: 'Sub-regional single-elimination qualifiers. Pacific sub-region winners meet in a regional playoff for four slots.',
      qualification: 'Winners enter Kickoff or the relevant Cup. Teams retaining 3 of 5 players keep competitive progress (roster continuity rule).',
      status: 'OFFICIAL territories, 3-of-5 continuity rule and payments; SIMULATED bracket sizes.',
      rewards: 'Qualification payment on reaching Kickoff or a Cup: $100,000 (non-partner teams).'
    },
    lcq: {
      field: 'Pacific LCQ: two South Asia and two Oceania teams.',
      format: 'Single-elimination playoff. Winner earns the fourth Pacific slot for Cup 2.',
      qualification: 'Additional Pacific qualification route for South Asia and Oceania.',
      status: 'OFFICIAL LCQ existence; SIMULATED field size and exact reward.',
      rewards: 'Cup qualification payment applies on entry.'
    }
  };

  function seasonStart(year) { return (year - 1) + '-11-23'; }

  // Official VCT live-event cities. The 2027 season keeps its existing
  // configured values; subsequent seasons rotate deterministically by year.
  var GLOBAL_VENUES = ['Seoul', 'Valencia', 'Austin', 'Bangkok', 'Manila', 'Tokyo', 'London', 'Santiago', 'Shanghai', 'Toronto', 'Paris', 'Madrid'];
  var INITIAL_VENUES = { masters1: 'Seoul', masters2: 'TBD', champions: 'Seoul' };
  function venueSet(year) {
    if (year <= 2027) return INITIAL_VENUES;
    var previous = venueSet(year - 1), rng = C.RNG('vct-venues|' + year), picked = [];
    var result = {};
    ['masters1', 'masters2', 'champions'].forEach(function (eventKey) {
      var choices = GLOBAL_VENUES.filter(function (city) {
        return picked.indexOf(city) < 0 && city !== previous[eventKey];
      });
      if (!choices.length) choices = GLOBAL_VENUES.filter(function (city) { return picked.indexOf(city) < 0; });
      result[eventKey] = rng.pick(choices);
      picked.push(result[eventKey]);
    });
    return result;
  }
  function hasDirectQualifierEntry(state) {
    return !!(state && state.orgs && state.orgs[state.clubId] &&
      (state.championsTitleHolder || Number(state.majorTrophyBypassSeason) === Number(state.season)));
  }

  /* ---------------- competition blueprints for a season ---------------- */
  function plan(year) {
    var y = year, p = y - 1, venues = venueSet(y);
    return [
      { key: 'oq1', type: 'oq', name: 'Kickoff Open Qualifiers', short: 'OQ 1', start: p + '-11-24', end: p + '-12-20', cycle: 'kickoff', tier: 'open' },
      { key: 'kickoff', type: 'kickoff', name: 'VCT ' + y + ' Kickoff', short: 'KICKOFF', start: y + '-01-13', end: y + '-02-07', tier: 'regional' },
      { key: 'masters1', type: 'masters', name: 'Masters ' + venues.masters1 + ' ' + y, short: 'MASTERS 1', start: y + '-02-20', end: y + '-03-03', city: venues.masters1, tier: 'international' },
      { key: 'oq2', type: 'oq', name: 'Cup 1 Open Qualifiers', short: 'OQ 2', start: y + '-03-08', end: y + '-03-28', cycle: 'cup1', tier: 'open' },
      { key: 'cup1', type: 'cup', name: 'VCT ' + y + ' Cup 1', short: 'CUP 1', start: y + '-04-03', end: y + '-04-26', tier: 'regional' },
      { key: 'masters2', type: 'masters', name: y === 2027 ? 'Masters 2 ' + y : 'Masters ' + venues.masters2 + ' ' + y, short: 'MASTERS 2', start: y + '-05-10', end: y + '-05-24', city: venues.masters2, tier: 'international' },
      { key: 'lcq', type: 'lcq', name: 'VCT Pacific LCQ ' + y, short: 'LCQ', start: y + '-06-01', end: y + '-06-08', tier: 'regional' },
      { key: 'oq3', type: 'oq', name: 'Cup 2 Open Qualifiers', short: 'OQ 3', start: y + '-06-05', end: y + '-06-20', cycle: 'cup2', tier: 'open' },
      { key: 'cup2', type: 'cup', name: 'VCT ' + y + ' Cup 2', short: 'CUP 2', start: y + '-07-05', end: y + '-07-26', tier: 'regional' },
      { key: 'champions', type: 'champions', name: y === 2027 ? 'VALORANT Champions ' + y : 'VALORANT Champions ' + venues.champions + ' ' + y, short: 'CHAMPIONS', start: y + '-09-05', end: y + '-09-27', city: venues.champions, tier: 'international' }
    ];
  }

  function addDays(date, n) { return C.addDays(date, n); }

  /* ---------------- creation helpers ---------------- */
  function newComp(state, spec) {
    return {
      id: 'c_' + spec.key + '_' + state.season,
      key: spec.key, type: spec.type, name: spec.name, short: spec.short, season: state.season,
      startDate: spec.start, endDate: spec.end, city: spec.city || '', tier: spec.tier,
      region: spec.region || null, teams: [], status: 'scheduled', phase: 'setup',
      swiss: { rounds: [], target: spec.type === 'champions' ? 4 : 3 },
      standings: {}, playoffs: null, placements: {}, champion: null,
      roundDates: [], roundIndex: 0, playoffDates: [], playoffIndex: 0,
      prizePool: spec.type === 'champions' ? 2250000 : spec.type === 'masters' ? 1000000 : spec.type === 'cup' ? 400000 : spec.type === 'kickoff' ? 250000 : 60000,
      rules: RULES[spec.type] || RULES.kickoff, cycle: spec.cycle || null,
      qualifying: spec.qualifying || null, log: [], rewards: [], userReached: 0
    };
  }

  function seedsFrom(list, state) {
    return list.slice().sort(function (a, b) {
      var oa = state.orgs[a], ob = state.orgs[b];
      if (!oa) return 1; if (!ob) return -1;
      return (ob.points || 0) - (oa.points || 0) || (ob.rep || 0) - (oa.rep || 0);
    });
  }

  function makeSwiss(state, comp, teams) {
    comp.teams = teams.slice();
    comp.standings = {};
    teams.forEach(function (id) {
      comp.standings[id] = { id: id, w: 0, l: 0, mw: 0, ml: 0, rw: 0, rl: 0, opp: [], bu: 0 };
    });
    comp.phase = 'swiss';
    // dates: swiss rounds every 2 days from start
    comp.roundDates = [];
    var target = comp.swiss.target;
    for (var i = 0; i < target + 3; i++) comp.roundDates.push(addDays(comp.startDate, i * 2 + 1));
    comp.status = 'active';
    pairSwiss(state, comp);
  }

  function pairSwiss(state, comp) {
    var teams = comp.teams.slice();
    var round = comp.swiss.rounds.length;
    var st = comp.standings;
    // sort by wins then map diff then random-ish reputation
    teams.sort(function (a, b) {
      var A = st[a], B = st[b];
      return (B.w - A.w) || ((B.mw - B.ml) - (A.mw - A.ml)) || ((B.rw - B.rl) - (A.rw - A.rl)) || ((state.orgs[b].rep || 0) - (state.orgs[a].rep || 0));
    });
    var paired = [], used = {};
    // try to pair within same score groups, avoid rematches
    for (var i = 0; i < teams.length; i++) {
      var a = teams[i];
      if (used[a]) continue;
      var candidates = teams.filter(function (b) {
        return !used[b] && b !== a && st[a].opp.indexOf(b) < 0;
      });
      if (!candidates.length) candidates = teams.filter(function (b) { return !used[b] && b !== a; });
      // prefer same number of wins
      candidates.sort(function (x, y) {
        return Math.abs(st[x].w - st[a].w) - Math.abs(st[y].w - st[a].w) || (state.orgs[y].rep - state.orgs[x].rep);
      });
      var b = candidates[0];
      if (!b) continue;
      used[a] = used[b] = true;
      paired.push({ a: a, b: b, sa: 0, sb: 0, played: false, date: comp.roundDates[round], winner: null, maps: [] });
    }
    var roundObj = { name: 'Swiss Round ' + (round + 1), matches: paired, simulated: false, date: comp.roundDates[round], kind: 'swiss' };
    comp.swiss.rounds.push(roundObj);
    return roundObj;
  }

  function playoffStructure(n) {
    // n = 8 -> QF, SF, F (+3rd)
    var rounds = [];
    var labels = n === 8 ? ['Quarter-finals', 'Semi-finals', 'Grand Final'] : n === 4 ? ['Semi-finals', 'Grand Final'] : ['Grand Final'];
    var counts = n === 8 ? [4, 2, 1] : n === 4 ? [2, 1] : [1];
    for (var i = 0; i < labels.length; i++) rounds.push({ name: labels[i], matches: [], simulated: false, kind: 'playoff' });
    return rounds;
  }

  function seedPlayoffs(state, comp, n) {
    var seeds = Object.keys(comp.standings).sort(function (a, b) {
      var A = comp.standings[a], B = comp.standings[b];
      return (B.w - A.w) || ((B.mw - B.ml) - (A.mw - A.ml)) || ((B.rw - B.rl) - (A.rw - A.rl));
    }).slice(0, n);
    comp.playoffs = { seeds: seeds, rounds: playoffStructure(n), thirdPlace: n === 8 ? { a: null, b: null, played: false, winner: null, sa: 0, sb: 0 } : null, n: n };
    comp.phase = 'playoffs';
    // dates after swiss
    var base = comp.swiss.rounds[comp.swiss.rounds.length - 1].date;
    comp.playoffDates = [addDays(base, 3), addDays(base, 5), addDays(base, 8)];
    buildPlayoffRound(state, comp);
  }

  function buildPlayoffRound(state, comp) {
    var po = comp.playoffs;
    var idx = po.rounds.findIndex(function (r) { return !r.simulated && !r.matches.length; });
    if (idx < 0) return null;
    var round = po.rounds[idx];
    var date = comp.playoffDates[Math.min(idx, comp.playoffDates.length - 1)];
    round.date = date;
    if (idx === 0) {
      var s = po.seeds;
      if (po.n === 8) {
        round.matches = [
          { a: s[0], b: s[7], sa: 0, sb: 0, winner: null, played: false, date: date },
          { a: s[3], b: s[4], sa: 0, sb: 0, winner: null, played: false, date: date },
          { a: s[1], b: s[6], sa: 0, sb: 0, winner: null, played: false, date: date },
          { a: s[2], b: s[5], sa: 0, sb: 0, winner: null, played: false, date: date }
        ];
      } else if (po.n === 4) {
        round.matches = [
          { a: s[0], b: s[3], sa: 0, sb: 0, winner: null, played: false, date: date },
          { a: s[1], b: s[2], sa: 0, sb: 0, winner: null, played: false, date: date }
        ];
      } else {
        round.matches = [{ a: s[0], b: s[1], sa: 0, sb: 0, winner: null, played: false, date: date }];
      }
    } else {
      var prev = po.rounds[idx - 1];
      var winners = prev.matches.map(function (m) { return m.winner; });
      for (var i = 0; i < winners.length; i += 2) {
        if (winners[i] && winners[i + 1]) round.matches.push({ a: winners[i], b: winners[i + 1], sa: 0, sb: 0, winner: null, played: false, date: date });
      }
      if (idx === po.rounds.length - 1 && po.n === 8 && prev.matches.length === 4) {
        // third-place match: QF losers are not used; use SF losers
      }
    }
    return round;
  }

  /* ---------------- starting / advancing ---------------- */
  function createOQ(state, spec) {
    var comps = [];
    var regionSubs = {
      Americas: ['North America', 'Latin America North', 'Latin America South', 'Brazil'],
      EMEA: ['Europe', 'Europe', 'Türkiye', 'MENA'],
      Pacific: ['South Korea', 'Japan', 'Thailand', 'Indonesia', 'Vietnam', 'Southeast Asia', 'South Asia', 'Oceania'],
      China: ['China', 'China']
    };
    if (spec.cycle === 'cup1' || spec.cycle === 'cup2') {
      // same regional structure
    }
    ['Americas', 'EMEA', 'Pacific', 'China'].forEach(function (region) {
      var subs = regionSubs[region];
      subs.forEach(function (sub, si) {
        var slotOffset = 0;
        if (region === 'EMEA' && si === 1) slotOffset = 1;
        if (region === 'China' && si === 1) slotOffset = 1;
        var pool = openTeamsFor(state, region, sub, slotOffset, spec.cycle);
        var label = (sub === 'China' && si === 1) ? 'China B' : (sub === 'Europe' && si === 1 ? 'Europe B' : sub);
        var c = newComp(state, {
          key: spec.key + '_' + region.replace(/\s/g, '') + '_' + si + '_' + (label === 'Europe B' ? 'EUR2' : label.replace(/\s/g, '')),
          type: 'oq', name: label + ' Open Qualifier', short: 'OQ',
          start: addDays(spec.start, si * 2), end: spec.end, region: region, tier: 'open',
          cycle: spec.cycle
        });
        c.subRegion = sub;
        c.region = region;
        c.oqRound = si;
        var teams = pool.slice(0, 4);
        if (!teams.length) return;
        c.teams = teams;
        c.phase = 'bracket';
        c.bracket = singleElim(teams, addDays(spec.start, si * 2), 2);
        c.status = 'active';
        comps.push(c);
      });
    });
    return comps;
  }

  function openTeamsFor(state, region, sub, slotOffset, cycle) {
    slotOffset = slotOffset || 0;
    var all = Object.keys(state.orgs).map(function (id) { return state.orgs[id]; }).filter(function (o) {
      return o.status !== 'inactive' && !o.partner && o.region === region && o.sub === sub &&
        !(cycle && o.id === state.clubId && hasDirectQualifierEntry(state));
    });
    var ids = all.sort(function (a, b) { return (b.rep || 0) - (a.rep || 0); }).map(function (o) { return o.id; });
    if (!cycle || !hasDirectQualifierEntry(state)) {
      if (state.orgs[state.clubId] && state.orgs[state.clubId].sub === sub && !state.orgs[state.clubId].partner) {
      ids = ids.filter(function (id) { return id !== state.clubId; });
      ids.unshift(state.clubId);
      }
    }
    // second group in the same territory takes the next tranche of teams
    var start = slotOffset * 4;
    return ids.slice(start, start + 4);
  }

  function singleElim(teams, startDate, stages) {
    var rounds = [];
    var n = teams.length;
    var labels = n === 4 ? ['Semi-finals', 'Final'] : n === 8 ? ['Quarter-finals', 'Semi-finals', 'Final'] : ['Final'];
    var first = [];
    for (var i = 0; i < n / 2; i++) first.push({ a: teams[i], b: teams[n - 1 - i], sa: 0, sb: 0, winner: null, played: false, date: startDate });
    rounds.push({ name: labels[0], matches: first, simulated: false, date: startDate });
    for (var r = 1; r < labels.length; r++) rounds.push({ name: labels[r], matches: [], simulated: false, date: addDays(startDate, r * 2) });
    return { rounds: rounds, n: n };
  }

  function advanceBracket(state, comp, bracket, prefix) {
    var idx = bracket.rounds.findIndex(function (r) { return !r.simulated; });
    if (idx < 0) return null;
    var round = bracket.rounds[idx];
    if (!round.matches.length) {
      var prev = bracket.rounds[idx - 1];
      var winners = prev.matches.map(function (m) { return m.winner; });
      for (var i = 0; i < winners.length; i += 2) if (winners[i] && winners[i + 1]) round.matches.push({ a: winners[i], b: winners[i + 1], sa: 0, sb: 0, winner: null, played: false, date: round.date });
    }
    return { round: round, index: idx };
  }

  function teamName(state, id) { return state.orgs[id] ? state.orgs[id].short : id; }

  /* ---------------- match application ---------------- */
  function ensureLineup(state, org) {
    if (!org) return [];
    var roster = (org.roster || []).map(function (id) { return state.players[id]; }).filter(function (p) { return p && !p.retired; });
    if (!org.lineup) org.lineup = [];
    var healthyIds = roster.filter(function (p) { return !p.injury || p.injury.days <= 0; }).map(function (p) { return p.id; });
    org.lineup = org.lineup.filter(function (id) {
      var p = state.players[id];
      return p && p.org === org.id && !p.retired && (!p.injury || p.injury.days <= 0 || healthyIds.length < 5);
    });
    // fill healthy players first by role need and level, then injured if needed
    var need = C.ROLES.slice();
    var chosen = org.lineup.slice();
    var pool = roster.slice().sort(function (a, b) {
      var ia = (a.injury && a.injury.days > 0) ? 1 : 0;
      var ib = (b.injury && b.injury.days > 0) ? 1 : 0;
      return (ia - ib) || (b.level - a.level);
    });
    pool.forEach(function (p) {
      if (chosen.length >= 5 || chosen.indexOf(p.id) >= 0) return;
      var roleCount = chosen.map(function (id) { return state.players[id].role; }).filter(function (r) { return r === p.role; }).length;
      if (roleCount >= 1 && need.indexOf(p.role) >= 0) return;
      if (need.indexOf(p.role) >= 0) { need.splice(need.indexOf(p.role), 1); chosen.push(p.id); }
    });
    pool.forEach(function (p) { if (chosen.length < 5 && chosen.indexOf(p.id) < 0) chosen.push(p.id); });
    org.lineup = chosen.slice(0, 5);
    return org.lineup;
  }

  function registerMatch(state, comp, match, opts) {
    var A = state.orgs[match.a], B = state.orgs[match.b];
    if (!A || !B) return null;
    var isUser = A.isUser || B.isUser;
    var bo = opts && opts.bo ? opts.bo : 3;
    if (opts && opts.final) bo = 5;
    ensureLineup(state, A); ensureLineup(state, B);
    var series;
    if ((A.roster || []).length < 5 || (B.roster || []).length < 5) {
      var forfeitA = (A.roster || []).length < 5;
      series = {
        id: 'forfeit_' + Date.now() + '_' + Math.floor(Math.random() * 999), date: state.date,
        teamA: A.id, teamB: B.id, winner: forfeitA ? B.id : A.id, loser: forfeitA ? A.id : B.id,
        scoreA: forfeitA ? 0 : 2, scoreB: forfeitA ? 2 : 0, bo: bo, maps: [], veto: { maps: [], bans: [] },
        styleA: A.playstyle, styleB: B.playstyle, comp: comp.name, stage: opts && opts.stage || '',
        isUser: isUser, userWon: isUser ? ((A.isUser ? !forfeitA : forfeitA)) : null,
        forfeit: true, analysis: {
          headline: 'Forfeit', verdict: 'A team could not field five players and forfeited the series.',
          causes: [{ severity: 'high', title: 'Incomplete roster', detail: 'A minimum of five contracted players is required to compete.', fixes: [{ label: 'Open squad', page: 'squad' }, { label: 'Sign free agents', page: 'recruitment' }] }],
          strengths: [], metrics: {}, playerRanking: [], best: null, worst: null
        }, mvp: null
      };
    } else {
      series = Engine.simulateSeries(state, A, B, {
        bo: bo, compName: comp.name, compId: comp.id, stage: opts && opts.stage || '',
        lineupA: A.lineup, lineupB: B.lineup, styleA: A.playstyle, styleB: B.playstyle,
        tag: comp.key + '_' + (opts && opts.stage || '')
      });
    }
    state.matchCounter = (state.matchCounter || 0) + 1;
    match.played = true;
    match.winner = series.winner;
    match.sa = A.isUser || A.id === series.teamA ? series.scoreA : series.scoreB;
    match.sb = B.isUser || B.id === series.teamB ? series.scoreB : series.scoreA;
    match.scoreA = series.scoreA; match.scoreB = series.scoreB;
    match.result = series;
    return series;
  }

  function applySeriesEffects(state, comp, series, match) {
    var A = state.orgs[series.teamA], B = state.orgs[series.teamB];
    if (!A || !B) return;
    var Awin = series.winner === A.id;
    var scores = series.maps || [];
    // form / morale / fatigue only when maps were played
    if (!series.forfeit) {
      [A, B].forEach(function (org, i) {
        var win = (i === 0) === Awin;
        var lineup = (org.lineup || []).map(function (id) { return state.players[id]; }).filter(Boolean);
        org.form = (org.form || []).concat([win ? 'W' : 'L']).slice(-10);
        lineup.forEach(function (p) {
          p.form = C.clamp((p.form || 65) + (win ? rngSigned(series.id, p.id, 3) : rngSigned(series.id, p.id, -3)), 20, 99);
          p.morale = C.clamp((p.morale || 65) + (win ? 1.8 : -2.2), 15, 99);
          p.fatigue = C.clamp((p.fatigue || 10) + 3 + series.maps.length * 2.2, 0, 100);
          p.tenure = (p.tenure || 1);
        });
        org.chemistry = C.clamp((org.chemistry || 60) + (win ? 0.8 : -0.9), 0, 100);
        org.rep = C.clamp((org.rep || 50) + (win ? 0.35 : -0.15), 30, 99);
      });
    }
    // map statistics per organisation + player stats
    (series.maps || []).forEach(function (m) {
      if (m && m.map) {
        [A, B].forEach(function (org, idx) {
          org.mapStats = org.mapStats || {};
          var ms = org.mapStats[m.map] = org.mapStats[m.map] || { played: 0, wins: 0, losses: 0, rw: 0, rl: 0 };
          var wonMap = (idx === 0 && m.winner === 'A') || (idx === 1 && m.winner === 'B');
          ms.played++;
          if (wonMap) ms.wins++; else ms.losses++;
          ms.rw += idx === 0 ? (m.scoreA || 0) : (m.scoreB || 0);
          ms.rl += idx === 0 ? (m.scoreB || 0) : (m.scoreA || 0);
        });
      }
      for (var id in m.stats) {
        var p = state.players[id], s = m.stats[id];
        if (!p) continue;
        p.stats.maps++; p.stats.kills += s.k; p.stats.deaths += s.d; p.stats.assists += s.a;
        p.stats.fk += s.fk; p.stats.fd += s.fd; p.stats.clutches += s.clutch || 0;
        p.stats.rounds += s.rounds;
        p.stats.acs = Math.round(((p.stats.acs * (p.stats.maps - 1)) + s.acs) / p.stats.maps);
        p.stats.kd = p.stats.deaths ? Math.round((p.stats.kills / p.stats.deaths) * 100) / 100 : p.stats.kills;
        p.stats.adr = Math.round(((p.stats.adr * (p.stats.maps - 1)) + s.adr) / p.stats.maps);
      }
      if (m.mvp && state.players[m.mvp]) state.players[m.mvp].stats.mvps++;
    });
  }
  function rngSigned(seed, id, mag) {
    var r = C.RNG(seed + '|' + id).next();
    return Math.round((r * 2 - 1) * mag * 10) / 10;
  }

  /* ---------------- standings ---------------- */
  function updateStanding(state, comp, match) {
    var st = comp.standings[match.a], sb = comp.standings[match.b];
    if (!st || !sb) return;
    st.opp.push(match.b); sb.opp.push(match.a);
    var aw = match.winner === match.a;
    if (aw) { st.w++; sb.l++; } else { sb.w++; st.l++; }
    var sA = match.scoreA != null ? match.scoreA : match.sa;
    var sB = match.scoreB != null ? match.scoreB : match.sb;
    st.mw += sA; st.ml += sB; sb.mw += sB; sb.ml += sA;
    (match.result && match.result.maps || []).forEach(function (m) {
      var AisA = match.result.teamA === match.a;
      var realA = AisA ? m.scoreA : m.scoreB, realB = AisA ? m.scoreB : m.scoreA;
      st.rw += realA; st.rl += realB; sb.rw += realB; sb.rl += realA;
    });
  }

  function isUserMatch(state, match) {
    var A = state.orgs[match.a], B = state.orgs[match.b];
    return (A && A.isUser) || (B && B.isUser);
  }

  /* ---------------- run a round ---------------- */
  function playMatch(state, comp, match, opts) {
    if (match.played) return null;
    var series = registerMatch(state, comp, match, opts);
    if (!series) return null;
    applySeriesEffects(state, comp, series, match);
    if (comp.standings[match.a]) updateStanding(state, comp, match);
    match.result = series;
    addResultNews(state, comp, series);
    return series;
  }

  function addResultNews(state, comp, series) {
    var A = state.orgs[series.teamA], B = state.orgs[series.teamB];
    if (!A || !B) return;
    var isUser = A.isUser || B.isUser;
    var title = A.short + ' ' + series.scoreA + '-' + series.scoreB + ' ' + B.short;
    var winner = state.orgs[series.winner];
    var body = comp.name + ' · ' + (series.maps || []).map(function (m) {
      var isA = m.teamA ? false : true;
      return m.map + ' ' + m.scoreA + '-' + m.scoreB;
    }).join(' · ');
    if (!series.maps || !series.maps.length) body = comp.name + ' · series forfeited.';
    state.news.unshift({
      id: 'n_' + Date.now().toString(36) + Math.floor(Math.random() * 1000), date: state.date,
      type: 'match', title: title, body: body, orgId: winner ? winner.id : null,
      importance: isUser ? 3 : comp.tier === 'international' ? 2 : 1, read: false, compId: comp.id
    });
    if (isUser && winner) {
      var userOrg = A.isUser ? A : B;
      var won = winner.id === userOrg.id;
      state.news.unshift({
        id: 'n_u' + Date.now().toString(36) + Math.floor(Math.random() * 1000), date: state.date,
        type: 'user', title: won ? 'Victory against ' + (A.isUser ? B.short : A.short) : 'Defeat against ' + (A.isUser ? B.short : A.short),
        body: series.analysis ? series.analysis.verdict : '', orgId: userOrg.id, importance: 4, read: false, compId: comp.id
      });
      userOrg.lastReport = series.id;
      state.lastReport = series;
    }
  }

  function checkUserProgress(state, comp) {
    if (!state.orgs[state.clubId] || !comp.teams.length) return;
    if (comp.teams.indexOf(state.clubId) < 0) return;
    var reached = comp.userReached || 0;
    var stage = comp.phase === 'playoffs' ? 2 : comp.phase === 'swiss' ? 1 : 0;
    comp.userReached = Math.max(reached, stage);
    if (comp.type === 'oq') {
      var alive = isTeamAlive(comp, state.clubId);
      if (alive) state.flags.oqStage = Math.max(state.flags.oqStage || 0, comp.phase === 'final' ? 3 : 2);
    }
  }
  function isTeamAlive(comp, id) {
    if (comp.bracket) {
      if (comp.bracket.rounds.every(function (r) { return r.simulated; })) return comp.bracket.rounds[comp.bracket.rounds.length - 1].matches[0].winner === id;
      return comp.bracket.rounds.some(function (r) { return r.matches.some(function (m) { return m.a === id || m.b === id; }); });
    }
    return true;
  }

  /* ---------------- completion / rewards ---------------- */
  function awardPrize(comp, pos) {
    var pool = comp.prizePool;
    var share = pos === 1 ? 0.38 : pos === 2 ? 0.2 : pos === 3 ? 0.12 : pos === 4 ? 0.09 : pos <= 8 ? 0.035 : 0.01;
    return Math.round(pool * share);
  }

  function completeComp(state, comp) {
    if (comp.status === 'done') return;
    comp.status = 'done';
    comp.phase = 'done';
    var placements = {};
    var order = [];
    if (!comp.playoffs && comp.bracket) {
      var brs = comp.bracket.rounds;
      var last = brs[brs.length - 1];
      if (comp.qualifyWinners) {
        var qual = last.matches.map(function (m) { return m.winner; }).filter(Boolean);
        var elim = last.matches.map(function (m) { return m.winner === m.a ? m.b : m.a; }).filter(Boolean);
        qual.forEach(function (id, i) { placements[id] = i + 1; order.push(id); });
        elim.forEach(function (id, i) { if (!placements[id]) placements[id] = 5 + i; });
        comp.champion = qual[0] || null;
      } else if (last && last.matches[0] && last.matches[0].winner) {
        var fm = last.matches[0];
        placements[fm.winner] = 1;
        placements[fm.winner === fm.a ? fm.b : fm.a] = 2;
        order.push(fm.winner);
        if (brs.length > 1) {
          brs[brs.length - 2].matches.forEach(function (m) {
            var lost = m.winner === m.a ? m.b : m.a;
            if (lost && !placements[lost]) placements[lost] = 3;
          });
        }
        comp.champion = fm.winner;
      }
    }
    if (comp.playoffs) {
      var rounds = comp.playoffs.rounds;
      var final = rounds[rounds.length - 1].matches[0];
      if (final && final.winner) {
        placements[final.winner] = 1;
        placements[final.winner === final.a ? final.b : final.a] = 2;
        order.push(final.winner);
        // third place
        if (comp.playoffs.thirdPlace && comp.playoffs.thirdPlace.winner) {
          placements[comp.playoffs.thirdPlace.winner] = 3;
          placements[comp.playoffs.thirdPlace.winner === comp.playoffs.thirdPlace.a ? comp.playoffs.thirdPlace.b : comp.playoffs.thirdPlace.a] = 4;
          order.push(comp.playoffs.thirdPlace.winner);
        } else if (rounds.length >= 2) {
          var sf = rounds[rounds.length - 2];
          var sfLosers = sf.matches.map(function (m) { return m.winner === m.a ? m.b : m.a; }).filter(Boolean);
          sfLosers.forEach(function (id, i) { if (!placements[id]) placements[id] = 3 + i; order.push(id); });
        }
        var qf = rounds.length >= 3 ? rounds[0] : null;
        if (qf) qf.matches.forEach(function (m) {
          var lost = m.winner === m.a ? m.b : m.a;
          if (!placements[lost]) placements[lost] = 5;
        });
      }
    }
    comp.teams.forEach(function (id) { if (!placements[id]) placements[id] = 9; });
    comp.placements = placements;
    comp.champion = Object.keys(placements).filter(function (id) { return placements[id] === 1; })[0] || null;
    // rewards + payments
    comp.teams.forEach(function (id) {
      var org = state.orgs[id]; if (!org || org.status === 'inactive') return;
      var pos = placements[id] || 9;
      var prize = awardPrize(comp, pos);
      var payment = 0;
      var qualifiedHere = pos <= 3 && (comp.type === 'oq' || comp.type === 'kickoff');
      if (!org.partner) {
        if (comp.type === 'kickoff' && comp.teams.indexOf(id) >= 0) payment += 100000;
        if (comp.type === 'cup') payment += 100000;
        if (comp.type === 'masters') payment += 200000;
        if (comp.type === 'champions') payment += 400000;
      }
      if (id === state.clubId) {
        if (prize > 0) C.recordTransaction(state, id, 'Prize money — ' + comp.name, prize, {
          type: 'prize', category: 'competition', compId: comp.id,
          lines: [{ label: 'Prize money — ' + comp.name + ' (P' + pos + ')', value: prize }]
        });
        if (payment > 0) C.recordTransaction(state, id, 'Qualification payment — ' + comp.name, payment, {
          type: 'qualification', category: 'competition', compId: comp.id,
          lines: [{ label: 'VCT qualification payment — ' + comp.name, value: payment }]
        });
      } else {
        org.budget = Math.round((org.budget || 0) + prize + payment);
      }
      org.points = (org.points || 0) + Math.max(0, 14 - pos) * (comp.tier === 'international' ? 3 : 1);
      if (comp.type === 'masters' || comp.type === 'champions') org.rep = C.clamp((org.rep || 50) + (pos === 1 ? 4 : pos <= 4 ? 2 : 0.5), 30, 99);
      if (id === state.clubId) {
        state.flags.seasonEarnings = (state.flags.seasonEarnings || 0) + prize + payment;
        if (pos === 1) {
          state.manager.trophies.push({
            name: comp.name, season: state.season, type: comp.type, city: comp.city || '', compId: comp.id
          });
          state.manager.xp += comp.tier === 'international' ? 120 : 60;
          if (['kickoff', 'cup', 'masters', 'champions'].indexOf(comp.type) >= 0) {
            state.majorTrophyBypassSeason = state.season + 1;
            if (comp.type === 'champions') state.championsTitleHolder = true;
          }
        }
      }
      comp.rewards.push({ orgId: id, pos: pos, prize: prize, payment: payment });
    });
    // qualification
    var placementsSorted = Object.keys(placements).sort(function (a, b) { return placements[a] - placements[b]; });
    comp.qualified = placementsSorted.slice(0, comp.qualSlots || 0);
    if (comp.type === 'kickoff') {
      state.qualifiers.masters1[comp.region] = placementsSorted.slice(0, 3);
      if (placementsSorted.indexOf(state.clubId) >= 0 && placementsSorted.indexOf(state.clubId) < 3 && state.orgs[state.clubId]) {
        state.flags.kickoffPos = placementsSorted.indexOf(state.clubId) + 1;
        state.flags.masters1Qualified = true;
      } else if (comp.teams.indexOf(state.clubId) >= 0) {
        state.flags.kickoffPos = placements[state.clubId];
      }
      if (comp.teams.indexOf(state.clubId) >= 0) state.flags.kickoffQualified = true;
    }
    if (comp.type === 'cup') {
      var q = placementsSorted.slice(0, 4);
      if (comp.key === 'cup1') state.qualifiers.masters2[comp.region] = q;
      else state.qualifiers.champions[comp.region] = q;
      if (comp.teams.indexOf(state.clubId) >= 0) {
        state.flags.bestCupPos = Math.min(state.flags.bestCupPos || 99, placements[state.clubId]);
        if (placements[state.clubId] < 4) {
          if (comp.key === 'cup1') state.flags.masters2Qualified = true;
          else state.flags.championsQualified = true;
        }
      }
    }
    if (comp.type === 'masters') {
      if (comp.teams.indexOf(state.clubId) >= 0) {
        state.flags.mastersPlayoffWin = Math.max(state.flags.mastersPlayoffWin || 0, placements[state.clubId] <= 4 ? 1 : 0);
      }
    }
    if (comp.type === 'champions') {
      if (comp.champion) {
        state.history.champions.push({ season: state.season, comp: comp.name, orgId: comp.champion, date: comp.endDate });
        state.news.unshift({
          id: 'n_champ' + Date.now(), date: state.date, type: 'trophy',
          title: state.orgs[comp.champion].name + ' win ' + comp.name + '!',
          body: state.orgs[comp.champion].name + ' are the ' + state.season + ' world champions.'
        });
      }
    }
    if (comp.type === 'oq') {
      if (comp.qualifyWinners) {
        var pq = placementsSorted.filter(function (id) { return (placements[id] || 99) <= comp.qualifyWinners; });
        if (hasDirectQualifierEntry(state) && state.orgs[state.clubId].region === 'Pacific' && pq.indexOf(state.clubId) < 0) {
          if (pq.length >= comp.qualifyWinners) pq.pop();
          pq.unshift(state.clubId);
        }
        state.qualifiers.kickoff.Pacific = pq;
        state.qualifiers.pacificPlayoffDone = true;
        state.news.unshift({
          id: 'n_pacq' + Date.now(), date: state.date, type: 'competition',
          title: 'Pacific Playoff: four Kickoff places decided',
          body: pq.map(function (id) { return state.orgs[id] ? state.orgs[id].name : id; }).join(', ') + ' advance to VCT Kickoff.',
          orgId: pq[0] || null, importance: 3, read: false, compId: comp.id
        });
        if (pq.indexOf(state.clubId) >= 0) {
          state.flags.oqStage = 4;
          state.flags.kickoffQualified = true;
          state.news.unshift({
            id: 'n_pacq_u' + Date.now(), date: state.date, type: 'user',
            title: 'QUALIFIED: VCT Kickoff', body: 'You came through the Pacific Regional Playoff. The $100,000 non-partner qualification payment is applied on Kickoff entry.',
            orgId: state.clubId, importance: 5, read: false
          });
        }
      } else {
        // record OQ winner for cycle
        var winnerId = comp.champion;
        if (winnerId) {
          var bucket = state.qualifiers[comp.cycle] = state.qualifiers[comp.cycle] || {};
          bucket[comp.region] = bucket[comp.region] || [];
          if (bucket[comp.region].indexOf(winnerId) < 0) bucket[comp.region].push(winnerId);
          if (winnerId === state.clubId) {
            state.flags.oqStage = 4;
            state.flags.kickoffQualified = true;
            state.news.unshift({
              id: 'n_oq' + Date.now(), date: state.date, type: 'user',
              title: 'QUALIFIED: ' + comp.name, body: 'Your organisation has won a place in the next VCT stage. The qualification payment will be paid on entry.',
              orgId: state.clubId, importance: 5, read: false
            });
          }
        }
      }
    }
    // record history
    state.history.competitions.push({
      season: state.season, id: comp.id, name: comp.name, type: comp.type, region: comp.region, city: comp.city || '',
      champion: comp.champion, runnerUp: placementsSorted[1] || null,
      placements: comp.teams.map(function (id) { return { orgId: id, pos: placements[id] || 9 }; }),
      date: comp.endDate
    });
    comp.teams.forEach(function (id) {
      var org = state.orgs[id];
      if (org) { org.form = (org.form || []); }
    });
    state.news.unshift({
      id: 'n_done' + Date.now(), date: state.date, type: 'competition',
      title: (comp.champion ? state.orgs[comp.champion].name + ' win ' + comp.name : comp.name + ' completed'),
      body: 'Final standings are available in Competitions.', orgId: comp.champion || null,
      importance: comp.tier === 'international' ? 4 : 2, read: false, compId: comp.id
    });
  }

  /* ---------------- season orchestration ---------------- */
  function initSeason(state) {
    state.comps = state.comps || {};
    state.qualifiers = { kickoff: {}, cup1: {}, cup2: {}, masters1: {}, masters2: {}, champions: {}, lcq: {} };
    state.flags = state.flags || {};
    if (hasDirectQualifierEntry(state) && !state.orgs[state.clubId].partner) {
      var directRegion = state.orgs[state.clubId].region;
      ['kickoff', 'cup1', 'cup2'].forEach(function (cycle) { state.qualifiers[cycle][directRegion] = [state.clubId]; });
      state.flags.directMajorEntry = true;
      state.news = state.news || [];
      state.news.unshift({
        id: 'n_direct_vct_' + state.season + '_' + state.clubId,
        date: state.date, type: 'user', title: 'Direct VCT event entry',
        body: state.championsTitleHolder
          ? 'As reigning Champions, your club bypasses Open Qualifiers for Kickoff and both Cups. Masters and Champions places are still earned by competition results.'
          : 'Your major-trophy title grants direct entry to Kickoff and both Cups this season; Open Qualifiers are skipped.',
        orgId: state.clubId, importance: 4, read: false
      });
    }
    var plans = plan(state.season);
    plans.forEach(function (p) {
      if (p.type === 'oq') return; // created dynamically at start date
      // these are created when their teams are known
    });
    // create the first OQ wave immediately
    createOQ(state, plans[0]).forEach(function (c) { state.comps[c.id] = c; });
    // Kickoff created when OQ completes (or at start date with whatever is qualified)
    state.seasonPlan = plans;
    state.lastCompCheck = state.date;
  }

  function partnerList(state, region) {
    return Object.keys(state.orgs).filter(function (id) {
      var o = state.orgs[id];
      return o.partner && o.region === region && o.status !== 'inactive';
    });
  }

  function createKickoff(state, bp) {
    ['Americas', 'EMEA', 'Pacific', 'China'].forEach(function (region) {
      var teams = partnerList(state, region).slice(0, 8);
      var q = (state.qualifiers.kickoff[region] || []).filter(function (id) { return teams.indexOf(id) < 0; });
      if (region === 'China') {
        // 8 partners + 2 visitors + 2 OQ
        var visitors = visitorTeams(state, 'China', 2).filter(function (id) { return teams.indexOf(id) < 0 && q.indexOf(id) < 0; });
        teams = teams.concat(visitors.slice(0, 2), q.slice(0, 2));
      } else {
        teams = teams.concat(q.slice(0, 4));
      }
      // fill if OQ incomplete
      var others = seedsFrom(Object.keys(state.orgs).filter(function (id) {
        var o = state.orgs[id]; return o.region === region && o.status !== 'inactive' && teams.indexOf(id) < 0 && !o.partner;
      }), state);
      while (teams.length < 12 && others.length) teams.push(others.shift());
      var c = newComp(state, { key: 'kickoff_' + region.replace(/\s/g, ''), type: 'kickoff', name: bp.name + ' — ' + region, short: bp.short, start: bp.start, end: bp.end, region: region, tier: 'regional' });
      c.qualSlots = 3;
      makeSwiss(state, c, seedsFrom(teams, state));
      state.comps[c.id] = c;
    });
  }

  function visitorTeams(state, region, n) {
    return seedsFrom(Object.keys(state.orgs).filter(function (id) {
      var o = state.orgs[id];
      return o.region === region && !o.partner && o.status !== 'inactive';
    }), state).slice(0, n);
  }

  function createCup(state, bp, key) {
    ['Americas', 'EMEA', 'Pacific', 'China'].forEach(function (region) {
      var teams = partnerList(state, region).slice(0, 8);
      var q = (state.qualifiers[state.seasonPlan.filter(function (x) { return x.key === key; })[0].cycle || key] || {})[region] || [];
      q = q.filter(function (id) { return teams.indexOf(id) < 0; });
      if (region === 'China') {
        var visitors = visitorTeams(state, 'China', 2).filter(function (id) { return teams.indexOf(id) < 0 && q.indexOf(id) < 0; });
        teams = teams.concat(visitors.slice(0, 2), q.slice(0, 2));
      } else {
        teams = teams.concat(q.slice(0, 4));
      }
      var others = seedsFrom(Object.keys(state.orgs).filter(function (id) {
        var o = state.orgs[id]; return o.region === region && o.status !== 'inactive' && teams.indexOf(id) < 0;
      }), state);
      while (teams.length < 12 && others.length) teams.push(others.shift());
      var c = newComp(state, { key: key + '_' + region.replace(/\s/g, ''), type: 'cup', name: bp.name + ' — ' + region, short: bp.short, start: bp.start, end: bp.end, region: region, tier: 'regional' });
      c.qualSlots = 4;
      makeSwiss(state, c, seedsFrom(teams, state));
      state.comps[c.id] = c;
    });
  }

  function createMasters(state, bp, key) {
    var teams = [];
    var source = key === 'masters1' ? state.qualifiers.masters1 : state.qualifiers.masters2;
    ['Americas', 'EMEA', 'Pacific', 'China'].forEach(function (region) {
      (source[region] || []).forEach(function (id) { if (teams.indexOf(id) < 0) teams.push(id); });
    });
    var others = seedsFrom(Object.keys(state.orgs).filter(function (id) {
      return state.orgs[id].status !== 'inactive' && teams.indexOf(id) < 0;
    }), state);
    var need = key === 'masters1' ? 12 : 16;
    while (teams.length < need && others.length) teams.push(others.shift());
    var c = newComp(state, { key: key, type: 'masters', name: bp.name, short: bp.short, start: bp.start, end: bp.end, tier: 'international', city: bp.city });
    c.qualSlots = 0;
    makeSwiss(state, c, seedsFrom(teams, state));
    state.comps[c.id] = c;
  }

  function createChampions(state, bp) {
    var teams = [];
    ['Americas', 'EMEA', 'Pacific', 'China'].forEach(function (region) {
      (state.qualifiers.champions[region] || []).forEach(function (id) { if (teams.indexOf(id) < 0) teams.push(id); });
    });
    var others = seedsFrom(Object.keys(state.orgs).filter(function (id) { return state.orgs[id].status !== 'inactive' && teams.indexOf(id) < 0; }), state);
    while (teams.length < 16 && others.length) teams.push(others.shift());
    var c = newComp(state, { key: 'champions', type: 'champions', name: bp.name, short: bp.short, start: bp.start, end: bp.end, tier: 'international', city: bp.city });
    c.qualSlots = 0;
    makeSwiss(state, c, seedsFrom(teams, state));
    state.comps[c.id] = c;
  }

  function createLCQ(state, bp) {
    var pool = seedsFrom(Object.keys(state.orgs).filter(function (id) {
      var o = state.orgs[id];
      return o.region === 'Pacific' && (o.sub === 'South Asia' || o.sub === 'Oceania') && o.status !== 'inactive';
    }), state);
    var teams = pool.slice(0, 4);
    if (teams.length < 4) {
      var more = seedsFrom(Object.keys(state.orgs).filter(function (id) { return state.orgs[id].region === 'Pacific' && teams.indexOf(id) < 0 && state.orgs[id].status !== 'inactive'; }), state);
      while (teams.length < 4 && more.length) teams.push(more.shift());
    }
    var c = newComp(state, { key: 'lcq', type: 'lcq', name: bp.name, short: bp.short, start: bp.start, end: bp.end, tier: 'regional', region: 'Pacific' });
    c.qualSlots = 1;
    c.teams = teams;
    c.bracket = singleElim(teams, bp.start, 2);
    c.phase = 'bracket';
    c.status = 'active';
    state.comps[c.id] = c;
  }

  /* ---------------- master advance ---------------- */
  function advanceComp(state, comp, date, stopForUser) {
    var results = [];
    if (comp.status === 'done') return results;
    if (date < comp.startDate) return results;
    if (comp.type === 'oq' || comp.type === 'lcq') {
      if (!comp.bracket) return results;
      var b = advanceBracket(state, comp, comp.bracket, comp.key);
      if (!b) { completeComp(state, comp); return results; }
      if (date < b.round.date) return results;
      if (comp.teams.indexOf(state.clubId) >= 0 && comp.cycle === 'kickoff') {
        var isLast = b.index === comp.bracket.rounds.length - 1;
        state.flags.oqStage = Math.max(state.flags.oqStage || 0, isLast ? 3 : 2);
      }
      var bo = (comp.type === 'lcq') ? 3 : 3;
      for (var i = 0; i < b.round.matches.length; i++) {
        var m = b.round.matches[i];
        if (m.played) continue;
        if (isUserMatch(state, m) && stopForUser) {
          return { pending: { compId: comp.id, matchIndex: i, roundIndex: b.index, match: m }, results: results };
        }
        var s = playMatch(state, comp, m, { bo: bo, stage: b.round.name });
        if (s) results.push(s);
      }
      b.round.simulated = true;
      // create next round matches
      var nextIdx = comp.bracket.rounds.findIndex(function (r) { return !r.simulated; });
      if (nextIdx > 0) {
        var prev = comp.bracket.rounds[nextIdx - 1];
        var winners = prev.matches.map(function (x) { return x.winner; });
        var nm = comp.bracket.rounds[nextIdx];
        nm.matches = [];
        for (var w = 0; w < winners.length; w += 2) if (winners[w] && winners[w + 1]) nm.matches.push({ a: winners[w], b: winners[w + 1], sa: 0, sb: 0, winner: null, played: false, date: nm.date });
      }
      if (comp.bracket.rounds.every(function (r) { return r.simulated; })) completeComp(state, comp);
      else {
        // Need to simulate next round when its date arrives, handled next call.
      }
      return { results: results };
    }
    if (comp.phase === 'swiss') {
      var round = comp.swiss.rounds[comp.roundIndex];
      if (!round) { seedPlayoffs(state, comp, comp.type === 'champions' ? 8 : 8); return advanceComp(state, comp, date, stopForUser); }
      if (date < round.date) return { results: results };
      for (var j = 0; j < round.matches.length; j++) {
        var mm = round.matches[j];
        if (mm.played) continue;
        if (isUserMatch(state, mm) && stopForUser) {
          return { pending: { compId: comp.id, matchIndex: j, roundIndex: comp.roundIndex, match: mm, phase: 'swiss' }, results: results };
        }
        var ss = playMatch(state, comp, mm, { bo: 3, stage: round.name });
        if (ss) results.push(ss);
      }
      round.simulated = true;
      comp.roundIndex++;
      comp.userReached = Math.max(comp.userReached || 0, comp.roundIndex);
      if (comp.roundIndex >= comp.swiss.target) {
        seedPlayoffs(state, comp, 8);
        return advanceComp(state, comp, date, stopForUser);
      } else {
        pairSwiss(state, comp);
      }
      return { results: results };
    }
    if (comp.phase === 'playoffs') {
      var po = comp.playoffs;
      var pIdx = po.rounds.findIndex(function (r) { return !r.simulated; });
      if (pIdx < 0) { completeComp(state, comp); return { results: results }; }
      var pr = po.rounds[pIdx];
      if (!pr.matches.length) { buildPlayoffRound(state, comp); pr = po.rounds[pIdx]; }
      if (date < pr.date) return { results: results };
      for (var k = 0; k < pr.matches.length; k++) {
        var pm = pr.matches[k];
        if (pm.played) continue;
        if (isUserMatch(state, pm) && stopForUser) {
          return { pending: { compId: comp.id, matchIndex: k, roundIndex: pIdx, match: pm, phase: 'playoffs' }, results: results };
        }
        var isFinal = pIdx === po.rounds.length - 1;
        var sc = playMatch(state, comp, pm, { bo: isFinal ? 5 : 3, final: isFinal, stage: pr.name });
        if (sc) results.push(sc);
      }
      pr.simulated = true;
      // third place
      if (po.n === 8 && pIdx === po.rounds.length - 2 && !po.thirdPlace.played && po.thirdPlace.a) { /* handled below */ }
      if (pIdx === 0 && po.n === 8) {
        var losers = po.rounds[0].matches.map(function (x) { return x.winner === x.a ? x.b : x.a; });
        // third place is between semi-final losers
      }
      buildPlayoffRound(state, comp);
      if (po.rounds.every(function (r) { return r.simulated; })) {
        // create third place from semis
        createThirdPlace(state, comp);
        completeComp(state, comp);
      }
      return { results: results };
    }
    return { results: results };
  }

  function createThirdPlace(state, comp) {
    var po = comp.playoffs;
    if (!po || po.n !== 8) return;
    var semis = po.rounds[1];
    if (!semis || semis.matches.length < 2) return;
    var l1 = semis.matches[0].winner === semis.matches[0].a ? semis.matches[0].b : semis.matches[0].a;
    var l2 = semis.matches[1].winner === semis.matches[1].a ? semis.matches[1].b : semis.matches[1].a;
    if (!l1 || !l2) return;
    var m = { a: l1, b: l2, sa: 0, sb: 0, winner: null, played: false, date: po.rounds[po.rounds.length - 1].date };
    if (isUserMatch(state, m)) {
      // leave to be played; for simplicity simulate immediately if user eliminated is false
      playMatch(state, comp, m, { bo: 3, stage: 'Third place' });
      po.thirdPlace = { a: l1, b: l2, winner: m.winner, sa: m.scoreA, sb: m.scoreB, played: true };
    } else {
      playMatch(state, comp, m, { bo: 3, stage: 'Third place' });
      po.thirdPlace = { a: l1, b: l2, winner: m.winner, sa: m.scoreA, sb: m.scoreB, played: true };
    }
    comp.standings[l1] = comp.standings[l1] || { w: 0, l: 0, mw: 0, ml: 0, rw: 0, rl: 0, opp: [] };
    comp.standings[l2] = comp.standings[l2] || { w: 0, l: 0, mw: 0, ml: 0, rw: 0, rl: 0, opp: [] };
    if (comp.standings[l1]) updateStanding(state, comp, m);
  }

  /* ---------------- user match resolution ---------------- */
  function playPending(state, pending, result) {
    var comp = state.comps[pending.compId];
    if (!comp) return null;
    if (!pending.stage) {
      if (pending.phase === 'swiss') pending.stage = comp.swiss.rounds[pending.roundIndex] ? comp.swiss.rounds[pending.roundIndex].name : '';
      else if (pending.phase === 'playoffs') pending.stage = comp.playoffs && comp.playoffs.rounds[pending.roundIndex] ? comp.playoffs.rounds[pending.roundIndex].name : '';
      else if (comp.bracket && comp.bracket.rounds[pending.roundIndex]) pending.stage = comp.bracket.rounds[pending.roundIndex].name;
    }
    var match;
    if (pending.phase === 'swiss') match = comp.swiss.rounds[pending.roundIndex].matches[pending.matchIndex];
    else if (pending.phase === 'playoffs') match = comp.playoffs.rounds[pending.roundIndex].matches[pending.matchIndex];
    else if (comp.bracket) match = comp.bracket.rounds[pending.roundIndex].matches[pending.matchIndex];
    if (!match) {
      // recover by id
      match = pending.match;
    }
    if (!match || match.played) return null;
    var bo = 3;
    if (pending.phase === 'playoffs' && comp.playoffs) {
      bo = pending.roundIndex === comp.playoffs.rounds.length - 1 ? 5 : 3;
    }
    var series = registerMatch(state, comp, match, { bo: bo, stage: pending.stage || '', final: bo === 5 });
    if (!series) return null;
    applySeriesEffects(state, comp, series, match);
    if (comp.standings[match.a]) updateStanding(state, comp, match);
    addResultNews(state, comp, series);
    var uo = state.orgs[state.clubId];
    if (uo) {
      uo.form = uo.form || [];
      uo.form.push(series.winner === state.clubId ? 'W' : 'L');
      uo.form = uo.form.slice(-10);
    }
    state.manager.wins += series.winner === state.clubId ? 1 : 0;
    state.manager.losses += series.winner === state.clubId ? 0 : 1;
    state.manager.xp += series.winner === state.clubId ? 12 : 5;
    return series;
  }

  /* ---------------- summary helpers ---------------- */
  function compStandingsRows(state, comp) {
    return Object.keys(comp.standings).map(function (id) {
      var s = comp.standings[id];
      return { id: id, org: state.orgs[id], w: s.w, l: s.l, mw: s.mw, ml: s.ml, rw: s.rw, rl: s.rl };
    }).sort(function (a, b) { return (b.w - a.w) || ((b.mw - b.ml) - (a.mw - a.ml)) || ((b.rw - b.rl) - (a.rw - a.rl)); });
  }

  function nextFixtureFor(state, orgId) {
    var best = null;
    for (var id in state.comps) {
      var c = state.comps[id];
      if (c.status === 'done' || c.status === 'scheduled') continue;
      if (c.teams.indexOf(orgId) < 0) continue;
      var fixtures = [];
      if (c.bracket) {
        c.bracket.rounds.forEach(function (r, ri) {
          r.matches.forEach(function (m, mi) {
            if (!m.played && (m.a === orgId || m.b === orgId)) fixtures.push({ comp: c, m: m, date: r.date, phase: 'bracket', roundIndex: ri, matchIndex: mi, stage: r.name });
          });
        });
      }
      if (c.phase === 'swiss' || (c.swiss && c.swiss.rounds.length)) {
        c.swiss.rounds.forEach(function (r, ri) {
          r.matches.forEach(function (m, mi) {
            if (!m.played && (m.a === orgId || m.b === orgId)) fixtures.push({ comp: c, m: m, date: r.date, phase: 'swiss', roundIndex: ri, matchIndex: mi, stage: r.name });
          });
        });
      }
      if (c.playoffs) {
        c.playoffs.rounds.forEach(function (r, ri) {
          r.matches.forEach(function (m, mi) {
            if (!m.played && (m.a === orgId || m.b === orgId)) fixtures.push({ comp: c, m: m, date: r.date, phase: 'playoffs', roundIndex: ri, matchIndex: mi, stage: r.name });
          });
        });
      }
      fixtures.forEach(function (f) {
        if (!f.date) return;
        if (!best || f.date < best.date) best = f;
      });
    }
    return best;
  }

  function userNextFixture(state) {
    return nextFixtureFor(state, state.clubId);
  }

  function simulateDate(state, date) {
    var out = { results: [], pending: null, completed: [] };
    var order = Object.keys(state.comps).map(function (id) { return state.comps[id]; }).filter(function (c) { return c.status === 'active'; })
      .sort(function (a, b) { return a.startDate < b.startDate ? -1 : 1; });
    for (var i = 0; i < order.length; i++) {
      var c = order[i];
      var res = advanceComp(state, c, date, true);
      if (res && res.results) out.results = out.results.concat(res.results);
      if (res && res.pending) { out.pending = res.pending; break; }
      if (c.status === 'done') out.completed.push(c);
    }
    // reschedule comps if all complete
    ensureSchedule(state, date);
    return out;
  }

  function hasComp(state, key) {
    return Object.keys(state.comps).some(function (id) { return id.indexOf('c_' + key) === 0; });
  }

  function ensureSchedule(state, date) {
    if (!state.seasonPlan) return;
    state.seasonPlan.forEach(function (bp) {
      if (bp.type === 'oq') {
        // ensure each cycle OQ wave exists (ids are c_oq1_<region>_<n>_<season>)
        var waveId = 'c_' + bp.key;
        var exists = Object.keys(state.comps).some(function (id) { return id.indexOf(waveId) === 0; });
        if (!exists && date >= C.addDays(bp.start, -3)) {
          createOQ(state, bp).forEach(function (c) { state.comps[c.id] = c; });
        }
        return;
      }
      if (hasComp(state, bp.key) || date < C.addDays(bp.start, -1)) return;
      if (bp.type === 'kickoff' && date >= C.addDays(bp.start, -3)) {
        createKickoff(state, bp);
      } else if (bp.type === 'cup' && date >= C.addDays(bp.start, -3)) {
        createCup(state, bp, bp.key);
      } else if (bp.type === 'masters' && date >= C.addDays(bp.start, -3)) {
        createMasters(state, bp, bp.key);
      } else if (bp.type === 'champions' && date >= C.addDays(bp.start, -3)) {
        createChampions(state, bp);
      } else if (bp.type === 'lcq' && date >= C.addDays(bp.start, -3)) {
        createLCQ(state, bp);
      }
    });
    ensurePacificPlayoff(state, date);
  }

  /* Pacific: the 8 sub-region winners meet in a one-round regional playoff;
     the four winners take the four Pacific slots in Kickoff. */
  function ensurePacificPlayoff(state, date) {
    if (state.seasonPlan == null) return;
    var kick = state.seasonPlan.filter(function (x) { return x.key === 'kickoff'; })[0];
    if (!kick) return;
    var playStart = C.addDays(kick.start, -22);
    var playEnd = C.addDays(kick.start, -14);
    if (date < playStart || date >= kick.start) return;
    if (hasComp(state, 'pacplay')) return;
    var oqComps = Object.keys(state.comps).map(function (id) { return state.comps[id]; }).filter(function (c) {
      return c.type === 'oq' && c.cycle === 'kickoff' && c.region === 'Pacific' && c.subRegion !== 'Pacific Playoff';
    });
    if (oqComps.length < 4 || !oqComps.every(function (c) { return c.status === 'done'; })) return;
    var winners = (state.qualifiers.kickoff.Pacific || []).filter(function (id) {
      return state.orgs[id] && state.orgs[id].region === 'Pacific' &&
        !(hasDirectQualifierEntry(state) && id === state.clubId);
    }).slice(0, 8);
    if (winners.length < 4) return;
    var c = newComp(state, {
      key: 'pacplay', type: 'oq', name: 'VCT Pacific Regional Playoff', short: 'PAC PLAYOFF',
      start: playStart, end: playEnd, region: 'Pacific', tier: 'open', cycle: 'kickoff'
    });
    c.subRegion = 'Pacific Playoff';
    c.qualifyWinners = 4;
    c.teams = winners;
    c.phase = 'bracket';
    c.bracket = {
      n: winners.length, rounds: [{
        name: 'Qualification matches', date: playStart, simulated: false,
        matches: winners.map(function (id, i) {
          return i < winners.length / 2 ? { a: id, b: winners[winners.length - 1 - i], sa: 0, sb: 0, winner: null, played: false, date: playStart } : null;
        }).filter(Boolean)
      }]
    };
    c.status = 'active';
    state.comps[c.id] = c;
    state.news.unshift({
      id: 'n_pacplay' + Date.now(), date: state.date, type: 'competition',
      title: 'Pacific Regional Playoff bracket drawn', orgId: null, importance: 2, read: false,
      body: 'The eight South Korea, Japan, Thailand, Indonesia, Vietnam, Southeast Asia, South Asia and Oceania qualifier winners meet for four Kickoff places.'
    });
  }

  function seasonComplete(state) {
    return Object.keys(state.comps).some(function (id) {
      var c = state.comps[id];
      return c && c.type === 'champions' && c.status === 'done';
    });
  }

  return {
    RULES: RULES, plan: plan, seasonStart: seasonStart, initSeason: initSeason, ensureSchedule: ensureSchedule,
    simulateDate: simulateDate, playPending: playPending, userNextFixture: userNextFixture,
    compStandingsRows: compStandingsRows, completeComp: completeComp, createOQ: createOQ,
    partnerList: partnerList, seasonComplete: seasonComplete, isUserMatch: isUserMatch,
    awardPrize: awardPrize, createThirdPlace: createThirdPlace, ensureLineup: ensureLineup,
    applySeriesEffects: applySeriesEffects
  };
})();
