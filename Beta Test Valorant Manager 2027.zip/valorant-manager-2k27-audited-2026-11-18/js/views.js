/* =====================================================================
   VALORANT MANAGER 2027 — ALL PAGES
   Every page explains the state, the next best action and the fix.
   ===================================================================== */
var Views = (function () {
  'use strict';
  var C = Core;
  var V = {};

  function st() { return Game.state; }
  function org() { return Game.org(); }
  function h(x) { return C.esc(x); }
  function money(n) { return C.money(n); }
  function full(n) { return C.moneyFull(n); }
  function rnd(n) { return Math.round(n || 0); }
  function sgn(n) { return (n > 0 ? '+' : '') + rnd(n); }

  function go(label, page, cls, tip) {
    return '<button class="btn ' + (cls || '') + '" data-act="go" data-page="' + page + '"' +
      (tip ? ' data-tip="' + h(tip) + '"' : '') + '>' + h(label) + '</button>';
  }
  function fixBtn(f) {
    if (!f) return '';
    if (f.player) return '<button class="btn xs ghost" data-act="openPlayer" data-id="' + h(f.player) + '">' + h(f.label) + '</button>';
    return '<button class="btn xs ghost" data-act="gotoFix" data-page="' + h(f.page || 'dashboard') + '"' +
      (f.focus ? ' data-focus="' + h(f.focus) + '"' : '') + '>' + h(f.label) + '</button>';
  }
  function panel(title, body, actions, cls) { return UI.panel(title, body, actions, cls); }
  function head(title, sub, actions) { return UI.header(title, sub, actions); }
  function tag(text, cls) { return UI.tag(text, cls); }
  function conf(c) { return UI.conf(c); }
  function kpi(l, v, d, cls) { return UI.kpi(l, v, d, cls); }
  function empty(t) { return UI.empty(t); }
  function trophyAsset(t) {
    if (t && t.type === 'champions') return 'assets/trophies/champions.svg';
    if (t && t.type === 'masters') return 'assets/trophies/masters.svg';
    return 'assets/trophies/regional.svg';
  }

  function winProb(a, b) {
    var d = ((a || 50) - (b || 50)) / 6.2;
    return 100 / (1 + Math.exp(-d));
  }
  function probBar(my, opp) {
    var p = winProb(my, opp);
    return UI.oddsBar(p, 100 - p);
  }
  function mapName(m) { return h(m); }
  function roleCounts(list) {
    var c = { Duelist: 0, Initiator: 0, Controller: 0, Sentinel: 0 };
    (list || []).forEach(function (p) { if (p) c[p.role]++; });
    return c;
  }
  function statusTag(status) {
    if (status === 'done') return tag('COMPLETE', 'green');
    if (status === 'active') return tag('LIVE', 'red');
    return tag('SCHEDULED');
  }
  function placeText(c, id) {
    if (!c.placements || !c.placements[id]) return '—';
    return C.ordinal(c.placements[id]);
  }
  function nextFixture() { return UI.nextFixture(); }
  function upcomingComps(limit) {
    var s = st();
    return Object.keys(s.comps).map(function (id) { return s.comps[id]; })
      .filter(function (c) { return c.status !== 'done'; })
      .sort(function (a, b) { return a.startDate < b.startDate ? -1 : 1; })
      .slice(0, limit || 6);
  }
  function userForm(o) { return ((o && o.form) || []).slice(-8); }
  function objectiveIcon(o) {
    return '<span class="obj-ic ' + (o.status === 'done' ? 'done' : o.status === 'failed' ? 'fail' : '') + '">' +
      (o.status === 'done' ? '✓' : o.status === 'failed' ? '✕' : '•') + '</span>';
  }
  function objectiveLine(o) {
    var s = st();
    var pct = 0;
    if (o.metric === 'kickoffPos' || o.metric === 'bestCupPos') {
      pct = o.progress ? C.clamp(100 - (o.progress - o.target) * 12, 0, 100) : 0;
    } else if (o.metric === 'payroll') {
      pct = o.target && o.progress ? C.clamp(100 - (o.progress / o.target - 1) * 100, 0, 100) : 0;
    } else if (o.metric === 'budgetPositive') {
      pct = o.progress ? 100 : 0;
    } else {
      pct = o.target ? C.clamp(o.progress / o.target * 100, 0, 100) : (o.done ? 100 : 0);
    }
    return '<div class="objline">' + objectiveIcon(o) +
      '<div style="flex:1;min-width:0"><div class="obj-t">' + h(o.title) + ' ' +
      (o.importance === 'critical' ? tag('CRITICAL', 'red') : o.importance === 'high' ? tag('HIGH', 'amber') : '') + '</div>' +
      '<div class="obj-s">' + h(o.success) + '</div>' +
      (o.status === 'active' ? C.bar(pct, 'auto') + '<div class="tiny" style="margin-top:3px">' + h(o.category) + ' · deadline ' + C.fmtDate(o.deadline) + '</div>' : '') +
      '</div></div>';
  }
  function newsRows(list) {
    return (list || []).map(function (n) {
      var o = n.orgId ? st().orgs[n.orgId] : null;
      return '<div class="newsitem" data-act="openNews" data-id="' + n.id + '">' +
        '<div class="news-thumb">' + (o ? C.logoMarkup(o, '', 28) : C.icon(n.type === 'trophy' ? 'competitions' : n.type === 'transfer' ? 'transfers' : 'news')) + '</div>' +
        '<div class="news-body"><div class="news-h">' + h(n.title) + (n.read ? '' : ' <span class="red">●</span>') + '</div>' +
        '<div class="news-m">' + h(n.type) + ' · ' + C.fmtDate(n.date) + '</div>' +
        '<div class="news-p">' + h(n.body) + '</div></div></div>';
    }).join('');
  }
  function newsExcerpt(body, limit) {
    var localized = I18N.text(body || '');
    if (localized.length <= limit) return h(localized);
    var cut = localized.slice(0, limit);
    var lastSpace = cut.lastIndexOf(' ');
    if (lastSpace > limit * 0.65) cut = cut.slice(0, lastSpace);
    return h(cut) + '…';
  }

  function nextActions() {
    var s = st(), o = org(), out = [];
    var nf = nextFixture();
    if (s.pendingMatch) {
      out.push({ t: 'Your match is ready', d: 'The lineup and tactical plan are locked in. Open match day, review the opponent, then play the series.', b: UI.btn('Open match day', 'go', { page: 'matchday', cls: 'primary' }) });
    } else if (nf) {
      out.push({ t: 'Next fixture · ' + C.fmtDate(nf.date), d: (nf.comp ? nf.comp.name + ' · ' : '') + (nf.stage || '') + '. Use the time before kick-off to train, prepare maps or fix a weak role.', b: UI.btn('Advance to match', 'toMatch', { cls: 'primary' }) });
    } else {
      out.push({ t: 'No fixture on the board', d: 'Advance time. The next Open Qualifier or competition window will appear automatically.', b: UI.btn('Advance 1 week', 'advance', { days: 7, cls: 'primary' }) });
    }
    var roster = Game.roster(o), bal = Engine.roleBalance(roster);
    if (roster.length < 5 || bal.gaps.length) {
      out.push({ t: 'Roster is incomplete', d: (bal.gaps.length ? 'No natural ' + bal.gaps.join(' or ') + '. ' : '') + 'A legal five is required or you forfeit. Sign a free agent or adjust the lineup.', b: UI.btn('Recruitment', 'go', { page: 'recruitment', cls: 'ghost' }) });
    }
    var expiring = roster.filter(function (p) { return p.contractEnd <= s.season; });
    if (expiring.length) {
      out.push({ t: expiring.length + ' contract(s) expire this season', d: expiring.map(function (p) { return p.nick; }).join(', ') + '. Renew now or they leave as free agents at the end of the year.', b: UI.btn('Open squad', 'go', { page: 'squad', cls: 'ghost' }) });
    }
    if (o.budget < 0) {
      out.push({ t: 'Budget is negative', d: 'Weekly wages are outpacing income. Reduce payroll, sign a sponsor or win prize money before the board intervenes.', b: UI.btn('Finances', 'go', { page: 'finances', cls: 'ghost' }) });
    }
    if (o.chemistry < 66) {
      out.push({ t: 'Chemistry is ' + rnd(o.chemistry) + '/100', d: 'Coordination and communication training raise the floor of every map. A rebuilt roster needs repeated weeks together.', b: UI.btn('Training plan', 'go', { page: 'training', cls: 'ghost' }) });
    }
    if (!out.length) out.push({ t: 'The project is stable', d: 'Keep developing the roster and prepare the next competition. Review the board objectives for the season targets.', b: UI.btn('Objectives', 'go', { page: 'objectives', cls: 'ghost' }) });
    return out.slice(0, 3).map(function (x) {
      return '<div class="guidance" style="margin-bottom:8px"><h4>' + h(x.t) + '</h4><p>' + h(x.d) + '</p>' +
        '<div class="row" style="margin-top:7px">' + x.b + '</div></div>';
    }).join('');
  }

  function littleMatch(nf) {
    if (!nf) return empty('No fixture scheduled. Advance time to continue the calendar.');
    var s = st(), o = org(), opp = nf.opp;
    var ra = Game.teamRating(o), rb = opp ? Game.teamRating(opp) : { overall: 50 };
    return '<div class="match-hero" style="margin-bottom:10px">' +
      '<div class="mh-team">' + C.logoMarkup(o, 'crest-lg', 56) + '<div><div class="mh-name">' + h(o.short) + '</div><div class="mh-meta">' + h(o.region) + ' · YOU</div></div></div>' +
      '<div class="mh-mid"><div class="mh-vs">VS</div><div class="mh-when">' + (nf.pending ? 'MATCH DAY' : C.fmtDate(nf.date)) + '</div></div>' +
      '<div class="mh-team right">' + C.logoMarkup(opp, 'crest-lg', 56) + '<div><div class="mh-name">' + h(opp ? opp.short : 'TBD') + '</div><div class="mh-meta">' + h(opp ? opp.region : '') + '</div></div></div>' +
      '</div>' +
      '<div class="row between" style="margin-bottom:4px"><span class="tiny">WIN PROBABILITY</span><span class="tiny">' + Math.round(winProb(ra.overall, rb.overall)) + '% · ' + (nf.comp ? h(nf.comp.short) : '') + ' · ' + h(nf.stage || '') + '</span></div>' +
      probBar(ra.overall, rb.overall) +
      '<div class="row" style="margin-top:10px">' +
      (nf.pending ? UI.btn('Open match day', 'go', { page: 'matchday', cls: 'primary' }) : UI.btn('Advance to match', 'toMatch', { cls: 'primary' })) +
      UI.btn('Competition', 'go', { page: 'competitions', cls: 'ghost' }) + '</div>';
  }

  /* ==================================================================
     DASHBOARD
  ================================================================== */
  V.dashboard = function () {
    var s = st(), o = org(), r = Game.teamRating(o), bal = Engine.roleBalance(Game.roster(o));
    var bs = Game.boardSummary(), nf = nextFixture(), fb = Game.financeBreakdown();
    var form = userForm(o);
    var recent = s.userMatches.slice(0, 5);
    var obj = (s.objectives || []).filter(function (x) { return x.status === 'active'; });
    var seasonDone = Competition.seasonComplete(s) && s.date >= (s.season + '-10-20');
    var incoming = s.incomingOffers || [];
    var injuredStarters = Game.lineup(o).filter(function (p) { return p && p.injury && p.injury.days > 0; });

    var alerts = '';
    if (seasonDone) {
      alerts += '<div class="goodbox" style="display:flex;align-items:center;justify-content:space-between;gap:10px">' +
        '<div><b>Season ' + s.season + ' complete</b> · All competitions finished. Review awards, retirements and advance to ' + (s.season + 1) + '.</div>' +
        UI.btn('Open Season Review', 'seasonReview', { cls: 'sm primary' }) + '</div>';
    }
    if (incoming.length) {
      alerts += '<div class="warnbox" style="display:flex;align-items:center;justify-content:space-between;gap:10px">' +
        '<div><b>' + incoming.length + ' incoming transfer bid(s)</b> waiting for your response.</div>' +
        UI.btn('Review offers', 'go', { page: 'transfers', cls: 'sm primary' }) + '</div>';
    }
    if (injuredStarters.length) {
      alerts += '<div class="badbox" style="display:flex;align-items:center;justify-content:space-between;gap:10px">' +
        '<div><b>Injured starter(s):</b> ' + injuredStarters.map(function (p) { return h(p.nick) + ' (' + p.injury.days + 'd)'; }).join(', ') + '. Rotate them on Squad or lower Training intensity.</div>' +
        UI.btn('Open squad', 'go', { page: 'squad', cls: 'sm ghost' }) + '</div>';
    }
    if (fb && fb.warnings && fb.warnings.length && fb.warnings[0].sev === 'bad') {
      alerts += '<div class="badbox" style="display:flex;align-items:center;justify-content:space-between;gap:10px">' +
        '<div><b>' + h(fb.warnings[0].title) + ':</b> ' + h(fb.warnings[0].body) + '</div>' +
        UI.btn('Open finances', 'go', { page: fb.warnings[0].page || 'finances', cls: 'sm ghost' }) + '</div>';
    }

    var hero = '<div class="hero"><div class="hero-mark">' + h(o.short) + '</div>' +
      '<div class="hero-in"><div class="row" style="gap:10px;align-items:center">' + C.logoMarkup(o, '', 42) +
      '<div><div class="hero-kicker">' + (o.partner ? 'VCT PARTNER · ' : 'OPEN CIRCUIT · ') + h(o.region) + ' · SEASON ' + s.season + '</div>' +
      '<div class="hero-title">' + h(o.name) + '</div></div></div>' +
      '<div class="hero-sub">' + h(o.notes || '') + '</div>' +
      '<div class="hero-stats">' +
      '<div class="hstat"><div class="hv">' + r.overall + '</div><div class="hl">Squad rating</div></div>' +
      '<div class="hstat"><div class="hv">' + rnd(o.chemistry) + '</div><div class="hl">Chemistry</div></div>' +
      '<div class="hstat"><div class="hv">' + (s.manager.wins + '-' + s.manager.losses) + '</div><div class="hl">Record</div></div>' +
      '<div class="hstat"><div class="hv">' + money(o.budget) + '</div><div class="hl">Budget</div></div>' +
      '<div class="hstat"><div class="hv">' + bs.confidence + '</div><div class="hl">Board</div></div>' +
      '</div></div>' +
      '<div class="hero-right"><div class="conf-ring">' + C.ring(bs.confidence, bs.confidence >= 60 ? '#2fd39b' : bs.confidence >= 40 ? '#f2b23e' : '#ff4655', 52) +
      '<div><div class="tiny">BOARD CONFIDENCE</div><div class="sub">' + bs.done + ' done · ' + bs.active + ' active · ' + bs.failed + ' failed</div></div></div>' +
      '<div class="sub" style="margin-top:4px">' + (o.partner ? 'Partner status guarantees Kickoff entry only.' : 'Route into the VCT: Open Qualifiers.') + '</div>' +
      UI.btn('Objectives', 'go', { page: 'objectives', cls: 'sm ghost' }) + '</div></div>';

    var kpis = '<div class="grid g3" style="margin-top:12px">' +
      kpi('Team rating', String(r.overall), 'Skill ' + r.skill + ' · coach ' + r.coach, r.overall >= 80 ? 'green' : r.overall >= 70 ? 'amber' : '') +
      kpi('Role balance', bal.score + '%', bal.gaps.length ? 'Gap: ' + bal.gaps.join(', ') : 'Every role covered', bal.gaps.length ? 'red' : 'green') +
      kpi('Annual payroll', money(Game.payroll(o)), 'Weekly wage share ' + money(Game.payroll(o) / 52), '') +
      kpi('Form', form.length ? form.join(' ') : '—', form.length ? 'Last ' + form.length + ' series' : 'No matches played yet', '') +
      kpi('Objectives', bs.done + '/' + (bs.done + bs.active + bs.failed), bs.critical.length + ' critical still active', bs.failed ? 'red' : '') +
      kpi('Reputation', String(rnd(o.rep)), o.partner ? 'VCT partner' : 'Challenger project', '') +
      '</div>';

    var left = '<div class="col" style="gap:12px">' + alerts + hero + kpis +
      panel('NEXT MATCH', littleMatch(nf), UI.btn('Calendar', 'go', { page: 'calendar', cls: 'xs ghost' })) +
      panel('WHAT TO DO NEXT', nextActions(), '') +
      panel('RECENT RESULTS', recent.length ? recent.map(function (m) {
        var a = s.orgs[m.teamA], b = s.orgs[m.teamB];
        return '<div class="scout-line"><span class="dotp ' + (m.userWon ? 'known' : '') + '"></span>' +
          '<div style="flex:1;min-width:0"><div style="font-family:var(--cond);font-size:14px">' +
          h(a ? a.short : '?') + ' <b>' + m.scoreA + '–' + m.scoreB + '</b> ' + h(b ? b.short : '?') + '</div>' +
          '<div class="tiny">' + h(m.comp) + ' · ' + h(m.stage || '') + ' · ' + C.fmtDate(m.date) + '</div></div>' +
          '<span class="tag ' + (m.userWon ? 'green' : 'red') + '">' + (m.userWon ? 'WIN' : 'LOSS') + '</span></div>';
      }).join('') : empty('No matches yet. The first fixture will appear in the top bar.'), UI.btn('History', 'go', { page: 'history', cls: 'xs ghost' })) +
      '</div>';

    var compPulse = upcomingComps(6).map(function (c) {
      var mine = c.teams.indexOf(s.clubId) >= 0;
      return '<div class="scout-line"><span class="dotp ' + (mine ? 'known' : '') + '"></span>' +
        '<div style="flex:1;min-width:0"><div style="font-family:var(--cond);font-size:14px">' + h(c.name) + '</div>' +
        '<div class="tiny">' + C.fmtDate(c.startDate) + ' · ' + c.teams.length + ' teams · ' + h(c.phase) + '</div></div>' +
        (mine ? tag('YOU', 'red') : tag(c.tier.toUpperCase(), '')) + '</div>';
    }).join('');

    var right = '<div class="col" style="gap:12px">' +
      panel('BOARD OBJECTIVES', obj.length ? obj.slice(0, 5).map(objectiveLine).join('') : empty('No active objectives.'), UI.btn('All objectives', 'go', { page: 'objectives', cls: 'xs ghost' })) +
      panel('COMPETITION PULSE', compPulse || empty('No competitions scheduled.'), UI.btn('Competitions', 'go', { page: 'competitions', cls: 'xs ghost' })) +
      panel('LATEST NEWS', newsRows(s.news.slice(0, 7)) || empty('No news yet.'), UI.btn('News', 'go', { page: 'news', cls: 'xs ghost' })) +
      panel('SQUAD SNAPSHOT', '<div class="split-2">' +
        '<div class="statline"><span>Players</span><b>' + Game.roster(o).length + '</b></div>' +
        '<div class="statline"><span>Academy</span><b>' + Game.academyList(o).length + '</b></div>' +
        '<div class="statline"><span>Staff</span><b>' + (o.staff || []).length + '</b></div>' +
        '<div class="statline"><span>Avg age</span><b>' + (Game.roster(o).length ? (C.avg(Game.roster(o).map(function (p) { return p.age; }))).toFixed(1) : '—') + '</b></div>' +
        '<div class="statline"><span>Attack</span><b>' + rnd(r.attack) + '</b></div>' +
        '<div class="statline"><span>Defence</span><b>' + rnd(r.defense) + '</b></div></div>' +
        '<div class="divider"></div><div class="sub">' + (bal.gaps.length ? 'Role gap: ' + h(bal.gaps.join(', ')) + '. Fix the lineup or sign a natural ' + h(bal.gaps[0]) + '.' : 'Starting five has every role covered.') + '</div>', UI.btn('Squad', 'go', { page: 'squad', cls: 'xs ghost' })) +
      '</div>';

    return head('Dashboard', 'SEASON ' + s.season + ' · ' + C.fmtDateLong(s.date), UI.btn('Save', 'saveNow', { cls: 'sm ghost' }) + UI.btn('Advance week', 'advance', { days: 7, cls: 'sm primary' })) +
      '<div class="grid g23">' + left + right + '</div>';
  };

  /* ==================================================================
     SQUAD
  ================================================================== */
  function playerCard(p, inLineup) {
    var o = p.org ? st().orgs[p.org] : null;
    var fat = rnd(p.fatigue);
    return '<div class="pcard ' + (inLineup ? 'selected' : '') + '">' +
      '<div class="pc-fat"><i style="width:' + fat + '%;background:' + (fat > 55 ? '#ff4655' : fat > 35 ? '#f2b23e' : '#2fd39b') + '"></i></div>' +
      '<span class="flag pc-flag">' + h(String(p.cc || '').toUpperCase()) + '</span>' +
      '<div data-act="openPlayer" data-id="' + p.id + '" style="cursor:pointer">' + C.portraitImg(p, o, 0, 'pc-img') + '</div>' +
      '<div class="pc-body"><div class="pc-top"><div><div class="pc-name">' + h(p.nick) + '</div>' +
      '<div class="pc-real">' + h(p.name || '') + '</div>' +
      '<div class="pc-role">' + h(p.role) + (p.secondary ? ' / ' + h(p.secondary) : '') + (p.igl ? ' · IGL' : '') + (p.captain ? ' · CAPTAIN' : '') + '</div></div>' +
      '<div class="pc-ovr ' + (p.level < 70 ? 'low' : '') + '">' + p.level + '<span>OVR</span></div></div>' +
      '<div class="pc-strip">' + C.roleTag(p.role) + tag('POT ' + p.potential, '') + conf(p.conf) +
      (p.injury && p.injury.days > 0 ? tag('INJURED · ' + p.injury.days + 'd', 'red') : '') +
      (p.transferListed ? tag('LISTED', 'amber') : '') +
      (p.sim ? tag('SIM', 'violet') : '') + '</div>' +
      '<div class="pc-actions">' + UI.btn('Profile', 'openPlayer', { id: p.id, cls: 'xs ghost' }) +
      UI.btn(inLineup ? 'Agent' : 'Renew', inLineup ? 'agentModal' : 'renewModal', { id: p.id, cls: 'xs ghost' }) + '</div>' +
      '</div></div>';
  }

  V.squad = function () {
    var s = st(), o = org(), roster = Game.roster(o).sort(function (a, b) { return b.level - a.level; });
    var lineup = Game.lineup(o), bal = Game.balance(), r = Game.teamRating(o);
    var starterIds = lineup.map(function (p) { return p.id; });
    var starters = lineup, bench = roster.filter(function (p) { return starterIds.indexOf(p.id) < 0; });
    var expiring = roster.filter(function (p) { return p.contractEnd <= s.season; });
    var cards = '';
    for (var i = 0; i < 5; i++) cards += starters[i] ? playerCard(starters[i], true) : '<div class="pcard" style="display:grid;place-items:center;min-height:220px"><div class="sub">Empty starting slot</div></div>';

    var benchRows = bench.map(function (p) {
      var stTag = p.injury && p.injury.days > 0 ? tag('INJ ' + p.injury.days + 'd', 'red') : (p.transferListed ? tag('LISTED', 'amber') : '');
      return '<tr><td>' + UI.playerLink(p, false) + (stTag ? ' ' + stTag : '') + '</td><td>' + C.roleTag(p.role) + (p.secondary ? ' <span class="tiny">/ ' + h(p.secondary) + '</span>' : '') + '</td><td class="r">' + p.level + '</td>' +
        '<td class="r">' + p.potential + '</td><td class="r">' + p.age + '</td><td class="r">' + rnd(p.form) + '</td>' +
        '<td class="r">' + rnd(p.fatigue) + '%</td><td class="r">' + (p.contractEnd <= s.season ? '<span class="red">' + p.contractEnd + '</span>' : p.contractEnd) + '</td>' +
        '<td class="r">' + UI.btn(p.transferListed ? 'Listed' : 'List', 'listPlayerModal', { id: p.id, cls: 'xs ' + (p.transferListed ? 'green' : 'ghost') }) +
        UI.btn('Renew', 'renewModal', { id: p.id, cls: 'xs ghost' }) + UI.btn('Release', 'releaseModal', { id: p.id, cls: 'xs danger' }) + '</td></tr>';
    });

    var attrs = ['skill', 'chem', 'agent', 'coach', 'prep', 'form', 'morale', 'fatigue'];
    var breakdown = attrs.map(function (k) {
      var label = { skill: 'Skill', chem: 'Chemistry', agent: 'Agent fit', coach: 'Coaching', prep: 'Preparation', form: 'Form', morale: 'Morale', fatigue: 'Fatigue' }[k];
      var v = r[k];
      return '<div class="attr"><div class="an"><span>' + label + '</span><span>' + rnd(v) + '</span></div>' + C.bar(v, k === 'fatigue' ? (v > 55 ? 'red' : 'green') : 'auto') + '</div>';
    }).join('');

    var contracts = expiring.length ? expiring.map(function (p) {
      return '<div class="scout-line"><span class="dotp"></span><div style="flex:1"><div style="font-family:var(--cond);font-size:13px">' + h(p.nick) + '</div>' +
        '<div class="tiny">' + h(p.role) + ' · ' + h(p.conf || '') + '</div></div>' +
        '<span class="tag red">' + p.contractEnd + '</span>' + UI.btn('Renew', 'renewModal', { id: p.id, cls: 'xs ghost' }) + '</div>';
    }).join('') : empty('No contracts expiring this season.');

    return head('Squad', roster.length + ' CONTRACTED · ' + Game.academyList(o).length + ' ACADEMY', UI.btn('Edit lineup', 'openLineup', { cls: 'primary' }) + UI.btn('Auto-select', 'autoLineup', { cls: 'ghost' })) +
      panel('STARTING FIVE', '<div class="grid g4" style="gap:9px">' + cards + '</div>', '', '') +
      '<div class="grid g23" style="margin-top:12px">' +
      '<div class="col" style="gap:12px">' +
      panel('BENCH & ROTATION', benchRows.length ? UI.table([{ label: 'Player' }, { label: 'Role' }, { label: 'OVR', cls: 'r' }, { label: 'POT', cls: 'r' }, { label: 'Age', cls: 'r' }, { label: 'Form', cls: 'r' }, { label: 'Fatigue', cls: 'r' }, { label: 'Contract', cls: 'r' }, { label: '', cls: 'r' }], benchRows) : empty('No bench players. Sign depth in Recruitment.'), '') +
      panel('EXPIRING CONTRACTS', contracts, '') +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('TEAM RATING BREAKDOWN', breakdown + '<div class="divider"></div><div class="sub">Overall <b>' + r.overall + '</b> is built from skill, chemistry, role balance, agent fit, coaching, preparation, morale and form. Fatigue is subtracted. Every component is visible so a result is never a black box.</div>', '') +
      panel('ROLE BALANCE', '<div class="row between"><b style="font-family:var(--cond);font-size:25px">' + bal.score + '%</b>' + (bal.gaps.length ? tag('GAP', 'red') : tag('LEGAL', 'green')) + '</div>' +
        '<div class="divider"></div>' + C.ROLES.map(function (role) {
          var n = bal.counts[role] || 0;
          return '<div class="statline"><span>' + role + '</span><b class="' + (n ? '' : 'red') + '">' + n + '</b></div>';
        }).join('') +
        '<div class="sub" style="margin-top:7px">' + (bal.gaps.length ? 'Missing: ' + h(bal.gaps.join(', ')) + '. A player out of role loses utility value and the report will flag it.' : 'Every role is covered. Duplicates beyond two are also penalised.') + '</div>', '') +
      panel('SQUAD HEALTH', '<div class="split-2">' +
        '<div class="statline"><span>Average age</span><b>' + (roster.length ? C.avg(roster.map(function (p) { return p.age; })).toFixed(1) : '—') + '</b></div>' +
        '<div class="statline"><span>Average OVR</span><b>' + (roster.length ? rnd(C.avg(roster.map(function (p) { return p.level; }))) : '—') + '</b></div>' +
        '<div class="statline"><span>Average fatigue</span><b>' + (roster.length ? rnd(C.avg(roster.map(function (p) { return p.fatigue; }))) + '%' : '—') + '</b></div>' +
        '<div class="statline"><span>Total value</span><b>' + money(C.sum(roster.map(function (p) { return p.value; }))) + '</b></div>' +
        '<div class="statline"><span>Payroll</span><b>' + money(Game.payroll(o)) + '/yr</b></div>' +
        '<div class="statline"><span>Captain</span><b>' + h((roster.filter(function (p) { return p.captain; })[0] || {}).nick || '—') + '</b></div></div>' +
        '<div class="row" style="margin-top:8px">' + UI.btn('Set captain', 'setCaptain', { id: (lineup[0] || {}).id || '', cls: 'xs ghost', tip: 'The first starter becomes captain. Leadership weights the squad.' }) + '</div>', '') +
      '</div></div>';
  };

  /* ==================================================================
     TACTICS
  ================================================================== */
  V.tactics = function () {
    var s = st(), o = org(), r = Game.teamRating(o), lineup = Game.lineup(o);
    var styles = C.PLAYSTYLES.map(function (x) {
      return '<div class="stylecard ' + (o.playstyle === x.id ? 'on' : '') + '" data-act="setStyle" data-value="' + h(x.id) + '">' +
        '<b>' + h(x.id) + '</b><span>' + h(x.desc) + '</span></div>';
    }).join('');
    var presets = C.TACTIC_PRESETS.map(function (x) {
      return '<div class="focus ' + (o.playstyle === x.style ? 'on' : '') + '" data-act="setStyle" data-value="' + h(x.style) + '">' +
        '<b>' + h(x.name) + '</b><span>' + h(x.desc) + '</span><span class="tiny" style="color:var(--red);margin-top:4px">' + h(x.style) + '</span></div>';
    }).join('');
    function mapRowHtml(m, inPool) {
      var prep = o.mapPrep && o.mapPrep[m.name] != null ? o.mapPrep[m.name] : 0;
      var ms = (o.mapStats && o.mapStats[m.name]) || { played: 0, wins: 0, losses: 0 };
      var wr = ms.played ? Math.round((ms.wins / ms.played) * 100) + '% (' + ms.wins + 'W–' + ms.losses + 'L)' : '0–0';
      return '<div class="mapcomp"><div><div style="font-family:var(--cond);font-size:14px">' + h(m.name) + '</div>' +
        '<div class="tiny">' + h(m.type) + ' · ' + wr + '</div></div>' +
        '<div><div class="row between"><span class="tiny">PREPARATION</span><span class="tiny">' + rnd(prep) + '/100</span></div>' + C.bar(prep, 'auto') +
        '<div class="tiny" style="margin-top:3px">' + h(m.note) + '</div></div>' +
        '<div class="r">' + UI.btn(inPool ? 'ACTIVE' : 'RESERVE', 'toggleMap', { value: m.name, cls: 'xs ' + (inPool ? 'green' : 'ghost'), disabled: true, tip: 'Active 7-map competitive rotation is locked for this season and rotates only between seasons.' }) + '</div></div>';
    }
    var activeMaps = C.MAPS.filter(function (m) { return s.settings.mapPool.indexOf(m.name) >= 0; });
    var reserveMaps = C.MAPS.filter(function (m) { return s.settings.mapPool.indexOf(m.name) < 0; });
    var mapRows = '<div class="hr-label" style="margin-top:0">ACTIVE 2027 COMPETITIVE ROTATION (7/7)</div>' +
      activeMaps.map(function (m) { return mapRowHtml(m, true); }).join('') +
      '<div class="hr-label">RESERVE / OUT OF ROTATION</div>' +
      reserveMaps.map(function (m) { return mapRowHtml(m, false); }).join('');
    var pickBoxes = s.settings.mapPool.map(function (m) {
      return '<label class="checkline" style="display:block"><input type="checkbox" value="' + h(m) + '" data-pref="pick" data-change="mapPrefPick"' +
        ((s.mapPrefs.picks || []).indexOf(m) >= 0 ? ' checked' : '') + '> ' + h(m) + '</label>';
    }).join('');
    var banBoxes = s.settings.mapPool.map(function (m) {
      return '<label class="checkline" style="display:block"><input type="checkbox" value="' + h(m) + '" data-pref="ban" data-change="mapPrefBan"' +
        ((s.mapPrefs.bans || []).indexOf(m) >= 0 ? ' checked' : '') + '> ' + h(m) + '</label>';
    }).join('');
    var agents = lineup.map(function (p) {
      return '<div class="scout-line"><span class="dotp known"></span><div style="flex:1;min-width:0"><div style="font-family:var(--cond);font-size:14px">' + h(p.nick) + ' <span class="tiny">' + h(p.role) + '</span></div>' +
        '<div class="agentchips" style="margin-top:3px">' + (p.agents || []).map(function (a) {
          return '<span class="agentchip ' + (a === p.agents[0] ? 'main' : '') + '">' + h(a) + '<span class="af">' + rnd(p.agentFamiliarity[a] || 50) + '</span></span>';
        }).join('') + '</div></div>' +
        UI.btn('Assign', 'agentModal', { id: p.id, cls: 'xs ghost' }) + '</div>';
    }).join('');
    var rows = ['attack', 'defense', 'chem', 'agent', 'prep', 'coach'].map(function (k) {
      var label = { attack: 'Attack structure', defense: 'Defence structure', chem: 'Chemistry', agent: 'Agent fit', prep: 'Map preparation', coach: 'Coaching' }[k];
      return '<div class="attr"><div class="an"><span>' + label + '</span><span>' + rnd(r[k]) + '</span></div>' + C.bar(r[k], 'auto') + '</div>';
    }).join('');

    return head('Tactics', 'PLAYSTYLE · MAP POOL · AGENT ASSIGNMENTS', UI.btn('Training plan', 'go', { page: 'training', cls: 'ghost' })) +
      '<div class="grid g23">' +
      '<div class="col" style="gap:12px">' +
      panel('TACTICAL STYLE', '<div class="stylegrid">' + styles + '</div><div class="divider"></div><div class="sub">Style modifies attack, defence, tempo, control and chaos in every simulated round. It is not cosmetic: an aggressive style raises entry volume but concedes retakes. Change it when the roster or opponent demands it.</div>', '') +
      panel('PRESETS', '<div class="focusgrid">' + presets + '</div>', '') +
      panel('MAP POOL & PREPARATION', '<div class="row between" style="margin-bottom:7px"><span class="tiny">' + s.settings.mapPool.length + ' COMPETITIVE MAPS ACTIVE</span>' +
        '<span class="tiny">Preparation rises with map-control training and analysis facilities</span></div>' + mapRows,
        UI.btn('Reset 2027 pool', 'resetMapPool2027', { cls: 'xs ghost' })) +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('STARTING FIVE & AGENTS', agents || empty('Set a lineup first.'), '') +
      panel('RATING DECOMPOSITION', rows + '<div class="divider"></div><div class="sub">Attack and defence add the style modifiers to the same base. The opponent comparison in the match report uses the same formula.</div>', '') +
      panel('VETO PREFERENCES', '<div class="grid g2"><div><div class="hr-label" style="margin-top:0">PICK MAPS (MAX 3)</div>' + pickBoxes + '</div><div><div class="hr-label" style="margin-top:0">BAN MAPS (MAX 3)</div>' + banBoxes + '</div></div>' +
        '<div class="sub" style="margin-top:7px">Preferences are honoured only when legal in the veto order. Bans remove a map you dislike; picks prioritise a map you have prepared.</div>', '') +
      panel('STYLE EFFECTS', C.PLAYSTYLES.map(function (x) {
        var si = C.STYLE_INFO[x.id] || {};
        return '<div class="scout-line"><span class="dotp ' + (o.playstyle === x.id ? 'known' : '') + '"></span><div style="flex:1"><div style="font-family:var(--cond);font-size:13px">' + h(x.id) + '</div>' +
          '<div class="tiny">ATK ' + sgn(si.atk || 0) + ' · DEF ' + sgn(si.def || 0) + ' · TEMPO ' + sgn(si.tempo || 0) + ' · CTRL ' + sgn(si.control || 0) + '</div></div></div>';
      }).join(''), '') +
      '</div></div>';
  };

  /* ==================================================================
     TRAINING
  ================================================================== */
  V.training = function () {
    var s = st(), o = org(), plan = s.trainingPlan || { primary: 'coordination', secondary: 'aim', intensity: 'normal' };
    var roster = Game.roster(o).concat(Game.academyList(o));
    var rep = (s.trainingReports || [])[0];
    var coach = Game.coach(o);
    var avgFat = roster.length ? rnd(C.avg(roster.map(function (p) { return p.fatigue; }))) : 0;
    var avgGrowth = roster.length ? C.avg(roster.map(function (p) { return p.growth || 0; })) : 0;
    var primary = C.TRAINING.filter(function (t) { return t.id === plan.primary; })[0] || C.TRAINING[8];
    var secondary = C.TRAINING.filter(function (t) { return t.id === plan.secondary; })[0];

    var primaryCards = C.TRAINING.map(function (t) {
      return '<div class="focus ' + (plan.primary === t.id ? 'on' : '') + '" data-act="setTrainPrimary" data-value="' + t.id + '" data-tip="' + h(t.desc) + '">' +
        '<b>' + h(t.name) + '</b><span>' + h(t.short) + ' · ' + h(t.attrs.join(', ')) + '</span></div>';
    }).join('');
    var secondaryCards = C.TRAINING.map(function (t) {
      return '<div class="focus ' + (plan.secondary === t.id ? 'on' : '') + '" data-act="setTrainSecondary" data-value="' + t.id + '">' +
        '<b>' + h(t.short) + '</b><span>' + h(t.name) + '</span></div>';
    }).join('') + '<div class="focus ' + (plan.secondary === 'none' ? 'on' : '') + '" data-act="setTrainSecondary" data-value="none"><b>NONE</b><span>No secondary focus · lower fatigue</span></div>';
    var intensities = ['light', 'normal', 'intense'].map(function (k) {
      var desc = { light: 'Low fatigue, slower growth', normal: 'Balanced development', intense: 'Fast growth, high fatigue and injury risk' }[k];
      return '<div class="focus ' + (plan.intensity === k ? 'on' : '') + '" data-act="setIntensity" data-value="' + k + '"><b>' + k.toUpperCase() + '</b><span>' + desc + '</span></div>';
    }).join('');

    var rows = roster.sort(function (a, b) { return (b.growth || 0) - (a.growth || 0) || b.potential - a.potential; }).map(function (p) {
      var gap = p.potential - p.level;
      return '<tr class="' + (p.academy ? '' : '') + '"><td>' + UI.playerLink(p, false) + (p.academy ? ' ' + tag('ACADEMY', 'violet') : '') + '</td>' +
        '<td>' + C.roleTag(p.role) + '</td><td class="r">' + p.level + '</td><td class="r">' + p.potential + '</td>' +
        '<td class="r ' + (gap >= 10 ? 'amber' : '') + '">' + gap + '</td>' +
        '<td class="r">' + (p.growth > 0 ? '<span class="green">+' + p.growth.toFixed(2) + '</span>' : '<span class="dim2">' + (p.growth != null ? p.growth.toFixed(2) : '—') + '</span>') + '</td>' +
        '<td class="r">' + rnd(p.form) + '</td><td class="r">' + rnd(p.fatigue) + '%</td>' +
        '<td class="r">' + (p.age <= 21 ? tag('DEVELOPING', 'green') : p.age >= 29 ? tag('VETERAN', 'amber') : tag('PRIME', '')) + '</td></tr>';
    }).join('');

    var lastReport = rep ? '<div class="row between"><b style="font-family:var(--cond);font-size:15px">' + h(rep.date) + ' · ' + h(String(rep.primary).toUpperCase()) + (rep.secondary ? ' + ' + h(String(rep.secondary).toUpperCase()) : '') + '</b>' +
      tag(String(rep.intensity).toUpperCase(), rep.intensity === 'intense' ? 'red' : rep.intensity === 'light' ? 'blue' : '') + '</div>' +
      '<div class="split-2" style="margin-top:7px">' +
      '<div class="statline"><span>Chemistry</span><b>' + rep.team.chemistryBefore + ' → ' + rep.team.chemistryAfter + '</b></div>' +
      '<div class="statline"><span>Average fatigue</span><b>' + rep.team.avgFatigue + '%</b></div></div>' +
      '<div class="hr-label">BIGGEST GAINS</div>' +
      (rep.team.best.length ? rep.team.best.map(function (b) {
        return '<div class="scout-line"><span class="dotp known"></span><div style="flex:1"><div style="font-family:var(--cond);font-size:13px">' + h(b.nick) + '</div>' +
          '<div class="tiny">OVR ' + b.before + ' → ' + b.level + '</div></div><span class="tag green">+' + b.delta + '</span></div>';
      }).join('') : empty('No measurable gain this week.')) +
      '<div class="divider"></div>' + rep.notes.map(function (n) { return '<div class="checkline">' + h(n) + '</div>'; }).join('')
      : empty('No training report yet. Set a plan and run a session, or advance a week — training executes automatically every Monday.');

    var autoNote = '<div class="guidance"><h4>Training runs automatically every week</h4><p>Each Monday the assistant applies the current plan to the first team and academy. Running a manual session is optional and adds an extra development block, but also adds fatigue. Use light weeks before a big series.</p></div>';

    return head('Training', 'PLAN · DEVELOPMENT · FATIGUE', UI.btn('Run manual session', 'runTraining', { cls: 'primary' }) + UI.btn('Advance week', 'advance', { days: 7, cls: 'ghost' })) +
      '<div class="grid g3">' +
      kpi('Primary focus', h(primary.short), h(primary.name), '') +
      kpi('Team chemistry', rnd(o.chemistry) + '/100', o.chemistry >= 70 ? 'Cohesive unit' : 'Needs coordinated work', o.chemistry >= 70 ? 'green' : o.chemistry < 55 ? 'red' : 'amber') +
      kpi('Average fatigue', avgFat + '%', avgFat > 55 ? 'Reduce intensity now' : 'Healthy load', avgFat > 55 ? 'red' : 'green') +
      kpi('Last week growth', '+' + C.round(avgGrowth, 2), 'Average OVR change per player', avgGrowth > 0.15 ? 'green' : '') +
      kpi('Development coach', coach ? String(coach.attrs.development) : '—', coach ? h(coach.name) : 'No coach hired', coach ? '' : 'red') +
      kpi('Training facility', 'LVL ' + ((o.facilities || {}).training || 1), 'Multiplies weekly gains', '') +
      '</div>' +
      '<div class="grid g23" style="margin-top:12px">' +
      '<div class="col" style="gap:12px">' +
      panel('PRIMARY FOCUS', '<div class="focusgrid">' + primaryCards + '</div><div class="sub" style="margin-top:8px">' + h(primary.desc) + '</div>', '') +
      panel('SECONDARY FOCUS', '<div class="focusgrid">' + secondaryCards + '</div><div class="sub" style="margin-top:8px">' + (secondary ? h(secondary.desc) : 'No secondary focus: less fatigue, less breadth.') + '</div>', '') +
      panel('INTENSITY', '<div class="grid g3" style="gap:7px">' + intensities + '</div><div class="sub" style="margin-top:8px">Intensity scales gains by 0.7× / 1.0× / 1.35× and fatigue by 6 / 11 / 18 per week. Recovery facilities reduce the fatigue cost.</div>', '') +
      panel('DEVELOPMENT TABLE', UI.table([{ label: 'Player' }, { label: 'Role' }, { label: 'OVR', cls: 'r' }, { label: 'POT', cls: 'r' }, { label: 'Gap', cls: 'r' }, { label: 'Growth', cls: 'r' }, { label: 'Form', cls: 'r' }, { label: 'Fatigue', cls: 'r' }, { label: 'Stage', cls: 'r' }], rows), UI.btn('Facilities', 'go', { page: 'facilities', cls: 'xs ghost' })) +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('LAST SESSION REPORT', lastReport, '') +
      panel('HOW DEVELOPMENT WORKS', autoNote +
        '<div class="attr"><div class="an"><span>Coach development</span><span>' + (coach ? coach.attrs.development : 42) + '</span></div>' + C.bar(coach ? coach.attrs.development : 42, 'auto') + '</div>' +
        '<div class="attr"><div class="an"><span>Training facility</span><span>' + (55 + ((o.facilities || {}).training || 1) * 6) + '</span></div>' + C.bar(55 + ((o.facilities || {}).training || 1) * 6, 'auto') + '</div>' +
        '<div class="attr"><div class="an"><span>Average fatigue</span><span>' + avgFat + '</span></div>' + C.bar(avgFat, avgFat > 55 ? 'red' : 'green') + '</div>' +
        '<div class="sub" style="margin-top:8px">Gains are highest for young players with a large potential gap. Veterans can decline. High fatigue reduces form and therefore match rating.</div>', '') +
      panel('RECOMMENDED NEXT STEP', avgFat > 55
        ? '<div class="badbox">Fatigue is above 55%. Switch to a light week or rest before the next series. A tired roster loses roughly 0.42 rating per fatigue point above 35.</div>'
        : (o.chemistry < 65
          ? '<div class="guidance"><h4>Raise chemistry first</h4><p>Coordination or communication training adds chemistry, which is 13% of your match rating. Aim and mechanics work will not fix disconnected rotations.</p></div>'
          : '<div class="goodbox">Load is healthy and chemistry is stable. Continue targeted development or switch to map control before a veto-heavy week.</div>'),
        UI.btn('Squad', 'go', { page: 'squad', cls: 'xs ghost' }) + UI.btn('Tactics', 'go', { page: 'tactics', cls: 'xs ghost' })) +
      '</div></div>';
  };

  /* ==================================================================
     RECRUITMENT
  ================================================================== */
  function marketRows(list, opts) {
    opts = opts || {};
    return list.map(function (p) {
      var o = p.org ? st().orgs[p.org] : null;
      var d = Game.demand(p.id) || { wage: 0, fee: 0 };
      var known = !!(st().scoutReports[p.id] || p.scouted);
      var wageText = known ? money(d.wage) : '<span class="dim2" data-tip="Scout the player for an accurate wage. The range is an estimate.">~' + money(d.wage * 0.85) + '–' + money(d.wage * 1.15) + '</span>';
      var feeText = p.org ? (known ? money(d.fee) : '<span class="dim2">~' + money(d.fee * 0.9) + '–' + money(d.fee * 1.1) + '</span>') : '<span class="green">FREE</span>';
      var availTag = p.injury && p.injury.days > 0 ? tag('INJURED', 'red') : (p.transferListed ? tag('LISTED', 'amber') : (!p.org ? tag('FREE', 'green') : tag('CONTRACTED', '')));
      return '<tr><td>' + UI.playerLink(p, false) + '</td>' +
        '<td>' + (o ? UI.orgCell(o, 15) : '<span class="dim2">Free agent</span>') + '</td>' +
        '<td>' + C.roleTag(p.role) + (p.secondary ? ' <span class="tiny">/ ' + h(p.secondary) + '</span>' : '') + '</td>' +
        '<td class="r">' + p.level + '</td><td class="r">' + p.potential + '</td>' +
        '<td class="r">' + p.age + '</td><td class="r">' + (p.org ? p.contractEnd : '—') + '</td>' +
        '<td class="c">' + availTag + '</td>' +
        '<td class="r">' + wageText + '</td><td class="r">' + feeText + '</td>' +
        '<td class="r">' + (!known ? UI.btn('Scout', 'scoutPlayer', { id: p.id, cls: 'xs ghost', tip: 'Costs $12,000 and reveals wage demand and asking price.' }) : '') +
        UI.btn(p.org === st().clubId ? 'Owned' : 'Offer', 'offerModal', { id: p.id, cls: 'xs primary', disabled: p.org === st().clubId }) + '</td></tr>';
    });
  }

  V.recruitment = function () {
    var s = st(), o = org(), f = (UI.filters && UI.filters.recruitment) || { role: 'all', sort: 'ovr', min: 0, maxAge: 40, search: '', freeOnly: false };
    var pool = f.freeOnly
      ? Game.freeAgents()
      : Object.keys(s.players).map(function (id) { return s.players[id]; })
          .filter(function (p) { return p && !p.retired && !p.academy && p.org !== o.id; });
    if (f.role && f.role !== 'all') pool = pool.filter(function (p) { return p.role === f.role || p.secondary === f.role; });
    if (f.min) pool = pool.filter(function (p) { return p.level >= f.min; });
    if (f.maxAge) pool = pool.filter(function (p) { return p.age <= f.maxAge; });
    if (f.search) {
      var q = f.search.toLowerCase();
      pool = pool.filter(function (p) { return (p.nick + ' ' + (p.name || '')).toLowerCase().indexOf(q) >= 0; });
    }
    pool = pool.sort(function (a, b) {
      if (f.sort === 'potential') return b.potential - a.potential;
      if (f.sort === 'age') return a.age - b.age;
      if (f.sort === 'value') return b.value - a.value;
      if (f.sort === 'wage') return (Game.demand(a.id) || {}).wage - (Game.demand(b.id) || {}).wage;
      return b.level - a.level;
    }).slice(0, 45);

    var bal = Engine.roleBalance(Game.roster(o));
    var needs = C.ROLES.map(function (r) {
      var n = Game.roster(o).filter(function (p) { return p.role === r; }).length;
      return '<div class="statline"><span>' + r + '</span><b class="' + (n ? '' : 'red') + '">' + n + ' contracted</b></div>';
    }).join('');

    var topProspects = Game.freeAgents().filter(function (p) { return p.age <= 21; })
      .sort(function (a, b) { return (b.potential + b.level) - (a.potential + a.level); }).slice(0, 5);

    return head('Recruitment', 'FREE AGENTS · SCOUTING · ROSTER NEEDS', UI.btn('Transfers', 'go', { page: 'transfers', cls: 'ghost' }) + UI.btn('Academy', 'go', { page: 'academy', cls: 'ghost' })) +
      '<div class="grid g4">' +
      kpi('Available free agents', String(Game.freeAgents().length), 'Unsigned players in the ecosystem', '') +
      kpi('Transfer budget', money(o.budget), 'Fees and wages come from this balance', o.budget < 0 ? 'red' : '') +
      kpi('Annual payroll', money(Game.payroll(o)), 'Average wage ' + money(Game.payroll(o) / Math.max(1, Game.roster(o).length)), '') +
      kpi('Scouting reports', String(Object.keys(s.scoutReports || {}).length), '$12K per report · reveals true demands', '') +
      '</div>' +
      '<div class="row" style="margin:12px 0 8px;gap:6px;flex-wrap:wrap">' +
      '<input id="recSearch" class="inp" style="max-width:230px" placeholder="Search nick or name…" value="' + h(f.search) + '" data-change="recSearchInput">' +
      '<select class="sel" data-change="filterRole"><option value="all">All roles</option>' + C.ROLES.map(function (r) { return '<option value="' + r + '"' + (f.role === r ? ' selected' : '') + '>' + r + '</option>'; }).join('') + '</select>' +
      '<select class="sel" data-change="filterSort"><option value="ovr"' + (f.sort === 'ovr' ? ' selected' : '') + '>Sort: OVR</option><option value="potential"' + (f.sort === 'potential' ? ' selected' : '') + '>Sort: Potential</option><option value="age"' + (f.sort === 'age' ? ' selected' : '') + '>Sort: Youngest</option><option value="value"' + (f.sort === 'value' ? ' selected' : '') + '>Sort: Value</option><option value="wage"' + (f.sort === 'wage' ? ' selected' : '') + '>Sort: Wage</option></select>' +
      '<select class="sel" data-change="filterMin"><option value="0">Any OVR</option>' + [60, 65, 70, 75, 80, 85].map(function (n) { return '<option value="' + n + '"' + (f.min === n ? ' selected' : '') + '>' + n + '+ OVR</option>'; }).join('') + '</select>' +
      '<select class="sel" data-change="filterAge"><option value="40">Any age</option>' + [19, 21, 23, 25, 27, 30].map(function (n) { return '<option value="' + n + '"' + (f.maxAge === n ? ' selected' : '') + '>Under ' + (n + 1) + '</option>'; }).join('') + '</select>' +
      '<label class="checkline" style="margin:0 6px"><input type="checkbox" data-change="filterFree"' + (f.freeOnly ? ' checked' : '') + '> Free agents only</label>' +
      UI.btn('Apply', 'recSearch', { cls: 'sm ghost' }) +
      '<span class="tiny" style="margin-left:auto">' + pool.length + ' shown · estimates become exact after scouting</span>' +
      '</div>' +
      '<div class="grid g23">' +
      '<div class="col" style="gap:12px">' +
      panel('AVAILABLE PLAYERS', pool.length ? UI.table([{ label: 'Player' }, { label: 'Club' }, { label: 'Role' }, { label: 'OVR', cls: 'r' }, { label: 'POT', cls: 'r' }, { label: 'Age', cls: 'r' }, { label: 'Contract', cls: 'r' }, { label: 'Status', cls: 'c' }, { label: 'Wage', cls: 'r' }, { label: 'Fee', cls: 'r' }, { label: '', cls: 'r' }], marketRows(pool)) : empty('No player matches these filters. Widen the search or advance time — new free agents appear after releases and retirements.'), UI.btn('Refresh', 'go', { page: 'recruitment', cls: 'xs ghost' })) +
      panel('TRANSFER & WAGE RULES', '<div class="checkline">Free agents cost no fee; only the annual wage is committed.</div>' +
        '<div class="checkline">A contracted player requires an asking price. The selling club refuses offers below its valuation.</div>' +
        '<div class="checkline">Players judge the project: reputation, playing time, wage and current roster quality all matter. A rejection always states the reason.</div>' +
        '<div class="checkline">You cannot sign a sixth starter into a full role without breaking chemistry. Balance the five first.</div>', '') +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('ROSTER NEEDS', needs + '<div class="divider"></div><div class="sub">' + (bal.gaps.length ? 'Missing a natural ' + h(bal.gaps.join(' and ')) + '. This directly lowers utility value and the role-balance component of your rating.' : 'All four roles are covered. Prioritise quality and potential over quantity.') + '</div>', UI.btn('Squad', 'go', { page: 'squad', cls: 'xs ghost' })) +
      panel('TOP FREE PROSPECTS', topProspects.length ? topProspects.map(function (p) {
        return '<div class="scout-line"><span class="dotp known"></span><div style="flex:1;min-width:0"><div style="font-family:var(--cond);font-size:13px">' + h(p.nick) + ' <span class="tiny">' + p.age + ' · ' + h(p.role) + '</span></div>' +
          '<div class="tiny">OVR ' + p.level + ' · POT ' + p.potential + ' · ' + money(Game.demand(p.id).wage) + '/yr</div></div>' +
          UI.btn('View', 'openPlayer', { id: p.id, cls: 'xs ghost' }) + '</div>';
      }).join('') : empty('No young free agents available.'), '') +
      panel('SCOUTING', '<div class="sub">Reports cost $12,000 and reveal the exact wage demand and asking price. Unscouted players show an estimated range, so a bid can be rejected for reasons you could have known.</div>' +
        (Object.keys(s.scoutReports || {}).length ? '<div class="hr-label">RECENT REPORTS</div>' + Object.keys(s.scoutReports).slice(-5).reverse().map(function (id) {
          var p = s.players[id], r = s.scoutReports[id];
          if (!p) return '';
          return '<div class="scout-line"><div style="flex:1;min-width:0"><div style="font-family:var(--cond);font-size:13px">' + h(p.nick) + '</div>' +
            '<div class="tiny">Wage ' + money(r.wage) + ' · Fee ' + (r.fee ? money(r.fee) : 'free') + ' · ' + C.fmtDate(r.date) + '</div></div>' +
            UI.btn('Offer', 'offerModal', { id: p.id, cls: 'xs ghost' }) + '</div>';
        }).join('') : ''), '') +
      '</div></div>';
  };

  /* ==================================================================
     TRANSFERS
  ================================================================== */
  V.transfers = function () {
    var s = st(), o = org();
    var incoming = s.incomingOffers || [];
    var myRoster = Game.roster(o).sort(function (a, b) { return b.level - a.level; });
    var myListed = myRoster.filter(function (p) { return p.transferListed; });
    var targets = Object.keys(s.players).map(function (id) { return s.players[id]; })
      .filter(function (p) { return p && p.org && p.org !== o.id && !p.retired; })
      .sort(function (a, b) { return ((b.transferListed ? 1 : 0) - (a.transferListed ? 1 : 0)) || (b.level - a.level); }).slice(0, 32);
    var history = (s.transferHistory || []).slice(0, 18);
    var reports = Object.keys(s.scoutReports || {}).map(function (id) { return { p: s.players[id], r: s.scoutReports[id] }; })
      .filter(function (x) { return x.p; }).reverse();

    var offerCards = incoming.length ? incoming.map(function (off) {
      var p = s.players[off.playerId];
      var buyer = s.orgs[off.buyerOrgId];
      if (!p) return '';
      return '<div class="offer-card">' +
        '<div class="row between" style="margin-bottom:6px">' +
        '<div class="row" style="gap:8px">' + C.logoMarkup(buyer, '', 24) +
        '<div><b style="font-family:var(--cond);font-size:15px">' + h(off.buyerName) + '</b><div class="tiny">Bid for ' + h(p.nick) + ' (' + h(p.role) + ' · OVR ' + p.level + ')</div></div></div>' +
        tag('OFFER ' + money(off.fee), 'amber') + '</div>' +
        '<div class="row between"><span class="tiny">Market value ' + money(p.value) + ' · expires ' + C.fmtDate(off.expires) + '</span>' +
        '<div class="row">' + UI.btn('Accept', 'acceptIncoming', { id: off.id, cls: 'xs green' }) +
        UI.btn('Counter', 'counterOfferModal', { id: off.id, cls: 'xs ghost' }) +
        UI.btn('Reject', 'rejectIncoming', { id: off.id, cls: 'xs danger' }) + '</div></div></div>';
    }).join('') : empty('No incoming bids right now. Transfer-list players below or via their profile to attract club offers.');

    var squadSellRows = myRoster.map(function (p) {
      return '<div class="scout-line">' +
        '<div style="flex:1;min-width:0"><div style="font-family:var(--cond);font-size:14px">' + h(p.nick) + ' <span class="tiny">' + h(p.role) + ' · OVR ' + p.level + ' · Value ' + money(p.value) + '</span></div>' +
        '<div class="tiny">' + (p.transferListed ? 'Listed at ' + money(p.askingPrice || p.value) + ' · Wage ' + money(p.wage) + '/yr' : 'Not listed · Wage ' + money(p.wage) + '/yr') + '</div></div>' +
        UI.btn(p.transferListed ? 'Manage' : 'Transfer list', 'listPlayerModal', { id: p.id, cls: 'xs ' + (p.transferListed ? 'green' : 'ghost') }) + '</div>';
    }).join('');

    return head('Transfers', 'MARKET · FEES · HISTORY', UI.btn('Recruitment', 'go', { page: 'recruitment', cls: 'ghost' })) +
      '<div class="grid g4">' +
      kpi('Budget', money(o.budget), 'Available for fees and wages', o.budget < 0 ? 'red' : '') +
      kpi('Payroll', money(Game.payroll(o)), 'Annual committed wages', '') +
      kpi('Incoming offers', String(incoming.length), myListed.length + ' player(s) transfer-listed', incoming.length ? 'amber' : '') +
      kpi('Deals completed', String((s.transferHistory || []).length), 'Across the current career', '') +
      '</div>' +
      '<div class="grid g23" style="margin-top:12px">' +
      '<div class="col" style="gap:12px">' +
      panel('INCOMING TRANSFER OFFERS', offerCards, '') +
      panel('TRANSFER MARKET · TOP AVAILABLE TALENT', UI.table([{ label: 'Player' }, { label: 'Club' }, { label: 'Role' }, { label: 'OVR', cls: 'r' }, { label: 'Age', cls: 'r' }, { label: 'Value', cls: 'r' }, { label: 'Asking', cls: 'r' }, { label: 'Contract', cls: 'r' }, { label: '' }],
        targets.map(function (p) {
          var d = Game.demand(p.id) || { fee: 0, wage: 0 };
          var known = !!(s.scoutReports[p.id] || p.scouted);
          return '<tr><td>' + UI.playerLink(p, false) + (p.transferListed ? ' ' + tag('LISTED', 'amber') : '') + '</td><td>' + UI.orgCell(s.orgs[p.org], 16) + '</td>' +
            '<td>' + C.roleTag(p.role) + (p.secondary ? ' <span class="tiny">/ ' + h(p.secondary) + '</span>' : '') + '</td><td class="r">' + p.level + '</td><td class="r">' + p.age + '</td>' +
            '<td class="r">' + money(p.value) + '</td><td class="r">' + (known ? money(d.fee) : '<span class="dim2">~' + money(d.fee * 0.9) + '–' + money(d.fee * 1.1) + '</span>') + '</td>' +
            '<td class="r">' + p.contractEnd + '</td><td class="r">' +
            (!known ? UI.btn('Scout', 'scoutPlayer', { id: p.id, cls: 'xs ghost' }) : '') +
            UI.btn('Bid', 'offerModal', { id: p.id, cls: 'xs primary', disabled: d.fee > o.budget }) + '</td></tr>';
        })), UI.btn('Search free agents', 'go', { page: 'recruitment', cls: 'xs ghost' })) +
      panel('TRANSFER HISTORY', history.length ? UI.table([{ label: 'Date' }, { label: 'Player' }, { label: 'From' }, { label: 'To' }, { label: 'Fee', cls: 'r' }, { label: 'Wage', cls: 'r' }],
        history.map(function (t) {
          return '<tr><td class="tiny">' + C.fmtDate(t.date) + '</td><td>' + h(t.nick || '—') + '</td>' +
            '<td>' + h(t.fromName || 'Free agent') + '</td><td>' + h(t.toName || t.to || '—') + '</td>' +
            '<td class="r">' + money(t.fee || 0) + '</td><td class="r">' + money(t.wage || 0) + '</td></tr>';
        })) : empty('No transfers completed yet.'), '') +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('SELLING PLAYERS · SQUAD LISTINGS', squadSellRows || empty('No players in your roster.'), UI.btn('Squad', 'go', { page: 'squad', cls: 'xs ghost' })) +
      panel('HOW TRANSFERS WORK', '<div class="checkline">Bid a fee and a wage. The player compares the offer with their current situation.</div>' +
        '<div class="checkline">Transfer-listed players in your club attract weekly AI bids based on market value and asking price.</div>' +
        '<div class="checkline">You can Accept, Reject, or Counter-offer incoming bids directly in the inbox.</div>' +
        '<div class="checkline">You must retain at least 5 active players (or promote an academy prospect) before completing a sale.</div>', '') +
      panel('SCOUTING REPORTS', reports.length ? reports.slice(0, 10).map(function (x) {
        return '<div class="scout-line"><div style="flex:1;min-width:0"><div style="font-family:var(--cond);font-size:13px">' + h(x.p.nick) + ' <span class="tiny">' + h(x.p.role) + ' · OVR ' + x.p.level + '</span></div>' +
          '<div class="tiny">Wage ' + money(x.r.wage) + ' · Fee ' + (x.r.fee ? money(x.r.fee) : 'free') + '</div>' +
          '<div class="tiny dim2">' + h(x.r.note) + '</div></div>' + UI.btn('Offer', 'offerModal', { id: x.p.id, cls: 'xs ghost' }) + '</div>';
      }).join('') : empty('No scouting reports. Open Recruitment and scout a target.'), '') +
      '</div></div>';
  };

  /* ==================================================================
     ACADEMY
  ================================================================== */
  V.academy = function () {
    var s = st(), o = org();
    var list = Game.academyList(o).sort(function (a, b) { return b.potential - a.potential; });
    var firstTeamYouth = Game.roster(o).filter(function (p) { return p.age <= 21; });
    var fac = (o.facilities || {}).academy || 1;
    var ready = list.filter(function (p) { return p.level >= 70 && p.age <= 21; });

    var rows = list.map(function (p) {
      var gap = p.potential - p.level;
      return '<tr><td>' + UI.playerLink(p, false) + '</td><td>' + C.roleTag(p.role) + '</td>' +
        '<td class="r">' + p.age + '</td><td class="r">' + p.level + '</td><td class="r">' + p.potential + '</td>' +
        '<td class="c">' + C.stars(p.potential) + '</td><td class="r">' + gap + '</td><td class="r">' + money(p.wage) + '</td>' +
        '<td class="r">' + (gap >= 10 ? tag('HIGH CEILING', 'green') : gap >= 5 ? tag('DEVELOPING', '') : tag('NEAR PEAK', 'amber')) + '</td>' +
        '<td class="r">' + UI.btn('Promote', 'promotePlayer', { id: p.id, cls: 'xs primary' }) + UI.btn('Profile', 'openPlayer', { id: p.id, cls: 'xs ghost' }) + '</td></tr>';
    }).join('');

    return head('Academy', list.length + ' PROSPECTS · FACILITY LVL ' + fac, UI.btn('Facilities', 'go', { page: 'facilities', cls: 'ghost' }) + UI.btn('Recruitment', 'go', { page: 'recruitment', cls: 'ghost' })) +
      '<div class="grid g4">' +
      kpi('Prospects', String(list.length), 'Maximum 12 · intake every season', '') +
      kpi('Ready for first team', String(ready.length), 'OVR 70+ and 21 or younger', ready.length ? 'green' : '') +
      kpi('Academy facility', 'LVL ' + fac, 'Improves intake quality', '') +
      kpi('Academy wage bill', money(C.sum(list.map(function (p) { return p.wage; }))), 'Discounted youth contracts', '') +
      '</div>' +
      '<div class="grid g23" style="margin-top:12px">' +
      '<div class="col" style="gap:12px">' +
      panel('ACADEMY SQUAD', rows ? UI.table([{ label: 'Player' }, { label: 'Role' }, { label: 'Age', cls: 'r' }, { label: 'OVR', cls: 'r' }, { label: 'POT', cls: 'r' }, { label: 'Potential', cls: 'c' }, { label: 'Gap', cls: 'r' }, { label: 'Wage', cls: 'r' }, { label: 'Status', cls: 'r' }, { label: '', cls: 'r' }], rows) : empty('No academy players. A youth intake arrives each pre-season, scaled by your academy facility and reputation.'), '') +
      panel('FIRST-TEAM PLAYERS ELIGIBLE FOR ACADEMY', firstTeamYouth.length ? UI.table([{ label: 'Player' }, { label: 'Role' }, { label: 'Age', cls: 'r' }, { label: 'OVR', cls: 'r' }, { label: 'POT', cls: 'r' }, { label: '', cls: 'r' }],
        firstTeamYouth.map(function (p) {
          return '<tr><td>' + UI.playerLink(p, false) + '</td><td>' + C.roleTag(p.role) + '</td><td class="r">' + p.age + '</td>' +
            '<td class="r">' + p.level + '</td><td class="r">' + p.potential + '</td>' +
            '<td class="r">' + UI.btn('Assign to academy', 'demotePlayer', { id: p.id, cls: 'xs ghost', disabled: p.age > 21 }) + '</td></tr>';
        })) : empty('No first-team player aged 21 or younger. Young players develop faster with competitive minutes than in the academy.'), '') +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('PIPELINE PLAN', '<div class="checkline">Intake size: 3 prospects for your club each pre-season, more with a higher academy facility.</div>' +
        '<div class="checkline">A prospect can be promoted at any time. Promotion removes the academy status and puts them on a senior wage.</div>' +
        '<div class="checkline">Players aged 21 or younger can be sent back to the academy, where they still train and recover but cannot play senior matches.</div>' +
        '<div class="checkline">Academy players keep a 35% wage discount, making them cheap depth and valuable trade assets.</div>', UI.btn('Training', 'go', { page: 'training', cls: 'xs ghost' })) +
      panel('READY FOR MINUTES', ready.length ? ready.map(function (p) {
        return '<div class="scout-line"><span class="dotp known"></span><div style="flex:1"><div style="font-family:var(--cond);font-size:14px">' + h(p.nick) + '</div>' +
          '<div class="tiny">OVR ' + p.level + ' · age ' + p.age + ' · ' + h(p.role) + '</div></div>' +
          UI.btn('Promote', 'promotePlayer', { id: p.id, cls: 'xs primary' }) + '</div>';
      }).join('') : empty('No prospect is ready yet. Keep training and check potential rather than current level.'), '') +
      panel('INTAKE QUALITY MODEL', C.ROLES.map(function (r) {
        return '<div class="statline"><span>' + r + '</span><b>' + list.filter(function (p) { return p.role === r; }).length + '</b></div>';
      }).join('') +
        '<div class="divider"></div><div class="sub">Facility level ' + fac + ' adds roughly ' + ((fac - 1) * 4) + '% to generated youth quality. Reputation adds up to +1.4 tiers. Every intake is flagged SIM because the players are generated, not real.</div>', '') +
      '</div></div>';
  };

  /* ==================================================================
     COMPETITIONS
  ================================================================== */
  function bracketBlock(comp) {
    var bracket = comp.bracket || comp.playoffs;
    if (!bracket || !bracket.rounds) return '';
    var cols = bracket.rounds.map(function (r) {
      var matches = r.matches && r.matches.length ? r.matches : [{ a: null, b: null, sa: 0, sb: 0, played: false }];
      return '<div class="br-col"><div class="br-col-title">' + h(r.name) + (r.date ? ' · ' + C.fmtDate(r.date) : '') + '</div>' +
        matches.map(function (m) {
          var A = m.a ? st().orgs[m.a] : null, B = m.b ? st().orgs[m.b] : null;
          var mine = m.a === st().clubId || m.b === st().clubId;
          return '<div class="br-match ' + (mine ? 'me' : '') + '">' +
            '<div class="br-row"><span>' + C.logoMarkup(A, '', 13) + ' ' + h(A ? A.short : 'TBD') + '</span><b>' + (m.played ? m.sa : '–') + '</b></div>' +
            '<div class="br-row"><span>' + C.logoMarkup(B, '', 13) + ' ' + h(B ? B.short : 'TBD') + '</span><b>' + (m.played ? m.sb : '–') + '</b></div>' +
            '</div>';
        }).join('') + '</div>';
    }).join('');
    var third = '';
    if (comp.playoffs && comp.playoffs.thirdPlace) {
      var tp = comp.playoffs.thirdPlace;
      var TA = tp.a ? st().orgs[tp.a] : null, TB = tp.b ? st().orgs[tp.b] : null;
      third = '<div class="br-col" style="min-width:130px"><div class="br-col-title">Third place</div><div class="br-match"><div class="br-row"><span>' + h(TA ? TA.short : 'TBD') + '</span><b>' + (tp.played ? tp.sa : '–') + '</b></div><div class="br-row"><span>' + h(TB ? TB.short : 'TBD') + '</span><b>' + (tp.played ? tp.sb : '–') + '</b></div></div></div>';
    }
    return '<div class="bracket">' + cols + third + '</div>';
  }

  function compsForKey(key) {
    var s = st();
    return Object.keys(s.comps).map(function (id) { return s.comps[id]; })
      .filter(function (c) { return c.key === key || c.key.indexOf(key + '_') === 0; });
  }

  function compDetail(c) {
    var s = st();
    var rows = Competition.compStandingsRows(s, c).map(function (r, i) {
      return '<tr class="' + (r.id === s.clubId ? 'me' : '') + '"><td class="r">' + (i + 1) + '</td><td>' + UI.orgCell(r.org, 16) + '</td>' +
        '<td class="r">' + r.w + '–' + r.l + '</td><td class="r">' + r.mw + '–' + r.ml + '</td><td class="r">' + r.rw + '–' + r.rl + '</td>' +
        '<td class="r">' + (r.w * 3 + (r.mw - r.ml)) + '</td></tr>';
    }).join('');
    var rule = c.rules || {};
    var mine = c.teams.indexOf(s.clubId) >= 0;
    var starPool = [];
    c.teams.forEach(function (oid) {
      var o2 = s.orgs[oid];
      if (!o2) return;
      (o2.roster || []).forEach(function (pid) {
        var p = s.players[pid];
        if (p && !p.sim && !p.retired) starPool.push({ p: p, o: o2 });
      });
    });
    starPool.sort(function (a, b) { return (b.p.level || 0) - (a.p.level || 0); });
    var stars = starPool.slice(0, 4).map(function (x) {
      return '<div class="row" style="gap:7px;align-items:center;cursor:pointer" data-act="openPlayer" data-id="' + x.p.id + '">' +
        C.portraitImg(x.p, x.o, 36, '', 'border-radius:50%;border:1px solid #2b3038') +
        '<div><div style="font-family:var(--cond);font-size:12px;font-weight:600">' + h(x.p.nick) + '</div>' +
        '<div class="tiny">' + h(x.o.short) + ' · ' + h(I18N.text(x.p.role)) + ' · OVR ' + x.p.level + '</div></div></div>';
    }).join('');
    var starBlock = stars ? '<div class="hr-label">STAR PLAYERS</div><div class="row" style="gap:14px;flex-wrap:wrap;margin-bottom:10px">' + stars + '</div>' : '';
    var swiss = c.swiss && c.swiss.rounds.length ? '<div class="hr-label">SWISS RESULTS</div>' + c.swiss.rounds.map(function (r) {
      return '<div style="margin-bottom:7px"><div class="tiny" style="margin-bottom:2px">' + h(r.name) + ' · ' + C.fmtDate(r.date) + '</div>' +
        r.matches.map(function (m) {
          var A = s.orgs[m.a], B = s.orgs[m.b];
          var me = m.a === s.clubId || m.b === s.clubId;
          return '<div class="scout-line ' + (me ? '' : '') + '" style="padding:2px 0"><div style="flex:1;font-size:10px;' + (me ? 'color:#fff;font-weight:600' : '') + '">' +
            h(A ? A.short : '?') + ' <b>' + m.sa + '–' + m.sb + '</b> ' + h(B ? B.short : '?') + (m.played ? '' : ' <span class="tiny dim2">upcoming</span>') + '</div></div>';
        }).join('') + '</div>';
    }).join('') : '';
    return panel(c.name + ' · ' + c.season, '<div class="row between" style="margin-bottom:8px">' +
      '<div class="row" style="gap:6px">' + statusTag(c.status) + tag(c.tier.toUpperCase(), c.tier === 'international' ? 'red' : '') + (mine ? tag('YOU', 'red') : '') + '</div>' +
      '<div class="tiny">' + C.fmtDate(c.startDate) + ' → ' + C.fmtDate(c.endDate) + ' · ' + c.teams.length + ' teams</div></div>' +
      starBlock +
      '<div class="grid g2"><div>' +
      '<div class="statline"><span>Field</span><b>' + c.teams.length + ' teams</b></div>' +
      (c.city ? '<div class="statline"><span>' + h(I18N.t('City')) + '</span><b>' + h(c.city) + '</b></div>' : '') +
      '<div class="statline"><span>Prize pool</span><b>' + money(c.prizePool) + '</b></div>' +
      '<div class="statline"><span>Phase</span><b>' + h(c.phase) + '</b></div>' +
      '<div class="statline"><span>Your placement</span><b>' + (c.placements[s.clubId] ? C.ordinal(c.placements[s.clubId]) : '—') + '</b></div>' +
      '<div class="hr-label">RULES</div><div class="sub">' + h(rule.field || '') + '</div>' +
      '<div class="sub" style="margin-top:4px">' + h(rule.format || '') + '</div>' +
      '<div class="sub" style="margin-top:4px">' + h(rule.qualification || '') + '</div>' +
      '<div class="row" style="margin-top:5px">' + tag(rule.status && rule.status.indexOf('SIMULATED') >= 0 ? 'PARTLY SIMULATED' : 'OFFICIAL', rule.status && rule.status.indexOf('SIMULATED') >= 0 ? 'amber' : 'green') + '</div>' +
      '<div class="sub" style="margin-top:4px">' + h(rule.rewards || '') + '</div>' +
      '</div><div>' +
      (rows ? UI.table([{ label: '#', cls: 'r' }, { label: 'Team' }, { label: 'W-L', cls: 'r' }, { label: 'Maps', cls: 'r' }, { label: 'Rounds', cls: 'r' }, { label: 'Pts', cls: 'r' }], rows) : '<div class="sub">Standings publish when the group stage begins.</div>') +
      '</div></div>' +
      (bracketBlock(c) ? '<div class="hr-label">BRACKET</div>' + bracketBlock(c) : '') + swiss, '');
  }

  V.competitions = function () {
    var s = st(), o = org();
    var region = UI.compRegion || 'all';
    var all = Object.keys(s.comps).map(function (id) { return s.comps[id]; });
    var shown = all.filter(function (c) {
      if (region === 'all') return true;
      if (region === 'international') return c.tier === 'international';
      if (region === 'qualifiers') return c.type === 'oq' || c.type === 'lcq';
      if (region === 'mine') return c.teams.indexOf(s.clubId) >= 0;
      return c.region === region && c.type !== 'oq';
    }).sort(function (a, b) { return a.startDate < b.startDate ? -1 : 1; });
    var open = UI.compId ? s.comps[UI.compId] : null;
    if (open && shown.indexOf(open) < 0) shown.unshift(open);

    var plan = Competition.plan(s.season);
    var roadmap = plan.map(function (p) {
      var list = compsForKey(p.key).filter(function (c) { return c.type !== 'oq' || c.cycle === p.cycle; });
      var active = list.some(function (c) { return c.status === 'active'; });
      var done = list.length > 0 && list.every(function (c) { return c.status === 'done'; });
      var userIn = list.some(function (c) { return c.teams.indexOf(s.clubId) >= 0; });
      return '<div class="scout-line"><span class="dotp ' + (done ? 'known' : '') + '"></span><div style="flex:1;min-width:0">' +
        '<div style="font-family:var(--cond);font-size:13px">' + h(p.name) + '</div>' +
        '<div class="tiny">' + C.fmtDate(p.start) + ' → ' + C.fmtDate(p.end) + ' · ' + (list.length || 1) + ' draw(s)</div></div>' +
        (userIn ? tag('ENTERED', 'red') : done ? tag('DONE', 'green') : active ? tag('LIVE', 'red') : tag('UPCOMING')) + '</div>';
    }).join('');

    var chips = [['all', 'All'], ['mine', 'My competitions'], ['international', 'International'], ['regional', 'Regional'], ['qualifiers', 'Qualifiers'], ['Americas', 'Americas'], ['EMEA', 'EMEA'], ['Pacific', 'Pacific'], ['China', 'China']].map(function (x) {
      return '<button class="btn xs ' + (region === x[0] ? 'primary' : 'ghost') + '" data-act="compRegion" data-value="' + x[0] + '">' + x[1] + '</button>';
    }).join('');

    var cards = shown.map(function (c) {
      var mine = c.teams.indexOf(s.clubId) >= 0;
      var place = c.placements[s.clubId];
      return '<div class="scout-line" style="cursor:pointer" data-act="openComp" data-id="' + c.id + '">' +
        '<div style="width:26px;text-align:center">' + C.icon('competitions') + '</div>' +
        '<div style="flex:1;min-width:0"><div style="font-family:var(--cond);font-size:14px">' + h(c.name) + ' ' + (mine ? tag('YOU', 'red') : '') + '</div>' +
        '<div class="tiny">' + C.fmtDate(c.startDate) + ' → ' + C.fmtDate(c.endDate) + ' · ' + c.teams.length + ' teams · ' + h(c.region || 'International') + (c.city ? ' · ' + h(c.city) : '') + '</div></div>' +
        (place ? tag(C.ordinal(place), 'amber') : statusTag(c.status)) + '</div>';
    }).join('');

    var qual = (s.qualifiers || {});
    var qList = [];
    ['kickoff', 'cup1', 'cup2', 'masters1', 'masters2', 'champions'].forEach(function (k) {
      Object.keys(qual[k] || {}).forEach(function (r) {
        (qual[k][r] || []).forEach(function (id) {
          if (id === s.clubId) qList.push({ key: k, region: r });
        });
      });
      (qual[k] || []).forEach && (qual[k] || []).forEach(function (id) {
        if (id === s.clubId) qList.push({ key: k, region: 'Global' });
      });
    });
    var qualBox = qList.length ? qList.map(function (q) {
      return '<div class="statline"><span>' + h(q.key.toUpperCase()) + '</span><b class="green">' + h(q.region) + '</b></div>';
    }).join('') : empty('No qualification secured yet. Win your Open Qualifier, then finish top three at Kickoff for Masters Seoul.');

    var next = nextFixture();
    return head('Competitions', '2027 VCT STRUCTURE · RESULTS · QUALIFICATION', UI.btn('Calendar', 'go', { page: 'calendar', cls: 'ghost' }) + UI.btn('Advance week', 'advance', { days: 7, cls: 'primary' })) +
      (next ? '<div style="margin-bottom:12px">' + littleMatch(next) + '</div>' : '') +
      (open ? '<div style="margin-bottom:12px">' + compDetail(open) + '</div>' : '') +
      '<div class="row" style="gap:5px;flex-wrap:wrap;margin-bottom:10px">' + chips + '</div>' +
      '<div class="grid g23">' +
      '<div class="col" style="gap:12px">' +
      panel('COMPETITIONS · ' + region.toUpperCase(), cards || empty('No competitions match this filter.'), '') +
      panel('2027 SEASON PATH', roadmap + '<div class="divider"></div><div class="sub">Official 2027 facts: Kickoff fields of 12 (8 partners + 4 OQ; China adds 2 visitors and 2 OQ), three Masters Seoul spots per region, Cups replacing league play, Pacific LCQ for South Asia and Oceania, and 16 global Open Qualifier territories. Bracket shapes not published by Riot are labelled SIMULATED inside each competition.</div>', UI.btn('Objectives', 'go', { page: 'objectives', cls: 'xs ghost' })) +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('YOUR QUALIFICATION', qualBox, '') +
      panel('FIXED PAYMENTS', '<div class="statline"><span>Kickoff qualification</span><b>$100K</b></div>' +
        '<div class="statline"><span>Cup qualification</span><b>$100K</b></div>' +
        '<div class="statline"><span>Masters qualification</span><b>$200K</b></div>' +
        '<div class="statline"><span>Champions qualification</span><b>$400K</b></div>' +
        '<div class="sub" style="margin-top:7px">Paid to non-partner teams on qualification, per the published 2027 structure. Prize money is separate and lands in the finance ledger.</div>', '') +
      panel('HOW PROGRESSION WORKS', '<div class="checkline">Kickoff: 12 teams, Swiss into a top-8 bracket. Top three go to Masters Seoul.</div>' +
        '<div class="checkline">Cup 1: top four qualify for Masters 2. Cup 2: top four qualify for Champions.</div>' +
        '<div class="checkline">Open Qualifiers feed Kickoff and both Cups. Non-partners have no other route in.</div>' +
        '<div class="checkline">The 3-of-5 roster continuity rule preserves competitive progress when a team keeps three players.</div>', '') +
      '</div></div>';
  };

  /* ==================================================================
     CALENDAR
  ================================================================== */
  function dayEvents(date) {
    var s = st(), out = [];
    Object.keys(s.comps).forEach(function (id) {
      var c = s.comps[id];
      if (c.startDate === date) out.push({ k: 'comp', t: c.short + ' starts', tip: c.name });
      if (c.endDate === date) out.push({ k: 'comp', t: c.short + ' final', tip: c.name });
    });
    s.userMatches.forEach(function (m) {
      if (m.date === date) out.push({ k: 'match', t: (m.userWon ? 'W ' : 'L ') + (s.orgs[m.teamA] ? s.orgs[m.teamA].short : '') + ' ' + m.scoreA + '-' + m.scoreB + ' ' + (s.orgs[m.teamB] ? s.orgs[m.teamB].short : '') });
    });
    if (s.pendingMatch && date === s.date) {
      var nf = nextFixture();
      out.push({ k: 'match', t: 'MATCH DAY · ' + (nf && nf.opp ? nf.opp.short : '') });
    }
    return out;
  }

  function myFixtures(limit) {
    var s = st(), out = [];
    Object.keys(s.comps).forEach(function (id) {
      var c = s.comps[id];
      function scan(rounds) {
        (rounds || []).forEach(function (r) {
          (r.matches || []).forEach(function (m) {
            if (!m.played && (m.a === s.clubId || m.b === s.clubId) && m.date) {
              var oppId = m.a === s.clubId ? m.b : m.a;
              out.push({ date: m.date, opp: s.orgs[oppId], comp: c, stage: r.name, home: m.a === s.clubId });
            }
          });
        });
      }
      if (c.swiss) scan(c.swiss.rounds);
      if (c.playoffs) scan(c.playoffs.rounds);
      if (c.bracket) scan(c.bracket.rounds);
    });
    if (s.pendingMatch) {
      var pc = s.comps[s.pendingMatch.compId], pm = s.pendingMatch.match;
      var oid = pm.a === s.clubId ? pm.b : pm.a;
      out.unshift({ date: s.date, opp: s.orgs[oid], comp: pc, stage: s.pendingMatch.stage || 'Match day', pending: true });
    }
    out.sort(function (a, b) { return a.date < b.date ? -1 : 1; });
    var seen = {};
    return out.filter(function (f) {
      var key = f.date + '|' + (f.opp ? f.opp.id : '') + '|' + (f.comp ? f.comp.id : '');
      if (seen[key]) return false;
      seen[key] = true; return true;
    }).slice(0, limit || 12);
  }

  V.calendar = function () {
    var s = st();
    var y = UI.calendar.year, m = UI.calendar.month;
    var matrix = C.monthMatrix(y, m);
    var monthName = I18N.monthLong(m);
    var dows = [1, 2, 3, 4, 5, 6, 0].map(function (i) { return I18N.weekday(i, true); });
    var html = dows.map(function (d) { return '<div class="cal-dow">' + d + '</div>'; }).join('');
    matrix.forEach(function (week) {
      week.forEach(function (date) {
        var dt = C.parseDate(date);
        var other = dt.getUTCMonth() !== m;
        var evs = dayEvents(date);
        var isToday = date === s.date;
        html += '<div class="cal-day ' + (other ? 'other' : '') + ' ' + (isToday ? 'today' : '') + '">' +
          '<div class="dn">' + dt.getUTCDate() + (isToday ? ' · ' + I18N.text('TODAY') : '') + '</div>' +
          evs.slice(0, 2).map(function (e) {
            return '<div class="cal-ev ' + e.k + '"' + (e.tip ? ' data-tip="' + h(e.tip) + '"' : '') + '>' + h(e.t) + '</div>';
          }).join('') +
          (evs.length > 2 ? '<div class="tiny dim2">+' + (evs.length - 2) + ' more</div>' : '') + '</div>';
      });
    });

    var fixtures = myFixtures(10);
    var fixtureRows = fixtures.map(function (f) {
      return '<div class="scout-line"><span class="dotp ' + (f.pending ? 'known' : '') + '"></span>' +
        '<div style="flex:1;min-width:0"><div style="font-family:var(--cond);font-size:13px">' + (f.opp ? h(f.opp.short) : 'TBD') + ' · ' + h(f.comp ? f.comp.short : '') + '</div>' +
        '<div class="tiny">' + C.fmtDate(f.date) + ' · ' + h(f.stage || '') + ' · ' + (f.home ? 'home' : 'away') + '</div></div>' +
        (f.pending ? UI.btn('Play', 'go', { page: 'matchday', cls: 'xs primary' }) : tag(C.diffDays(s.date, f.date) + 'd', '')) + '</div>';
    }).join('');

    return head('Calendar', monthName.toUpperCase() + ' ' + y, UI.btn('Previous', 'calPrev', { cls: 'sm ghost' }) + UI.btn('Today', 'calToday', { cls: 'sm ghost' }) + UI.btn('Next', 'calNext', { cls: 'sm ghost' })) +
      '<div class="grid g23">' +
      '<div class="col" style="gap:12px">' +
      panel('SCHEDULE · ' + monthName + ' ' + y, '<div class="cal">' + html + '</div>' +
        '<div class="row" style="gap:12px;margin-top:8px"><span class="tiny"><span class="cal-ev match" style="display:inline-block;padding:0 4px">MATCH</span> your fixture</span>' +
        '<span class="tiny"><span class="cal-ev comp" style="display:inline-block;padding:0 4px">COMP</span> competition window</span></div>', '') +
      panel('YOUR NEXT FIXTURES', fixtureRows || empty('No future fixtures. Advance time — the next qualifying window will be scheduled automatically.'), UI.btn('Advance week', 'advance', { days: 7, cls: 'xs ghost' })) +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('TODAY', '<div class="statline"><span>Date</span><b>' + C.fmtDateLong(s.date) + '</b></div>' +
        '<div class="statline"><span>Season</span><b>' + s.season + '</b></div>' +
        '<div class="statline"><span>Split</span><b>' + h(Game.splitInfo(s).name) + '</b></div>' +
        '<div class="divider"></div>' + (nextFixture() ? littleMatch(nextFixture()) : '<div class="sub">No fixture scheduled. Advance time to reach the next window.</div>'), '') +
      panel('COMPETITION WINDOWS', Competition.plan(s.season).map(function (p) {
        return '<div class="scout-line"><span class="dotp"></span><div style="flex:1"><div style="font-family:var(--cond);font-size:13px">' + h(p.short) + '</div>' +
          '<div class="tiny">' + C.fmtDate(p.start) + ' → ' + C.fmtDate(p.end) + '</div></div>' + tag(p.tier.toUpperCase(), p.tier === 'international' ? 'red' : '') + '</div>';
      }).join(''), '') +
      panel('TIME CONTROLS', '<div class="sub">Every skip simulates intermediate matches, weekly training, injury recovery, wages, sponsors, AI transfers and news.</div>' +
        '<div class="grid g2" style="margin-top:8px;gap:6px">' +
        UI.btn('+1 Day', 'doSkip', { value: 'day', cls: 'sm ghost' }) +
        UI.btn('+1 Week', 'doSkip', { value: 'week', cls: 'sm ghost' }) +
        UI.btn('Next Match', 'doSkip', { value: 'match', cls: 'sm primary' }) +
        UI.btn('Next Event', 'doSkip', { value: 'event', cls: 'sm ghost' }) +
        UI.btn('End of Split', 'confirmSkip', { value: 'split', cls: 'sm ghost' }) +
        UI.btn('End of Season', 'confirmSkip', { value: 'season', cls: 'sm ghost' }) +
        '</div>', '') +
      '</div></div>';
  };

  /* ==================================================================
     FINANCES
  ================================================================== */
  V.finances = function () {
    var s = st(), o = org();
    var fb = Game.financeBreakdown();
    var summary = Game.sponsorSummary() || { active: [], all: [], annual: 0, received: 0, bonuses: 0, remaining: 0, upcoming: 0, nextDate: null, totalValue: 0, weeklyAverage: 0 };
    var ledger = s.financeLedger || [];
    var sponsorOffers = s.sponsorOffers || [];
    var finObj = (s.objectives || []).filter(function (x) { return x.category === 'Financial' && x.status === 'active'; });

    var ledgerRows = ledger.slice(0, 16).map(function (l) {
      return '<tr><td class="tiny">' + C.fmtDate(l.date) + '</td><td>' + h(l.note || 'Weekly operations') + '</td>' +
        '<td class="r ' + ((l.total || 0) >= 0 ? 'green' : 'red') + '">' + ((l.total || 0) >= 0 ? '+' : '') + money(l.total || 0) + '</td></tr>';
    }).join('');

    function nextAmount(c) {
      var remaining = Math.max(0, (c.total || 0) - (c.paid || 0));
      if (remaining <= 0) return 0;
      if ((c.payments || 0) >= (c.periods || 1) - 1) return remaining;
      return Math.min(remaining, c.periodAmount || Math.round((c.annual || 0) / 12));
    }
    function freqLabel(f) { return f === 'quarterly' ? 'quarter' : f === 'weekly' ? 'week' : 'month'; }
    function objectiveStatus(o2) {
      if (o2.status === 'done') return '<b class="green">MET · +' + money(o2.bonus) + '</b>';
      if (o2.status === 'failed') return '<b class="red">MISSED</b>';
      return '<b>' + money(o2.bonus) + ' bonus</b>';
    }

    var warnHtml = fb.warnings.length ? fb.warnings.map(function (w) {
      return '<div class="' + (w.sev === 'bad' ? 'badbox' : 'warnbox') + '" style="margin-bottom:8px;display:flex;align-items:center;justify-content:space-between;gap:10px">' +
        '<div><b>' + h(w.title) + '</b><div style="margin-top:2px">' + h(w.body) + '</div></div>' +
        (w.page && w.page !== 'finances' ? UI.btn('Fix', 'go', { page: w.page, cls: 'xs ghost' }) : '') + '</div>';
    }).join('') : '<div class="goodbox" style="margin-bottom:8px">Cashflow and payroll ratio are healthy.</div>';

    var contractCards = summary.active.length ? summary.active.map(function (c) {
      var paidPct = c.total ? C.clamp(Math.round(c.paid / c.total * 100), 0, 100) : 0;
      var left = Math.max(0, c.total - c.paid);
      return '<div class="guidance" style="margin-bottom:10px">' +
        '<div class="row between"><h4 style="margin:0">' + h(c.name) + '</h4>' + tag(c.years + ' YR · ' + (c.freq || 'monthly').toUpperCase(), 'green') + '</div>' +
        '<div class="grid g4" style="margin-top:7px">' +
        '<div><div class="tiny">ANNUAL</div><b style="font-family:var(--cond);font-size:16px">' + money(c.annual) + '</b></div>' +
        '<div><div class="tiny">PER ' + freqLabel(c.freq).toUpperCase() + '</div><b style="font-family:var(--cond);font-size:16px">' + money(nextAmount(c)) + '</b></div>' +
        '<div><div class="tiny">RECEIVED</div><b style="font-family:var(--cond);font-size:16px">' + money(c.paid) + '</b></div>' +
        '<div><div class="tiny">REMAINING</div><b style="font-family:var(--cond);font-size:16px">' + money(left) + '</b></div>' +
        '</div>' +
        '<div class="attr" style="margin-top:7px"><div class="an"><span>Contract progress · ' + c.payments + '/' + c.periods + ' instalments</span><span>' + paidPct + '%</span></div>' + C.bar(paidPct, 'auto') + '</div>' +
        '<div class="statline"><span>Next payment</span><b>' + money(nextAmount(c)) + ' on ' + C.fmtDate(c.nextPayment) + '</b></div>' +
        '<div class="statline"><span>Contract period</span><b>' + C.fmtDate(c.start) + ' → ' + C.fmtDate(c.end) + '</b></div>' +
        ((c.objectives || []).length ? (c.objectives || []).map(function (o2) {
          return '<div class="statline"><span>' + h(o2.label) + '</span>' + objectiveStatus(o2) + '</div>';
        }).join('') : '') +
        '<div class="tiny" style="margin-top:6px">Bonuses earned: ' + money(c.bonusesPaid || 0) + '. Payments are credited automatically on the due date; missed objectives reduce the renewal offer and reputation.</div>' +
        '</div>';
    }).join('') : '<div class="badbox">No active sponsorship contract. Sign one from the sponsor market below. Without commercial income the organisation relies on prize money, qualification payments and the partner stipend.</div>';

    var pastCards = summary.all.filter(function (c) { return c.status !== 'active'; }).length ? summary.all.filter(function (c) { return c.status !== 'active'; }).map(function (c) {
      return '<div class="statline"><span>' + h(c.name) + ' · ' + C.fmtDate(c.start) + ' → ' + C.fmtDate(c.end) + '</span><b>' + money(c.paid) + ' received' + (c.renewalDeclined ? ' · not renewed' : '') + '</b></div>';
    }).join('') : '<div class="sub">No completed sponsorships yet.</div>';

    var sponsorCards = sponsorOffers.length ? sponsorOffers.map(function (sp) {
      var total = sp.value * sp.years;
      var per = Math.round(sp.value / (sp.freq === 'quarterly' ? 4 : 12));
      var objs = (sp.objectives || []).slice(0, 2).map(function (o2) {
        return '<div class="tiny">• ' + h(o2.label) + ' — bonus ' + money(o2.bonus) + '</div>';
      }).join('');
      return '<div class="guidance" style="margin-bottom:8px"><div class="row between"><h4 style="margin:0">' + h(sp.name) + '</h4>' +
        (sp.renewal ? tag('RENEWAL', 'red') : tag(sp.years + ' YR', '')) + '</div>' +
        '<p>' + h(sp.desc) + ' Requirement: ' + h(sp.req) + '.</p>' +
        '<div class="row between" style="margin-top:5px"><div><div class="tiny">ANNUAL VALUE</div><b style="font-family:var(--cond);font-size:17px">' + money(sp.value) + '</b>' +
        '<div class="tiny">' + money(total) + ' total · ' + money(per) + ' per ' + freqLabel(sp.freq) + ' · expires ' + C.fmtDate(sp.expires) + '</div></div>' +
        '<div class="row">' + UI.btn('Negotiate', 'negotiateSponsor', { id: sp.id, cls: 'sm ghost', disabled: !!sp.negotiated }) + UI.btn(sp.renewal ? 'Renew' : 'Sign deal', 'signSponsor', { id: sp.id, cls: 'sm primary' }) + '</div></div>' +
        objs + '</div>';
    }).join('') : empty('No sponsor offers. Refresh the market or advance to a new month.');

    var incCat = fb.incomeCategories, expCat = fb.expenseCategories;
    var catPanel = '<div class="split-2">' +
      '<div><div class="hr-label" style="margin-top:0">INCOME RECORDED</div>' +
      '<div class="statline"><span>Sponsorships</span><b class="green">+' + money(incCat.sponsorship) + '</b></div>' +
      '<div class="statline"><span>Prize money</span><b class="green">+' + money(incCat.prize) + '</b></div>' +
      '<div class="statline"><span>Commercial & stipend</span><b class="green">+' + money(incCat.commercial) + '</b></div>' +
      '<div class="statline"><span>Transfer sales</span><b class="green">+' + money(incCat.transfers) + '</b></div></div>' +
      '<div><div class="hr-label" style="margin-top:0">EXPENSES RECORDED</div>' +
      '<div class="statline"><span>Player payroll</span><b class="red">-' + money(expCat.payroll) + '</b></div>' +
      '<div class="statline"><span>Staff salaries</span><b class="red">-' + money(expCat.staff) + '</b></div>' +
      '<div class="statline"><span>Club operations</span><b class="red">-' + money(expCat.operations) + '</b></div>' +
      '<div class="statline"><span>Transfers & scouting</span><b class="red">-' + money(expCat.transfers + expCat.scouting) + '</b></div>' +
      '<div class="statline"><span>Facilities & severance</span><b class="red">-' + money(expCat.facilities + expCat.severance) + '</b></div></div></div>';

    var rulesPanel = '<div class="checkline">Transfer buyouts + 10% signing bonus are deducted immediately; incoming sales credit your budget on completion.</div>' +
      '<div class="checkline">Keep Annual Payroll inside the sustainable cap (' + money(fb.payrollCap) + '/yr) to avoid negative monthly cashflow.</div>' +
      '<div class="checkline">Sponsor instalments credit automatically on scheduled due dates and pay extra performance bonuses when milestones are met.</div>' +
      '<div class="checkline">Non-partner clubs earn fixed qualification bonuses ($100K–$400K) and tournament prize pools directly into club balance.</div>';

    return head('Finances', 'BUDGET · SPONSORSHIPS · LEDGER', UI.btn('Refresh sponsors', 'refreshSponsors', { cls: 'ghost' }) + UI.btn('Advance week', 'advance', { days: 7, cls: 'primary' })) +
      '<div class="grid g4">' +
      kpi('Available budget', money(fb.budget), fb.budget >= 0 ? 'Cash balance on hand' : 'Insolvent — stabilize finances', fb.budget >= 0 ? 'green' : 'red') +
      kpi('Monthly income', '+' + money(fb.monthlyIncome), 'Sponsors + commercial revenue', 'green') +
      kpi('Monthly expenses', '-' + money(fb.monthlyExpenses), 'Wages, staff & operations', '') +
      kpi('Monthly net', (fb.monthlyNet >= 0 ? '+' : '') + money(fb.monthlyNet), 'Projected monthly cashflow', fb.monthlyNet >= 0 ? 'green' : 'red') +
      '</div>' +
      '<div class="grid g4" style="margin-top:10px">' +
      kpi('Remaining payroll budget', money(fb.remainingPayrollBudget), 'Cap ' + money(fb.payrollCap) + ' · Payroll ' + money(fb.annualPayroll), fb.remainingPayrollBudget >= 0 ? 'green' : 'amber') +
      kpi('Sponsorship income', money(fb.sponsorshipAnnual) + '/yr', summary.active.length + ' active · next 30d +' + money(fb.sponsorshipNext30), '') +
      kpi('Upcoming commitments', money(fb.upcomingCommitments), 'Next 30 days recurring costs', '') +
      kpi('Sponsorship received', money(summary.received + summary.bonuses), money(summary.bonuses) + ' in performance bonuses', 'green') +
      '</div>' +
      '<div class="grid g23" style="margin-top:12px">' +
      '<div class="col" style="gap:12px">' +
      panel('FINANCIAL WARNINGS', warnHtml, '') +
      panel('ACTIVE SPONSORSHIPS', contractCards, '') +
      panel('SPONSOR MARKET', sponsorCards, '') +
      panel('SPONSORSHIP HISTORY', pastCards, '') +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('INCOME VS EXPENSE CATEGORIES', catPanel, '') +
      panel('LEDGER', ledgerRows ? UI.table([{ label: 'Date' }, { label: 'Entry' }, { label: 'Amount', cls: 'r' }], ledgerRows) : empty('No entries yet.'), '') +
      panel('BUDGET & TRANSFER RULES', rulesPanel, '') +
      panel('FINANCIAL OBJECTIVES', finObj.length ? finObj.map(objectiveLine).join('') : empty('No active financial objective.'), UI.btn('Objectives', 'go', { page: 'objectives', cls: 'xs ghost' })) +
      panel('FIXED 2027 PAYMENTS', '<div class="statline"><span>Kickoff qualification</span><b>$100K</b></div><div class="statline"><span>Cup qualification</span><b>$100K</b></div>' +
        '<div class="statline"><span>Masters qualification</span><b>$200K</b></div><div class="statline"><span>Champions qualification</span><b>$400K</b></div>' +
        '<div class="sub" style="margin-top:7px">Non-partner teams only. Prize pools: Kickoff $250K, Cup $400K, Masters $1M, Champions $2.25M. All rewards are recorded in the ledger when a competition is finalised.</div>', '') +
      '</div></div>';
  };

  /* ==================================================================
     STAFF
  ================================================================== */
  V.staff = function () {
    var s = st(), o = org();
    var current = (o.staff || []).map(function (id) { return s.staff[id]; }).filter(Boolean);
    var market = Game.staffFree();
    var coach = Game.coach(o);
    var totalSalary = C.sum(current.map(function (x) { return x.salary; }));

    var curRows = current.map(function (x) {
      return '<tr><td><b style="font-family:var(--cond);font-size:13px">' + h(x.name) + '</b><div class="tiny">' + h(x.nick) + ' · ' + h(C.countryName(x.cc)) + '</div></td>' +
        '<td>' + h(x.role) + '</td><td class="r">' + x.age + '</td><td class="r"><b>' + x.grade.toFixed(1) + '</b></td>' +
        '<td class="r">' + money(x.salary) + '</td><td class="c">' + conf(x.conf) + '</td>' +
        '<td class="r">' + UI.btn('Release', 'fireStaff', { id: x.id, cls: 'xs danger' }) + '</td></tr>';
    }).join('');
    var marketRows = market.map(function (x) {
      return '<tr><td><b style="font-family:var(--cond);font-size:13px">' + h(x.name) + '</b><div class="tiny">' + h(x.nick) + ' · ' + h(C.countryName(x.cc)) + '</div></td>' +
        '<td>' + h(x.role) + '</td><td class="r">' + x.age + '</td><td class="r"><b>' + x.grade.toFixed(1) + '</b></td>' +
        '<td class="r">' + money(x.salary) + '</td><td class="r">' +
        '<span class="tiny">COA ' + x.attrs.coaching + ' · ANA ' + x.attrs.analysis + ' · DEV ' + x.attrs.development + '</span></td>' +
        '<td class="r">' + UI.btn('Hire', 'hireStaff', { id: x.id, cls: 'xs primary', disabled: x.salary > o.budget }) + '</td></tr>';
    }).join('');

    var effects = coach ? '<div class="attr"><div class="an"><span>Coaching (team rating)</span><span>' + coach.attrs.coaching + '</span></div>' + C.bar(coach.attrs.coaching, 'auto') + '</div>' +
      '<div class="attr"><div class="an"><span>Development (training)</span><span>' + coach.attrs.development + '</span></div>' + C.bar(coach.attrs.development, 'auto') + '</div>' +
      '<div class="attr"><div class="an"><span>Analysis (preparation)</span><span>' + coach.attrs.analysis + '</span></div>' + C.bar(coach.attrs.analysis, 'auto') + '</div>' +
      '<div class="attr"><div class="an"><span>Scouting (market info)</span><span>' + coach.attrs.scouting + '</span></div>' + C.bar(coach.attrs.scouting, 'auto') + '</div>'
      : '<div class="badbox">No head coach. The squad trains at a 42 development baseline and loses coaching rating. Hire one before the season starts.</div>';

    return head('Staff', current.length + ' APPOINTED · PAYROLL ' + money(totalSalary), UI.btn('Facilities', 'go', { page: 'facilities', cls: 'ghost' }) + UI.btn('Training', 'go', { page: 'training', cls: 'ghost' })) +
      '<div class="grid g3">' +
      kpi('Head coach', coach ? h(coach.name) : 'VACANT', coach ? 'Grade ' + coach.grade.toFixed(1) + ' · coaching ' + coach.attrs.coaching : 'Hire immediately', coach ? '' : 'red') +
      kpi('Staff salary', money(totalSalary) + '/yr', money(totalSalary / 52) + ' per week', '') +
      kpi('Market candidates', String(market.length), 'Refreshed each pre-season', '') +
      '</div>' +
      '<div class="grid g23" style="margin-top:12px">' +
      '<div class="col" style="gap:12px">' +
      panel('CURRENT STAFF', curRows ? UI.table([{ label: 'Name' }, { label: 'Role' }, { label: 'Age', cls: 'r' }, { label: 'Grade', cls: 'r' }, { label: 'Salary', cls: 'r' }, { label: 'Source', cls: 'c' }, { label: '', cls: 'r' }], curRows) : empty('No staff appointed. A head coach is the single most important hire.'), '') +
      panel('AVAILABLE CANDIDATES', marketRows ? UI.table([{ label: 'Name' }, { label: 'Role' }, { label: 'Age', cls: 'r' }, { label: 'Grade', cls: 'r' }, { label: 'Salary', cls: 'r' }, { label: 'Attributes' }, { label: '', cls: 'r' }], marketRows) : empty('No candidates available. The market refreshes at the start of each season.'), '') +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('COACHING IMPACT', effects + '<div class="sub" style="margin-top:8px">The highest-graded staff member becomes the head coach automatically. Coaching is 5% of team rating; development multiplies every training gain.</div>', '') +
      panel('STAFF ROLES', '<div class="checkline">Head Coach: match rating and training development.</div>' +
        '<div class="checkline">Assistant Coach: depth in preparation and player management.</div>' +
        '<div class="checkline">Analyst: opponent preparation and map veto information.</div>' +
        '<div class="checkline">Performance Coach: recovery and fatigue management.</div>' +
        '<div class="checkline">Scout: accuracy and reach of the recruitment market.</div>' +
        '<div class="sub" style="margin-top:6px">In this simulation the highest-graded coach applies the primary coaching bonus; other staff contribute their salary and credibility.</div>', '') +
      panel('RECOMMENDATION', coach
        ? (coach.grade < 6.5 ? '<div class="guidance"><h4>Upgrade the head coach</h4><p>Grade ' + coach.grade.toFixed(1) + ' is below the partner standard. A grade 7.5+ coach adds roughly 2 rating points and accelerates player development.</p></div>'
          : '<div class="goodbox">The coaching department is competitive. Invest remaining budget in facilities or roster depth rather than another coach.</div>')
        : '<div class="badbox">Hire a head coach before the first official match. Training gains and team rating both suffer without one.</div>', '') +
      '</div></div>';
  };

  /* ==================================================================
     FACILITIES
  ================================================================== */
  var FAC_INFO = [
    { key: 'training', name: 'Training Centre', icon: 'training', desc: 'Quality of practice servers, aim labs and coaching space. Multiplies weekly player development.', effect: 'Development factor 55 + 6 per level. Level 5 is roughly 30% faster growth than level 2.' },
    { key: 'recovery', name: 'Recovery Suite', icon: 'facilities', desc: 'Physio, sleep and nutrition support. Reduces fatigue gained in training and speeds daily recovery.', effect: 'Training fatigue −1.6 per level. Daily recovery rises with the level.' },
    { key: 'analysis', name: 'Analysis Lab', icon: 'tactics', desc: 'Opponent review, map preparation and data infrastructure. Raises preparation for every map in the pool.', effect: 'Adds map preparation in the match rating: ±1.2 rating per level from the level-2 baseline.' },
    { key: 'academy', name: 'Academy', icon: 'academy', desc: 'Youth scouting, housing and education. Improves the quality and size of each pre-season intake.', effect: 'Each level adds about 4% to generated youth quality and improves the intake ceiling.' }
  ];
  V.facilities = function () {
    var o = org();
    var fac = o.facilities || { training: 1, recovery: 1, analysis: 1, academy: 1 };
    var upkeep = (fac.training + fac.recovery + fac.analysis + fac.academy) * 140;
    var cards = FAC_INFO.map(function (f) {
      var lvl = fac[f.key] || 1;
      var cost = lvl >= 5 ? 0 : Math.round(140000 * Math.pow(1.65, lvl - 1));
      var pips = '';
      for (var i = 0; i < 5; i++) pips += '<i class="' + (i < lvl ? 'on' : '') + '" style="display:inline-block;width:13px;height:5px;margin-right:3px;background:' + (i < lvl ? 'var(--red)' : 'var(--line2)') + '"></i>';
      return '<div class="guidance" style="margin-bottom:9px"><div class="row between"><h4 style="margin:0">' + h(f.name) + '</h4>' + tag('LVL ' + lvl, lvl >= 4 ? 'green' : '') + '</div>' +
        '<div style="margin:6px 0">' + pips + '</div><p>' + h(f.desc) + '</p>' +
        '<div class="tiny" style="color:var(--dim2);margin-bottom:7px">' + h(f.effect) + '</div>' +
        '<div class="row between"><span class="tiny">' + (lvl >= 5 ? 'MAXIMUM LEVEL' : 'UPGRADE COST ' + money(cost)) + '</span>' +
        UI.btn(lvl >= 5 ? 'Maxed' : 'Upgrade', 'upgradeFacility', { value: f.key, cls: 'sm ' + (lvl >= 5 ? 'ghost' : 'primary'), disabled: lvl >= 5 || cost > o.budget }) + '</div></div>';
    }).join('');

    return head('Facilities', 'INFRASTRUCTURE · UPKEEP ' + money(upkeep) + '/YR', UI.btn('Staff', 'go', { page: 'staff', cls: 'ghost' })) +
      '<div class="grid g4">' +
      kpi('Training', 'LVL ' + fac.training, 'Development speed', '') +
      kpi('Recovery', 'LVL ' + fac.recovery, 'Fatigue control', '') +
      kpi('Analysis', 'LVL ' + fac.analysis, 'Map preparation', '') +
      kpi('Academy', 'LVL ' + fac.academy, 'Youth intake', '') +
      '</div>' +
      '<div class="grid g23" style="margin-top:12px">' +
      '<div class="col" style="gap:12px">' +
      panel('FACILITY UPGRADES', cards, '') +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('HOW UPGRADES PAY OFF', '<div class="checkline">Training and recovery affect every week of the season, not only matches.</div>' +
        '<div class="checkline">Analysis adds preparation, one of eight components in the match rating.</div>' +
        '<div class="checkline">Academy level improves the generated prospects you receive each pre-season.</div>' +
        '<div class="checkline">Upkeep is charged weekly: ' + money(upkeep / 52) + '. A level-5 facility network costs ' + money(2800) + ' per week.</div>', '') +
      panel('INVESTMENT ADVICE', (o.budget < 300000 ? '<div class="badbox">Budget is too thin for infrastructure. Win prize money or reduce payroll first; an upgrade that leaves you unable to pay wages is worse than no upgrade.</div>'
        : '<div class="goodbox">You can afford one upgrade without endangering payroll. Prioritise Training if your squad is young, Recovery if fatigue is above 55%, Analysis before a major event.</div>'), '') +
      panel('CURRENT EFFECTS', FAC_INFO.map(function (f) {
        var v = 0;
        if (f.key === 'training') v = 55 + (fac.training || 1) * 6;
        else if (f.key === 'recovery') v = (fac.recovery || 1) * 10;
        else if (f.key === 'analysis') v = 58 + ((fac.analysis || 2) - 2) * 1.2;
        else v = (fac.academy || 1) * 20;
        return '<div class="attr"><div class="an"><span>' + h(f.name) + '</span><span>' + Math.round(v) + '</span></div>' + C.bar(v, 'auto') + '</div>';
      }).join(''), '') +
      '</div></div>';
  };

  /* ==================================================================
     OBJECTIVES
  ================================================================== */
  V.objectives = function () {
    var s = st(), o = org();
    var objs = s.objectives || [];
    var active = objs.filter(function (x) { return x.status === 'active'; });
    var done = objs.filter(function (x) { return x.status === 'done'; });
    var failed = objs.filter(function (x) { return x.status === 'failed'; });
    var bs = Game.boardSummary();
    var level = s.manager.levelInfo || Engine.managerLevel(s.manager.xp || 0);

    function detail(o2) {
      var pct = 0;
      if (o2.metric === 'kickoffPos' || o2.metric === 'bestCupPos') pct = o2.progress ? C.clamp(100 - (o2.progress - o2.target) * 12, 0, 100) : 0;
      else if (o2.metric === 'payroll') pct = o2.target && o2.progress ? C.clamp(100 - (o2.progress / o2.target - 1) * 100, 0, 100) : 0;
      else if (o2.metric === 'budgetPositive') pct = o2.progress ? 100 : 0;
      else pct = o2.target ? C.clamp(o2.progress / o2.target * 100, 0, 100) : 0;
      return '<div class="guidance" style="margin-bottom:9px"><div class="row between"><h4 style="margin:0">' + h(o2.title) + '</h4>' +
        (o2.status === 'done' ? tag('ACHIEVED', 'green') : o2.status === 'failed' ? tag('FAILED', 'red') : tag(o2.importance.toUpperCase(), o2.importance === 'critical' ? 'red' : o2.importance === 'high' ? 'amber' : '')) + '</div>' +
        '<p>' + h(o2.why) + '</p>' +
        '<div class="checkline"><b>Success:</b>&nbsp;' + h(o2.success) + '</div>' +
        '<div class="checkline"><b>If missed:</b>&nbsp;' + h(o2.fail) + '</div>' +
        (o2.status === 'active' ? '<div style="margin-top:6px"><div class="row between"><span class="tiny">PROGRESS</span><span class="tiny">' + Math.round(pct) + '%</span></div>' + C.bar(pct, 'auto') + '</div>' : '') +
        '<div class="row between" style="margin-top:7px"><span class="tiny">' + h(o2.category) + ' · deadline ' + C.fmtDate(o2.deadline) + '</span>' +
        UI.btn('Open ' + (o2.page || 'dashboard'), 'go', { page: o2.page || 'dashboard', cls: 'xs ghost' }) + '</div></div>';
    }

    return head('Objectives', (active.length + done.length + failed.length) + ' BOARD TARGETS · SEASON ' + s.season, UI.btn('Dashboard', 'go', { page: 'dashboard', cls: 'ghost' })) +
      '<div class="hero" style="margin-bottom:12px"><div class="hero-in"><div class="hero-kicker">BOARD REVIEW</div>' +
      '<div class="hero-title">' + (bs.confidence >= 70 ? 'The board is behind the project' : bs.confidence >= 45 ? 'The board is watching closely' : 'The board is losing patience') + '</div>' +
      '<div class="hero-sub">' + done.length + ' objectives achieved · ' + active.length + ' active · ' + failed.length + ' failed. Confidence is ' + bs.confidence + '/100; critical failures cost far more than minor misses.</div>' +
      '<div class="hero-stats"><div class="hstat"><div class="hv">' + bs.confidence + '</div><div class="hl">Confidence</div></div>' +
      '<div class="hstat"><div class="hv">' + done.length + '</div><div class="hl">Achieved</div></div>' +
      '<div class="hstat"><div class="hv">' + active.length + '</div><div class="hl">Active</div></div>' +
      '<div class="hstat"><div class="hv">' + failed.length + '</div><div class="hl">Failed</div></div>' +
      '<div class="hstat"><div class="hv">LVL ' + level.level + '</div><div class="hl">Manager</div></div></div></div>' +
      '<div class="hero-right"><div class="conf-ring">' + C.ring(bs.confidence, bs.confidence >= 60 ? '#2fd39b' : bs.confidence >= 40 ? '#f2b23e' : '#ff4655', 58) +
      '<div><div class="tiny">BOARD CONFIDENCE</div><div class="sub">' + (o.partner ? 'Partner review' : 'Open-circuit project') + '</div></div></div>' +
      '<div class="sub" style="margin-top:5px">' + h((s.manager.boardNotes || []).slice(-1)[0] ? s.manager.boardNotes.slice(-1)[0].note : 'No board notes yet.') + '</div></div></div>' +
      '<div class="grid g23">' +
      '<div class="col" style="gap:12px">' +
      panel('ACTIVE OBJECTIVES', active.length ? active.map(detail).join('') : empty('No active objectives. The board will set new targets at the end of the season.'), '') +
      panel('COMPLETED', done.length ? done.map(detail).join('') : empty('Nothing achieved yet this season.'), '') +
      panel('FAILED', failed.length ? failed.map(detail).join('') : empty('No failed objectives.'), '') +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('MANAGER PROFILE', '<div class="statline"><span>Name</span><b>' + h(s.manager.name) + '</b></div>' +
        '<div class="statline"><span>Nationality</span><b>' + h(C.countryName(s.manager.nat)) + '</b></div>' +
        '<div class="statline"><span>Age</span><b>' + s.manager.age + '</b></div>' +
        '<div class="statline"><span>Reputation</span><b>' + rnd(s.manager.rep) + '</b></div>' +
        '<div class="statline"><span>Record</span><b>' + s.manager.wins + '–' + s.manager.losses + '</b></div>' +
        '<div class="statline"><span>Trophies</span><b>' + (s.manager.trophies || []).length + '</b></div>' +
        '<div class="attr" style="margin-top:8px"><div class="an"><span>Level ' + level.level + '</span><span>' + level.progress + '%</span></div>' + C.bar(level.progress, 'auto') + '</div>' +
        '<div class="tiny">' + level.next + ' XP to level ' + (level.level + 1) + '</div>', '') +
      panel('HOW CONFIDENCE MOVES', '<div class="checkline">Achieving an objective raises confidence and manager reputation.</div>' +
        '<div class="checkline">Missing a critical objective costs significantly more than a normal one.</div>' +
        '<div class="checkline">A negative budget and a broken roster add pressure even when results are good.</div>' +
        '<div class="checkline">Confidence affects board patience, not match simulation. Difficulty changes patience, never the engine.</div>', '') +
      panel('SEASON CONTEXT', '<div class="statline"><span>Club</span><b>' + h(o.name) + '</b></div>' +
        '<div class="statline"><span>Status</span><b>' + (o.partner ? 'VCT Partner' : 'Open Circuit') + '</b></div>' +
        '<div class="statline"><span>Reputation</span><b>' + rnd(o.rep) + '</b></div>' +
        '<div class="statline"><span>Budget</span><b class="' + (o.budget < 0 ? 'red' : '') + '">' + money(o.budget) + '</b></div>' +
        '<div class="statline"><span>Kickoff position</span><b>' + (s.flags.kickoffPos ? C.ordinal(s.flags.kickoffPos) : '—') + '</b></div>' +
        '<div class="statline"><span>Champions qualified</span><b>' + (s.flags.championsQualified ? 'YES' : 'NO') + '</b></div>', '') +
      '</div></div>';
  };

  /* ==================================================================
     NEWS
  ================================================================== */
  V.news = function () {
    var s = st();
    var filter = (UI.filters && UI.filters.news) || 'all';
    var types = ['all', 'world', 'transfer', 'trophy', 'squad', 'finance', 'academy', 'facilities', 'competition', 'user', 'match'];
    var list = s.news.filter(function (n) { return filter === 'all' || n.type === filter; });
    var unread = s.news.filter(function (n) { return !n.read; }).length;
    var chips = types.map(function (t) {
      return '<button class="btn xs ' + (filter === t ? 'primary' : 'ghost') + '" data-act="newsFilter" data-value="' + t + '">' + (t === 'all' ? 'ALL' : t.toUpperCase()) + '</button>';
    }).join('');
    var featured = s.news.filter(function (n) { return n.importance >= 4; }).slice(0, 3);

    return head('News', unread + ' UNREAD · ' + s.news.length + ' STORIES', UI.btn('Mark all read', 'markAllRead', { cls: 'ghost' })) +
      (featured.length ? '<div class="grid g3" style="margin-bottom:12px">' + featured.map(function (n) {
        return '<div class="guidance" data-act="openNews" data-id="' + n.id + '" style="cursor:pointer;margin:0"><div class="tiny">' + h(n.type.toUpperCase()) + ' · ' + C.fmtDate(n.date) + '</div>' +
          '<h4 style="margin-top:3px">' + h(n.title) + '</h4><p>' + newsExcerpt(n.body, 150) + '</p></div>';
      }).join('') + '</div>' : '') +
      '<div class="row" style="gap:4px;flex-wrap:wrap;margin-bottom:10px">' + chips + '</div>' +
      '<div class="grid g23">' +
      '<div class="col" style="gap:12px">' +
      panel('NEWS FEED', list.length ? newsRows(list.slice(0, 40)) : empty('No stories with this filter.'), '') +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('WHY NEWS MATTERS', '<div class="sub">News records what changed in the world and why it matters to you. Transfer stories show the direction of the market; competition results update reputation and ranking points; board notes warn you before a review.</div>', '') +
      panel('BOOKMARKS', '<div class="scout-line"><div style="flex:1"><div style="font-family:var(--cond);font-size:13px">Transfer market</div><div class="tiny">Free agents and fees</div></div>' + UI.btn('Open', 'go', { page: 'transfers', cls: 'xs ghost' }) + '</div>' +
        '<div class="scout-line"><div style="flex:1"><div style="font-family:var(--cond);font-size:13px">Competition results</div><div class="tiny">Brackets and standings</div></div>' + UI.btn('Open', 'go', { page: 'competitions', cls: 'xs ghost' }) + '</div>' +
        '<div class="scout-line"><div style="flex:1"><div style="font-family:var(--cond);font-size:13px">Board objectives</div><div class="tiny">Season targets</div></div>' + UI.btn('Open', 'go', { page: 'objectives', cls: 'xs ghost' }) + '</div>', '') +
      panel('SOURCE & CONFIDENCE', '<div class="sub">Database snapshot: ' + C.DB_SNAPSHOT + '. Status tags: OFFICIAL (confirmed by the organisation or Riot), REPORTED (credible outlet), LIKELY (multiple signals), RUMORED (unconfirmed), UNKNOWN (no reliable data), SIM (generated player or simulated format). Never treat a rumour as official.</div>', '') +
      '</div></div>';
  };

  /* ==================================================================
     HISTORY
  ================================================================== */
  V.history = function () {
    var s = st(), o = org();
    var hst = s.history || { seasons: [], competitions: [], champions: [], awards: [], retirees: [] };
    var trophies = s.manager.trophies || [];
    var seasonRows = hst.seasons.slice().reverse().map(function (x) {
      return '<tr><td><b>' + x.season + '</b></td><td>' + h(x.clubName) + '</td>' +
        '<td class="r">' + (x.kickoffPos ? C.ordinal(x.kickoffPos) : '—') + '</td>' +
        '<td class="r">' + (x.bestCupPos ? C.ordinal(x.bestCupPos) : '—') + '</td>' +
        '<td class="c">' + (x.mastersPlayed ? tag('YES', 'green') : tag('NO', '')) + '</td>' +
        '<td class="c">' + (x.championsQualified ? tag('YES', 'green') : tag('NO', '')) + '</td>' +
        '<td class="r">' + (x.objectives ? x.objectives.done + '/' + (x.objectives.done + x.objectives.failed) : '—') + '</td>' +
        '<td class="r">' + (x.trophies && x.trophies.length ? '<span class="amber">' + x.trophies.length + '</span>' : '—') + '</td>' +
        '<td class="r">' + money(x.budget || 0) + '</td></tr>';
    }).join('');

    var hallRows = (hst.champions || []).slice().reverse().map(function (c) {
      var champ = s.orgs[c.orgId];
      return '<tr><td class="r">' + c.season + '</td><td>' + h(c.comp) + '</td><td>' + (champ ? UI.orgCell(champ, 16) : h(c.orgId || '—')) + '</td><td class="r tiny">' + C.fmtDate(c.date) + '</td></tr>';
    }).join('');

    var awardsRows = (hst.awards || []).slice().reverse().map(function (a) {
      var mvp = a.mvp ? s.players[a.mvp] : null;
      var rising = a.risingStar ? s.players[a.risingStar] : null;
      return '<tr><td class="r">' + a.season + '</td><td>' + (mvp ? UI.playerLink(mvp, true) : '—') + '</td>' +
        '<td>' + (rising ? UI.playerLink(rising, true) : '—') + '</td></tr>';
    }).join('');

    var retireRows = (hst.retirees || []).slice().reverse().slice(0, 24).map(function (r) {
      var org2 = r.org ? s.orgs[r.org] : null;
      return '<tr><td>' + h(r.nick) + '<div class="tiny">' + h(r.name || '') + ' · ' + h(r.role || '') + '</div></td>' +
        '<td>' + (org2 ? h(org2.short) : '—') + '</td><td class="r">' + (r.age || '—') + '</td><td class="r">' + (r.peak || '—') + '</td><td class="r">' + r.season + '</td></tr>';
    }).join('');

    var trophyCards = trophies.length ? trophies.slice().reverse().map(function (t) {
      return '<div class="scout-line trophy-cabinet-card"><img src="' + trophyAsset(t) + '" alt="' + h(I18N.t('Trophy')) + '" width="42" height="42" loading="lazy" decoding="async"><div style="flex:1"><div style="font-family:var(--cond);font-size:13px">' + h(t.name) + '</div>' +
        '<div class="tiny">' + h(I18N.t('Season')) + ' ' + h(t.season) + (t.city ? ' · ' + h(t.city) : '') + '</div></div></div>';
    }).join('') : empty('No trophies yet. The first Kickoff title would be remembered here.');

    return head('History', 'HALL OF FAME · SEASONS · AWARDS', UI.btn('Save / export', 'go', { page: 'settings', cls: 'ghost' })) +
      '<div class="hero" style="margin-bottom:12px"><div class="hero-in"><div class="hero-kicker">CAREER RECORD</div>' +
      '<div class="hero-title">' + h(s.manager.name) + '</div>' +
      '<div class="hero-sub">' + (hst.seasons.length || 1) + ' season(s) at ' + h(o.name) + ' · ' + s.manager.wins + ' series wins · ' + (trophies.length) + ' trophies · reputation ' + rnd(s.manager.rep) + '</div>' +
      '<div class="hero-stats"><div class="hstat"><div class="hv">' + hst.seasons.length + '</div><div class="hl">Seasons</div></div>' +
      '<div class="hstat"><div class="hv">' + trophies.length + '</div><div class="hl">Trophies</div></div>' +
      '<div class="hstat"><div class="hv">' + (hst.retirees || []).length + '</div><div class="hl">Retirements seen</div></div>' +
      '<div class="hstat"><div class="hv">' + (hst.champions || []).length + '</div><div class="hl">Titles recorded</div></div></div></div>' +
      '<div class="hero-right"><div class="sub">Every completed season is archived with placements, trophies, budget and awards. Nothing is overwritten when you start a new career.</div>' +
      UI.btn('Objectives', 'go', { page: 'objectives', cls: 'sm ghost' }) + '</div></div>' +
      '<div class="grid g23">' +
      '<div class="col" style="gap:12px">' +
      panel('SEASON BY SEASON', seasonRows ? UI.table([{ label: 'Season' }, { label: 'Club' }, { label: 'Kickoff', cls: 'r' }, { label: 'Best Cup', cls: 'r' }, { label: 'Masters', cls: 'c' }, { label: 'Champions', cls: 'c' }, { label: 'Objectives', cls: 'r' }, { label: 'Trophies', cls: 'r' }, { label: 'Budget', cls: 'r' }], seasonRows) : empty('Your first season is still in progress. The archive fills at the season review.'), '') +
      panel('HALL OF FAME · CHAMPIONS', hallRows ? UI.table([{ label: 'Season', cls: 'r' }, { label: 'Competition' }, { label: 'Champion' }, { label: 'Date', cls: 'r' }], hallRows) : empty('No champion recorded yet. The first Champions winner enters the hall of fame.'), '') +
      panel('RETIREMENTS', retireRows ? UI.table([{ label: 'Player' }, { label: 'Last club' }, { label: 'Age', cls: 'r' }, { label: 'Peak', cls: 'r' }, { label: 'Season', cls: 'r' }], retireRows) : empty('No retirements recorded. Ageing and retirements run at each season transition.'), '') +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('TROPHY CABINET', trophyCards, '') +
      panel('SEASON AWARDS', awardsRows ? UI.table([{ label: 'Season', cls: 'r' }, { label: 'MVP' }, { label: 'Rising Star' }], awardsRows) : empty('Awards are calculated at the season review.'), '') +
      panel('COMPETITION ARCHIVE', (hst.competitions || []).length ? (hst.competitions || []).slice().reverse().slice(0, 14).map(function (c) {
        var champ = c.champion ? s.orgs[c.champion] : null;
        return '<div class="scout-line"><span class="dotp ' + (champ ? 'known' : '') + '"></span><div style="flex:1;min-width:0"><div style="font-family:var(--cond);font-size:13px">' + h(c.name) + '</div>' +
          '<div class="tiny">' + (champ ? 'Won by ' + h(champ.name) : 'No champion') + ' · ' + C.fmtDate(c.date) + (c.city ? ' · ' + h(c.city) : '') + '</div></div>' + tag('S' + c.season, '') + '</div>';
      }).join('') : empty('No completed competitions yet.'), '') +
      '</div></div>';
  };

  /* ==================================================================
     SETTINGS
  ================================================================== */
  /* ==================================================================
     LIVE WORLD ROSTERS
  ================================================================== */
  V.rosters = function () {
    var s = st();
    var directory = Game.liveRosters();
    var filters = UI.filters.rosters;
    var teams = directory.teams || [];
    var allCompetitions = directory.competitions || [];
    var selectedOrg = filters.org || 'all';
    var selectedRegion = filters.region || 'all';
    var selectedLeague = filters.league || 'all';
    var selectedCompetition = filters.competition || 'all';
    var query = String(filters.search || '').toLowerCase().trim();
    var regions = [];
    var leagues = [];

    teams.forEach(function (team) {
      if (team.org.region && regions.indexOf(team.org.region) < 0) regions.push(team.org.region);
      if (team.league && leagues.indexOf(team.league) < 0) leagues.push(team.league);
    });
    regions.sort(); leagues.sort();

    function option(value, label, selected) {
      return '<option value="' + h(value) + '"' + (String(value) === String(selected) ? ' selected' : '') + '>' + h(label) + '</option>';
    }
    function filterSelect(key, label, options, selected) {
      return '<label class="field roster-filter"><span>' + h(label) + '</span><select class="inp" data-change="rosterFilter" data-roster-filter="' + key + '">' + options + '</select></label>';
    }
    function contractStatus(player) {
      if (player.contractEnd == null || player.contractEnd === '') return I18N.t('Contract details unavailable');
      if (Number(player.contractEnd) <= Number(s.season)) {
        return I18N.t('Expires after season {season}', { season: s.season });
      }
      return I18N.t('Contract through {season}', { season: player.contractEnd });
    }
    function playerRow(player, team, starter) {
      var agents = (player.agents || []).filter(Boolean).join(', ') || I18N.t('No agents listed');
      var status = player.contractEnd != null && Number(player.contractEnd) <= Number(s.season)
        ? tag('Expiring', 'amber') : tag('Under contract', 'green');
      if (player.transferListed) status += tag('Listed', 'amber');
      if (player.injury && player.injury.days > 0) status += tag(I18N.t('Injured · {days}d', { days: player.injury.days }), 'red');
      return '<div class="roster-player' + (starter ? ' starter' : '') + '">' +
        C.portraitImg(player, team.org, 44, 'roster-avatar') +
        '<div class="roster-player-info"><div class="roster-player-top"><button class="roster-player-link" data-act="openPlayer" data-id="' + h(player.id) + '">' + h(player.nick) + '</button>' +
        '<span class="roster-rating">' + rnd(player.level) + ' OVR</span></div>' +
        '<div class="roster-player-meta">' + C.roleTag(player.role) + (player.secondary ? ' <span class="dim2">/ ' + h(player.secondary) + '</span>' : '') +
        ' · ' + h(contractStatus(player)) + '</div>' +
        '<div class="roster-player-agents"><span>' + h(I18N.t('Agents')) + ':</span> ' + h(agents) + '</div>' +
        (status ? '<div class="roster-player-status">' + status + '</div>' : '') + '</div></div>';
    }

    var orgOptions = option('all', I18N.t('All organizations'), selectedOrg) + teams.map(function (team) {
      return option(team.id, team.org.name, selectedOrg);
    }).join('');
    var regionOptions = option('all', I18N.t('All regions'), selectedRegion) + regions.map(function (region) {
      return option(region, I18N.text(region), selectedRegion);
    }).join('');
    var leagueOptions = option('all', I18N.t('All leagues'), selectedLeague) + leagues.map(function (league) {
      return option(league, I18N.text(league), selectedLeague);
    }).join('');
    var compOptions = option('all', I18N.t('All competitions'), selectedCompetition) + allCompetitions.map(function (comp) {
      return option(comp.id, comp.name + ' · ' + (comp.season || s.season), selectedCompetition);
    }).join('');

    var filtered = teams.filter(function (team) {
      if (selectedOrg !== 'all' && team.id !== selectedOrg) return false;
      if (selectedRegion !== 'all' && team.org.region !== selectedRegion) return false;
      if (selectedLeague !== 'all' && team.league !== selectedLeague) return false;
      if (selectedCompetition !== 'all' && !team.competitions.some(function (comp) { return comp.id === selectedCompetition; })) return false;
      if (query) {
        var search = [team.org.name, team.org.short, team.org.region, team.league]
          .concat(team.roster.map(function (player) { return [player.nick, player.name, player.role].join(' '); }))
          .join(' ').toLowerCase();
        if (search.indexOf(query) < 0) return false;
      }
      return true;
    });

    var totalPlayers = filtered.reduce(function (sum, team) { return sum + team.roster.length; }, 0);
    var totalReserves = filtered.reduce(function (sum, team) { return sum + team.reserves.length; }, 0);
    var totalStaff = filtered.reduce(function (sum, team) { return sum + team.staff.length; }, 0);
    var filterBody = '<div class="roster-filters">' +
      filterSelect('org', 'Organization', orgOptions, selectedOrg) +
      filterSelect('region', 'Region', regionOptions, selectedRegion) +
      filterSelect('league', 'League', leagueOptions, selectedLeague) +
      filterSelect('competition', 'Competition', compOptions, selectedCompetition) +
      '<label class="field roster-filter roster-search"><span>' + h(I18N.t('Search teams or players')) + '</span><input class="inp" type="search" value="' + h(filters.search || '') + '" placeholder="' + h(I18N.t('Search teams or players')) + '" data-change="rosterFilter" data-roster-filter="search"></label>' +
      '</div><div class="row roster-filter-actions">' +
      UI.btn('Apply filters', 'applyRosterFilters', { cls: 'sm primary' }) +
      UI.btn('Clear filters', 'resetRosterFilters', { cls: 'sm ghost' }) +
      '<span class="tiny">' + h(I18N.t('Showing {shown} of {total} organizations', { shown: filtered.length, total: teams.length })) + '</span></div>';

    var teamCards = filtered.map(function (team) {
      var activeComp = team.competitions.filter(function (comp) { return comp.status !== 'done'; })
        .sort(function (a, b) { return String(a.startDate || '').localeCompare(String(b.startDate || '')); })[0];
      var starters = team.starters.slice(0, 5).map(function (player) { return playerRow(player, team, true); }).join('');
      var reserves = team.reserves.map(function (player) { return playerRow(player, team, false); }).join('');
      var staff = team.staff.slice().sort(function (a, b) { return String(a.role || '').localeCompare(String(b.role || '')); }).map(function (member) {
        return '<div class="roster-staff-row"><span class="roster-staff-role">' + h(member.role || I18N.t('Staff')) + '</span><b>' + h(member.nick || member.name || I18N.t('Unknown')) + '</b>' +
          (member.grade != null ? '<span class="tiny">' + Number(member.grade).toFixed(1) + ' / 10</span>' : '') + '</div>';
      }).join('');
      var league = I18N.text(team.league);
      return '<details class="roster-team"><summary><span class="roster-team-main">' + C.logoMarkup(team.org, 'roster-org-logo', 38) +
        '<span class="roster-org-title"><b>' + h(team.org.name) + '</b><span>' + h(team.org.region || I18N.t('Unassigned region')) + ' · ' + h(league) + '</span></span></span>' +
        '<span class="roster-team-counts"><span>' + h(I18N.t('{count} starters', { count: team.starters.length })) + '</span><span>' + h(I18N.t('{count} reserves', { count: team.reserves.length })) + '</span><span>' + h(I18N.t('{count} staff', { count: team.staff.length })) + '</span></span>' +
        '<span class="roster-expand" aria-hidden="true">+</span></summary>' +
        '<div class="roster-team-body"><div class="roster-current-org"><span>' + h(I18N.t('Current organization')) + ': <b>' + h(team.org.name) + '</b></span>' +
        (activeComp ? '<span>' + h(I18N.t('Current competition')) + ': <b>' + h(activeComp.name) + '</b></span>' : '<span>' + h(I18N.t('No current competition')) + '</span>') + '</div>' +
        '<div class="roster-detail-grid"><section class="roster-section"><h3>' + h(I18N.t('Starting five')) + '</h3><div class="roster-player-list">' + (starters || empty('No starting lineup recorded.')) + '</div></section>' +
        '<section class="roster-section"><h3>' + h(I18N.t('Substitutes and reserves')) + '</h3><div class="roster-player-list">' + (reserves || empty('No reserve players.')) + '</div></section>' +
        '<section class="roster-section roster-staff"><h3>' + h(I18N.t('Coaches and staff')) + '</h3><div class="roster-staff-list">' + (staff || empty('No staff assigned.')) + '</div></section></div></div></details>';
    }).join('');

    var updates = (directory.updates || []).map(function (update) {
      var teamOrg = update.orgId ? s.orgs[update.orgId] : null;
      return '<div class="roster-update"><span class="roster-update-date">' + h(C.fmtDate(update.date, true)) + '</span>' +
        '<div class="roster-update-copy"><b>' + h(update.title) + '</b>' + (update.body ? '<span>' + h(update.body) + '</span>' : '') +
        (teamOrg ? '<small>' + h(teamOrg.name) + '</small>' : '') + '</div><span class="tag">' + h(I18N.text(update.type)) + '</span></div>';
    }).join('');

    return head('Live rosters', I18N.t('Career date: {date} · Rosters reflect this save', { date: C.fmtDate(directory.date, true) })) +
      panel('Find a team', filterBody, '') +
      '<div class="grid g4 roster-kpis">' +
      kpi('Organizations', String(filtered.length), I18N.t('of {total} active teams', { total: teams.length }), '') +
      kpi('Players', String(totalPlayers), I18N.t('Current first-team rosters'), '') +
      kpi('Reserves', String(totalReserves), I18N.t('Substitutes and depth players'), '') +
      kpi('Staff', String(totalStaff), I18N.t('Coaches and support staff'), '') +
      '</div>' +
      panel('Organizations and teams', teamCards || empty('No organizations match these filters.'), '') +
      panel('Recent transfers and roster changes', updates || empty('No roster changes recorded yet.'), '');
  };

  V.settings = function () {
    var s = st(), o = org();
    var saves = Game.saves();
    var diff = C.DIFFICULTY[s.difficulty] || C.DIFFICULTY.Normal;
    var audio = VgmAudio.getSettings();
    var saveRows = saves.map(function (x) {
      var current = x.id === s.id;
      return '<tr class="' + (current ? 'me' : '') + '"><td><b style="font-family:var(--cond);font-size:13px">' + h(x.name) + '</b><div class="tiny">' + h(x.badge || '') + ' · season ' + (x.season || '—') + '</div></td>' +
        '<td class="r tiny">' + C.fmtDate(x.date) + '</td><td class="r tiny">' + (x.updated ? new Date(x.updated).toLocaleDateString() : '—') + '</td>' +
        '<td class="r">' + (current ? tag('ACTIVE', 'red') : UI.btn('Load', 'loadSave', { id: x.id, cls: 'xs ghost' })) +
        UI.btn('Delete', 'deleteSave', { id: x.id, cls: 'xs danger', disabled: current }) + '</td></tr>';
    }).join('');
    var stResult = UI.selfTestResult;

    return head('Settings', 'SAVES · PREFERENCES · DIAGNOSTICS', UI.btn('Save now', 'saveNow', { cls: 'primary' })) +
      '<div class="grid g23">' +
      '<div class="col" style="gap:12px">' +
      panel('CAREER', '<div class="split-2">' +
        '<div class="statline"><span>Manager</span><b>' + h(s.manager.name) + '</b></div>' +
        '<div class="statline"><span>Club</span><b>' + h(o.name) + '</b></div>' +
        '<div class="statline"><span>Save name</span><b>' + h(s.name) + '</b></div>' +
        '<div class="statline"><span>Season</span><b>' + s.season + '</b></div>' +
        '<div class="statline"><span>Date</span><b>' + C.fmtDate(s.date) + '</b></div>' +
        '<div class="statline"><span>Difficulty</span><b>' + h(s.difficulty) + '</b></div></div>' +
        '<div class="divider"></div><div class="sub">' + h(diff.desc) + ' Difficulty changes AI strength, budgets, wages, board patience and youth growth — never the simulation rules themselves, so results stay explainable.</div>' +
        '<div class="row" style="margin-top:8px;flex-wrap:wrap">' + UI.btn('Save', 'saveNow', { cls: 'sm primary' }) + UI.btn('Export JSON', 'exportSave', { cls: 'sm ghost' }) + UI.btn('Import JSON', 'importClick', { cls: 'sm ghost' }) + UI.btn('Main menu', 'mainMenu', { cls: 'sm ghost' }) + '</div>', '') +
      panel('SAVED CAREERS', saveRows ? UI.table([{ label: 'Career' }, { label: 'Date', cls: 'r' }, { label: 'Saved', cls: 'r' }, { label: '', cls: 'r' }], saveRows) : empty('No local saves. Use Save now or export a JSON backup.'), '') +
      panel('PREFERENCES', '<div class="scout-line"><div style="flex:1"><div style="font-family:var(--cond);font-size:13px">Autosave</div><div class="tiny">Write to local storage after every advance and action.</div></div>' +
        '<button class="btn sm ' + (s.settings.autoSave ? 'green' : 'ghost') + '" data-act="toggleAutoSave">' + (s.settings.autoSave ? 'ON' : 'OFF') + '</button></div>' +
        '<div class="scout-line"><div style="flex:1"><div style="font-family:var(--cond);font-size:13px">Guidance & tooltips</div><div class="tiny">Info icons, contextual recommendations and beginner mode.</div></div>' +
        '<button class="btn sm ' + (s.settings.tips ? 'green' : 'ghost') + '" data-act="toggleTips">' + (s.settings.tips ? 'ON' : 'OFF') + '</button></div>' +
        '<div class="scout-line"><div style="flex:1"><div style="font-family:var(--cond);font-size:13px">Notifications</div><div class="tiny">Toasts for completed actions and match results.</div></div>' +
        '<button class="btn sm ' + (s.settings.notifications ? 'green' : 'ghost') + '" data-act="toggleNotif">' + (s.settings.notifications ? 'ON' : 'OFF') + '</button></div>' +
        '<div class="scout-line"><div style="flex:1"><div style="font-family:var(--cond);font-size:13px">Beginner mode</div><div class="tiny">Shows extra explanations and recommended actions across every page.</div></div>' +
        '<button class="btn sm ' + (s.guided ? 'green' : 'ghost') + '" data-act="toggleGuided">' + (s.guided ? 'ON' : 'OFF') + '</button></div>' +
        '<div class="scout-line"><div style="flex:1"><div style="font-family:var(--cond);font-size:13px">Language</div><div class="tiny">' + h(I18N.langMeta(I18N.get()).native) + ' · interface, dates, numbers and match explanations.</div></div>' +
        '<button class="btn sm ghost" data-act="openLanguageModal">Change</button></div>', '') +
      panel(I18N.t('Audio & sound'), '<div class="sub audio-note">' + h(I18N.t('The supplied instrumental plays by default · no vocals. Playback starts after your first interaction; selected audio stays in this browser.')) + '</div>' +
        '<div class="scout-line"><div style="flex:1"><div style="font-family:var(--cond);font-size:13px">' + h(I18N.t('Music')) + '</div><div class="tiny">' + h(I18N.t('VALORANT Champions instrumental by default. Choose a local file to replace it.')) + '</div></div>' +
        '<button class="btn sm ' + (audio.musicEnabled ? 'green' : 'ghost') + '" data-act="toggleMusic">' + h(I18N.t(audio.musicEnabled ? 'ON' : 'OFF')) + '</button></div>' +
        '<label class="audio-volume"><span>' + h(I18N.t('Music volume')) + ' <b id="musicVolumeValue">' + Math.round(audio.musicVolume * 100) + '%</b></span><input type="range" min="0" max="100" value="' + Math.round(audio.musicVolume * 100) + '" data-change="audioVolume" data-audio="music" aria-label="' + h(I18N.t('Music volume')) + '"></label>' +
        '<div class="scout-line"><div style="flex:1"><div style="font-family:var(--cond);font-size:13px">' + h(I18N.t('Sound effects')) + '</div><div class="tiny">' + h(I18N.t('Short, soft clicks and subtle success or error tones.')) + '</div></div>' +
        '<button class="btn sm ' + (audio.sfxEnabled ? 'green' : 'ghost') + '" data-act="toggleSfx">' + h(I18N.t(audio.sfxEnabled ? 'ON' : 'OFF')) + '</button></div>' +
        '<label class="audio-volume"><span>' + h(I18N.t('Effects volume')) + ' <b id="sfxVolumeValue">' + Math.round(audio.sfxVolume * 100) + '%</b></span><input type="range" min="0" max="100" value="' + Math.round(audio.sfxVolume * 100) + '" data-change="audioVolume" data-audio="sfx" aria-label="' + h(I18N.t('Effects volume')) + '"></label>' +
        '<div class="scout-line"><div style="flex:1;min-width:0"><div style="font-family:var(--cond);font-size:13px">' + h(I18N.t('Current music')) + '</div><div class="tiny audio-track-name">' + h(audio.currentTrackName) + '</div></div>' +
        UI.btn('Choose instrumental file', 'importMusic', { cls: 'sm ghost' }) + (audio.customTrackName ? UI.btn('Remove custom track', 'removeCustomMusic', { cls: 'sm danger' }) : '') + '</div>' +
        '<div class="tiny audio-license-note">' + h(I18N.t('Only use audio files you have the right to play; your file stays in this browser.')) + '</div>' +
        '<input id="customMusicFile" class="audio-file-input" type="file" accept="audio/*,.mp3,.wav,.ogg,.m4a,.aac,.flac" aria-label="' + h(I18N.t('Choose instrumental file')) + '" tabindex="-1" hidden>' +
        '<div class="row" style="margin-top:6px">' + UI.btn(I18N.t('Preview UI sound'), 'previewSfx', { cls: 'sm ghost' }) + '</div>', '') +
      panel('CLUB IDENTITY & LOGO', '<div class="logo-upload-box"><div class="logo-preview">' + C.logoMarkup(o, '', 52) + '</div>' +
        '<div style="flex:1;min-width:0"><div class="sub">' + (o.customLogo ? 'Custom emblem active across dashboard, brackets, news and history.' : 'Upload a custom PNG, JPG or WEBP club logo. Persists in your career save.') + '</div>' +
        '<div class="row" style="margin-top:7px">' + UI.btn(o.customLogo ? 'Replace logo' : 'Upload logo', 'setClubLogo', { cls: 'sm ghost' }) +
        (o.customLogo ? UI.btn('Remove logo', 'removeClubLogo', { cls: 'sm danger' }) : '') + '</div></div></div>', '') +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('DATA & SOURCES', '<div class="statline"><span>Database snapshot</span><b>' + C.DB_SNAPSHOT + '</b></div>' +
        '<div class="statline"><span>Game version</span><b>' + C.VERSION + '</b></div>' +
        '<div class="statline"><span>Partner organisations</span><b>32</b></div>' +
        '<div class="statline"><span>Players materialised</span><b>' + Object.keys(s.players).length + '</b></div>' +
        '<div class="divider"></div><div class="checkline"><b>OFFICIAL</b>&nbsp;confirmed by Riot or the organisation.</div>' +
        '<div class="checkline"><b>REPORTED</b>&nbsp;credible outlet, not confirmed.</div>' +
        '<div class="checkline"><b>LIKELY</b>&nbsp;multiple converging signals.</div>' +
        '<div class="checkline"><b>RUMORED</b>&nbsp;unconfirmed market talk, never treated as fact.</div>' +
        '<div class="checkline"><b>SIM</b>&nbsp;generated player or simulated bracket detail.</div>', '') +
      panel('DIAGNOSTICS', '<div class="sub">Run a headless multi-season simulation to verify progression, contracts, retirements, saves and history. This does not touch your career.</div>' +
        '<div class="row" style="margin-top:8px">' + UI.btn('Run self-test (2 seasons)', 'selfTest', { cls: 'sm primary' }) + '</div>' +
        (stResult ? '<div class="divider"></div><div class="row between"><b>' + (stResult.ok ? 'PASSED' : 'ISSUES FOUND') + '</b><span class="tiny">' + stResult.checks.filter(function (c) { return c.pass; }).length + '/' + stResult.checks.length + '</span></div>' +
          stResult.checks.map(function (c) {
            return '<div class="checkline" style="color:' + (c.pass ? 'var(--green)' : 'var(--red)') + '">' + (c.pass ? '✓ ' : '✕ ') + h(c.name) + (c.detail ? ' <span class="dim2">(' + h(c.detail) + ')</span>' : '') + '</div>';
          }).join('') +
          (stResult.errors.length ? '<div class="badbox" style="margin-top:6px">' + stResult.errors.map(h).join('<br>') + '</div>' : '')
          : ''), '') +
      panel('START OVER', '<div class="sub">Starting a new career keeps this save in the list. Export a JSON backup before deleting anything.</div>' +
        '<div class="row" style="margin-top:8px">' + UI.btn('New career', 'newCareerConfirm', { cls: 'sm ghost' }) + UI.btn('Export backup', 'exportSave', { cls: 'sm ghost' }) + '</div>' +
        '<div class="divider"></div><div class="tiny dim2">16 pages · real 2027 partners and rosters · official format where published · every simulated rule labelled.</div>', '') +
      '</div></div>';
  };

  /* ==================================================================
     MATCH DAY
  ================================================================== */
  V.matchday = function () {
    var s = st(), o = org(), nf = nextFixture();
    if (!nf) {
      return head('Match day', 'NO FIXTURE READY') +
        '<div class="grid g23"><div class="col" style="gap:12px">' +
        panel('NO MATCH SCHEDULED', '<div class="sub">Advance time until the next fixture. The simulation stops automatically the day before your match so you can prepare.</div><div class="row" style="margin-top:9px">' + UI.btn('Advance to match', 'toMatch', { cls: 'primary' }) + UI.btn('Calendar', 'go', { page: 'calendar', cls: 'ghost' }) + '</div>', '') +
        '</div><div class="col" style="gap:12px">' + panel('PREPARATION CHECKLIST', '<div class="checkline">Starting five valid and every role covered.</div><div class="checkline">Agent assignments comfortable at 75+ familiarity.</div><div class="checkline">Fatigue under 55% for the whole lineup.</div><div class="checkline">Active 7-map competitive pool with preparation concentrated on your picks.</div>', '') + '</div></div>';
    }
    var opp = nf.opp, r = Game.teamRating(o), ro = opp ? Game.teamRating(opp) : { overall: 50, attack: 50, defense: 50, skill: 50, chem: 50, coach: 50, agent: 50, prep: 50, form: 50, morale: 50, fatigue: 0 };
    var lineup = Game.lineup(o);
    var oppIds = (opp && (opp.lineup && opp.lineup.length ? opp.lineup : opp.roster)) || [];
    var oppPlayers = oppIds.map(function (id) { return s.players[id]; }).filter(Boolean).slice(0, 5);
    var form = (opp && opp.form) || [];
    var p = winProb(r.overall, ro.overall);
    var bo = nf.comp && nf.comp.type === 'champions' ? 5 : (nf.stage && nf.stage.indexOf('Final') >= 0 ? 5 : 3);
    var h2h = s.userMatches.filter(function (m) {
      return (m.teamA === s.clubId && m.teamB === (opp && opp.id)) || (m.teamB === s.clubId && m.teamA === (opp && opp.id));
    });
    var hw = h2h.filter(function (m) { return m.userWon; }).length;

    var myRows = lineup.map(function (pl) {
      var agent = pl.agents[0] || '—';
      return '<tr><td>' + UI.playerLink(pl, false) + '</td><td>' + C.roleTag(pl.role) + '</td><td class="r">' + pl.level + '</td>' +
        '<td class="r">' + rnd(pl.form) + '</td><td class="r">' + rnd(pl.morale) + '</td><td class="r ' + (pl.fatigue > 55 ? 'red' : '') + '">' + rnd(pl.fatigue) + '%</td>' +
        '<td class="r">' + h(agent) + ' <span class="tiny">' + rnd(pl.agentFamiliarity[agent] || 50) + '</span></td></tr>';
    }).join('');
    var oppRows = oppPlayers.map(function (pl) {
      return '<tr><td>' + UI.playerLink(pl, false) + '</td><td>' + C.roleTag(pl.role) + '</td><td class="r">' + pl.level + '</td>' +
        '<td class="r">' + rnd(pl.form) + '</td><td class="r">' + rnd(pl.fatigue) + '%</td></tr>';
    }).join('');

    var compare = [['Team rating', r.overall, ro.overall], ['Skill', r.skill, ro.skill], ['Chemistry', r.chem, ro.chem], ['Agent fit', r.agent, ro.agent], ['Preparation', r.prep, ro.prep], ['Coaching', r.coach, ro.coach], ['Form', r.form, ro.form], ['Morale', r.morale, ro.morale], ['Fatigue (lower is better)', r.fatigue, ro.fatigue]];
    var compareRows = compare.map(function (c) {
      var mine = c[1], theirs = c[2];
      var better = c[0].indexOf('Fatigue') >= 0 ? mine < theirs : mine > theirs;
      return '<div class="statline"><span>' + c[0] + '</span><b><span class="' + (better ? 'green' : '') + '">' + rnd(mine) + '</span> <span class="dim2">vs</span> <span class="' + (!better ? 'amber' : '') + '">' + rnd(theirs) + '</span></b></div>';
    }).join('');

    var mapRows = s.settings.mapPool.map(function (m) {
      var prep = (o.mapPrep && o.mapPrep[m]) || 55;
      return '<div class="mapcomp"><div><div style="font-family:var(--cond);font-size:13px">' + h(m) + '</div><div class="tiny">' + h((C.MAPS.filter(function (x) { return x.name === m; })[0] || {}).type || '') + '</div></div>' +
        '<div>' + C.bar(prep, 'auto') + '</div><div class="r tiny">' + rnd(prep) + '</div></div>';
    }).join('');

    var warnings = [];
    if (!lineup.length || lineup.length < 5) warnings.push('You do not have five starters. The match will be forfeited if this is not fixed.');
    var bal = Engine.roleBalance(lineup);
    if (bal.gaps.length) warnings.push('No natural ' + bal.gaps.join(' / ') + ' in the lineup. Utility coverage suffers in every round.');
    if (r.fatigue > 55) warnings.push('Average fatigue is ' + r.fatigue + '%. Consider resting a player or switching to a light week.');
    if (r.chem < 60) warnings.push('Chemistry is ' + r.chem + '/100. Coordination training would raise the floor of the rating.');
    if (p < 40) warnings.push('You are a clear underdog on rating. A slower, defensive style reduces variance.');

    var pending = !!nf.pending;
    return head('Match day', (nf.comp ? nf.comp.name : 'FRIENDLY') + ' · ' + (nf.stage || ''), UI.btn('Squad', 'go', { page: 'squad', cls: 'ghost' }) + UI.btn('Tactics', 'go', { page: 'tactics', cls: 'ghost' })) +
      (pending ? '' : '<div class="guidance" style="margin-bottom:10px"><h4>Preview mode</h4><p>The match is scheduled for ' + C.fmtDate(nf.date) + '. You can still train, sign players and change tactics. Use “Advance to match” to reach match day and lock the plan.</p></div>') +
      littleMatch(nf) +
      '<div class="grid g23" style="margin-top:12px">' +
      '<div class="col" style="gap:12px">' +
      panel('YOUR STARTING FIVE', myRows ? UI.table([{ label: 'Player' }, { label: 'Role' }, { label: 'OVR', cls: 'r' }, { label: 'Form', cls: 'r' }, { label: 'Morale', cls: 'r' }, { label: 'Fatigue', cls: 'r' }, { label: 'Primary agent', cls: 'r' }], myRows) : empty('No lineup set.'), UI.btn('Edit lineup', 'openLineup', { cls: 'xs ghost' }) + UI.btn('Agents', 'go', { page: 'tactics', cls: 'xs ghost' })) +
      panel('OPPONENT', opp ? '<div class="row" style="gap:10px;margin-bottom:8px">' + C.logoMarkup(opp, 'crest-lg', 46) +
        '<div><div style="font-family:var(--cond);font-size:18px">' + h(opp.name) + '</div><div class="tiny">' + h(opp.region + ' · ' + (opp.partner ? 'VCT partner' : 'Open circuit')) + ' · ' + h(opp.playstyle || 'Balanced') + '</div>' +
        '<div class="tiny">Record vs you: ' + hw + '–' + (h2h.length - hw) + '</div></div></div>' +
        (oppRows ? UI.table([{ label: 'Player' }, { label: 'Role' }, { label: 'OVR', cls: 'r' }, { label: 'Form', cls: 'r' }, { label: 'Fatigue', cls: 'r' }], oppRows) : empty('Opponent lineup unpublished.')) : empty('Opponent unknown.'), opp ? UI.btn('Scout club', 'openOrg', { id: opp.id, cls: 'xs ghost' }) : '') +
      panel('COMPARISON', compareRows, '') +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('MATCH PLAN', '<div class="statline"><span>Series length</span><b>Bo' + bo + '</b></div>' +
        '<div class="statline"><span>Your style</span><b>' + h(o.playstyle || 'Balanced') + '</b></div>' +
        '<div class="statline"><span>Win probability</span><b>' + Math.round(p) + '%</b></div>' +
        '<div class="statline"><span>Map pool</span><b>' + s.settings.mapPool.length + ' maps</b></div>' +
        '<div class="row" style="margin-top:8px">' + (pending ? UI.btn('Play series', 'playMatch', { cls: 'primary' }) : UI.btn('Advance to match', 'toMatch', { cls: 'primary' })) + '</div>' +
        '<div class="sub" style="margin-top:8px">' + (pending ? 'The series starts immediately. The result includes a full explanation, player scoreboard and fixes.' : 'Preparation remains editable until match day.') + '</div>', '') +
      panel('MAP PREPARATION', mapRows, '') +
      panel('RISK CHECK', warnings.length ? warnings.map(function (w) { return '<div class="badbox" style="margin-bottom:6px">' + h(w) + '</div>'; }).join('') : '<div class="goodbox">No structural warning. The five is legal, fatigue is controlled and preparation is reasonable.</div>',
        UI.btn('Training', 'go', { page: 'training', cls: 'xs ghost' })) +
      '</div></div>';
  };

  /* ==================================================================
     MATCH REPORT
  ================================================================== */
  V.report = function () {
    var s = st(), series = UI.lastSeries || s.lastReport;
    if (!series) {
      return head('Match report', 'NO SERIES TO DISPLAY') + panel('NO REPORT', '<div class="sub">Play a match from Match day to generate a full report.</div>', UI.btn('Dashboard', 'go', { page: 'dashboard', cls: 'primary' }));
    }
    var o = s.orgs[series.teamA], b = s.orgs[series.teamB];
    var userIsA = series.teamA === s.clubId;
    var me = userIsA ? o : b, opp = userIsA ? b : o;
    var myScore = userIsA ? series.scoreA : series.scoreB;
    var oppScore = userIsA ? series.scoreB : series.scoreA;
    var won = series.winner === s.clubId;
    var an = I18N.localizeAnalysis(series.analysis) || { headline: 'Series complete', verdict: '', causes: [], strengths: [], metrics: {} };
    var mvp = series.mvp ? s.players[series.mvp.id] : null;

    var mapCards = (series.maps || []).map(function (m, i) {
      var mvpP = m.mvp ? s.players[m.mvp] : null;
      var ms = userIsA ? m.scoreA : m.scoreB, os = userIsA ? m.scoreB : m.scoreA;
      return '<div class="guidance" style="margin-bottom:8px"><div class="row between"><h4 style="margin:0">Map ' + (i + 1) + ' · ' + h(m.map) + '</h4>' +
        '<b style="font-family:var(--cond);font-size:17px">' + ms + '–' + os + (m.ot ? ' <span class="tiny amber">OT</span>' : '') + '</b></div>' +
        '<div class="tiny">' + h(me.short) + ' vs ' + h(opp.short) + ' · ' + m.duration + ' min · MVP ' + (mvpP ? h(mvpP.nick) : '—') + '</div></div>';
    }).join('');

    var causes = (an.causes || []).map(function (c) {
      var cls = c.severity === 'high' ? 'badbox' : c.severity === 'med' ? 'guidance' : 'guidance';
      return '<div class="' + cls + '" style="margin-bottom:7px"><div class="row between"><b style="font-family:var(--cond);font-size:13px">' + h(c.title) + '</b>' +
        tag(c.severity.toUpperCase(), c.severity === 'high' ? 'red' : c.severity === 'med' ? 'amber' : '') + '</div>' +
        '<div class="sub" style="margin:4px 0 6px">' + h(c.detail) + '</div>' +
        '<div class="row" style="gap:4px;flex-wrap:wrap">' + (c.fixes || []).map(fixBtn).join('') + '</div></div>';
    }).join('');

    var strengths = (an.strengths || []).map(function (x) {
      return '<div class="checkline">' + h(typeof x === 'string' ? x : (x.text || '')) + '</div>';
    }).join('');

    var metrics = an.metrics || {};
    var metricBox = '<div class="split-2">' +
      '<div class="statline"><span>Opening duels</span><b>' + (metrics.fkRate != null ? metrics.fkRate + '%' : '—') + '</b></div>' +
      '<div class="statline"><span>Team ACS</span><b>' + (metrics.acs || '—') + '</b></div>' +
      '<div class="statline"><span>Attack rating</span><b>' + (metrics.attack || '—') + ' <span class="dim2">vs ' + (metrics.oppAttack || '—') + '</span></b></div>' +
      '<div class="statline"><span>Defence rating</span><b>' + (metrics.defense || '—') + ' <span class="dim2">vs ' + (metrics.oppDefense || '—') + '</span></b></div>' +
      '<div class="statline"><span>Preparation</span><b>' + (metrics.prep || '—') + '</b></div>' +
      '<div class="statline"><span>Chemistry</span><b>' + (metrics.chem || '—') + '</b></div>' +
      '<div class="statline"><span>Fatigue</span><b>' + (metrics.fatigue || 0) + '%</b></div>' +
      '<div class="statline"><span>Clutches won</span><b>' + (metrics.clutch || 0) + '</b></div></div>';

    var agg = {};
    (series.maps || []).forEach(function (m) {
      for (var id in m.stats) {
        var x = m.stats[id];
        if (!agg[id]) agg[id] = { id: id, k: 0, d: 0, a: 0, fk: 0, fd: 0, acs: 0, maps: 0, clutch: 0 };
        agg[id].k += x.k; agg[id].d += x.d; agg[id].a += x.a; agg[id].fk += x.fk; agg[id].fd += x.fd;
        agg[id].acs += x.acs; agg[id].maps++; agg[id].clutch += x.clutch;
      }
    });
    var scoreRows = Object.keys(agg).map(function (id) { return agg[id]; })
      .filter(function (x) { return s.players[x.id]; })
      .sort(function (a, b2) { return (b2.acs / Math.max(1, b2.maps)) - (a.acs / Math.max(1, a.maps)); })
      .map(function (x) {
        var pl = s.players[x.id], mine = pl.org === s.clubId;
        return '<tr class="' + (mine ? 'me' : '') + '"><td>' + UI.playerLink(pl, false) + '</td><td>' + C.roleTag(pl.role) + '</td>' +
          '<td class="r">' + Math.round(x.acs / Math.max(1, x.maps)) + '</td><td class="r">' + x.k + '</td><td class="r">' + x.d + '</td>' +
          '<td class="r">' + (x.k / Math.max(1, x.d)).toFixed(2) + '</td><td class="r">' + x.a + '</td><td class="r">' + x.fk + '</td><td class="r">' + (x.fk - x.fd) + '</td></tr>';
      }).join('');

    return head('Match report', h(me.short) + ' ' + myScore + '–' + oppScore + ' ' + h(opp.short) + ' · ' + h(series.comp || ''), UI.btn('Back to dashboard', 'go', { page: 'dashboard', cls: 'ghost' }) + UI.btn('Next match', 'toMatch', { cls: 'primary' })) +
      '<div class="hero" style="margin-bottom:12px"><div class="hero-in"><div class="hero-kicker">' + h(series.comp || 'SERIES') + ' · ' + h(series.stage || '') + ' · ' + C.fmtDate(series.date) + '</div>' +
      '<div class="hero-title ' + (won ? 'green' : 'red') + '">' + (won ? 'VICTORY' : 'DEFEAT') + '</div>' +
      '<div class="hero-sub">' + h(an.headline || '') + ' ' + h(an.verdict || '') + '</div>' +
      '<div class="hero-stats"><div class="hstat"><div class="hv">' + myScore + '–' + oppScore + '</div><div class="hl">Maps</div></div>' +
      '<div class="hstat"><div class="hv">' + (mvp ? h(mvp.nick) : '—') + '</div><div class="hl">Series MVP</div></div>' +
      '<div class="hstat"><div class="hv">' + (metrics.acs || '—') + '</div><div class="hl">Team ACS</div></div>' +
      '<div class="hstat"><div class="hv">' + (metrics.fkRate != null ? metrics.fkRate + '%' : '—') + '</div><div class="hl">Opening duels</div></div></div></div>' +
      '<div class="hero-right"><div class="sub">Every result is derived from the eight rating components and the round simulation. The causes below are the levers you can change.</div>' + UI.btn('Competitions', 'go', { page: 'competitions', cls: 'sm ghost' }) + '</div></div>' +
      '<div class="grid g23">' +
      '<div class="col" style="gap:12px">' +
      panel('WHY THIS HAPPENED', causes || '<div class="goodbox">No structural weakness detected. The result followed the rating model and round variance.</div>', '') +
      panel('SCOREBOARD', scoreRows ? UI.table([{ label: 'Player' }, { label: 'Role' }, { label: 'ACS', cls: 'r' }, { label: 'K', cls: 'r' }, { label: 'D', cls: 'r' }, { label: 'K/D', cls: 'r' }, { label: 'A', cls: 'r' }, { label: 'FK', cls: 'r' }, { label: 'FD±', cls: 'r' }], scoreRows) : empty('No player statistics recorded.'), '') +
      panel('MAP BY MAP', mapCards || empty('Series forfeited or no maps played.'), '') +
      '</div>' +
      '<div class="col" style="gap:12px">' +
      panel('METRICS', metricBox, '') +
      panel('WHAT WORKED', strengths || '<div class="sub">No standout strength this series.</div>', '') +
      panel('SERIES MVP', mvp ? '<div class="row" style="gap:9px">' + C.portraitImg(mvp, me, 64, '', 'border:1px solid var(--line2)') +
        '<div><div style="font-family:var(--cond);font-size:18px">' + h(mvp.nick) + '</div>' +
        '<div class="tiny">' + h(mvp.role) + ' · OVR ' + mvp.level + '</div>' +
        '<div class="sub" style="margin-top:3px">' + series.mvp.acs + ' ACS · ' + series.mvp.k + '/' + series.mvp.d + ' K/D · ' + series.mvp.fk + ' opening kills</div></div></div>' : empty('No MVP recorded.'), '') +
      panel('NEXT ACTIONS', '<div class="checkline">Open the Training page and target the lowest metric above.</div>' +
        '<div class="checkline">Review the lineup: a role gap or 30+ fatigue cost rating points.</div>' +
        '<div class="checkline">Prepare your pick maps before the next series.</div>', UI.btn('Training', 'go', { page: 'training', cls: 'xs ghost' }) + UI.btn('Tactics', 'go', { page: 'tactics', cls: 'xs ghost' })) +
      '</div></div>';
  };

  return V;
})();
