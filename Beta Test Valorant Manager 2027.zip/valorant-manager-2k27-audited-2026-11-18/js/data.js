/* =====================================================================
   VALORANT MANAGER 2027 — REAL-WORLD DATABASE SNAPSHOT
   Data snapshot: 17 November 2026.
   Sources: VCT official announcements (2027 partner list, 2027 format,
   Open Qualifiers payout/structure), THESPIKE.GG VCT 2027 Rostermania
   Tracker (17 Nov 2026), VLR.gg news & team rankings, Liquipedia VCT 2027,
   EGamersWorld roster reports, Strafe off-season tracker.
   Every roster carries a confidence status. Fictional fillers are flagged
   SIM so a rumour is never presented as an official signing.
   ===================================================================== */
var DB = (function () {
  'use strict';
  var O = function (id, name, short, region, sub, cc, city, colors, logo, tier, rep, budget, sponsor, conf, source, notes, titles) {
    return {
      id: id, name: name, short: short, region: region, sub: sub, country: cc, city: city, colors: colors,
      logo: logo, partner: tier === 'partner', tier: tier, rep: rep, budget: budget, sponsor: sponsor,
      rosterStatus: conf, source: source, notes: notes, titles: titles || [], founded: 2019,
      status: 'active'
    };
  };

  var ORGS = [
    /* ---------------- VCT AMERICAS (8 partners) ---------------- */
    O('sentinels', 'Sentinels', 'SEN', 'Americas', 'North America', 'us', 'Los Angeles', ['#ff4655', '#111111'], 'sentinels', 'partner', 94, 4200000, 3200000, 'OFFICIAL', 'THESPIKE 16 Nov 2026; VCT 2027 partners', 'Rebuilt around johnqt after missing Champions 2026. Four new arrivals.', ['Champions 2021', 'Masters Reykjavík 2021']),
    O('100-thieves', '100 Thieves', '100T', 'Americas', 'North America', 'us', 'Los Angeles', ['#e3242b', '#0d0d0d'], '100-thieves', 'partner', 88, 3600000, 2700000, 'OFFICIAL', 'THESPIKE 13 Nov 2026; VCT 2027 partners', 'Kept the 2026 core, extended Cryocells and Asuna.', ['Masters Toronto 2025']),
    O('nrg', 'NRG', 'NRG', 'Americas', 'North America', 'us', 'Los Angeles', ['#ffffff', '#0b0b0b'], 'nrg', 'partner', 85, 2800000, 2100000, 'REPORTED', 'THESPIKE 17 Nov 2026', 'Lost keiko and brawk to Sentinels; rebuilding around mada.', ['Champions 2023']),
    O('g2-esports', 'G2 Esports', 'G2', 'Americas', 'North America', 'us', 'Berlin', ['#ffffff', '#c8102e'], 'g2-esports', 'partner', 90, 3900000, 3000000, 'REPORTED', 'THESPIKE 14 Nov 2026', 'Rumoured superteam: kiNgg, Sato and HYUNMIN join leaf and trent.', ['Masters Bangkok 2025']),
    O('loud', 'LOUD', 'LOUD', 'Americas', 'Brazil', 'br', 'São Paulo', ['#00ff88', '#0a0a0a'], 'loud', 'partner', 89, 3200000, 2400000, 'REPORTED', 'THESPIKE 17 Nov 2026', 'Champions Shanghai 2026 winners. Major rebuild after departures.', ['Champions 2022', 'Champions Shanghai 2026']),
    O('mibr', 'MIBR', 'MIBR', 'Americas', 'Brazil', 'br', 'São Paulo', ['#00c2ff', '#0b0b0b'], 'mibr', 'partner', 84, 2600000, 1900000, 'RUMORED', 'THESPIKE 14 Nov 2026', 'Less reportedly joining; entire 2026 starting roster benched.', []),
    O('leviat-n', 'LEVIATÁN', 'LEV', 'Americas', 'Latin America South', 'ar', 'Buenos Aires', ['#7b61ff', '#0a0a0a'], 'leviat-n', 'partner', 83, 2400000, 1700000, 'REPORTED', 'THESPIKE 14 Nov 2026', 'kiNgg left after five years. lukxo and erde arrive.', ['Masters Madrid 2024']),
    O('kr-esports', 'KRÜ Esports', 'KRÜ', 'Americas', 'Latin America South', 'ar', 'Buenos Aires', ['#ff2e63', '#0b0b0b'], 'kr-esports', 'partner', 82, 2100000, 1500000, 'REPORTED', 'THESPIKE 17 Nov 2026', 'Released heat, mwzera, Dantedeu5 and Saadhak. Darker arrives.', []),

    /* ---------------- VCT EMEA (8 partners) ---------------- */
    O('fnatic', 'Fnatic', 'FNC', 'EMEA', 'Europe', 'gb', 'London', ['#ff5900', '#0a0a0a'], 'fnatic', 'partner', 93, 3800000, 2900000, 'REPORTED', 'EGamersWorld 02 Nov 2026; THESPIKE 06 Nov 2026', 'Boaster and Alfajer depart after five and four years. ANGE1 reported as coach.', ['Champions 2019', 'Masters Berlin 2023']),
    O('team-vitality', 'Team Vitality', 'VIT', 'EMEA', 'Europe', 'fr', 'Paris', ['#ffd600', '#0a0a0a'], 'team-vitality', 'partner', 89, 3400000, 2600000, 'OFFICIAL', 'THESPIKE 11 Nov 2026', 'jawgemo joins PROFEK, Jamppi, Chronicle and Sayonara.', ['Masters Shanghai 2024']),
    O('team-liquid', 'Team Liquid', 'TL', 'EMEA', 'Europe', 'nl', 'Utrecht', ['#00b4ff', '#0b1622'], 'team-liquid', 'partner', 87, 3000000, 2300000, 'REPORTED', 'THESPIKE 17 Nov 2026', 'nAts exploring options; trexx left. Rebuild in progress.', ['Masters Copenhagen 2022']),
    O('karmine-corp', 'Karmine Corp', 'KC', 'EMEA', 'Europe', 'fr', 'Paris', ['#00b0f0', '#0a0a0a'], 'karmine-corp', 'partner', 88, 3100000, 2400000, 'RUMORED', 'THESPIKE 17 Nov 2026', 'The 2026 core is unchanged: dos9, LewN, Avez, SUYGETSU, N4RRATE.', ['Masters Toronto 2025']),
    O('team-heretics', 'Team Heretics', 'TH', 'EMEA', 'Europe', 'es', 'Madrid', ['#ffd600', '#0a0a0a'], 'team-heretics', 'partner', 86, 2700000, 2000000, 'REPORTED', 'EGamersWorld 02 Nov 2026', 'RieNs and benjyfishy anchor a rebuilt roster.', []),
    O('fut-esports', 'FUT Esports', 'FUT', 'EMEA', 'Türkiye', 'tr', 'Istanbul', ['#ff6a00', '#0a0a0a'], 'fut-esports', 'partner', 84, 2400000, 1750000, 'OFFICIAL', 'THESPIKE 17 Nov 2026', 'aspas confirmed. The biggest signing in Turkish VALORANT history.', []),
    O('bbl-esports', 'BBL Esports', 'BBL', 'EMEA', 'Türkiye', 'tr', 'Istanbul', ['#ffd600', '#111111'], 'bbl-esports', 'partner', 78, 1600000, 1100000, 'RUMORED', 'THESPIKE 17 Nov 2026', 'Stable Turkish core with Loita and Lar0k arriving.', []),
    O('gentle-mates', 'Gentle Mates', 'GM', 'EMEA', 'Europe', 'fr', 'Paris', ['#39ff88', '#0a0a0a'], 'gentle-mates', 'partner', 80, 2000000, 1400000, 'REPORTED', 'EGamersWorld 02 Nov 2026', 'Entire roster released in October, then rebuilt around Boaster and Alfajer.', []),

    /* ---------------- VCT PACIFIC (8 partners) ---------------- */
    O('paper-rex', 'Paper Rex', 'PRX', 'Pacific', 'Southeast Asia', 'sg', 'Singapore', ['#ff2e88', '#0a0a0a'], 'paper-rex', 'partner', 93, 3500000, 2700000, 'REPORTED', 'EGamersWorld 02 Nov 2026; THESPIKE 17 Nov 2026', 'f0rsakeN and something stay; PatMen returns from Global Esports.', ['Masters Copenhagen 2023', 'Champions 2025']),
    O('t1', 'T1', 'T1', 'Pacific', 'South Korea', 'kr', 'Seoul', ['#e2012d', '#0a0a0a'], 't1', 'partner', 94, 4600000, 3500000, 'OFFICIAL', 'THESPIKE 13 Nov 2026; VCT partners', 'TenZ and crashies join stax, BuZz and iZu. Sacy is head coach.', ['Champions 2025']),
    O('gen-g', 'Gen.G', 'GEN', 'Pacific', 'South Korea', 'kr', 'Seoul', ['#c9a227', '#0a0a0a'], 'gen-g', 'partner', 90, 3200000, 2500000, 'OFFICIAL', 'THESPIKE 13 Nov 2026', 'Completed with Ray. MaKo and Dambi arrive from DRX.', ['Masters Madrid 2024']),
    O('crazy-raccoon', 'Crazy Raccoon', 'CR', 'Pacific', 'Japan', 'jp', 'Tokyo', ['#14b8ff', '#0a0a0a'], 'crazy-raccoon', 'partner', 85, 2600000, 2000000, 'RUMORED', 'THESPIKE 17 Nov 2026', 'New Japanese core built around SugarZ3ro and Meiy.', []),
    O('zeta-division', 'ZETA DIVISION', 'ZETA', 'Pacific', 'Japan', 'jp', 'Tokyo', ['#ffffff', '#0a0a0a'], 'zeta-division', 'partner', 84, 2300000, 1700000, 'RUMORED', 'THESPIKE 17 Nov 2026', 'yatsuka and Ken arrive; SugarZ3ro departs for Crazy Raccoon.', []),
    O('rex-regum-qeon', 'Rex Regum Qeon', 'RRQ', 'Pacific', 'Indonesia', 'id', 'Jakarta', ['#ffd000', '#0a0a0a'], 'rex-regum-qeon', 'partner', 82, 1900000, 1350000, 'RUMORED', 'THESPIKE 17 Nov 2026', 'Indonesian core with Monyet and Jemkin.', []),
    O('full-sense', 'FULL SENSE', 'FS', 'Pacific', 'Thailand', 'th', 'Bangkok', ['#00e0a4', '#0a0a0a'], 'full-sense', 'partner', 80, 1700000, 1200000, 'REPORTED', 'THESPIKE 17 Nov 2026', 'Crws moves to head coach. seph1roth leads a young roster.', []),
    O('gam-esports', 'GAM Esports', 'GAM', 'Pacific', 'Vietnam', 'vn', 'Ho Chi Minh City', ['#ffd400', '#0a0a0a'], 'gam-esports', 'partner', 76, 1400000, 950000, 'RUMORED', 'THESPIKE 17 Nov 2026', 'New VCT partner. Vietnamese roster still being assembled.', []),

    /* ---------------- VCT CHINA (8 partners) ---------------- */
    O('edward-gaming', 'EDward Gaming', 'EDG', 'China', 'China', 'cn', 'Shanghai', ['#ffffff', '#0a0a0a'], 'edward-gaming', 'partner', 91, 3300000, 2500000, 'RUMORED', 'THESPIKE 17 Nov 2026', 'CHICHOO and nobody leave after five years. Rebuild around Rossy and stew.', ['Champions 2024', 'Masters Shanghai 2024']),
    O('bilibili-gaming', 'Bilibili Gaming', 'BLG', 'China', 'China', 'cn', 'Hangzhou', ['#00a1d6', '#0a0a0a'], 'bilibili-gaming', 'partner', 86, 2500000, 1900000, 'OFFICIAL', 'THESPIKE 11-13 Nov 2026', 'Smoggy and Alvinboy complete a star-studded Chinese lineup.', []),
    O('jd-gaming', 'JD Gaming', 'JDG', 'China', 'China', 'cn', 'Beijing', ['#e60012', '#0a0a0a'], 'jd-gaming', 'partner', 84, 2300000, 1700000, 'OFFICIAL', 'VLR 17 Nov 2026', 'glacier arrives from Wolves. Roster still incomplete.', []),
    O('tyloo', 'TYLOO', 'TYL', 'China', 'China', 'cn', 'Hangzhou', ['#ff3b30', '#0a0a0a'], 'tyloo', 'partner', 80, 1800000, 1300000, 'UNKNOWN', 'No roster announcement as of 17 Nov 2026', 'Rebuilding from scratch after failing to retain its 2026 core.', []),
    O('weibo-gaming', 'Weibo Gaming', 'WBG', 'China', 'China', 'cn', 'Shanghai', ['#ff8200', '#0a0a0a'], 'weibo-gaming', 'partner', 81, 1900000, 1400000, 'RUMORED', 'THESPIKE 17 Nov 2026', 'Babybay joins as the franchise piece.', []),
    O('trace-esports', 'Trace Esports', 'TRACE', 'China', 'China', 'cn', 'Shanghai', ['#00d4a0', '#0a0a0a'], 'trace-esports', 'partner', 79, 1700000, 1200000, 'RUMORED', 'THESPIKE 17 Nov 2026', 'CHICHOO and nobody reunite in Shanghai.', []),
    O('all-gamers', 'All Gamers', 'AG', 'China', 'China', 'cn', 'Shanghai', ['#ff4b2b', '#0a0a0a'], 'all-gamers', 'partner', 78, 1500000, 1050000, 'RUMORED', 'THESPIKE 17 Nov 2026', 'jinggg and spring headline the new project.', []),
    O('xi-lai-gaming', 'Xi Lai Gaming', 'XLG', 'China', 'China', 'cn', 'Shenzhen', ['#7b61ff', '#0a0a0a'], 'xi-lai-gaming', 'partner', 80, 1800000, 1300000, 'RUMORED', 'THESPIKE 17 Nov 2026', 'd4v41, Zmjjkk and Xavi8k form a frightening trio on paper.', []),

    /* ---------------- NON-PARTNERS (active) ---------------- */
    O('aurora-gaming', 'Aurora Gaming', 'AUR', 'EMEA', 'Europe', 'ru', 'Moscow', ['#00e5ff', '#0a0a0a'], 'aurora-gaming', 'challenger', 83, 1400000, 700000, 'OFFICIAL', 'THESPIKE 29 Oct / 02 Nov 2026', 'Not partnered. Built a superteam for the European Open Qualifier.', []),
    O('cloud9', 'Cloud9', 'C9', 'Americas', 'North America', 'us', 'Los Angeles', ['#4aa8ff', '#0a0a0a'], 'cloud9', 'challenger', 82, 1600000, 800000, 'OFFICIAL', 'THESPIKE 07 Nov 2026', 'Lost partnership but retained a competitive roster for NA qualifiers.', ['Champions 2023']),
    O('natus-vincere', 'Natus Vincere', 'NAVI', 'EMEA', 'Europe', 'ua', 'Kyiv', ['#ffe500', '#0a0a0a'], 'natus-vincere', 'challenger', 80, 1100000, 550000, 'OFFICIAL', 'THESPIKE 29 Oct 2026', 'Promoted NAVI Junior after releasing the main roster.', ['Masters Berlin 2023']),
    O('eternal-fire', 'Eternal Fire', 'EF', 'EMEA', 'Türkiye', 'tr', 'Istanbul', ['#ff6a00', '#0a0a0a'], 'eternal-fire', 'challenger', 76, 900000, 420000, 'OFFICIAL', 'THESPIKE 04-10 Nov 2026', 'sociablEE and s0pp join a Turkish project aimed at Kickoff.', []),
    O('kiwoom-drx', 'KIWOOM DRX', 'DRX', 'Pacific', 'South Korea', 'kr', 'Seoul', ['#00a5ff', '#0a0a0a'], 'kiwoom-drx', 'challenger', 81, 1200000, 600000, 'OFFICIAL', 'THESPIKE 22 Oct 2026', 'Lost four starters after missing partnership. Rebuilding around yong.', ['Champions 2022']),
    O('nongshim-redforce', 'Nongshim RedForce', 'NS', 'Pacific', 'South Korea', 'kr', 'Seoul', ['#e4002b', '#0a0a0a'], 'nongshim-redforce', 'challenger', 78, 900000, 400000, 'OFFICIAL', 'THESPIKE 04 Nov 2026', 'UdoTan joins a settled Korean core.', []),
    O('boom-esports', 'BOOM Esports', 'BOOM', 'Pacific', 'Indonesia', 'id', 'Jakarta', ['#ff2d2d', '#0a0a0a'], 'boom-esports', 'challenger', 75, 650000, 280000, 'REPORTED', 'VLR rankings Nov 2026', 'Indonesian challenger mainstay. Targeting the SEA qualifier.', []),
    O('team-secret', 'Team Secret', 'TS', 'Pacific', 'Southeast Asia', 'ph', 'Manila', ['#00e0ff', '#0a0a0a'], 'team-secret', 'challenger', 74, 600000, 250000, 'UNKNOWN', 'No 2027 announcement', 'Philippine organisation evaluating the new open circuit.', []),
    O('shopify-rebellion-black', 'Shopify Rebellion Black', 'SRB', 'Americas', 'North America', 'us', 'Toronto', ['#7ed957', '#0a0a0a'], 'shopify-rebellion-black', 'challenger', 77, 950000, 450000, 'OFFICIAL', 'THESPIKE 07 Nov 2026', 'Former M80 core with Zander and Smoke. A serious NA qualifier threat.', []),
    O('m80', 'M80', 'M80', 'Americas', 'North America', 'us', 'Los Angeles', ['#f2b23e', '#0a0a0a'], 'm80', 'challenger', 76, 700000, 300000, 'REPORTED', 'THESPIKE 07 Nov 2026 (core to Shopify)', 'Lost its core to Shopify Rebellion. Rebuilding.', []),
    O('flyquest', 'FlyQuest', 'FLY', 'Americas', 'North America', 'us', 'Los Angeles', ['#00b140', '#0a0a0a'], 'flyquest', 'challenger', 72, 500000, 200000, 'UNKNOWN', 'No confirmed 2027 roster', 'Evaluating a return through the NA Open Qualifier.', []),
    O('lyon', 'LYON', 'LYON', 'Americas', 'Brazil', 'br', 'São Paulo', ['#ffd400', '#0a0a0a'], 'lyon', 'challenger', 73, 550000, 220000, 'UNKNOWN', 'No confirmed 2027 roster', 'Brazilian organisation entering the open circuit.', []),
    O('envy', 'ENVY', 'ENVY', 'Americas', 'North America', 'us', 'Dallas', ['#00a3e0', '#0a0a0a'], 'envy', 'challenger', 74, 600000, 260000, 'REPORTED', 'VLR rankings Nov 2026', 'Rebuilding a North American roster.', []),
    O('furia', 'FURIA', 'FURIA', 'Americas', 'Brazil', 'br', 'São Paulo', ['#111111', '#ffffff'], 'furia', 'inactive', 78, 0, 0, 'OFFICIAL', 'THESPIKE 02 Nov 2026', 'Ceased competitive VALORANT operations after missing the 2027 partnership.', []),
    O('global-esports', 'Global Esports', 'GE', 'Pacific', 'South Asia', 'in', 'Mumbai', ['#00d1b2', '#0a0a0a'], 'global-esports', 'inactive', 73, 0, 0, 'OFFICIAL', 'THESPIKE 20 Oct 2026', 'Exited esports entirely. Its players are free agents.', []),
    O('giantx', 'GIANTX', 'GX', 'EMEA', 'Europe', 'es', 'Madrid', ['#a855f7', '#0a0a0a'], 'giantx', 'challenger', 76, 750000, 320000, 'OFFICIAL', 'THESPIKE 04 Nov 2026', 'Released five players. Rebuilding for the European qualifier.', []),
    O('movistar-koi', 'Movistar KOI', 'KOI', 'EMEA', 'Europe', 'es', 'Madrid', ['#ffcf00', '#0a0a0a'], 'movistar-koi', 'challenger', 78, 1000000, 480000, 'UNKNOWN', 'No confirmed 2027 roster', 'Spanish organisation weighing a Challengers return.', []),
    O('apeks', 'Apeks', 'APK', 'EMEA', 'Europe', 'no', 'Oslo', ['#00e0b4', '#0a0a0a'], 'apeks', 'challenger', 73, 520000, 200000, 'UNKNOWN', 'No confirmed 2027 roster', 'Nordic organisation active in the European open circuit.', []),
    O('s8ul', 'S8UL', 'S8UL', 'Pacific', 'South Asia', 'in', 'Mumbai', ['#ffcc00', '#0a0a0a'], 's8ul', 'challenger', 69, 320000, 130000, 'UNKNOWN', 'No confirmed 2027 roster', 'Indian creator-led organisation entering Open Qualifiers.', []),
    O('funplus-phoenix', 'FunPlus Phoenix', 'FPX', 'China', 'China', 'cn', 'Shanghai', ['#ff4d00', '#0a0a0a'], 'funplus-phoenix', 'challenger', 77, 800000, 350000, 'REPORTED', 'THESPIKE 10 Nov 2026', 'Chinese challenger project after losing its partner slot.', ['Masters Copenhagen 2022']),
    O('wolves-esports', 'Wolves Esports', 'WOL', 'China', 'China', 'cn', 'Shanghai', ['#00b4ff', '#0a0a0a'], 'wolves-esports', 'challenger', 76, 700000, 300000, 'REPORTED', 'THESPIKE 17 Nov 2026 (glacier to JDG)', 'Lost glacier to JD Gaming. Rebuilding.', []),
    O('nova-esports', 'Nova Esports', 'NOVA', 'China', 'China', 'cn', 'Hong Kong', ['#00e0ff', '#0a0a0a'], 'nova-esports', 'challenger', 75, 650000, 270000, 'REPORTED', 'THESPIKE 17 Nov 2026', 'Hong Kong based roster aiming at the China Open Qualifier.', []),
    O('dragon-ranger-gaming', 'Dragon Ranger Gaming', 'DRG', 'China', 'China', 'cn', 'Shanghai', ['#ff2d55', '#0a0a0a'], 'dragon-ranger-gaming', 'challenger', 74, 560000, 230000, 'REPORTED', 'THESPIKE 27 Oct 2026', 'vo0kashu exploring options; the rest of the roster remains.', []),
    O('any-questions-gaming', 'Any Questions Gaming', 'AQ', 'China', 'China', 'cn', 'Shanghai', ['#f2b23e', '#0a0a0a'], 'any-questions-gaming', 'challenger', 70, 380000, 150000, 'REPORTED', 'THESPIKE 03 Nov 2026', 'ED101 joins as head coach. A rising Chinese challenger team.', []),
    O('titan-esports-club', 'Titan Esports Club', 'TEC', 'China', 'China', 'cn', 'Shanghai', ['#e01e37', '#0a0a0a'], 'titan-esports-club', 'challenger', 72, 470000, 190000, 'REPORTED', 'THESPIKE 11 Nov 2026', 'Anaks joins after leaving Bilibili Gaming.', []),
    O('varrel', 'VARREL', 'VARREL', 'Pacific', 'Japan', 'jp', 'Tokyo', ['#00b0f0', '#0a0a0a'], 'varrel', 'challenger', 68, 280000, 110000, 'OFFICIAL', 'THESPIKE 04 Nov 2026', 'Entire lineup released. Rebuilding for the Japanese qualifier.', []),
    O('detonation-focusme', 'DetonatioN FocusMe', 'DFM', 'Pacific', 'Japan', 'jp', 'Tokyo', ['#ff3b30', '#0a0a0a'], 'detonation-focusme', 'challenger', 71, 400000, 160000, 'OFFICIAL', 'THESPIKE 04 Nov 2026', 'Reset around captain SSeeS.', []),
    O('dplus-esports', 'Dplus Esports', 'DK', 'Pacific', 'South Korea', 'kr', 'Seoul', ['#00a5ff', '#0a0a0a'], 'dplus-esports', 'challenger', 69, 300000, 120000, 'UNKNOWN', 'VLR rankings Nov 2026', 'Korean challenger team.', []),
    O('oasis-gaming', 'Oasis Gaming', 'OAS', 'Pacific', 'Southeast Asia', 'ph', 'Manila', ['#00d084', '#0a0a0a'], 'oasis-gaming', 'challenger', 71, 380000, 150000, 'REPORTED', 'VLR rankings Nov 2026', 'Philippine contender for the SEA qualifier.', []),
    O('sharper-esports', 'Sharper Esports', 'SHRP', 'Pacific', 'Thailand', 'th', 'Bangkok', ['#ff9f1c', '#0a0a0a'], 'sharper-esports', 'challenger', 72, 420000, 170000, 'REPORTED', 'VLR rankings Nov 2026', 'Rising Thai roster.', []),
    O('fancy-united', 'Fancy United Esports', 'FUE', 'Pacific', 'Vietnam', 'vn', 'Hanoi', ['#ff5e5b', '#0a0a0a'], 'fancy-united-esports', 'challenger', 71, 360000, 140000, 'REPORTED', 'VLR rankings Nov 2026', 'Vietnamese qualifier specialist.', []),
    O('jade-lions', 'Jade Lions', 'JL', 'Pacific', 'Southeast Asia', 'ph', 'Manila', ['#00c9a7', '#0a0a0a'], 'jade-lions', 'challenger', 68, 260000, 100000, 'REPORTED', 'VLR rankings Nov 2026', 'Young Philippine roster.', []),
    O('xipto-esports', 'Xipto Esports', 'XPT', 'Pacific', 'Thailand', 'th', 'Bangkok', ['#00b4d8', '#0a0a0a'], 'xipto-esports', 'challenger', 67, 240000, 95000, 'REPORTED', 'VLR rankings Nov 2026', 'Thai challenger team.', []),
    O('bar-a-esports', 'Barça eSports', 'BARÇA', 'EMEA', 'Europe', 'es', 'Barcelona', ['#a50044', '#004d98'], 'bar-a-esports', 'challenger', 70, 350000, 150000, 'REPORTED', 'THESPIKE 04 Nov 2026', 'Pa1ze and MONSTEERR headline a new Spanish project.', []),
    O('enterprise-esports', 'Enterprise Esports', 'ENT', 'EMEA', 'Europe', 'cz', 'Prague', ['#ffd400', '#0a0a0a'], 'enterprise-esports', 'challenger', 73, 380000, 160000, 'REPORTED', 'VLR Europe rankings Nov 2026', 'Czech organisation ranked top of the European ladder.', []),
    O('fire-flux-esports', 'Fire Flux Esports', 'FF', 'EMEA', 'Türkiye', 'tr', 'Istanbul', ['#ff5c00', '#0a0a0a'], 'fire-flux-esports', 'challenger', 70, 290000, 120000, 'REPORTED', 'VLR Europe rankings Nov 2026', 'Turkish qualifier regular.', []),
    O('mandatory', 'Mandatory', 'MND', 'EMEA', 'Europe', 'gb', 'London', ['#ff4655', '#0a0a0a'], 'mandatory', 'challenger', 69, 250000, 100000, 'OFFICIAL', 'THESPIKE 01 Nov 2026', 'Signed Kicks, Veqaj, starxo, MiniBoo and runneR.', []),
    O('eintracht-frankfurt', 'Eintracht Frankfurt', 'SGE', 'EMEA', 'Europe', 'de', 'Frankfurt', ['#e1000f', '#0a0a0a'], 'eintracht-frankfurt', 'challenger', 71, 300000, 130000, 'UNKNOWN', 'VLR Europe rankings Nov 2026', 'Football club esports division.', [])
  ];

  /* ---------------- REAL PLAYER SPECS ----------------
     p(nick, realName, country, role, orgId, grade 0-10, age, opts)
     grade is a reputation-informed ability anchor, not a real-world rating.
  ------------------------------------------------------ */
  function p(nick, name, cc, role, org, grade, age, opts) {
    opts = opts || {};
    var photos = window.PLAYER_PHOTOS || {};
    var fixes = window.PLAYER_NAME_FIXES_BY_NICK || {};
    var nk = String(nick || '').toLowerCase();
    var ok = String(org || '').toLowerCase();
    var photo = (photos.byPlayer && photos.byPlayer[nk + '|' + ok]) || (photos.byNick && photos.byNick[nk]) || null;
    return {
      nick: nick, name: fixes[nk] || name || '', cc: cc, role: role, org: org, grade: grade, age: age,
      agents: opts.agents || null, secondary: opts.secondary || null, conf: opts.conf || null,
      captain: !!opts.captain, igl: !!opts.igl, photo: photo,
      note: opts.note || '', natOverride: opts.nat || null
    };
  }

  var PLAYERS = [
    /* ===== SENTINELS ===== */
    p('johnqt', 'Mohamed Amine Ouarid', 'ma', 'Controller', 'sentinels', 8.6, 24, { igl: true, captain: true, agents: ['Omen', 'Astra'], conf: 'OFFICIAL' }),
    p('brawk', 'Brock Somerhalder', 'us', 'Initiator', 'sentinels', 8.1, 22, { agents: ['Sova', 'Fade'], conf: 'OFFICIAL' }),
    p('OXY', 'Francis Hoang', 'us', 'Duelist', 'sentinels', 8.8, 22, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL' }),
    p('canezerra', 'Caden Canez', 'us', 'Sentinel', 'sentinels', 7.9, 21, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' }),
    p('keiko', 'Georgio Sanassy', 'gb', 'Initiator', 'sentinels', 8.0, 23, { agents: ['KAY/O', 'Skye'], conf: 'OFFICIAL' }),
    p('Zellsis', 'Jordan Montemurro', 'us', 'Sentinel', 'sentinels', 7.2, 27, { agents: ['Killjoy', 'Sage'], conf: 'OFFICIAL', note: 'Emergency substitute and content creator.' }),

    /* ===== 100 THIEVES ===== */
    p('Timotino', 'Timothy Ta', 'us', 'Controller', '100-thieves', 7.8, 22, { igl: true, agents: ['Omen', 'Astra'], conf: 'RUMORED' }),
    p('vora', 'Kyle Vora', 'us', 'Initiator', '100-thieves', 7.6, 21, { agents: ['Sova', 'Gekko'], conf: 'RUMORED' }),
    p('Cryocells', 'Nolan Vongkhamchanh', 'us', 'Duelist', '100-thieves', 8.6, 22, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL' }),
    p('bang', 'Sean Bezerra', 'us', 'Sentinel', '100-thieves', 7.7, 24, { agents: ['Killjoy', 'Cypher'], conf: 'RUMORED' }),
    p('Asuna', 'Peter Mazuryk', 'us', 'Duelist', '100-thieves', 8.4, 23, { agents: ['Raze', 'Neon'], conf: 'OFFICIAL' }),

    /* ===== NRG ===== */
    p('mada', 'Adam Pampuch', 'us', 'Duelist', 'nrg', 8.5, 22, { agents: ['Jett', 'Iso'], conf: 'REPORTED' }),
    p('skuba', 'Logan Jenkins', 'us', 'Controller', 'nrg', 7.4, 24, { agents: ['Omen', 'Viper'], conf: 'REPORTED' }),
    p('Ethan', 'Ethan Arnold', 'us', 'Initiator', 'nrg', 7.9, 25, { agents: ['Sova', 'Fade'], conf: 'REPORTED' }),
    p('eeiu', 'Daniel Vucenovic', 'us', 'Controller', 'nrg', 7.6, 25, { agents: ['Viper', 'Harbor'], conf: 'REPORTED' }),
    p('s0m', 'Sam Oh', 'us', 'Sentinel', 'nrg', 7.3, 24, { agents: ['Killjoy', 'Cypher'], conf: 'LIKELY' }),

    /* ===== G2 ===== */
    p('leaf', 'Nathan Orf', 'us', 'Sentinel', 'g2-esports', 8.3, 21, { agents: ['Killjoy', 'Deadlock'], conf: 'REPORTED' }),
    p('trent', 'Trent Cairns', 'us', 'Initiator', 'g2-esports', 8.4, 24, { igl: true, agents: ['Skye', 'KAY/O'], conf: 'REPORTED' }),
    p('Sato', 'Sato Naoki', 'jp', 'Controller', 'g2-esports', 8.0, 22, { agents: ['Omen', 'Astra'], conf: 'RUMORED' }),
    p('HYUNMIN', 'Kim Hyun-min', 'kr', 'Duelist', 'g2-esports', 8.9, 22, { agents: ['Jett', 'Raze'], conf: 'RUMORED' }),
    p('kiNgg', 'Kim Seung-hyun', 'kr', 'Controller', 'g2-esports', 8.8, 24, { igl: true, agents: ['Omen', 'Viper'], conf: 'RUMORED' }),

    /* ===== LOUD ===== */
    p('DaviH', 'David Harada', 'br', 'Duelist', 'loud', 7.9, 21, { agents: ['Jett', 'Raze'], conf: 'RUMORED' }),
    p('basic', 'Luis Henrique Tessaro', 'br', 'Controller', 'loud', 7.6, 24, { agents: ['Omen', 'Astra'], conf: 'RUMORED' }),
    p('cortezia', 'Gabriel Cortez', 'br', 'Sentinel', 'loud', 7.7, 23, { agents: ['Killjoy', 'Cypher'], conf: 'RUMORED' }),

    /* ===== MIBR ===== */
    p('Less', 'Felipe de Loyola', 'br', 'Controller', 'mibr', 9.2, 22, { agents: ['Viper', 'Omen'], conf: 'RUMORED' }),

    /* ===== LEVIATÁN ===== */
    p('spikeziN', 'Thiago Martins', 'br', 'Duelist', 'leviat-n', 8.1, 23, { agents: ['Jett', 'Raze'], conf: 'RUMORED' }),
    p('Neon', 'Matheus dos Santos', 'br', 'Initiator', 'leviat-n', 7.5, 22, { agents: ['Sova', 'Fade'], conf: 'RUMORED' }),
    p('blowz', 'Gabriel Bloise', 'br', 'Controller', 'leviat-n', 7.6, 24, { agents: ['Omen', 'Astra'], conf: 'RUMORED' }),
    p('lukxo', 'Lucas Soares', 'br', 'Initiator', 'leviat-n', 7.9, 21, { agents: ['Skye', 'Gekko'], conf: 'REPORTED' }),
    p('erde', 'Bruno Ferreira', 'br', 'Sentinel', 'leviat-n', 7.4, 22, { agents: ['Killjoy', 'Cypher'], conf: 'REPORTED' }),

    /* ===== KRÜ ===== */
    p('Darker', 'Nicolás Segovia', 'ar', 'Duelist', 'kr-esports', 8.0, 22, { agents: ['Jett', 'Raze'], conf: 'RUMORED' }),

    /* ===== FNATIC ===== */
    p('kaajak', 'Maksim Kujundžić', 'rs', 'Duelist', 'fnatic', 8.6, 21, { agents: ['Jett', 'Raze'], conf: 'REPORTED' }),
    p('Cloud', 'Kirill Nekrasov', 'ru', 'Initiator', 'fnatic', 7.8, 22, { agents: ['Sova', 'Fade'], conf: 'RUMORED' }),
    p('valyn', 'Brendan Kelly', 'ca', 'Controller', 'fnatic', 8.3, 26, { igl: true, agents: ['Omen', 'Astra'], conf: 'REPORTED' }),
    p('marteen', 'Martin Pátek', 'cz', 'Duelist', 'fnatic', 8.2, 21, { agents: ['Raze', 'Iso'], conf: 'REPORTED' }),
    p('Minny', 'Minami Takahashi', 'jp', 'Sentinel', 'fnatic', 7.8, 22, { agents: ['Killjoy', 'Cypher'], conf: 'REPORTED' }),

    /* ===== VITALITY ===== */
    p('jawgemo', 'Alexander Mor', 'us', 'Duelist', 'team-vitality', 9.0, 24, { agents: ['Raze', 'Jett'], conf: 'OFFICIAL' }),
    p('PROFEK', 'Dawid Świątek', 'pl', 'Controller', 'team-vitality', 8.3, 25, { agents: ['Omen', 'Astra'], conf: 'OFFICIAL' }),
    p('Jamppi', 'Elias Olkkonen', 'fi', 'Sentinel', 'team-vitality', 8.5, 24, { agents: ['Chamber', 'Killjoy'], conf: 'OFFICIAL' }),
    p('Chronicle', 'Timofey Khromov', 'ru', 'Sentinel', 'team-vitality', 8.4, 26, { agents: ['Killjoy', 'Viper'], conf: 'OFFICIAL' }),
    p('Sayonara', 'Ilya Bolshakov', 'ru', 'Initiator', 'team-vitality', 8.1, 21, { agents: ['Sova', 'KAY/O'], conf: 'OFFICIAL' }),

    /* ===== KARMINE CORP ===== */
    p('dos9', 'Nihat Aktaş', 'tr', 'Duelist', 'karmine-corp', 8.2, 22, { agents: ['Jett', 'Raze'], conf: 'RUMORED' }),
    p('LewN', 'Nicolas Banti', 'fr', 'Sentinel', 'karmine-corp', 7.9, 24, { agents: ['Killjoy', 'Cypher'], conf: 'RUMORED' }),
    p('SUYGETSU', 'Dmitrii Ilushin', 'ru', 'Controller', 'karmine-corp', 8.6, 24, { agents: ['Viper', 'Omen'], conf: 'RUMORED' }),
    p('avez', 'Alexis Nguyễn', 'fr', 'Initiator', 'karmine-corp', 7.7, 22, { agents: ['Skye', 'Fade'], conf: 'RUMORED' }),
    p('N4RRATE', 'Nathan Ngo', 'fr', 'Duelist', 'karmine-corp', 7.8, 21, { agents: ['Raze', 'Neon'], conf: 'RUMORED' }),

    /* ===== HERETICS ===== */
    p('RieNs', 'Rienaud Baco', 'fr', 'Initiator', 'team-heretics', 8.4, 22, { igl: true, agents: ['Sova', 'Fade'], conf: 'REPORTED' }),
    p('benjyfishy', 'Benjamin Fish', 'gb', 'Sentinel', 'team-heretics', 8.0, 22, { agents: ['Killjoy', 'Chamber'], conf: 'REPORTED' }),
    p('hiro', 'Hiroshi Nakamura', 'jp', 'Duelist', 'team-heretics', 7.7, 21, { agents: ['Jett', 'Raze'], conf: 'REPORTED' }),
    p('chloric', 'Vladimir Ivanov', 'ru', 'Controller', 'team-heretics', 7.6, 23, { agents: ['Omen', 'Astra'], conf: 'REPORTED' }),
    p('Jamelinho213', 'Jamel Bensalem', 'fr', 'Duelist', 'team-heretics', 7.4, 20, { agents: ['Raze', 'Iso'], conf: 'REPORTED' }),

    /* ===== FUT ===== */
    p('aspas', 'Erick Santos', 'br', 'Duelist', 'fut-esports', 9.6, 23, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL', note: 'Reported seven-figure deal after leaving MIBR.' }),
    p('yetujey', 'Yusuf Yeter', 'tr', 'Initiator', 'fut-esports', 7.7, 23, { agents: ['Sova', 'Fade'], conf: 'REPORTED' }),
    p('Wo0t', 'Mert Alkan', 'tr', 'Initiator', 'fut-esports', 8.2, 21, { agents: ['KAY/O', 'Gekko'], conf: 'OFFICIAL' }),
    p('KROSTALY', 'Kaan Krostaly', 'tr', 'Controller', 'fut-esports', 7.7, 23, { agents: ['Omen', 'Astra'], conf: 'REPORTED' }),
    p('xeus', 'Yusuf Doğan Gözgen', 'tr', 'Sentinel', 'fut-esports', 7.5, 22, { agents: ['Killjoy', 'Cypher'], conf: 'LIKELY' }),

    /* ===== LIQUID ===== */
    p('kamo', 'Kamil Bednarek', 'pl', 'Duelist', 'team-liquid', 8.2, 24, { agents: ['Jett', 'Raze'], conf: 'REPORTED' }),
    p('GSR', 'Gustavo Sousa', 'br', 'Initiator', 'team-liquid', 7.5, 21, { agents: ['Sova', 'Fade'], conf: 'RUMORED' }),
    p('Kicks', 'Kimmie Laasner', 'ee', 'Sentinel', 'mandatory', 7.3, 25, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' }),
    p('Veqaj', 'Sylvain Pattyn', 'be', 'Initiator', 'mandatory', 7.2, 23, { agents: ['Sova', 'Fade'], conf: 'OFFICIAL' }),
    p('starxo', 'Patryk Kopczyński', 'pl', 'Controller', 'mandatory', 7.1, 24, { agents: ['Omen', 'Astra'], conf: 'OFFICIAL' }),
    p('MiniBoo', 'Dominykas Lukaševičius', 'lt', 'Duelist', 'mandatory', 7.0, 21, { agents: ['Raze', 'Jett'], conf: 'OFFICIAL' }),
    p('runneR', 'Emil Trajkovski', 'se', 'Sentinel', 'mandatory', 6.9, 21, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' }),

    /* ===== BBL ===== */
    p('ComeBack', 'Berk Can', 'tr', 'Controller', 'bbl-esports', 7.4, 24, { agents: ['Omen', 'Astra'], conf: 'RUMORED' }),
    p('VenTT', 'Emirhan Vural', 'tr', 'Duelist', 'bbl-esports', 7.3, 22, { agents: ['Jett', 'Raze'], conf: 'RUMORED' }),
    p('oroni', 'Okan Arslan', 'tr', 'Sentinel', 'bbl-esports', 7.2, 23, { agents: ['Killjoy', 'Cypher'], conf: 'RUMORED' }),
    p('Loita', 'Ali Osman', 'tr', 'Initiator', 'bbl-esports', 7.1, 21, { agents: ['Skye', 'Fade'], conf: 'RUMORED' }),
    p('Lar0k', 'Larok Kaya', 'tr', 'Duelist', 'bbl-esports', 7.0, 20, { agents: ['Raze', 'Neon'], conf: 'RUMORED' }),

    /* ===== GENTLE MATES ===== */
    p('Alfajer', 'Emir Beder', 'tr', 'Duelist', 'gentle-mates', 9.1, 22, { agents: ['Jett', 'Chamber'], conf: 'REPORTED' }),
    p('Boaster', 'Jake Howlett', 'gb', 'Controller', 'gentle-mates', 8.5, 30, { igl: true, captain: true, agents: ['Omen', 'Astra'], conf: 'REPORTED' }),
    p('Ruxic', 'Rui Silva', 'pt', 'Initiator', 'gentle-mates', 7.5, 22, { agents: ['Skye', 'Sova'], conf: 'REPORTED' }),
    p('Magnum', 'Magnus Larsen', 'dk', 'Sentinel', 'gentle-mates', 7.4, 23, { agents: ['Killjoy', 'Cypher'], conf: 'REPORTED' }),
    p('kozzy', 'Kozma Petrov', 'ru', 'Initiator', 'gentle-mates', 7.6, 21, { agents: ['KAY/O', 'Fade'], conf: 'REPORTED' }),

    /* ===== PAPER REX ===== */
    p('f0rsakeN', 'Jason Susanto', 'id', 'Controller', 'paper-rex', 9.4, 23, { agents: ['Astra', 'Omen'], conf: 'REPORTED', note: 'Flex wizard. Set the global standard for controller play.' }),
    p('something', 'Ilya Petrov', 'ru', 'Duelist', 'paper-rex', 9.1, 22, { agents: ['Jett', 'Raze'], conf: 'REPORTED' }),
    p('invy', 'Adrian Reyes', 'ph', 'Initiator', 'paper-rex', 8.2, 22, { agents: ['Sova', 'Fade'], conf: 'REPORTED' }),
    p('PatMen', 'Patrick Mendoza', 'ph', 'Sentinel', 'paper-rex', 8.0, 23, { agents: ['Killjoy', 'Cypher'], conf: 'REPORTED' }),

    /* ===== T1 ===== */
    p('stax', 'Kim Gu-taek', 'kr', 'Initiator', 't1', 8.5, 26, { igl: true, captain: true, agents: ['Sova', 'Fade'], conf: 'OFFICIAL' }),
    p('BuZz', 'Yu Byung-chul', 'kr', 'Duelist', 't1', 8.8, 24, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL' }),
    p('iZu', 'Kim Jun-hyuk', 'kr', 'Sentinel', 't1', 8.2, 22, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' }),
    p('TenZ', 'Tyson Ngo', 'ca', 'Duelist', 't1', 9.3, 25, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL' }),
    p('crashies', 'Austin Roberts', 'us', 'Initiator', 't1', 8.1, 24, { agents: ['KAY/O', 'Skye'], conf: 'OFFICIAL' }),

    /* ===== GEN.G ===== */
    p('t3xture', 'Kim Na-ra', 'kr', 'Duelist', 'gen-g', 9.1, 22, { agents: ['Jett', 'Raze'], conf: 'REPORTED' }),
    p('Karon', 'Kim Seung-won', 'kr', 'Initiator', 'gen-g', 9.0, 23, { agents: ['Sova', 'Fade'], conf: 'REPORTED' }),
    p('MaKo', 'Kim Myeong-kwan', 'kr', 'Controller', 'gen-g', 8.0, 24, { agents: ['Omen', 'Astra'], conf: 'OFFICIAL' }),
    p('Dambi', 'Park Dambi', 'kr', 'Sentinel', 'gen-g', 7.6, 21, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' }),
    p('Ray', 'Ray Kim', 'kr', 'Duelist', 'gen-g', 7.8, 21, { agents: ['Neon', 'Iso'], conf: 'OFFICIAL' }),
    p('Raxcal', 'Raxcal Kim', 'kr', 'Sentinel', 'gen-g', 7.4, 20, { agents: ['Cypher', 'Deadlock'], conf: 'REPORTED' }),
    p('Xiesta', 'Lee Xiesta', 'kr', 'Controller', 'gen-g', 7.4, 21, { agents: ['Viper', 'Harbor'], conf: 'REPORTED' }),

    /* ===== ZETA ===== */
    p('yatsuka', 'Kazuya Ikeda', 'jp', 'Duelist', 'zeta-division', 7.8, 23, { agents: ['Jett', 'Raze'], conf: 'REPORTED' }),
    p('Ken', 'Kenji Sato', 'jp', 'Controller', 'zeta-division', 7.5, 24, { agents: ['Omen', 'Astra'], conf: 'RUMORED' }),
    p('eKo', 'Yeom Wang-ryong', 'kr', 'Initiator', 'zeta-division', 7.6, 25, { agents: ['Sova', 'Fade'], conf: 'RUMORED' }),
    p('Absol', 'Kazuki Fujinoki', 'jp', 'Sentinel', 'zeta-division', 7.3, 22, { agents: ['Killjoy', 'Cypher'], conf: 'RUMORED' }),
    p('SyouTa', 'Shota Aoki', 'jp', 'Initiator', 'zeta-division', 7.2, 22, { agents: ['Breach', 'Skye'], conf: 'RUMORED' }),

    /* ===== CRAZY RACCOON ===== */
    p('akame', 'Akame Sato', 'jp', 'Duelist', 'crazy-raccoon', 8.0, 21, { agents: ['Jett', 'Raze'], conf: 'RUMORED' }),
    p('Meiy', 'Mei Yoshida', 'jp', 'Initiator', 'crazy-raccoon', 7.9, 22, { agents: ['Sova', 'Fade'], conf: 'RUMORED' }),
    p('Aace', 'Aace Tanaka', 'jp', 'Controller', 'crazy-raccoon', 7.4, 23, { agents: ['Omen', 'Astra'], conf: 'RUMORED' }),
    p('SugarZ3ro', 'Shota Watanabe', 'jp', 'Sentinel', 'crazy-raccoon', 7.6, 24, { agents: ['Killjoy', 'Cypher'], conf: 'RUMORED' }),
    p('CLZ', 'CLZ Yamamoto', 'jp', 'Duelist', 'crazy-raccoon', 7.3, 20, { agents: ['Raze', 'Neon'], conf: 'RUMORED' }),

    /* ===== RRQ ===== */
    p('Monyet', 'Monyet Saputra', 'id', 'Duelist', 'rex-regum-qeon', 8.0, 22, { agents: ['Jett', 'Raze'], conf: 'RUMORED' }),
    p('xffero', 'Fero Pratama', 'id', 'Initiator', 'rex-regum-qeon', 7.5, 23, { agents: ['Sova', 'Fade'], conf: 'RUMORED' }),
    p('Jemkin', 'Jemkin Wijaya', 'id', 'Controller', 'rex-regum-qeon', 7.6, 22, { agents: ['Omen', 'Astra'], conf: 'RUMORED' }),
    p('Kushy', 'Kushy Santoso', 'id', 'Sentinel', 'rex-regum-qeon', 7.3, 21, { agents: ['Killjoy', 'Cypher'], conf: 'RUMORED' }),
    p('crazyguy', 'Crazyguy Halim', 'id', 'Duelist', 'rex-regum-qeon', 7.5, 20, { agents: ['Raze', 'Iso'], conf: 'RUMORED' }),

    /* ===== FULL SENSE ===== */
    p('seph1roth', 'Seph1roth Chai', 'th', 'Controller', 'full-sense', 7.6, 23, { agents: ['Omen', 'Astra'], conf: 'REPORTED' }),
    p('Leviathan', 'Leviathan Pham', 'th', 'Duelist', 'full-sense', 7.7, 21, { agents: ['Jett', 'Raze'], conf: 'REPORTED' }),
    p('Kr1stal', 'Kr1stal Nguyen', 'th', 'Initiator', 'full-sense', 7.4, 22, { agents: ['Sova', 'Fade'], conf: 'REPORTED' }),

    /* ===== GAM ===== */
    p('CrazyGuy', 'Nguyen CrazyGuy', 'vn', 'Duelist', 'gam-esports', 7.8, 21, { agents: ['Jett', 'Raze'], conf: 'RUMORED' }),

    /* ===== EDWARD GAMING ===== */
    p('Rossy', 'Rossy Chen', 'cn', 'Duelist', 'edward-gaming', 7.7, 23, { agents: ['Jett', 'Raze'], conf: 'RUMORED' }),
    p('stew', 'Stew Zhang', 'cn', 'Controller', 'edward-gaming', 7.4, 22, { agents: ['Omen', 'Astra'], conf: 'RUMORED' }),

    /* ===== BILIBILI ===== */
    p('Smoggy', 'Zhang Zhao', 'cn', 'Controller', 'bilibili-gaming', 8.3, 24, { agents: ['Omen', 'Viper'], conf: 'OFFICIAL' }),
    p('Knight', 'Knight Li', 'cn', 'Sentinel', 'bilibili-gaming', 8.4, 23, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' }),
    p('nephh', 'Nephh Wang', 'cn', 'Initiator', 'bilibili-gaming', 7.9, 22, { agents: ['Sova', 'Fade'], conf: 'OFFICIAL' }),
    p('whzy', 'Whzy Xu', 'cn', 'Duelist', 'bilibili-gaming', 8.5, 21, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL' }),
    p('Alvinboy', 'Alvin Hong', 'cn', 'Duelist', 'bilibili-gaming', 8.0, 20, { agents: ['Raze', 'Neon'], conf: 'OFFICIAL' }),

    /* ===== JD GAMING ===== */
    p('glacier', 'Glacier Ma', 'cn', 'Duelist', 'jd-gaming', 7.9, 22, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL' }),

    /* ===== TRACE ===== */
    p('CHICHOO', 'Huang Chichoo', 'cn', 'Sentinel', 'trace-esports', 9.0, 25, { agents: ['Killjoy', 'Cypher'], conf: 'RUMORED' }),
    p('nobody', 'Nobody Wang', 'cn', 'Initiator', 'trace-esports', 8.2, 24, { agents: ['Sova', 'Fade'], conf: 'RUMORED' }),

    /* ===== WEIBO ===== */
    p('Babybay', 'Andrej Francisty', 'us', 'Duelist', 'weibo-gaming', 8.0, 27, { agents: ['Jett', 'Raze'], conf: 'RUMORED' }),

    /* ===== XI LAI ===== */
    p('d4v41', 'Ahmad Khalish Rusyaidee', 'my', 'Initiator', 'xi-lai-gaming', 8.8, 27, { agents: ['Sova', 'KAY/O'], conf: 'RUMORED', note: 'Left Paper Rex after six seasons.' }),
    p('happywei', 'Happywei Lin', 'cn', 'Duelist', 'xi-lai-gaming', 8.1, 21, { agents: ['Jett', 'Raze'], conf: 'RUMORED' }),
    p('Xavi8k', 'Xavi8k Zhou', 'cn', 'Controller', 'xi-lai-gaming', 7.7, 22, { agents: ['Omen', 'Astra'], conf: 'RUMORED' }),
    p('Zmjjkk', 'Zheng Yongkang', 'cn', 'Duelist', 'xi-lai-gaming', 9.4, 23, { agents: ['Jett', 'Chamber'], conf: 'RUMORED', note: 'Reported blockbuster move from EDward Gaming.' }),
    p('happywei2', 'Happywei (flex)', 'cn', 'Sentinel', 'xi-lai-gaming', 7.4, 20, { agents: ['Killjoy', 'Vyse'], conf: 'UNKNOWN' }),

    /* ===== ALL GAMERS ===== */
    p('jinggg', 'Wang Jing Jie', 'sg', 'Duelist', 'all-gamers', 8.4, 21, { agents: ['Raze', 'Jett'], conf: 'RUMORED' }),
    p('spring', 'Spring Li', 'cn', 'Initiator', 'all-gamers', 7.6, 22, { agents: ['Skye', 'Fade'], conf: 'RUMORED' }),

    /* ===== NON-PARTNER REAL ROSTERS ===== */
    p('Boaster2', '', 'gb', 'Controller', 'aurora-gaming', 0.1, 30, { conf: 'UNKNOWN', note: 'placeholder' }),

    /* ===== FREE AGENTS ===== */
    p('nAts', 'Ayaz Akhmetshin', 'ru', 'Sentinel', null, 8.7, 25, { agents: ['Viper', 'Cypher'], conf: 'OFFICIAL', note: 'Free agent after leaving Team Liquid.' }),
    p('Boaster_fa', 'Jake Howlett', 'gb', 'Controller', null, 8.4, 30, { agents: ['Omen', 'Astra'], igl: true, conf: 'REPORTED' }),
    p('WsLeo', 'Huang Ping-wei', 'tw', 'Sentinel', null, 7.9, 24, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' }),
    p('tkzin', 'Enzo Zimiani', 'br', 'Initiator', null, 7.5, 22, { agents: ['Sova', 'Fade'], conf: 'OFFICIAL' }),
    p('JitBoyS', 'Jittana Nokngam', 'th', 'Duelist', null, 7.8, 23, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL' }),
    p('Killua', 'Taned Teerasawad', 'th', 'Controller', null, 7.4, 25, { agents: ['Omen', 'Astra'], conf: 'OFFICIAL' }),
    p('sushiboys', 'Panyawat Subsiriroj', 'th', 'Sentinel', null, 7.3, 24, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' }),
    p('cortezia', 'Gabriel Cortez', 'br', 'Sentinel', null, 7.7, 23, { agents: ['Killjoy', 'Cypher'], conf: 'REPORTED' }),
    p('reduxx', 'Yassine Aboulalazm', 'ma', 'Initiator', null, 7.3, 23, { agents: ['Sova', 'Fade'], conf: 'OFFICIAL' }),
    p('JonahP', 'Jonah Pulice', 'us', 'Duelist', null, 7.7, 24, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL' }),
    p('Jerrwin', 'Gurjiwan Gill', 'ca', 'Initiator', null, 7.4, 23, { agents: ['KAY/O', 'Skye'], conf: 'OFFICIAL' }),
    p('Meteor', 'Kim Tae-O', 'kr', 'Duelist', null, 8.3, 25, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL' }),
    p('Munchkin', 'Byeon Sang-beom', 'kr', 'Controller', null, 8.0, 27, { agents: ['Omen', 'Astra'], igl: true, conf: 'OFFICIAL' }),
    p('DH', 'Doh Dong-hyun', 'kr', 'Sentinel', null, 7.9, 24, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' }),
    p('KDG', 'Kim Dong-gyun', 'kr', 'Initiator', null, 7.6, 24, { agents: ['Sova', 'Fade'], conf: 'OFFICIAL' }),
    p('CheongGak', 'CheongGak Lee', 'kr', 'Sentinel', null, 7.3, 22, { agents: ['Killjoy', 'Deadlock'], conf: 'OFFICIAL' }),
    p('Efina', 'Kim Nak-Yeon', 'kr', 'Controller', null, 7.6, 23, { agents: ['Viper', 'Omen'], conf: 'OFFICIAL' }),
    p('Ash', 'Ha Hyun-cheol', 'kr', 'Sentinel', null, 7.5, 24, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' }),
    p('Xdll', 'Xdll Kim', 'kr', 'Duelist', null, 7.6, 23, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL' }),
    p('Saadhak', 'Matias Delipetro', 'ar', 'Controller', null, 8.2, 27, { agents: ['Omen', 'Astra'], igl: true, conf: 'OFFICIAL' }),
    p('heat', 'Olavo Marcelo', 'br', 'Duelist', null, 8.1, 25, { agents: ['Raze', 'Jett'], conf: 'OFFICIAL' }),
    p('mwzera', 'Leonardo Serrati', 'br', 'Duelist', null, 8.1, 23, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL' }),
    p('Dantedeu5', 'Jesús Larrosa', 'ar', 'Sentinel', null, 7.3, 24, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' }),
    p('vo0kashu', 'Ilya Ushakov', 'ru', 'Duelist', null, 7.7, 21, { agents: ['Jett', 'Neon'], conf: 'OFFICIAL' }),
    p('Rarga', 'Arthur Churyumov', 'ru', 'Duelist', null, 7.6, 22, { agents: ['Raze', 'Jett'], conf: 'OFFICIAL' }),
    p('NoMan', 'James Man Ga-kit', 'hk', 'Initiator', null, 7.2, 23, { agents: ['Skye', 'Fade'], conf: 'OFFICIAL' }),
    p('Artzin', 'Arthur Araujo', 'br', 'Initiator', null, 7.4, 24, { agents: ['Sova', 'KAY/O'], conf: 'OFFICIAL' }),
    p('Xan', 'Xan Lim', 'id', 'Sentinel', null, 7.2, 23, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' }),
    p('Flicker', 'Flicker Park', 'kr', 'Initiator', null, 7.4, 20, { agents: ['Sova', 'Fade'], conf: 'LIKELY' }),
    p('yong', 'Yong Kim', 'kr', 'Controller', null, 7.3, 20, { agents: ['Omen', 'Astra'], conf: 'LIKELY' }),
    p('Francis', 'Francis Lee', 'kr', 'Duelist', null, 7.5, 21, { agents: ['Jett', 'Raze'], conf: 'REPORTED' }),
    p('Ivy', 'Ivy Choi', 'kr', 'Controller', null, 7.2, 22, { agents: ['Viper', 'Omen'], conf: 'REPORTED' }),
    p('Rb', 'Rb Jung', 'kr', 'Sentinel', null, 7.1, 21, { agents: ['Killjoy', 'Cypher'], conf: 'REPORTED' }),
    p('UdoTan', 'Udo Tan', 'id', 'Initiator', null, 7.4, 22, { agents: ['Sova', 'Fade'], conf: 'OFFICIAL' }),
    p('Xross', 'Xross Han', 'kr', 'Duelist', null, 7.0, 19, { agents: ['Raze', 'Neon'], conf: 'REPORTED' }),
    p('sociablEE', 'Volkan Yönal', 'tr', 'Initiator', null, 7.6, 24, { agents: ['KAY/O', 'Skye'], conf: 'OFFICIAL' }),
    p('s0pp', 'Efe Tur', 'tr', 'Duelist', null, 7.3, 21, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL' }),
    p('BadreX', 'Emirhan Muzıroğlu', 'tr', 'Sentinel', null, 7.2, 22, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' }),
    p('Anaks', 'Ye Sang-jun', 'kr', 'Controller', null, 7.4, 23, { agents: ['Omen', 'Astra'], conf: 'OFFICIAL' }),
    p('Derke', 'Nikita Sirmitev', 'fi', 'Duelist', null, 9.2, 24, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL', note: 'Free agent after leaving Vitality. Expected to headline a non-partner project.' }),
    p('Boo', 'Ričardas Lukaševičius', 'lt', 'Initiator', null, 8.4, 23, { agents: ['Sova', 'Fade'], conf: 'OFFICIAL' }),
    p('trexx', 'Nikita Cherednichenko', 'ru', 'Initiator', null, 8.0, 25, { agents: ['KAY/O', 'Skye'], conf: 'OFFICIAL' }),
    p('B1SK', 'B1SK Petrov', 'ru', 'Sentinel', null, 7.4, 22, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' }),
    p('chiwa', 'Chiwa Suzuki', 'jp', 'Controller', null, 7.5, 23, { agents: ['Omen', 'Astra'], conf: 'OFFICIAL' }),
    p('GLYPH', 'Glyph Carter', 'us', 'Initiator', null, 7.3, 22, { agents: ['Sova', 'Fade'], conf: 'OFFICIAL' }),
    p('alym', 'Alym Kaliyev', 'kz', 'Controller', null, 7.2, 21, { agents: ['Omen', 'Astra'], conf: 'OFFICIAL' }),
    p('Derrek', 'Derrek Lee', 'us', 'Sentinel', null, 7.6, 26, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' }),
    p('nightz', 'Nightz Park', 'us', 'Duelist', null, 7.1, 20, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL' }),
    p('FireBallOps', 'FireBallOps Kim', 'kr', 'Duelist', null, 7.6, 22, { agents: ['Jett', 'Raze'], conf: 'OFFICIAL' }),
    p('Zander', 'Alexander Dituri', 'us', 'Controller', null, 7.3, 25, { agents: ['Omen', 'Astra'], conf: 'OFFICIAL' }),
    p('Smoke', 'Smoke Brown', 'us', 'Sentinel', null, 7.0, 23, { agents: ['Killjoy', 'Cypher'], conf: 'OFFICIAL' })
  ];

  /* Clean the placeholder row */
  PLAYERS = PLAYERS.filter(function (x) { return x.grade > 1; });

  /* Coaches / staff: real where confirmed, generated elsewhere */
  var STAFF = [
    { nick: 'Sacy', name: 'Gustavo Rossi', cc: 'br', org: 't1', role: 'Head Coach', grade: 9.0, age: 33, conf: 'OFFICIAL', note: 'Former Champions winner, appointed 13 Nov 2026.' },
    { nick: 'ANGE1', name: 'Kirill Karasiow', cc: 'ua', org: 'fnatic', role: 'Head Coach', grade: 8.0, age: 35, conf: 'REPORTED' },
    { nick: 'Mavera', name: 'Mavera Kaya', cc: 'tr', org: 'fut-esports', role: 'Head Coach', grade: 7.5, age: 31, conf: 'REPORTED' },
    { nick: 'kaplan', name: 'Kaplan Yılmaz', cc: 'tr', org: 'gentle-mates', role: 'Head Coach', grade: 7.4, age: 30, conf: 'REPORTED' },
    { nick: 'Crws', name: 'Thanamethk Mahatthananuyut', cc: 'th', org: 'full-sense', role: 'Head Coach', grade: 7.6, age: 30, conf: 'OFFICIAL', note: 'Moved from player to head coach, 17 Nov 2026.' },
    { nick: 'Immi', name: 'Immi Andersson', cc: 'se', org: 'cloud9', role: 'Head Coach', grade: 7.6, age: 29, conf: 'OFFICIAL' },
    { nick: 'hvoya', name: 'Aleksandr Eremin', cc: 'ru', org: 'aurora-gaming', role: 'Head Coach', grade: 7.7, age: 32, conf: 'OFFICIAL' },
    { nick: 'Chet', name: 'Chet Singh', cc: 'us', org: 'sentinels', role: 'Head Coach', grade: 8.4, age: 33, conf: 'LIKELY' },
    { nick: 'ED101', name: 'ED101 Chen', cc: 'cn', org: 'any-questions-gaming', role: 'Head Coach', grade: 7.0, age: 28, conf: 'OFFICIAL' },
    { nick: 'Hype', name: 'Hype Kang', cc: 'kr', org: 'nongshim-redforce', role: 'Head Coach', grade: 7.0, age: 29, conf: 'OFFICIAL' },
    { nick: 'Persia', name: 'Yang Zi-on', cc: 'tw', org: 'nongshim-redforce', role: 'Assistant Coach', grade: 6.8, age: 27, conf: 'OFFICIAL' },
    { nick: 'Sungmin', name: 'So Seong-min', cc: 'kr', org: 't1', role: 'Assistant Coach', grade: 7.2, age: 30, conf: 'OFFICIAL' },
    { nick: 'Szed', name: 'Philipp Schickor', cc: 'de', org: 'team-vitality', role: 'Assistant Coach', grade: 7.2, age: 28, conf: 'OFFICIAL' },
    { nick: 'Scuttt', name: 'Benjamin Hutchinson', cc: 'gb', org: 'team-vitality', role: 'Analyst', grade: 7.0, age: 26, conf: 'OFFICIAL' }
  ];

  /* ---- data normalisation: remove duplicates, assign confirmed non-partner rosters ---- */
  PLAYERS = PLAYERS.filter(function (x) {
    if (x.nick === 'Boaster_fa' || x.nick === 'Boaster2' || x.nick === 'happywei2') return false;
    if (!x.org && x.nick === 'cortezia') return false;
    return true;
  });
  var REASSIGN = {
    Derke: 'aurora-gaming', Boo: 'aurora-gaming', trexx: 'aurora-gaming', B1SK: 'aurora-gaming', chiwa: 'aurora-gaming',
    FireBallOps: 'cloud9', GLYPH: 'cloud9', alym: 'cloud9', Derrek: 'cloud9', nightz: 'cloud9',
    Zander: 'shopify-rebellion-black', Smoke: 'shopify-rebellion-black',
    Francis: 'nongshim-redforce', Ivy: 'nongshim-redforce', Rb: 'nongshim-redforce', UdoTan: 'nongshim-redforce', Xross: 'nongshim-redforce',
    yong: 'kiwoom-drx', Flicker: 'kiwoom-drx',
    sociablEE: 'eternal-fire', s0pp: 'eternal-fire', BadreX: 'eternal-fire',
    Anaks: 'titan-esports-club'
  };
  PLAYERS.forEach(function (p) { if (REASSIGN[p.nick] && !p.org) p.org = REASSIGN[p.nick]; });

  return { ORGS: ORGS, PLAYERS: PLAYERS, STAFF: STAFF };
})();
