/* =====================================================================
   VALORANT MANAGER 2027 — CORE (utils, constants, assets, storage)
   ===================================================================== */
var Core = (function () {
  'use strict';

  var VERSION = '1.0.0';
  var DB_SNAPSHOT = '2026-11-17';

  var ROLES = ['Duelist', 'Initiator', 'Controller', 'Sentinel'];

  var ROLE_INFO = {
    Duelist: { short: 'DUE', color: '#ff4655', desc: 'Creates space, takes opening duels and forces the first contact. High mechanical demand.' },
    Initiator: { short: 'INI', color: '#f2b23e', desc: 'Gathers information and sets up executes with utility. The engine of coordinated attacks.' },
    Controller: { short: 'CTL', color: '#4ea3ff', desc: 'Shapes the map with smokes and walls, controls timing and denies information.' },
    Sentinel: { short: 'SEN', color: '#2fd39b', desc: 'Locks down sites, watches flanks and stabilises the defence. Discipline over flash.' }
  };

  var PLAYSTYLES = [
    { id: 'Aggressive', desc: 'Fast executes, high opening-duel volume, punish passivity. Risky on defence.' },
    { id: 'Defensive', desc: 'Slow, information-first, retake-heavy. Concedes early map control.' },
    { id: 'Balanced', desc: 'Adapts round to round. No extreme bonus, no extreme weakness.' },
    { id: 'Fast-paced', desc: 'Tempo overwhelms prepared opponents. Weak against disciplined defaults.' },
    { id: 'Methodical', desc: 'Structured default into mid-round call. Rewards gamesense and patience.' },
    { id: 'Map control', desc: 'Prioritises space and rotations. Strong on large maps, slower to close rounds.' },
    { id: 'Adaptable', desc: 'Adjusts to the opponent after two rounds. Needs high gamesense and coaching.' }
  ];

  var STYLE_INFO = {
    Aggressive: { atk: 5, def: -3, tempo: 4, control: -1, chaos: 3 },
    Defensive: { atk: -4, def: 5, tempo: -3, control: 2, chaos: -2 },
    Balanced: { atk: 0, def: 0, tempo: 0, control: 0, chaos: 0 },
    'Fast-paced': { atk: 4, def: -2, tempo: 5, control: -2, chaos: 3 },
    Methodical: { atk: 1, def: 2, tempo: -4, control: 3, chaos: -3 },
    'Map control': { atk: 0, def: 2, tempo: -2, control: 5, chaos: -1 },
    Adaptable: { atk: 1, def: 1, tempo: 0, control: 1, chaos: 0 }
  };

  var TRAINING = [
    { id: 'aim', name: 'Aim & Mechanics', short: 'AIM', attrs: ['aim', 'mechanics'], desc: 'Raw aim, crosshair placement and mechanical consistency. High fatigue.' },
    { id: 'coordination', name: 'Team Coordination', short: 'COORD', attrs: ['teamplay', 'communication'], desc: 'Trades, spacing and support play. Builds chemistry.' },
    { id: 'attack', name: 'Attack Structure', short: 'ATK', attrs: ['decision', 'gamesense'], desc: 'Executes, defaults and post-plant. Improves attack rating.' },
    { id: 'defense', name: 'Defensive Coordination', short: 'DEF', attrs: ['positioning', 'gamesense'], desc: 'Setups, retakes and rotations. Improves defence rating.' },
    { id: 'mapcontrol', name: 'Map Control', short: 'CTRL', attrs: ['positioning', 'adaptability'], desc: 'Space, timing and mid-round movement across the map pool.' },
    { id: 'agent', name: 'Agent Mastery', short: 'AGENT', attrs: ['adaptability', 'mechanics'], desc: 'Utility line-ups and comfort on assigned agents.' },
    { id: 'comms', name: 'Communication', short: 'COMMS', attrs: ['communication', 'teamplay'], desc: 'Callouts, info sharing and mid-round discipline.' },
    { id: 'mental', name: 'Mental Preparation', short: 'MENTAL', attrs: ['mental', 'clutch'], desc: 'Resilience, pressure handling and clutch composure.' },
    { id: 'general', name: 'General Training', short: 'GEN', attrs: ['aim', 'gamesense', 'teamplay'], desc: 'Balanced development, no specialisation, low fatigue.' }
  ];

  var DIFFICULTY = {
    Beginner: { label: 'Beginner', ai: 0.93, money: 1.25, wage: 0.9, patience: 1.5, growth: 1.15, desc: 'Forgiving board, richer budgets, weaker AI. Learn the systems.' },
    Normal: { label: 'Normal', ai: 1, money: 1, wage: 1, patience: 1, growth: 1, desc: 'The intended experience. Balanced challenge and economy.' },
    Difficult: { label: 'Difficult', ai: 1.06, money: 0.9, wage: 1.08, patience: 0.75, growth: 0.95, desc: 'Sharper AI, tighter budgets, less patient board.' },
    Expert: { label: 'Expert', ai: 1.12, money: 0.8, wage: 1.15, patience: 0.55, growth: 0.88, desc: 'Every mistake is punished. Build carefully.' }
  };

  var REGIONS = [
    { id: 'Americas', subs: ['North America', 'Brazil', 'Latin America North', 'Latin America South'], color: '#ff4655' },
    { id: 'EMEA', subs: ['Europe', 'Türkiye', 'MENA'], color: '#4ea3ff' },
    { id: 'Pacific', subs: ['South Korea', 'Japan', 'Thailand', 'Indonesia', 'Vietnam', 'Southeast Asia', 'South Asia', 'Oceania'], color: '#2fd39b' },
    { id: 'China', subs: ['China'], color: '#f2b23e' }
  ];

  var COUNTRIES = {
    us: ['United States', 'North America'], ca: ['Canada', 'North America'], br: ['Brazil', 'Brazil'],
    ar: ['Argentina', 'Latin America South'], cl: ['Chile', 'Latin America South'], pe: ['Peru', 'Latin America South'],
    mx: ['Mexico', 'Latin America North'], co: ['Colombia', 'Latin America North'], cr: ['Costa Rica', 'Latin America North'],
    gb: ['United Kingdom', 'Europe'], fr: ['France', 'Europe'], de: ['Germany', 'Europe'], es: ['Spain', 'Europe'],
    pt: ['Portugal', 'Europe'], it: ['Italy', 'Europe'], nl: ['Netherlands', 'Europe'], be: ['Belgium', 'Europe'],
    se: ['Sweden', 'Europe'], no: ['Norway', 'Europe'], dk: ['Denmark', 'Europe'], fi: ['Finland', 'Europe'],
    pl: ['Poland', 'Europe'], cz: ['Czechia', 'Europe'], sk: ['Slovakia', 'Europe'], hu: ['Hungary', 'Europe'],
    ro: ['Romania', 'Europe'], bg: ['Bulgaria', 'Europe'], gr: ['Greece', 'Europe'], ua: ['Ukraine', 'Europe'],
    ru: ['Russia', 'Europe'], by: ['Belarus', 'Europe'], lt: ['Lithuania', 'Europe'], lv: ['Latvia', 'Europe'],
    ee: ['Estonia', 'Europe'], rs: ['Serbia', 'Europe'], hr: ['Croatia', 'Europe'], si: ['Slovenia', 'Europe'],
    tr: ['Türkiye', 'Türkiye'], ma: ['Morocco', 'MENA'], eg: ['Egypt', 'MENA'], ae: ['UAE', 'MENA'],
    sa: ['Saudi Arabia', 'MENA'], kw: ['Kuwait', 'MENA'], qa: ['Qatar', 'MENA'], jo: ['Jordan', 'MENA'],
    lb: ['Lebanon', 'MENA'], dz: ['Algeria', 'MENA'], tn: ['Tunisia', 'MENA'], il: ['Israel', 'Europe'],
    kr: ['South Korea', 'South Korea'], jp: ['Japan', 'Japan'], cn: ['China', 'China'], tw: ['Taiwan', 'Southeast Asia'],
    hk: ['Hong Kong', 'Southeast Asia'], sg: ['Singapore', 'Southeast Asia'], my: ['Malaysia', 'Southeast Asia'],
    id: ['Indonesia', 'Indonesia'], th: ['Thailand', 'Thailand'], vn: ['Vietnam', 'Vietnam'],
    ph: ['Philippines', 'Southeast Asia'], in: ['India', 'South Asia'], pk: ['Pakistan', 'South Asia'],
    bd: ['Bangladesh', 'South Asia'], lk: ['Sri Lanka', 'South Asia'], np: ['Nepal', 'South Asia'],
    au: ['Australia', 'Oceania'], nz: ['New Zealand', 'Oceania'], mn: ['Mongolia', 'Southeast Asia'],
    kz: ['Kazakhstan', 'Europe'], ge: ['Georgia', 'Europe'], am: ['Armenia', 'Europe'], az: ['Azerbaijan', 'Europe']
  };

  var MAPS = [
    { name: 'Abyss', type: 'defense', note: 'No boundaries. Positioning errors are instantly fatal.' },
    { name: 'Bind', type: 'attack', note: 'No mid, teleporters reward fast rotations and utility-heavy executes.' },
    { name: 'Corrode', type: 'balanced', note: 'Tight, utility-dense layout. Coordinated executes are essential.' },
    { name: 'Haven', type: 'attack', note: 'Three sites. Rotations are long: information is king.' },
    { name: 'Lotus', type: 'balanced', note: 'Three sites with doors and destructibles. Utility timing wins rounds.' },
    { name: 'Summit', type: 'balanced', note: 'Zhangjiajie cliffside with droppable walls and tight chokes. Space control decides retakes.' },
    { name: 'Sunset', type: 'defense', note: 'Mid-centric, retake-heavy. Sentinels anchor the whole map.' },
    { name: 'Ascent', type: 'balanced', note: 'Long sightlines, mid control decides everything. Sentinels and controllers shine.' },
    { name: 'Split', type: 'defense', note: 'Vertical map. Chokes are lethal without a disciplined default.' },
    { name: 'Icebox', type: 'balanced', note: 'Verticality and long angles. Requires precise utility and sniper control.' },
    { name: 'Breeze', type: 'attack', note: 'Huge open spaces. Operator value and map control are decisive.' },
    { name: 'Fracture', type: 'attack', note: 'Attackers pinch from two sides. Defender coordination is stressed.' },
    { name: 'Pearl', type: 'defense', note: 'Tight corridors. Defaults and mid-round calling separate teams.' }
  ];

  var ACTIVE_MAP_POOL_2027 = ['Abyss', 'Bind', 'Corrode', 'Haven', 'Lotus', 'Summit', 'Sunset'];
  var RESERVE_MAPS = ['Ascent', 'Split', 'Icebox', 'Breeze', 'Fracture', 'Pearl'];

  function normalizePool(pool) {
    var validNames = MAPS.map(function (m) { return m.name; });
    var out = [];
    (pool || []).forEach(function (m) {
      if (validNames.indexOf(m) >= 0 && out.indexOf(m) < 0) out.push(m);
    });
    for (var i = 0; i < ACTIVE_MAP_POOL_2027.length && out.length < 7; i++) {
      if (out.indexOf(ACTIVE_MAP_POOL_2027[i]) < 0) out.push(ACTIVE_MAP_POOL_2027[i]);
    }
    return out.slice(0, 7);
  }

  var AGENTS = {
    Jett: 'Duelist', Raze: 'Duelist', Reyna: 'Duelist', Phoenix: 'Duelist', Yoru: 'Duelist', Neon: 'Duelist',
    Iso: 'Duelist', Waylay: 'Duelist',
    Sova: 'Initiator', Breach: 'Initiator', Skye: 'Initiator', 'KAY/O': 'Initiator', Fade: 'Initiator',
    Gekko: 'Initiator', Tejo: 'Initiator',
    Brimstone: 'Controller', Viper: 'Controller', Omen: 'Controller', Astra: 'Controller', Harbor: 'Controller',
    Clove: 'Controller',
    Killjoy: 'Sentinel', Cypher: 'Sentinel', Sage: 'Sentinel', Chamber: 'Sentinel', Deadlock: 'Sentinel', Vyse: 'Sentinel'
  };

  var AGENT_LIST = Object.keys(AGENTS);

  var MAP_META = {
    Ascent: { Duelist: ['Jett', 'Raze', 'Iso'], Initiator: ['Sova', 'KAY/O', 'Fade'], Controller: ['Omen', 'Astra', 'Brimstone'], Sentinel: ['Killjoy', 'Cypher', 'Chamber'] },
    Bind: { Duelist: ['Raze', 'Phoenix', 'Waylay'], Initiator: ['Skye', 'Breach', 'Gekko'], Controller: ['Brimstone', 'Viper', 'Omen'], Sentinel: ['Cypher', 'Killjoy', 'Sage'] },
    Haven: { Duelist: ['Jett', 'Neon', 'Iso'], Initiator: ['Sova', 'Breach', 'Fade'], Controller: ['Omen', 'Astra', 'Harbor'], Sentinel: ['Killjoy', 'Cypher', 'Vyse'] },
    Split: { Duelist: ['Raze', 'Jett', 'Neon'], Initiator: ['Skye', 'Breach', 'Fade'], Controller: ['Omen', 'Viper', 'Astra'], Sentinel: ['Cypher', 'Killjoy', 'Deadlock'] },
    Icebox: { Duelist: ['Jett', 'Neon', 'Iso'], Initiator: ['Sova', 'KAY/O', 'Fade'], Controller: ['Viper', 'Harbor', 'Omen'], Sentinel: ['Killjoy', 'Sage', 'Chamber'] },
    Breeze: { Duelist: ['Jett', 'Neon', 'Waylay'], Initiator: ['Sova', 'Skye', 'KAY/O'], Controller: ['Viper', 'Harbor', 'Astra'], Sentinel: ['Cypher', 'Chamber', 'Killjoy'] },
    Fracture: { Duelist: ['Raze', 'Neon', 'Phoenix'], Initiator: ['Breach', 'Skye', 'Fade'], Controller: ['Brimstone', 'Viper', 'Omen'], Sentinel: ['Killjoy', 'Cypher', 'Deadlock'] },
    Pearl: { Duelist: ['Jett', 'Raze', 'Iso'], Initiator: ['Sova', 'Fade', 'KAY/O'], Controller: ['Astra', 'Omen', 'Viper'], Sentinel: ['Killjoy', 'Cypher', 'Deadlock'] },
    Lotus: { Duelist: ['Raze', 'Neon', 'Jett'], Initiator: ['Skye', 'Fade', 'Breach'], Controller: ['Omen', 'Astra', 'Viper'], Sentinel: ['Killjoy', 'Cypher', 'Vyse'] },
    Sunset: { Duelist: ['Raze', 'Jett', 'Iso'], Initiator: ['Skye', 'KAY/O', 'Fade'], Controller: ['Omen', 'Astra', 'Brimstone'], Sentinel: ['Cypher', 'Killjoy', 'Sage'] },
    Abyss: { Duelist: ['Jett', 'Raze', 'Neon'], Initiator: ['Sova', 'Fade', 'KAY/O'], Controller: ['Omen', 'Astra', 'Harbor'], Sentinel: ['Killjoy', 'Cypher', 'Vyse'] },
    Corrode: { Duelist: ['Raze', 'Iso', 'Phoenix'], Initiator: ['Gekko', 'Skye', 'Fade'], Controller: ['Omen', 'Astra', 'Brimstone'], Sentinel: ['Killjoy', 'Cypher', 'Deadlock'] },
    Summit: { Duelist: ['Raze', 'Neon', 'Jett'], Initiator: ['Sova', 'Breach', 'Tejo'], Controller: ['Omen', 'Viper', 'Astra'], Sentinel: ['Killjoy', 'Cypher', 'Vyse'] }
  };

  var TACTIC_PRESETS = [
    { id: 'default', name: 'Balanced Default', style: 'Balanced', desc: 'Safe, adaptable structure. Good starting point for any roster.' },
    { id: 'rush', name: 'Fast Executes', style: 'Fast-paced', desc: 'High tempo, utility-burn executes. Best with aggressive duelists.' },
    { id: 'fortress', name: 'Fortress Defence', style: 'Defensive', desc: 'Passive defaults, strong retakes. Needs disciplined sentinels.' },
    { id: 'control', name: 'Map Control', style: 'Map control', desc: 'Slow space-taking, mid-round calls. Rewards gamesense.' },
    { id: 'antistrat', name: 'Adaptive Anti-Strat', style: 'Adaptable', desc: 'Reads the opponent, changes tempo. Requires coaching quality.' }
  ];

  /* ---------------- RNG ---------------- */
  function hash(str) {
    str = String(str);
    var h = 2166136261;
    for (var i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
    return h >>> 0;
  }
  function RNG(seed) {
    var s = typeof seed === 'number' ? seed >>> 0 : hash(seed || Math.random());
    var api = {
      seed: s,
      next: function () {
        s |= 0; s = s + 0x6D2B79F5 | 0;
        var t = Math.imul(s ^ s >>> 15, 1 | s);
        t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
      },
      int: function (a, b) { return a + Math.floor(api.next() * (b - a + 1)); },
      float: function (a, b) { return a + api.next() * (b - a); },
      chance: function (p) { return api.next() < p; },
      pick: function (arr) { return arr[Math.floor(api.next() * arr.length)]; },
      shuffle: function (arr) {
        var a = arr.slice();
        for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(api.next() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
        return a;
      },
      weighted: function (items, weightFn) {
        var total = 0, i;
        for (i = 0; i < items.length; i++) total += weightFn(items[i]);
        var r = api.next() * total;
        for (i = 0; i < items.length; i++) { r -= weightFn(items[i]); if (r <= 0) return items[i]; }
        return items[items.length - 1];
      }
    };
    return api;
  }
  function uid(prefix, rng) {
    return (prefix || 'id') + '_' + (rng ? rng.int(100000, 999999) : Math.floor(Math.random() * 1e6)).toString(36) + Date.now().toString(36).slice(-4);
  }

  /* ---------------- format ---------------- */
  function clamp(v, a, b) { a = a == null ? 0 : a; b = b == null ? 100 : b; return v < a ? a : v > b ? b : v; }
  function avg(arr) { if (!arr || !arr.length) return 0; var s = 0; for (var i = 0; i < arr.length; i++) s += arr[i]; return s / arr.length; }
  function sum(arr) { var s = 0; for (var i = 0; i < arr.length; i++) s += arr[i]; return s; }
  function round(v, d) { var m = Math.pow(10, d || 0); return Math.round(v * m) / m; }
  function hasI18n() { return typeof window !== 'undefined' && window.I18N; }
  function money(n) {
    if (hasI18n() && window.I18N.get() !== 'en') return window.I18N.money(n);
    if (n == null || isNaN(n)) return '$0';
    var neg = n < 0; n = Math.abs(n);
    var s;
    if (n >= 1000000) s = '$' + (n / 1000000).toFixed(n >= 10000000 ? 1 : 2) + 'M';
    else if (n >= 1000) s = '$' + Math.round(n / 1000) + 'K';
    else s = '$' + Math.round(n);
    return (neg ? '-' : '') + s;
  }
  function moneyFull(n) {
    if (hasI18n() && window.I18N.get() !== 'en') return window.I18N.moneyFull(n);
    var neg = n < 0; n = Math.round(Math.abs(n));
    return (neg ? '-' : '') + '$' + n.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }
  function num(n) { if (hasI18n() && window.I18N.get() !== 'en') return window.I18N.num(n); return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  var MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  function parseDate(iso) { var p = String(iso).split('-'); return new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])); }
  function iso(d) { return d.toISOString().slice(0, 10); }
  function addDays(isoStr, n) { var d = parseDate(isoStr); d.setUTCDate(d.getUTCDate() + n); return iso(d); }
  function addMonths(isoStr, n) {
    var d = parseDate(isoStr), day = d.getUTCDate();
    d.setUTCDate(1);
    d.setUTCMonth(d.getUTCMonth() + n);
    var last = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 0)).getUTCDate();
    d.setUTCDate(Math.min(day, last));
    return iso(d);
  }
  function diffDays(a, b) { return Math.round((parseDate(b) - parseDate(a)) / 86400000); }

  /* Single source of truth for money movements. Every transaction adjusts the
     organisation balance AND writes a dated ledger entry, so the dashboard,
     history and persistence can never disagree. */
  function recordTransaction(state, orgId, note, amount, meta) {
    if (!state || !state.orgs || !state.orgs[orgId]) return null;
    meta = meta || {};
    var org = state.orgs[orgId];
    amount = Math.round(amount || 0);
    org.budget = Math.round((org.budget || 0) + amount);
    var entry = {
      id: 'tx_' + Date.now().toString(36) + '_' + Math.floor(Math.random() * 1e6).toString(36),
      date: state.date, total: amount, note: note,
      type: meta.type || 'transaction', category: meta.category || 'other',
      lines: meta.lines || [{ label: note, value: amount }],
      orgId: orgId
    };
    if (meta.compId) entry.compId = meta.compId;
    if (meta.playerId) entry.playerId = meta.playerId;
    if (meta.contractId) entry.contractId = meta.contractId;
    if (meta.offerId) entry.offerId = meta.offerId;
    state.financeLedger = state.financeLedger || [];
    state.financeLedger.unshift(entry);
    if (state.financeLedger.length > 120) state.financeLedger.length = 120;
    return entry;
  }
  function fmtDate(isoStr, withYear) {
    if (!isoStr) return '—';
    if (hasI18n() && window.I18N.get() !== 'en') return window.I18N.fmtDate(isoStr, withYear);
    var d = parseDate(isoStr);
    return d.getUTCDate() + ' ' + MONTHS[d.getUTCMonth()] + (withYear !== false ? ' ' + d.getUTCFullYear() : '');
  }
  function fmtDateLong(isoStr) {
    if (!isoStr) return '—';
    if (hasI18n() && window.I18N.get() !== 'en') return window.I18N.fmtDateLong(isoStr);
    var d = parseDate(isoStr);
    var dows = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    return dows[d.getUTCDay()] + ' ' + d.getUTCDate() + ' ' + MONTHS[d.getUTCMonth()] + ' ' + d.getUTCFullYear();
  }
  function monthMatrix(year, month) {
    var first = new Date(Date.UTC(year, month, 1));
    var start = new Date(first); start.setUTCDate(1 - ((first.getUTCDay() + 6) % 7));
    var out = [], d = new Date(start);
    for (var w = 0; w < 6; w++) {
      var row = [];
      for (var i = 0; i < 7; i++) { row.push(iso(d)); d.setUTCDate(d.getUTCDate() + 1); }
      out.push(row);
    }
    return out;
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function titleCase(s) { return String(s || '').replace(/\w\S*/g, function (t) { return t.charAt(0).toUpperCase() + t.slice(1).toLowerCase(); }); }
  function pct(v) { return Math.round(v) + '%'; }
  function ordinal(n) { if (hasI18n() && window.I18N.get() !== 'en') return window.I18N.ordinal(n); var s = ['th', 'st', 'nd', 'rd'], v = n % 100; return n + (s[(v - 20) % 10] || s[v] || s[0]); }
  function initials(name) {
    var parts = String(name || '?').replace(/[^\w\s]/g, ' ').trim().split(/\s+/);
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  }

  /* ---------------- visual helpers ---------------- */
  function svgURI(svg) { return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg).replace(/'/g, '%27'); }

  function monogram(name, color, size) {
    var c = color || '#ff4655';
    var t = esc(initials(name)).slice(0, 3);
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">' +
      '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#1a1f27"/><stop offset="1" stop-color="#0b0d11"/></linearGradient></defs>' +
      '<rect width="100" height="100" fill="url(#g)"/>' +
      '<path d="M0 78 L100 44 L100 100 L0 100 Z" fill="' + c + '" opacity="0.18"/>' +
      '<path d="M0 0 L100 0 L100 8 L0 20 Z" fill="' + c + '" opacity="0.55"/>' +
      '<text x="50" y="61" font-family="Arial Narrow, Arial" font-weight="bold" font-size="34" fill="#e8eaee" text-anchor="middle" letter-spacing="1">' + t + '</text>' +
      '</svg>';
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg).replace(/'/g, '%27');
  }

  function portrait(p, org, big) {
    if (p && p.photo) return p.photo;
    var color = (org && org.colors && org.colors[0]) || '#ff4655';
    var seed = hash((p && p.id) || 'x');
    var r = RNG(seed);
    var id = 'a' + (seed % 99991);
    var ang = 20 + (seed % 40);
    var skin = ['#2b2f37', '#33373f', '#262a31'][seed % 3];
    var style = seed % 3;
    var hair = style === 0 ?
      '<path d="M64 66 q6 -26 36 -26 q30 0 36 26 l-4 20 h-64 z" fill="#15181d"/>' :
      style === 1 ?
      '<path d="M62 74 q0 -38 38 -38 q38 0 38 38 l-2 12 h-74 z" fill="#15181d"/><path d="M78 48 q22 -12 44 0" stroke="' + color + '" stroke-width="2" opacity=".5" fill="none"/>' :
      '<path d="M62 70 q4 -30 38 -30 q34 0 38 30 l-6 16 h-64 z" fill="#12151a"/>';
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 232">' +
      '<defs><linearGradient id="bg' + id + '" x1="0" y1="0" x2="0.7" y2="1">' +
      '<stop stop-color="#161a21"/><stop offset="1" stop-color="#0a0c10"/></linearGradient>' +
      '<linearGradient id="rim' + id + '" x1="0" y1="0" x2="1" y2="1"><stop stop-color="' + color + '" stop-opacity=".85"/><stop offset="1" stop-color="' + color + '" stop-opacity="0"/></linearGradient></defs>' +
      '<rect width="200" height="232" fill="url(#bg' + id + ')"/>' +
      '<g opacity=".13" stroke="#fff" stroke-width="1"><path d="M0 46 H200 M0 92 H200 M0 138 H200 M0 184 H200"/><path d="M50 0 V232 M100 0 V232 M150 0 V232"/></g>' +
      '<path d="M0 232 L200 ' + (150 + seed % 40) + ' L200 232 Z" fill="' + color + '" opacity=".16"/>' +
      '<g transform="translate(' + (95 + (seed % 12) - 6) + ' 120) scale(1.02)">' +
      '<path d="M-58 112 q6 -62 58 -62 q52 0 58 62 z" fill="' + skin + '"/>' +
      '<path d="M-30 58 q-3 -20 12 -24 l4 20 z" fill="' + skin + '"/><path d="M30 58 q3 -20 -12 -24 l-4 20 z" fill="' + skin + '"/>' +
      '<ellipse cx="0" cy="-8" rx="35" ry="43" fill="' + skin + '"/>' +
      hair +
      '<path d="M-34 -6 q34 16 68 -2" stroke="' + color + '" stroke-width="2.2" opacity=".55" fill="none"/>' +
      '<path d="M-20 -10 h12 M8 -10 h12" stroke="#0b0d12" stroke-width="4" stroke-linecap="round"/>' +
      '<path d="M-8 16 q8 4 16 0" stroke="#0b0d12" stroke-width="2.5" fill="none"/>' +
      '</g>' +
      '<path d="M0 0 H200 V4 L0 18 Z" fill="' + color + '" opacity=".7"/>' +
      '<rect x="8" y="8" width="42" height="3" fill="' + color + '"/>' +
      '</svg>';
    return svgURI(svg);
  }

  function logoMarkup(org, cls, size) {
    if (!org) return '<img class="' + (cls || '') + '" src="' + monogram('?', '#444') + '" alt="?" decoding="async">';
    var col = (org.colors && org.colors[0]) || '#ff4655';
    var nm = org.short || org.name || '?';
    var src = org.customLogo ? org.customLogo : (org.logo ? 'assets/logos/' + org.logo + '.png' : monogram(nm, col));
    var extraStyle = (size ? 'width:' + size + 'px;height:' + size + 'px;' : '') + (org.customLogo ? 'object-fit:cover;border-radius:3px;' : '');
    return '<img class="' + (cls || '') + '" src="' + src + '" alt="' + esc(nm) + '" loading="lazy" decoding="async" ' +
      'data-lname="' + esc(nm) + '" data-lcol="' + esc(col) + '" onerror="Core.imgFallback(this)"' + (extraStyle ? ' style="' + extraStyle + '"' : '') + '>';
  }
  function portraitImg(p, org, size, cls, extraStyle) {
    var nick = (p && p.nick) || '?';
    var col = (org && org.colors && org.colors[0]) || '#ff4655';
    var src = portrait(p, org);
    var st = (size ? 'width:' + size + 'px;height:' + size + 'px;' : '') + 'object-fit:cover;object-position:top center;' + (extraStyle || '');
    return '<img class="' + (cls || 'pavatar') + '" src="' + src + '" alt="' + esc(nick) + '" loading="lazy" decoding="async" ' +
      'data-pid="' + esc((p && p.id) || 'x') + '" data-pcol="' + esc(col) + '" onerror="Core.imgFallback(this)"' +
      (size ? ' width="' + size + '" height="' + size + '"' : '') + ' style="' + st + '">';
  }
  function imgFallback(el) {
    el.onerror = null;
    var fb = el.getAttribute('data-fb');
    if (fb) { el.src = fb; return; }
    var pid = el.getAttribute('data-pid');
    if (pid) {
      el.src = portrait({ id: pid, photo: null }, { colors: [el.getAttribute('data-pcol') || '#ff4655'] });
      return;
    }
    var lname = el.getAttribute('data-lname');
    if (lname) {
      el.src = monogram(lname, el.getAttribute('data-lcol') || '#ff4655');
      return;
    }
    el.src = monogram('?', '#444');
  }

  function roleTag(role) {
    var ri = ROLE_INFO[role];
    if (!ri) return '';
    return '<span class="tag role" style="color:' + ri.color + ';border-color:' + ri.color + '44">' + ri.short + '</span>';
  }
  function flag(code) {
    if (!code || !COUNTRIES[code]) return '';
    return '<span class="flag" title="' + esc(countryName(code)) + '">' + code.toUpperCase() + '</span>';
  }
  function countryName(code) {
    if (!COUNTRIES[code]) return code || '—';
    if (hasI18n() && window.I18N.countryName) {
      var n = window.I18N.countryName(code);
      if (n && n !== String(code).toUpperCase()) return n;
    }
    return COUNTRIES[code][0];
  }
  function bar(value, color) {
    var cls = color === 'auto' ? (value >= 70 ? 'green' : value >= 45 ? 'amber' : '') : (color || '');
    return '<div class="bar ' + cls + '"><i style="width:' + clamp(value, 0, 100) + '%"></i></div>';
  }
  function stars(value) {
    var n = clamp(Math.round(value / 20), 0, 5), out = '<span class="stars">';
    for (var i = 0; i < 5; i++) out += '<i class="' + (i < n ? 'on' : '') + '"></i>';
    return out + '</span>';
  }
  function ring(value, color, size) {
    size = size || 44; var r = size / 2 - 3; var c = 2 * Math.PI * r;
    color = color || '#ff4655';
    return '<div class="circle" style="width:' + size + 'px;height:' + size + 'px">' +
      '<svg width="' + size + '" height="' + size + '"><circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke="#22262e" stroke-width="3"/>' +
      '<circle cx="' + size / 2 + '" cy="' + size / 2 + '" r="' + r + '" fill="none" stroke="' + color + '" stroke-width="3" stroke-dasharray="' + c + '" stroke-dashoffset="' + (c - c * clamp(value, 0, 100) / 100) + '"/></svg>' +
      '<span class="cv">' + Math.round(value) + '</span></div>';
  }
  function formDots(form) {
    var out = '<div class="formdots">';
    for (var i = 0; i < (form || []).length; i++) out += '<span class="formdot ' + (form[i] === 'W' ? 'W' : 'L') + '">' + (form[i] === 'W' ? 'W' : 'L') + '</span>';
    return out + '</div>';
  }

  var ICONS = {
    dashboard: '<path d="M3 9.5 12 3l9 6.5V21h-6v-6H9v6H3z"/>',
    squad: '<circle cx="9" cy="8" r="3.2"/><path d="M2.5 21c0-4 3-6.5 6.5-6.5s6.5 2.5 6.5 6.5"/><path d="M17 11.2c2.6.5 4.5 2.7 4.5 5.8"/>',
    roster: '<circle cx="9" cy="8" r="3"/><path d="M2.5 20c0-3.6 2.7-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="18" cy="9" r="2.3"/><path d="M17 14c2.8.2 4.5 2.3 4.5 5"/>',
    tactics: '<path d="M4 20V4h16v16z"/><path d="M4 12h16M12 4v16"/><circle cx="12" cy="12" r="3"/>',
    training: '<path d="M3 8h18M3 16h18"/><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/>',
    recruitment: '<circle cx="11" cy="11" r="6.5"/><path d="M16 16l5 5"/>',
    transfers: '<path d="M4 8h15l-3-3M20 16H5l3 3"/>',
    competitions: '<path d="M8 3h8v5a4 4 0 0 1-8 0z"/><path d="M8 5H4v2a4 4 0 0 0 4 4M16 5h4v2a4 4 0 0 1-4 4M12 12v5M8 21h8"/><path d="M10 17h4v4h-4z"/>',
    calendar: '<rect x="3" y="5" width="18" height="16"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    finances: '<path d="M12 2v20M17 6.5C17 4.6 14.8 3.5 12 3.5S7 4.6 7 6.5s2.2 3.5 5 3.5 5 1.6 5 3.5-2.2 3.5-5 3.5-5-1.1-5-3"/>',
    staff: '<circle cx="12" cy="7" r="3.2"/><path d="M5 21c0-4 3-6.5 7-6.5s7 2.5 7 6.5"/><path d="M3 13l3-3M21 13l-3-3"/>',
    academy: '<path d="M3 9l9-5 9 5-9 5z"/><path d="M7 11v6c0 1 2.2 2.5 5 2.5s5-1.5 5-2.5v-6"/>',
    facilities: '<path d="M3 21V8l6-4v17M9 21V10l6-3v14M15 21V12l6-2v11"/><path d="M2 21h20"/>',
    objectives: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="3.5"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>',
    news: '<path d="M4 4h13v16H4z"/><path d="M17 8h3v9a3 3 0 0 1-3 3M7 8h7M7 12h7M7 16h4"/>',
    history: '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/><path d="M12 7v5l3 2"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.8-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1A1.6 1.6 0 0 0 9 19.4a1.6 1.6 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.8 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1A1.6 1.6 0 0 0 4.6 9a1.6 1.6 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.8.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.8V9a1.6 1.6 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.6 1.6 0 0 0-1.5 1z"/>',
    play: '<path d="M5 3l16 9-16 9z"/>',
    advance: '<path d="M5 4l9 8-9 8M16 4v16"/>',
    chev: '<path d="M9 6l6 6-6 6"/>',
    check: '<path d="M4 12l5 5L20 6"/>',
    swap: '<path d="M4 8h15l-3-3M20 16H5l3 3"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>',
    calendar2: '<rect x="3" y="5" width="18" height="16"/><path d="M3 10h18M8 3v4M16 3v4"/>'
  };
  function icon(name, cls) {
    return '<svg class="' + (cls || '') + '" viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[name] || '') + '</svg>';
  }

  /* ---------------- storage ---------------- */
  var Store = (function () {
    var KEY = 'vgm27.saves.v1', AUTO = 'vgm27.autosave.v1', AVAILABLE = true;
    try { window.localStorage.setItem('vgm27.probe', '1'); window.localStorage.removeItem('vgm27.probe'); }
    catch (e) { AVAILABLE = false; }

    function read(key, fallback) {
      if (!AVAILABLE) return fallback;
      try { var raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; }
      catch (e) { return fallback; }
    }
    function write(key, val) {
      if (!AVAILABLE) return false;
      try { localStorage.setItem(key, JSON.stringify(val)); return true; }
      catch (e) { return false; }
    }
    return {
      available: AVAILABLE,
      list: function () {
        var idx = read(KEY, []);
        return (idx || []).map(function (s) { return { id: s.id, name: s.name, club: s.club, date: s.date, season: s.season, updated: s.updated, badge: s.badge }; })
          .sort(function (a, b) { return (b.updated || 0) - (a.updated || 0); });
      },
      save: function (state) {
        var idx = read(KEY, []);
        idx = idx.filter(function (s) { return s.id !== state.id; });
        idx.push({
          id: state.id, name: state.name, club: state.clubId, date: state.date, season: state.season,
          updated: Date.now(), badge: (state.orgs[state.clubId] && state.orgs[state.clubId].short) || ''
        });
        idx.sort(function (a, b) { return b.updated - a.updated; });
        write(KEY, idx.slice(0, 24));
        if (!write('vgm27.state.' + state.id, state)) return false;
        if (state.settings && state.settings.autoSave) write(AUTO, state);
        return true;
      },
      load: function (id) { return read('vgm27.state.' + id, null); },
      autosave: function () { return read(AUTO, null); },
      remove: function (id) {
        if (!AVAILABLE) return;
        var idx = read(KEY, []).filter(function (s) { return s.id !== id; });
        write(KEY, idx);
        try { localStorage.removeItem('vgm27.state.' + id); } catch (e) { }
      },
      hasAny: function () { return this.list().length > 0 || !!this.autosave(); }
    };
  })();

  function download(filename, text) {
    var blob = new Blob([text], { type: 'application/json' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = filename; document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 500);
  }

  return {
    VERSION: VERSION, DB_SNAPSHOT: DB_SNAPSHOT, ROLES: ROLES, ROLE_INFO: ROLE_INFO, PLAYSTYLES: PLAYSTYLES,
    STYLE_INFO: STYLE_INFO, TRAINING: TRAINING, DIFFICULTY: DIFFICULTY, REGIONS: REGIONS, COUNTRIES: COUNTRIES,
    MAPS: MAPS, ACTIVE_MAP_POOL_2027: ACTIVE_MAP_POOL_2027, RESERVE_MAPS: RESERVE_MAPS, normalizePool: normalizePool,
    AGENTS: AGENTS, AGENT_LIST: AGENT_LIST, MAP_META: MAP_META, TACTIC_PRESETS: TACTIC_PRESETS,
    hash: hash, RNG: RNG, uid: uid, clamp: clamp, avg: avg, sum: sum, round: round, money: money,
    moneyFull: moneyFull, num: num, MONTHS: MONTHS, parseDate: parseDate, iso: iso, addDays: addDays,
    addMonths: addMonths, recordTransaction: recordTransaction,
    diffDays: diffDays, fmtDate: fmtDate, fmtDateLong: fmtDateLong, monthMatrix: monthMatrix, esc: esc,
    titleCase: titleCase, pct: pct, ordinal: ordinal, initials: initials, svgURI: svgURI, monogram: monogram,
    portrait: portrait, portraitImg: portraitImg, logoMarkup: logoMarkup, imgFallback: imgFallback, roleTag: roleTag, flag: flag,
    countryName: countryName, bar: bar, stars: stars, ring: ring, formDots: formDots, icon: icon, ICONS: ICONS,
    Store: Store, download: download
  };
})();
