/* =====================================================================
   VALORANT MANAGER 2027 — UI SHELL / COMPONENTS / EVENTS
   ===================================================================== */
var UI = (function () {
  'use strict';
  var C = Core;
  var U = {
    current: 'dashboard', params: {}, lastSeries: null,
    filters: {
      recruitment: { role: 'all', sort: 'ovr', min: 0, maxAge: 40, search: '', freeOnly: false },
      news: 'all', rosters: { org: 'all', region: 'all', league: 'all', competition: 'all', search: '' }
    },
    calendar: { year: 2026, month: 10 },
    compTab: 'overview', compRegion: 'all', compId: null,
    setup: null,
    setupStep: 1,
    selfTestResult: null,
    audioPanelOpen: false,
    trophyQueue: [],
    trophyCelebrationShowing: false
  };

  function s() { return Game.state; }
  function h(x) { return C.esc(x); }
  function money(n) { return C.money(n); }
  function fullMoney(n) { return C.moneyFull(n); }
  function icon(n, cls) { return C.icon(n, cls); }

  /* ------------------------------------------------------------------
     COMPONENTS
  ------------------------------------------------------------------ */
  U.header = function (title, sub, actions, helpTopic) {
    var guideBtn = helpTopic === false ? '' : U.btn('Guide', 'openHelp', { value: helpTopic || U.current || 'dashboard', cls: 'sm ghost', tip: 'Open tactical & management guide for this section.' });
    return '<div class="page-head"><div><h1 class="page-title">' + h(title) + (sub ? '<small>' + h(sub) + '</small>' : '') + '</h1></div>' +
      '<div class="page-actions">' + guideBtn + (actions || '') + '</div></div>';
  };
  U.panel = function (title, body, actions, cls) {
    return '<div class="panel ' + (cls || '') + '">' +
      '<div class="ph"><div class="ph-t"><i class="sq"></i>' + h(title) + '</div><div class="ph-a">' + (actions || '') + '</div></div>' +
      '<div class="pb">' + body + '</div></div>';
  };
  U.panelFlush = function (title, body, actions, cls) {
    return '<div class="panel ' + (cls || '') + '">' +
      '<div class="ph"><div class="ph-t"><i class="sq"></i>' + h(title) + '</div><div class="ph-a">' + (actions || '') + '</div></div>' +
      '<div class="pb flush">' + body + '</div></div>';
  };
  U.btn = function (label, act, opts) {
    opts = opts || {};
    return '<button class="btn ' + (opts.cls || '') + '" data-act="' + act + '"' +
      (opts.id ? ' data-id="' + h(opts.id) + '"' : '') +
      (opts.page ? ' data-page="' + h(opts.page) + '"' : '') +
      (opts.days ? ' data-days="' + h(opts.days) + '"' : '') +
      (opts.value ? ' data-value="' + h(opts.value) + '"' : '') +
      (opts.tip ? ' data-tip="' + h(opts.tip) + '"' : '') +
      (opts.disabled ? ' disabled' : '') + '>' + (opts.icon ? icon(opts.icon) : '') + h(label) + '</button>';
  };
  U.info = function (text, title) {
    return '<span class="iinfo" data-tip="' + h(text) + '"' + (title ? ' data-tip-title="' + h(title) + '"' : '') + '>i</span>';
  };
  U.tag = function (text, cls) { return '<span class="tag ' + (cls || '') + '">' + h(text) + '</span>'; };
  U.conf = function (conf) {
    var map = { OFFICIAL: 'green', REPORTED: 'blue', LIKELY: 'amber', RUMORED: 'red', UNKNOWN: '', 'FREE AGENT': 'violet', SIM: 'violet' };
    return '<span class="tag ' + (map[conf] || '') + '" title="' + h(conf) + '">' + h(conf || 'UNKNOWN') + '</span>';
  };
  U.kpi = function (label, value, desc, cls) {
    return '<div class="kpi ' + (cls || '') + '"><div class="kl">' + h(label) + '</div><div class="kv">' + value + '</div><div class="kd">' + (desc || '') + '</div></div>';
  };
  U.empty = function (text) { return '<div class="empty">' + h(text) + '</div>'; };
  U.table = function (headers, rows, cls) {
    var head = '<tr>' + headers.map(function (x) { return '<th>' + (x && x.label != null ? x.label : x) + '</th>'; }).join('') + '</tr>';
    var body = Array.isArray(rows) ? rows.join('') : String(rows == null ? '' : rows);
    return '<div class="table-wrap"><table class="tbl ' + (cls || '') + '">' + head + body + '</table></div>';
  };
  U.orgCell = function (org, small) {
    if (!org) return '<span class="dim2">Free agent</span>';
    return '<span class="row" style="gap:6px">' + C.logoMarkup(org, '', small || 18) + '<span class="name">' + h(org.short || org.name) + '</span></span>';
  };
  U.playerLink = function (p, showOrg, orgOverride) {
    if (!p) return '';
    var org = orgOverride !== undefined ? orgOverride : (p.org ? s().orgs[p.org] : null);
    return '<span class="row" style="gap:6px">' + U.avatar(p, org, 22) + C.flag(p.cc) +
      '<a class="link" data-act="openPlayer" data-id="' + p.id + '">' + h(p.nick) + '</a>' +
      (showOrg ? ' <span class="tiny">' + (org ? h(org.short) : 'FA') + '</span>' : '') + '</span>';
  };
  U.avatar = function (p, org, size) {
    return C.portraitImg(p, org, size || 32, 'pavatar', 'border:1px solid var(--line2);border-radius:2px;flex:0 0 auto');
  };
  U.spark = function (values, color, height) {
    height = height || 32;
    if (!values || values.length < 2) return '<div class="sub dim2">Not enough data yet.</div>';
    var min = Math.min.apply(null, values), max = Math.max.apply(null, values);
    var span = (max - min) || 1, w = 160;
    var pts = values.map(function (v, i) { return (i / (values.length - 1) * w).toFixed(1) + ',' + (height - 4 - (v - min) / span * (height - 8)).toFixed(1); }).join(' ');
    return '<svg viewBox="0 0 ' + w + ' ' + height + '" width="100%" height="' + height + '" preserveAspectRatio="none">' +
      '<polyline points="' + pts + '" fill="none" stroke="' + (color || '#ff4655') + '" stroke-width="1.6"/>' +
      '<polyline points="0,' + height + ' ' + pts + ' ' + w + ',' + height + '" fill="' + (color || '#ff4655') + '" opacity=".08" stroke="none"/></svg>';
  };
  U.ring = function (value, color, size) { return C.ring(value, color, size); };
  U.formDots = function (form) { return C.formDots(form || []); };
  U.oddsBar = function (a, b) {
    var total = Math.max(1, a + b);
    var pa = Math.round(a / total * 100), pb = 100 - pa;
    return '<div class="oddsbar"><div style="width:' + pa + '%;background:var(--red)">' + pa + '%</div>' +
      '<div style="width:' + pb + '%;background:#2c4059">' + pb + '%</div></div>';
  };

  /* ------------------------------------------------------------------
     MODALS / TOASTS / TIPS
  ------------------------------------------------------------------ */
  U.modal = function (opts) {
    var root = document.getElementById('modal-root');
    root.innerHTML = '<div class="modal-back" data-act="' + h(opts.closeAction || 'closeModal') + '"></div>' +
      '<div class="modal ' + (opts.size || '') + '">' +
      '<div class="modal-head"><div><div class="modal-title">' + h(opts.title || '') + '</div>' +
      (opts.sub ? '<div class="modal-sub">' + h(opts.sub) + '</div>' : '') + '</div>' +
      '<button class="xbtn" data-act="' + h(opts.closeAction || 'closeModal') + '">✕</button></div>' +
      '<div class="modal-body">' + (opts.body || '') + '</div>' +
      (opts.footer ? '<div class="modal-foot">' + opts.footer + '</div>' : '') + '</div>';
    root.classList.add('open');
    I18N.apply(root);
  };
  U.closeModal = function () {
    var root = document.getElementById('modal-root');
    root.classList.remove('open');
    root.innerHTML = '';
    if (U.trophyCelebrationShowing) { U.trophyQueue = []; U.trophyCelebrationShowing = false; }
  };

  U.renderAudioDock = function () {
    var root = document.getElementById('audio-dock');
    if (!root || !window.VgmAudio) return;
    var a = VgmAudio.getSettings();
    root.innerHTML = '<button class="audio-dock-toggle" data-act="toggleAudioPanel" aria-label="Audio controls" data-tip="Audio controls">' +
      '<span class="audio-dock-glyph">' + (a.musicEnabled || a.sfxEnabled ? '♪' : '♫') + '</span><span class="audio-dock-label">' + h(I18N.t('Audio')) + '</span></button>' +
      '<section class="audio-dock-panel' + (U.audioPanelOpen ? ' open' : '') + '" aria-label="Audio controls">' +
        '<header><div><b>' + h(I18N.t('Audio controls')) + '</b><small>' + h(I18N.t('Game sound')) + '</small></div>' +
          '<button class="audio-dock-close" data-act="toggleAudioPanel" aria-label="Close">✕</button></header>' +
        '<div class="audio-dock-track"><span class="audio-dock-note">♫</span><span title="' + h(a.currentTrackName) + '">' + h(a.currentTrackName) + '</span></div>' +
        '<div class="audio-dock-row"><span>' + h(I18N.t('Music')) + '</span><button class="btn xs ' + (a.musicEnabled ? 'green' : 'ghost') + '" data-act="toggleMusic">' + h(I18N.t(a.musicEnabled ? 'Pause music' : 'Resume music')) + '</button></div>' +
        '<label class="audio-dock-volume"><span>' + h(I18N.t('Music volume')) + '<b id="audioDockMusicValue">' + Math.round(a.musicVolume * 100) + '%</b></span><input type="range" min="0" max="100" value="' + Math.round(a.musicVolume * 100) + '" data-change="audioVolume" data-audio="music" aria-label="' + h(I18N.t('Music volume')) + '"></label>' +
        '<div class="audio-dock-row"><span>' + h(I18N.t('Sound effects')) + '</span><button class="btn xs ' + (a.sfxEnabled ? 'green' : 'ghost') + '" data-act="toggleSfx">' + h(I18N.t(a.sfxEnabled ? 'ON' : 'OFF')) + '</button></div>' +
        '<label class="audio-dock-volume"><span>' + h(I18N.t('Effects volume')) + '<b id="audioDockSfxValue">' + Math.round(a.sfxVolume * 100) + '%</b></span><input type="range" min="0" max="100" value="' + Math.round(a.sfxVolume * 100) + '" data-change="audioVolume" data-audio="sfx" aria-label="' + h(I18N.t('Effects volume')) + '"></label>' +
      '</section>';
    I18N.apply(root);
  };

  function trophyAsset(trophy) {
    var type = trophy && trophy.type;
    if (type === 'champions') return 'assets/trophies/champions.svg';
    if (type === 'masters') return 'assets/trophies/masters.svg';
    return 'assets/trophies/regional.svg';
  }
  U.showNextTrophy = function () {
    var t = U.trophyQueue[0];
    if (!t) { U.trophyCelebrationShowing = false; return; }
    U.trophyCelebrationShowing = true;
    var remaining = U.trophyQueue.length > 1;
    U.modal({
      title: I18N.t('Trophy unlocked'), sub: I18N.t(t.type === 'champions' ? 'WORLD CHAMPION' : t.type === 'masters' ? 'GLOBAL TITLE' : 'VCT TITLE'), size: 'narrow', closeAction: 'dismissTrophies',
      body: '<div class="trophy-celebration"><div class="trophy-glow"></div><img class="trophy-art" src="' + trophyAsset(t) + '" alt="' + h(I18N.t('Trophy')) + '" width="172" height="172" decoding="async"><div class="trophy-copy"><div class="trophy-eyebrow">' + h(I18N.t('CHAMPIONSHIP SECURED')) + '</div><h2>' + h(t.name) + '</h2><p>' + h(I18N.t('Season')) + ' ' + h(t.season) + (t.city ? ' · ' + h(t.city) : '') + '</p></div></div>',
      footer: U.btn(remaining ? 'Next trophy' : 'Continue', 'nextTrophyCelebration', { cls: 'primary' })
    });
  };
  U.enqueueTrophies = function (trophies) {
    (trophies || []).forEach(function (t) { U.trophyQueue.push(t); });
    if (trophies && trophies.length && !U.trophyCelebrationShowing) U.showNextTrophy();
  };
  U.confirm = function (title, body, action, id, danger) {
    U.modal({
      title: title, sub: 'CONFIRM ACTION', size: 'narrow', body: '<div class="sub">' + body + '</div>',
      footer: U.btn('Cancel', 'closeModal', { cls: 'ghost' }) + U.btn('Confirm', action, { cls: danger ? 'danger' : 'primary', id: id })
    });
  };
  U.toast = function (title, body, kind) {
    if (window.VgmAudio) VgmAudio.playFeedback(kind);
    var root = document.getElementById('toast-root');
    var el = document.createElement('div');
    el.className = 'toast ' + (kind || '');
    el.innerHTML = '<b>' + h(title) + '</b>' + (body ? '<span>' + h(body) + '</span>' : '');
    root.appendChild(el);
    I18N.apply(el);
    setTimeout(function () { el.style.opacity = '0'; setTimeout(function () { el.remove(); }, 240); }, 4200);
  };

  function tipFor(el) {
    var tip = document.getElementById('tip');
    tip.innerHTML = (el.getAttribute('data-tip-title') ? '<b>' + h(el.getAttribute('data-tip-title')) + '</b>' : '') + h(el.getAttribute('data-tip') || '');
    I18N.apply(tip);
    tip.hidden = false;
    var r = el.getBoundingClientRect();
    var left = Math.min(window.innerWidth - 270, r.left);
    var top = r.bottom + 7;
    if (top + 90 > window.innerHeight) top = r.top - 82;
    tip.style.left = left + 'px';
    tip.style.top = top + 'px';
  }

  /* ------------------------------------------------------------------
     SHELL
  ------------------------------------------------------------------ */
  var NAV = [
    { group: 'CLUB', items: [['dashboard', 'Dashboard', 'dashboard'], ['squad', 'Squad', 'squad'], ['tactics', 'Tactics', 'tactics'], ['training', 'Training', 'training']] },
    { group: 'RECRUITMENT', items: [['recruitment', 'Recruitment', 'recruitment'], ['transfers', 'Transfers', 'transfers'], ['academy', 'Academy', 'academy']] },
    { group: 'COMPETITION', items: [['competitions', 'Competitions', 'competitions'], ['calendar', 'Calendar', 'calendar']] },
    { group: 'OPERATIONS', items: [['finances', 'Finances', 'finances'], ['staff', 'Staff', 'staff'], ['facilities', 'Facilities', 'facilities'], ['objectives', 'Objectives', 'objectives']] },
    { group: 'WORLD', items: [['news', 'News', 'news'], ['history', 'History', 'history'], ['rosters', 'Live rosters', 'roster']] },
    { group: 'SYSTEM', items: [['settings', 'Settings', 'settings']] }
  ];

  U.nextFixture = function () {
    var st = s(); if (!st) return null;
    if (st.pendingMatch) {
      var comp = st.comps[st.pendingMatch.compId];
      var m = st.pendingMatch.match;
      var oppId = m.a === st.clubId ? m.b : m.a;
      return { pending: true, comp: comp, match: m, opp: st.orgs[oppId], date: st.date, stage: st.pendingMatch.stage || (comp && comp.phase) || 'Match day' };
    }
    var f = Competition.userNextFixture(st);
    if (f) {
      var oppId2 = f.m.a === st.clubId ? f.m.b : f.m.a;
      return { pending: false, comp: f.comp, match: f.m, opp: st.orgs[oppId2], date: f.date, stage: f.stage };
    }
    return null;
  };

  function renderSidebar() {
    var st = s(), org = Game.org();
    var html = '<div class="brand"><div class="brand-mark">V</div><div class="brand-txt"><b>MANAGER 2027</b><span>VCT ECOSYSTEM</span></div></div>' +
      '<div class="clubbox" data-act="go" data-page="squad">' + C.logoMarkup(org, '', 30) +
      '<div style="min-width:0"><div class="cb-name">' + h(org.short || org.name) + '</div>' +
      '<div class="cb-meta">' + h(org.region + ' · ' + (org.partner ? 'PARTNER' : 'OPEN CIRCUIT')) + '</div></div></div>' +
      '<div class="navscroll">';
    NAV.forEach(function (g) {
      html += '<div class="navlabel">' + g.group + '</div>';
      g.items.forEach(function (it) {
        var badge = '';
        if (it[0] === 'news') {
          var unread = st.news.filter(function (n) { return !n.read; }).length;
          if (unread) badge = '<span class="badge">' + unread + '</span>';
        }
        if (it[0] === 'transfers') {
          var inc = (st.incomingOffers || []).length;
          if (inc) badge = '<span class="badge">' + inc + '</span>';
        }
        if (it[0] === 'objectives') {
          var crit = st.objectives.filter(function (o) { return o.status === 'active' && o.importance === 'critical'; }).length;
          if (crit) badge = '<span class="badge">' + crit + '</span>';
        }
        html += '<div class="navitem ' + (U.current === it[0] ? 'active' : '') + '" data-act="go" data-page="' + it[0] + '">' +
          '<span class="ni">' + icon(it[2]) + '</span><span class="nl">' + it[1] + '</span>' + badge + '</div>';
      });
    });
    html += '</div><div class="sidefoot" data-act="go" data-page="objectives"><div class="avatar">' + h(C.initials(st.manager.name)) + '</div>' +
      '<div style="min-width:0"><div class="sf-name">' + h(st.manager.name) + '</div>' +
      '<div class="sf-meta">LVL ' + (st.manager.levelInfo ? st.manager.levelInfo.level : 1) + ' · CONF ' + st.manager.confidence + '</div></div></div>';
    document.getElementById('sidebar').innerHTML = html;
  }

  function renderTopbar() {
    var st = s(), nf = U.nextFixture();
    var dObj = C.parseDate(st.date);
    var weekday = I18N.weekday(dObj.getUTCDay(), false);
    var seasonDone = Competition.seasonComplete(st) && st.date >= (st.season + '-10-20');
    var next = '';
    if (seasonDone) {
      next = '<div class="nextmatch" data-act="seasonReview">' +
        '<div class="nm-txt"><div class="nm-top">SEASON COMPLETE</div>' +
        '<div class="nm-main">Season ' + st.season + ' Review Ready</div>' +
        '<div class="nm-sub">Finalise standings, ageing & start Season ' + (st.season + 1) + '</div></div></div>';
    } else if (nf) {
      next = '<div class="nextmatch" data-act="' + (nf.pending ? 'go' : 'toMatch') + '"' + (nf.pending ? ' data-page="matchday"' : '') + '>' +
        C.logoMarkup(nf.opp, '', 26) +
        '<div class="nm-txt"><div class="nm-top">' + (nf.pending ? 'MATCH DAY' : 'NEXT MATCH · ' + C.fmtDate(nf.date)) + '</div>' +
        '<div class="nm-main">' + h(nf.opp ? nf.opp.short : 'TBD') + '</div>' +
        '<div class="nm-sub">' + h((nf.comp ? nf.comp.short : '') + ' · ' + (nf.stage || '')) + '</div></div></div>';
    } else {
      next = '<div class="nextmatch" data-act="toMatch"><div class="nm-txt"><div class="nm-top">NO FIXTURE</div><div class="nm-main">Advance time</div>' +
        '<div class="nm-sub">The next window or qualifier will appear here</div></div></div>';
    }
    var unread = st.news.filter(function (n) { return !n.read; }).length;
    var pending = !!st.pendingMatch;
    document.getElementById('topbar').innerHTML =
      '<div class="tb-sec tb-date"><div class="tb-lab">' + h('Season ' + st.season) + '</div><div class="tb-val">' + C.fmtDate(st.date) + '</div>' +
      '<div class="tb-sub">' + h(weekday) + '</div></div>' +
      '<div class="tb-sec grow">' + next + '</div>' +
      '<div class="tb-sec optional"><div class="row">' +
      U.btn('+1D', 'advance', { cls: 'sm ghost', days: 1, tip: 'Advance one calendar day.' }) +
      U.btn('+1W', 'advance', { cls: 'sm ghost', days: 7, tip: 'Advance one week. Stops automatically for a match.' }) +
      (seasonDone
        ? U.btn('SEASON REVIEW', 'seasonReview', { cls: 'sm primary', tip: 'Review season results and advance to the next season.' })
        : U.btn(pending ? 'PLAY' : 'TO MATCH', pending ? 'playMatch' : 'toMatch', { cls: 'sm primary', tip: pending ? 'Open the match-day screen.' : 'Advance until your next fixture.' })) +
      U.btn('SKIP', 'openSkipMenu', { cls: 'sm ghost', tip: 'More time-skip options: Next Event, End of Split, End of Season.' }) +
      '</div></div>' +
      '<div class="tb-sec optional"><button class="iconbtn" data-act="go" data-page="news" data-tip="Unread news">' + icon('news') + (unread ? '<i class="dot"></i>' : '') + '</button></div>' +
      '<div class="tb-sec"><div class="savestat" data-tip="Autosave is ' + (st.settings.autoSave ? 'on' : 'off') + '"><i></i>' + (st.settings.autoSave ? 'AUTOSAVE' : 'MANUAL') + '</div></div>' +
      '<div class="tb-sec" style="border-right:0"><div class="row" style="gap:7px;cursor:pointer" data-act="go" data-page="settings">' +
      '<div class="avatar" style="width:28px;height:28px;border:1px solid var(--line2);display:grid;place-items:center;font-family:var(--cond);font-weight:700;color:var(--red)">' + h(C.initials(st.manager.name)) + '</div>' +
      '<div><div class="tb-val" style="font-size:13px">' + h(st.manager.name) + '</div><div class="tb-sub">' + st.manager.wins + 'W ' + st.manager.losses + 'L · ' + h(st.difficulty) + '</div></div></div></div>';
  }

  function renderFooter() {
    var st = s();
    document.getElementById('footerbar').innerHTML =
      '<span>VALORANT MANAGER 2027 <b>v' + C.VERSION + '</b></span>' +
      '<span>DATA SNAPSHOT <b>' + C.DB_SNAPSHOT + '</b></span>' +
      '<span>SEASON <b>' + st.season + '</b></span>' +
      '<span>LAST SAVE <b>' + (st.lastSaved ? new Date(st.lastSaved).toLocaleTimeString() : '—') + '</b></span>' +
      '<span style="margin-left:auto">' + (st.settings.tips ? '<b>GUIDED MODE ON</b> · press ? for shortcuts' : 'GUIDED MODE OFF') + '</span>';
  }

  U.render = function () {
    if (!s()) { U.landing(); return; }
    document.getElementById('app').hidden = false;
    var landing = document.getElementById('landing');
    if (landing) landing.remove();
    renderSidebar(); renderTopbar(); renderFooter();
    var view = document.getElementById('view');
    var fn = Views[U.current] || Views.dashboard;
    try {
      view.innerHTML = fn(U.params || {});
    } catch (e) {
      view.innerHTML = U.header('Something went wrong', 'PAGE ERROR') +
        '<div class="badbox">' + h(String(e && e.message || e)) + '</div>' +
        '<pre class="sub" style="white-space:pre-wrap;margin-top:10px">' + h(String(e && e.stack || '')) + '</pre>';
      if (window.console) console.error(e);
    }
    var pageLabel = U.current.charAt(0).toUpperCase() + U.current.slice(1);
    document.title = 'VGM27 · ' + (I18N.get() === 'en' ? pageLabel : I18N.text(pageLabel));
    U.renderAudioDock();
    I18N.apply(document.body);
  };
  U.route = function (page, params) {
    if (!Views[page]) page = 'dashboard';
    U.current = page;
    U.params = params || {};
    U.render();
    var v = document.getElementById('view'); if (v) v.scrollTop = 0;
  };
  U.refresh = function () { U.render(); };

  /* ------------------------------------------------------------------
     PLAYER / ORG / OFFER MODALS
  ------------------------------------------------------------------ */
  U.playerModal = function (id) {
    var st = s(), p = st.players[id];
    if (!p) return;
    var org = p.org ? st.orgs[p.org] : null;
    var mine = org && org.isUser;
    var attrs = '';
    Engine.CORE_ATTRS.forEach(function (k) {
      attrs += '<div class="attr"><div class="an"><span>' + Engine.ATTR_LABELS[k] + '</span><span>' + Math.round(p.attrs[k]) + '</span></div><div class="bar"><i style="width:' + p.attrs[k] + '%"></i></div></div>';
    });
    var roleAttrs = '';
    Engine.ROLE_ATTRS[p.role].forEach(function (k) {
      roleAttrs += '<div class="attr"><div class="an"><span>' + Engine.ATTR_LABELS[k] + '</span><span>' + Math.round(p.roleAttrs[k]) + '</span></div><div class="bar blue"><i style="width:' + p.roleAttrs[k] + '%"></i></div></div>';
    });
    var agents = (p.agents || []).map(function (a) {
      return '<span class="agentchip main">' + h(a) + '<span class="af">' + Math.round(p.agentFamiliarity[a] || 50) + '</span></span>';
    }).join('');
    var actions = '';
    if (mine) {
      actions = U.btn('Renew contract', 'renewModal', { id: p.id, cls: 'primary' }) +
        (!p.academy ? U.btn(p.transferListed ? 'Manage listing' : 'Transfer list', 'listPlayerModal', { id: p.id, cls: p.transferListed ? 'green' : 'ghost' }) : '') +
        U.btn(p.academy ? 'Promote' : 'Release', p.academy ? 'promotePlayer' : 'releaseModal', { id: p.id, cls: p.academy ? 'green' : 'danger' });
      if (!p.academy && p.age <= 21) actions += U.btn('To academy', 'demotePlayer', { id: p.id, cls: 'ghost' });
      actions += U.btn('Photo', 'playerPhoto', { id: p.id, cls: 'ghost', tip: 'Replace this portrait with your own image. The image is resized and stored inside the career save.' });
    } else {
      actions = U.btn('Scout ($12K)', 'scoutPlayer', { id: p.id, cls: 'ghost' }) + U.btn('Make offer', 'offerModal', { id: p.id, cls: 'primary' });
    }
    var exp = p.contractEnd <= st.season ? '<span class="red">EXPIRING</span>' : p.contractEnd;
    var injTag = p.injury && p.injury.days > 0 ? U.tag('INJURED · ' + p.injury.days + 'd', 'red') : '';
    var listTag = p.transferListed ? U.tag('LISTED · ' + C.money(p.askingPrice || Engine.valueFor(p)), 'amber') : '';
    var histRows = (p.history || []).slice().reverse().slice(0, 6).map(function (hs) {
      return '<tr><td>' + hs.season + '</td><td>' + h(hs.orgName || '—') + '</td><td class="r">' + hs.level + '</td><td class="r">' + ((hs.stats && hs.stats.maps) || 0) + '</td><td class="r">' + ((hs.stats && hs.stats.acs) || 0) + '</td><td class="r">' + ((hs.stats && hs.stats.kd) || 0) + '</td></tr>';
    }).join('');
    U.modal({
      title: p.nick, sub: (p.name || '') + ' · ' + p.role + (p.secondary ? ' / ' + p.secondary : ''),
      size: 'wide',
      body: '<div class="grid g32">' +
        '<div class="col">' +
        '<div class="row" style="gap:12px;align-items:flex-start">' + U.avatar(p, org, 118) +
        '<div style="flex:1"><div class="row between"><div><div class="row">' + C.flag(p.cc) + '<b style="font-family:var(--cond);font-size:21px">' + h(p.nick) + '</b></div>' +
        '<div class="sub">' + h(p.name || '—') + ' · ' + h(C.countryName(p.cc)) + ' · age ' + p.age + '</div></div>' +
        '<div style="text-align:right"><div class="pc-ovr">' + p.level + '<span>OVR</span></div><div class="tiny">POT ' + p.potential + ' ' + C.stars(p.potential) + '</div></div></div>' +
        '<div class="row wrap" style="margin-top:8px;gap:5px">' + U.conf(p.conf) + C.roleTag(p.role) + (p.secondary ? U.tag('2nd: ' + p.secondary, '') : '') + U.tag(p.personality || 'Balanced') +
        (p.igl ? U.tag('IGL', 'amber') : '') + (p.captain ? U.tag('Captain', 'red') : '') + (p.sim ? U.tag('FICTIONAL', 'violet') : '') + injTag + listTag + '</div>' +
        '<div class="divider"></div><div class="split-2"><div class="statline"><span>Club</span><b>' + (org ? h(org.short) : 'Free agent') + '</b></div>' +
        '<div class="statline"><span>Contract</span><b>' + exp + '</b></div>' +
        '<div class="statline"><span>Wage</span><b>' + (p.wage ? C.money(p.wage) + '/yr' : '—') + '</b></div>' +
        '<div class="statline"><span>Market value</span><b>' + C.money(p.value) + '</b></div>' +
        '<div class="statline"><span>Form</span><b>' + Math.round(p.form) + '</b></div>' +
        '<div class="statline"><span>Morale</span><b>' + Math.round(p.morale) + '</b></div>' +
        '<div class="statline"><span>Fatigue</span><b>' + Math.round(p.fatigue) + '%</b></div>' +
        '<div class="statline"><span>Availability</span><b class="' + (p.injury ? 'red' : 'green') + '">' + (p.injury ? h(p.injury.reason || p.injury.type || 'Injury') + ' (' + p.injury.days + 'd)' : 'Available') + '</b></div></div></div></div>' +
        '<div class="muted-box" style="margin-top:9px"><div class="tiny">SOURCE / CONFIDENCE</div><div class="sub">' + h(p.src || p.note || 'No source listed.') + '</div>' +
        (p.note ? '<div class="sub" style="margin-top:4px">' + h(p.note) + '</div>' : '') + '</div>' +
        '<div class="hr-label">AGENTS</div><div class="agentchips">' + agents + '</div>' +
        '<div class="hr-label">SEASON STATISTICS</div>' +
        '<div class="split-2"><div class="statline"><span>Maps</span><b>' + (p.stats.maps || 0) + '</b></div><div class="statline"><span>ACS</span><b>' + (p.stats.acs || 0) + '</b></div>' +
        '<div class="statline"><span>K / D</span><b>' + (p.stats.kills || 0) + ' / ' + (p.stats.deaths || 0) + '</b></div><div class="statline"><span>K:D</span><b>' + (p.stats.kd || 0) + '</b></div>' +
        '<div class="statline"><span>First kills</span><b>' + (p.stats.fk || 0) + '</b></div><div class="statline"><span>MVPs</span><b>' + (p.stats.mvps || 0) + '</b></div></div>' +
        (histRows ? '<div class="hr-label">CAREER HISTORY</div>' + U.table([{ label: 'Season' }, { label: 'Club' }, { label: 'OVR', cls: 'r' }, { label: 'Maps', cls: 'r' }, { label: 'ACS', cls: 'r' }, { label: 'K:D', cls: 'r' }], histRows) : '') +
        '</div>' +
        '<div class="col"><div class="panel"><div class="ph"><div class="ph-t">CORE ATTRIBUTES</div></div><div class="pb">' + attrs + '</div></div>' +
        '<div class="panel"><div class="ph"><div class="ph-t">ROLE ATTRIBUTES</div></div><div class="pb">' + roleAttrs + '</div></div></div>' +
        '</div>',
      footer: actions + U.btn('Close', 'closeModal', { cls: 'ghost' })
    });
  };

  U.offerModal = function (id) {
    var st = s(), p = st.players[id], org = Game.org();
    if (!p) return;
    var dem = Game.demand(id);
    var fin = Game.financeBreakdown();
    var value = p.value;
    var feeDefault = p.org ? dem.fee : 0;
    var bonusDefault = Math.round(dem.wage * 0.1);
    var overBudget = (feeDefault + bonusDefault) > org.budget;
    var overCap = fin && (fin.remainingPayrollBudget - dem.wage) < 0;
    U.modal({
      title: 'Offer for ' + p.nick, sub: p.role + (p.secondary ? ' / ' + p.secondary : '') + ' · OVR ' + p.level + ' · ' + (p.org ? st.orgs[p.org].short : 'FREE AGENT'),
      body: '<div class="grid g2"><div>' +
        '<div class="statline"><span>Player expectation (wage)</span><b>' + C.money(dem.wage) + '/yr</b></div>' +
        '<div class="statline"><span>' + (p.org ? 'Asking price' : 'Transfer fee') + '</span><b>' + (p.org ? C.money(dem.fee) : 'Free') + '</b></div>' +
        '<div class="statline"><span>Market value</span><b>' + C.money(value) + '</b></div>' +
        '<div class="statline"><span>Available budget</span><b>' + C.money(org.budget) + '</b></div>' +
        '<div class="statline"><span>Remaining payroll room</span><b class="' + (overCap ? 'amber' : 'green') + '">' + C.money(fin ? fin.remainingPayrollBudget : 0) + '/yr</b></div>' +
        '<div class="statline"><span>Confidence</span><b>' + U.conf(p.conf) + '</b></div>' +
        '</div><div class="section-note">Wage is annual. Transfer fee plus a 10% signing bonus are deducted immediately from cash budget; wages are paid weekly. ' +
        (overBudget ? '<div class="badbox" style="margin-top:8px">Upfront cost exceeds your current cash budget. Lower the fee or sell a player first.</div>' : overCap ? '<div class="warnbox" style="margin-top:8px">This wage pushes payroll above your sustainable budget cap. Consider releasing or selling a high earner.</div>' : '') +
        '</div></div>' +
        '<div class="divider"></div>' +
        '<div class="split-2">' +
        '<div class="field"><label>Transfer fee ($)</label><input class="inp" id="offFee" type="number" min="0" step="5000" value="' + feeDefault + '"></div>' +
        '<div class="field"><label>Annual wage ($)</label><input class="inp" id="offWage" type="number" min="0" step="1000" value="' + dem.wage + '"></div>' +
        '<div class="field"><label>Contract length (years)</label><select class="inp" id="offYears"><option>1</option><option selected>2</option><option>3</option><option>4</option></select></div>' +
        '<div class="field"><label>Promised role</label><select class="inp" id="offRole"><option value="starter">Starter</option><option value="rotation">Rotation</option><option value="bench">Bench</option></select></div>' +
        '</div>',
      footer: U.btn('Cancel', 'closeModal', { cls: 'ghost' }) + U.btn('Submit offer', 'submitOffer', { id: id, cls: 'primary' })
    });
  };

  U.renewModal = function (id) {
    var st = s(), p = st.players[id];
    if (!p) return;
    var demand = Engine.wageDemand(p, Game.org());
    var fin = Game.financeBreakdown();
    var diffW = demand - (p.wage || 0);
    var capWarn = fin && (fin.remainingPayrollBudget - diffW) < 0;
    U.modal({
      title: 'Renew ' + p.nick, sub: 'CONTRACT EXPIRES ' + p.contractEnd, size: 'narrow',
      body: '<div class="statline"><span>Current wage</span><b>' + C.money(p.wage) + '/yr</b></div>' +
        '<div class="statline"><span>Expected wage</span><b>' + C.money(demand) + '/yr</b></div>' +
        '<div class="statline"><span>Payroll impact</span><b class="' + (diffW > 0 ? 'amber' : 'green') + '">' + (diffW >= 0 ? '+' : '') + C.money(diffW) + '/yr</b></div>' +
        '<div class="statline"><span>Squad morale</span><b>' + Math.round(p.morale) + '</b></div>' +
        (capWarn ? '<div class="warnbox" style="margin-top:8px">Renewal puts annual payroll above your sustainable revenue cap.</div>' : '') +
        '<div class="field" style="margin-top:10px"><label>New annual wage ($)</label><input class="inp" id="renWage" type="number" step="1000" value="' + demand + '"></div>' +
        '<div class="field"><label>Years</label><select class="inp" id="renYears"><option>1</option><option selected>2</option><option>3</option><option>4</option></select></div>' +
        '<div class="sub">The player accepts at 94% of expectation or above. Renewing early protects squad chemistry and avoids free-agent departures.</div>',
      footer: U.btn('Cancel', 'closeModal', { cls: 'ghost' }) + U.btn('Sign contract', 'submitRenew', { id: p.id, cls: 'primary' })
    });
  };

  U.listPlayerModal = function (id) {
    var st = s(), p = st.players[id];
    if (!p) return;
    var est = Engine.valueFor(p);
    var cur = p.askingPrice || Math.max(est, Engine.askingPrice(p));
    U.modal({
      title: 'Transfer List — ' + p.nick, sub: p.role + ' · OVR ' + p.level + ' · MARKET VALUE ' + C.money(est), size: 'narrow',
      body: '<div class="statline"><span>Market valuation</span><b>' + C.money(est) + '</b></div>' +
        '<div class="statline"><span>Annual wage saved if sold</span><b>' + C.money(p.wage) + '/yr</b></div>' +
        '<div class="field" style="margin-top:10px"><label>Asking price ($)</label><input class="inp" id="listAsk" type="number" min="10000" step="5000" value="' + cur + '"></div>' +
        '<div class="sub">Clubs across the ecosystem evaluate listed players weekly and submit bids to your Transfers inbox based on valuation and squad needs.</div>',
      footer: (p.transferListed ? U.btn('Remove from list', 'unlistPlayer', { id: p.id, cls: 'danger' }) : '') +
        U.btn('Cancel', 'closeModal', { cls: 'ghost' }) + U.btn('Save asking price', 'submitListPlayer', { id: p.id, cls: 'primary' })
    });
  };

  U.counterOfferModal = function (offerId) {
    var st = s();
    var offer = (st.incomingOffers || []).filter(function (o) { return o.id === offerId; })[0];
    if (!offer) return;
    var p = st.players[offer.playerId];
    U.modal({
      title: 'Negotiate Offer — ' + (p ? p.nick : ''), sub: offer.buyerName + ' · CURRENT BID ' + C.money(offer.fee), size: 'narrow',
      body: '<div class="statline"><span>Current offer</span><b>' + C.money(offer.fee) + '</b></div>' +
        '<div class="statline"><span>Market value</span><b>' + (p ? C.money(p.value) : '—') + '</b></div>' +
        '<div class="field" style="margin-top:10px"><label>Counter-demand fee ($)</label><input class="inp" id="counterFeeInp" type="number" min="10000" step="5000" value="' + Math.round(offer.fee * 1.15) + '"></div>' +
        '<div class="sub">If your counter fits the buying club budget and valuation ceiling, they accept immediately. Excessive demands can cause talks to collapse.</div>',
      footer: U.btn('Cancel', 'closeModal', { cls: 'ghost' }) + U.btn('Send counter-offer', 'submitCounterOffer', { id: offer.id, cls: 'primary' })
    });
  };

  U.orgModal = function (id) {
    var st = s(), org = st.orgs[id];
    if (!org) return;
    var roster = (org.roster || []).map(function (x) { return st.players[x]; }).filter(Boolean).sort(function (a, b) { return b.level - a.level; });
    var coach = Game.coach(org);
    var rows = roster.map(function (p) {
      return '<tr><td>' + U.playerLink(p, false, org) + '</td><td>' + C.roleTag(p.role) + '</td><td class="r">' + p.level + '</td><td class="r">' + p.age + '</td><td class="r">' + C.money(p.wage) + '</td></tr>';
    });
    U.modal({
      title: org.name, sub: org.region + ' · ' + org.sub + ' · ' + (org.partner ? 'VCT PARTNER' : org.tier.toUpperCase()),
      body: '<div class="row between"><div class="row" style="gap:10px">' + C.logoMarkup(org, 'crest-lg', 64) +
        '<div><div class="statline"><span>Reputation</span><b>' + Math.round(org.rep) + '</b></div><div class="statline"><span>Budget</span><b>' + C.money(org.budget) + '</b></div>' +
        '<div class="statline"><span>Chemistry</span><b>' + Math.round(org.chemistry) + '</b></div><div class="statline"><span>Head coach</span><b>' + (coach ? h(coach.nick) : '—') + '</b></div></div></div>' +
        '<div style="max-width:280px" class="sub">' + h(org.notes || '') + '<div class="tiny" style="margin-top:5px">SOURCE: ' + h(org.source || '—') + '</div></div></div>' +
        '<div class="hr-label">ROSTER STATUS: ' + h(org.rosterStatus || 'UNKNOWN') + '</div>' +
        (rows.length ? U.table([{ label: 'Player' }, { label: 'Role' }, { label: 'OVR' }, { label: 'Age' }, { label: 'Wage' }], rows) : U.empty('No contracted players.')),
      footer: U.btn('Close', 'closeModal', { cls: 'ghost' })
    });
  };

  U.newsModal = function (id) {
    var n = s().news.filter(function (x) { return x.id === id; })[0];
    if (!n) return;
    n.read = true;
    U.modal({
      title: n.title, sub: C.fmtDateLong(n.date) + ' · ' + n.type + ' · importance ' + n.importance,
      body: '<div class="report-block">' + h(n.body) + '</div>',
      footer: U.btn('Close', 'closeModal', { cls: 'ghost' })
    });
  };

  U.lineupModal = function () {
    var st = s(), org = Game.org();
    var roster = Game.roster(org);
    var lineup = org.lineup || [];
    var slots = '';
    for (var i = 0; i < 5; i++) {
      var opts = roster.map(function (p) {
        return '<option value="' + p.id + '"' + (lineup[i] === p.id ? ' selected' : '') + '>' + h(p.nick) + ' · ' + p.role + ' · ' + p.level + '</option>';
      }).join('');
      slots += '<div class="field"><label>Slot ' + (i + 1) + '</label><select class="inp" id="lineup' + i + '">' + opts + '</select></div>';
    }
    U.modal({
      title: 'Starting five', sub: 'ROLE COVERAGE AFFECTS EVERY RATING', size: 'narrow',
      body: '<div class="sub" style="margin-bottom:9px">Pick exactly five players. A natural Duelist, Initiator, Controller and Sentinel is the baseline; duplicates and gaps are penalised in simulation and explained in match reports.</div>' + slots,
      footer: U.btn('Auto-select', 'autoLineup', { cls: 'ghost' }) + U.btn('Cancel', 'closeModal', { cls: 'ghost' }) + U.btn('Save lineup', 'saveLineup', { cls: 'primary' })
    });
  };

  U.matchPreviewModal = function () {
    var nf = U.nextFixture();
    if (!nf || !nf.pending) { U.toast('No match ready', 'Advance time until a fixture is pending.', 'warn'); return; }
    U.route('matchday');
  };

  U.agentModal = function (playerId) {
    var st = s(), p = st.players[playerId];
    if (!p) return;
    var list = C.AGENT_LIST.filter(function (a) { return C.AGENTS[a] === p.role; });
    var opts = list.map(function (a) {
      return '<option value="' + a + '"' + (p.agents[0] === a ? ' selected' : '') + '>' + a + ' · familiarity ' + Math.round(p.agentFamiliarity[a] || 50) + '</option>';
    }).join('');
    U.modal({
      title: 'Assign agent — ' + p.nick, sub: p.role.toUpperCase() + ' POOL', size: 'narrow',
      body: '<div class="field"><label>Primary agent</label><select class="inp" id="agentPick">' + opts + '</select></div>' +
        '<div class="sub">Agent familiarity is trained via Agent Mastery and improves map-specific fit. Picking a non-meta comfort pick is allowed but the report will flag lower utility value.</div>',
      footer: U.btn('Cancel', 'closeModal', { cls: 'ghost' }) + U.btn('Assign', 'submitAgent', { id: p.id, cls: 'primary' })
    });
  };

  /* ------------------------------------------------------------------
     LANDING / SETUP WIZARD & LOGO UPLOADER
  ------------------------------------------------------------------ */
  U.openLogoPicker = function (onDone) {
    var input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/png,image/jpeg,image/webp,.png,.jpg,.jpeg,.webp';
    input.style.display = 'none';
    document.body.appendChild(input);
    input.addEventListener('change', function () {
      var f = input.files && input.files[0];
      if (!f) { input.remove(); return; }
      var okType = /image\/(png|jpeg|webp)/i.test(f.type) || /\.(png|jpe?g|webp)$/i.test(f.name);
      if (!okType) {
        U.toast('Unsupported image', 'Please choose a PNG, JPG, or WEBP file.', 'bad');
        input.remove();
        return;
      }
      var reader = new FileReader();
      reader.onload = function () {
        var img = new Image();
        img.onload = function () {
          var dim = 192;
          var cv = document.createElement('canvas');
          cv.width = dim; cv.height = dim;
          var ctx = cv.getContext('2d');
          var scale = Math.max(dim / img.width, dim / img.height);
          var w = img.width * scale, ht = img.height * scale;
          ctx.drawImage(img, (dim - w) / 2, (dim - ht) / 2, w, ht);
          try {
            onDone(cv.toDataURL('image/png'));
          } catch (err) {
            U.toast('Upload failed', 'Could not process this image.', 'bad');
          }
          input.remove();
        };
        img.onerror = function () { U.toast('Upload failed', 'Invalid image file.', 'bad'); input.remove(); };
        img.src = String(reader.result);
      };
      reader.onerror = function () { U.toast('Upload failed', 'Could not read this file.', 'bad'); input.remove(); };
      reader.readAsDataURL(f);
    });
    input.click();
  };

  U.setupDefaults = function () {
    return {
      managerName: 'Alex Mercer', managerNat: 'gb', managerAge: 34, difficulty: 'Normal', guided: true,
      mode: 'existing', clubId: 'sentinels', region: 'Americas', sub: 'North America',
      orgName: 'Phoenix Ascend', orgShort: 'PHX', city: 'Los Angeles', colors: ['#ff4655', '#0b0d11'], customLogo: null
    };
  };

  /* ------------------------------------------------------------------
     LANGUAGE GATE / SWITCHER
  ------------------------------------------------------------------ */
  U.langChoice = I18N.detect();

  function langCards(selected) {
    return I18N.LANGS.map(function (l) {
      return '<button class="langcard ' + (selected === l.id ? 'on' : '') + '" data-act="pickLanguage" data-value="' + l.id + '">' +
        '<span class="langflag">' + l.flag + '</span><span class="langnative">' + h(l.native) + '</span>' +
        '<span class="langname">' + h(l.name) + '</span><span class="langcode">' + l.short + '</span></button>';
    }).join('');
  }

  U.languageGate = function () {
    var old = document.getElementById('langgate');
    if (old) old.remove();
    var el = document.createElement('div');
    el.id = 'langgate';
    el.className = 'langgate';
    el.innerHTML = '<div class="langgate-card">' +
      '<div class="langgate-brand">VALORANT <span>MANAGER</span> 2027</div>' +
      '<div class="langgate-kicker">FIRST LAUNCH</div>' +
      '<h1>Choose your language</h1>' +
      '<p>Select the language used across the entire game. You can change it at any time in Settings without touching your career.</p>' +
      '<div class="langgrid">' + langCards(U.langChoice) + '</div>' +
      '<div class="langgate-foot"><span class="tiny">' + I18N.LANGS.length + ' languages · ' + h(I18N.t('Available any time in Settings')) + '</span>' +
      '<button class="btn primary" data-act="confirmLanguage">Continue</button></div>' +
      '</div>';
    document.body.appendChild(el);
    document.getElementById('app').hidden = true;
    var landing = document.getElementById('landing');
    if (landing) landing.remove();
    I18N.apply(el);
    U.renderAudioDock();
    return el;
  };

  U.languageModal = function (keepChoice) {
    if (!keepChoice) U.langChoice = I18N.get();
    U.modal({
      title: 'Language', sub: 'INTERFACE · DATES · NUMBER FORMATS', size: 'wide',
      body: '<div class="sub" style="margin-bottom:10px">Changing the language only changes the interface and generated explanations. Career data, saves, attributes, finances and results are never modified.</div>' +
        '<div class="langgrid">' + langCards(U.langChoice) + '</div>',
      footer: U.btn('Cancel', 'closeModal', { cls: 'ghost' }) + U.btn('Apply language', 'applyLanguage', { cls: 'primary' })
    });
    I18N.apply(document.getElementById('modal-root'));
  };

  U.refreshLanguage = function () {
    I18N.set(I18N.get());
    // Re-render from the English source so no stale translated text survives.
    if (s()) { U.render(); }
    else if (document.getElementById('langgate')) { U.languageGate(); }
    else { U.landing(); }
    U.renderAudioDock();
    I18N.apply(document.body);
  };

  function saveCards() {
    var saves = Game.saves();
    var auto = Core.Store.autosave();
    var autoRow = auto ? '<div class="scout-line" style="padding:7px 0"><span class="dotp known"></span>' +
      '<div style="flex:1;min-width:0"><div style="font-family:var(--cond);font-size:14px;font-weight:600">Continue autosave</div>' +
      '<div class="tiny">' + h((auto.orgs && auto.orgs[auto.clubId] ? auto.orgs[auto.clubId].short : 'Career') + ' · season ' + (auto.season || '') + ' · ' + (auto.date || '')) + '</div></div>' +
      '<button class="btn xs primary" data-act="loadAutosave">Continue</button></div>' : '';
    if (!saves.length) return autoRow + '<div class="muted-box sub">No named saves yet. Start a new career on the right.</div>';
    return autoRow + saves.map(function (sv) {
      var org = null;
      var loaded = null;
      var label = sv.badge || 'Career';
      return '<div class="scout-line" style="padding:7px 0"><span class="dotp known"></span>' +
        '<div style="flex:1;min-width:0"><div style="font-family:var(--cond);font-size:14px;font-weight:600">' + h(sv.name || label) + '</div>' +
        '<div class="tiny">' + h((sv.badge || '') + ' · ' + (sv.season || '') + ' · ' + (sv.date || '')) + '</div></div>' +
        '<button class="btn xs primary" data-act="loadSave" data-id="' + h(sv.id) + '">Load</button>' +
        '<button class="btn xs danger" data-act="deleteSave" data-id="' + h(sv.id) + '">✕</button></div>';
    }).join('');
  }

  U.landing = function () {
    if (!U.setup) U.setup = U.setupDefaults();
    var el = document.getElementById('landing');
    if (!el) {
      el = document.createElement('div');
      el.id = 'landing';
      document.body.appendChild(el);
    }
    el.className = 'setup';
    document.getElementById('app').hidden = true;
    var st = U.setup;
    var step = U.setupStep;
    var content = '';

    if (step === 1) {
      var diffs = Object.keys(C.DIFFICULTY).map(function (d) {
        return '<div class="stylecard ' + (st.difficulty === d ? 'on' : '') + '" data-act="setupDiff" data-value="' + d + '">' +
          '<b>' + d + '</b><span>' + C.DIFFICULTY[d].desc + '</span></div>';
      }).join('');
      content = '<div class="hr-label">STEP 1 OF 3 · MANAGER PROFILE</div>' +
        '<div class="grid g2"><div class="field"><label>Manager name</label><input class="inp" data-setup="managerName" value="' + h(st.managerName) + '" maxlength="28"></div>' +
        '<div class="field"><label>Nationality</label><select class="inp" data-setup="managerNat">' +
        Object.keys(C.COUNTRIES).sort(function (a, b) { return C.countryName(a).localeCompare(C.countryName(b)); }).map(function (cc) {
          return '<option value="' + cc + '"' + (st.managerNat === cc ? ' selected' : '') + '>' + C.countryName(cc) + '</option>';
        }).join('') + '</select></div>' +
        '<div class="field"><label>Age</label><input class="inp" type="number" min="24" max="70" data-setup="managerAge" value="' + st.managerAge + '"></div>' +
        '<div class="field"><label>Guidance</label><select class="inp" data-setup="guided"><option value="true"' + (st.guided ? ' selected' : '') + '>Beginner mode — full guidance</option><option value="false"' + (!st.guided ? ' selected' : '') + '>Experienced — reduced tips</option></select></div></div>' +
        '<div class="hr-label">DIFFICULTY</div><div class="stylegrid">' + diffs + '</div>' +
        '<div class="warnbox" style="margin-top:12px">Difficulty changes the challenge only: AI strength, starting budget, wage demands and board patience. It never locks content, pages or mechanics.</div>';
    } else if (step === 2) {
      var regions = C.REGIONS.map(function (r) {
        return '<button class="btn ' + (st.region === r.id ? 'primary' : 'ghost') + '" data-act="setupRegion" data-value="' + r.id + '">' + r.id + '</button>';
      }).join('');
      var orgs = DB.ORGS.filter(function (o) { return o.status !== 'inactive' && o.region === st.region; });
      var grid = orgs.map(function (o) {
        return '<div class="orgcard ' + (st.clubId === o.id ? 'on' : '') + '" data-act="setupClub" data-id="' + o.id + '">' +
          C.logoMarkup(o, '', 30) + '<div><div class="oc-n">' + h(o.short) + '</div><div class="oc-m">' + h(o.sub) + ' · ' + (o.partner ? 'PARTNER' : 'OPEN') + '</div></div>' +
          '<div class="oc-r">' + o.rep + '</div></div>';
      }).join('');
      content = '<div class="hr-label">STEP 2 OF 3 · CHOOSE YOUR PROJECT</div>' +
        '<div class="segmented" style="margin-bottom:12px"><button class="' + (st.mode === 'existing' ? 'on' : '') + '" data-act="setupMode" data-value="existing">Existing organisation</button>' +
        '<button class="' + (st.mode === 'new' ? 'on' : '') + '" data-act="setupMode" data-value="new">Found a new club</button></div>';
      if (st.mode === 'existing') {
        content += '<div class="row wrap" style="margin-bottom:9px">' + regions + '</div><div class="orgpick">' + grid + '</div>' +
          '<div class="sub" style="margin-top:8px">Partner status guarantees Kickoff entry only. Non-partners must earn their place through the Open Qualifier. Reputation shown 0–99.</div>';
      } else {
        var previewMarkup = st.customLogo
          ? '<img src="' + st.customLogo + '" alt="Logo preview">'
          : C.monogram(st.orgShort || st.orgName || 'NEW', st.colors[0], 56);
        content += '<div class="grid g2">' +
          '<div class="field"><label>Organisation name</label><input class="inp" data-setup="orgName" value="' + h(st.orgName) + '" maxlength="34"></div>' +
          '<div class="field"><label>Short tag (2–5)</label><input class="inp" data-setup="orgShort" value="' + h(st.orgShort) + '" maxlength="5"></div>' +
          '<div class="field"><label>Region</label><select class="inp" data-setup="region">' + C.REGIONS.map(function (r) { return '<option' + (st.region === r.id ? ' selected' : '') + '>' + r.id + '</option>'; }).join('') + '</select></div>' +
          '<div class="field"><label>Sub-region</label><select class="inp" data-setup="sub">' +
          (C.REGIONS.filter(function (r) { return r.id === st.region; })[0] || C.REGIONS[0]).subs.map(function (x) {
            return '<option' + (st.sub === x ? ' selected' : '') + '>' + x + '</option>';
          }).join('') + '</select></div>' +
          '<div class="field"><label>Home city</label><input class="inp" data-setup="city" value="' + h(st.city) + '"></div>' +
          '<div class="field"><label>Primary colour</label><div class="colorpick"><input type="color" data-setup="color0" value="' + st.colors[0] + '"><input type="color" data-setup="color1" value="' + st.colors[1] + '"></div></div>' +
          '<div class="field span2"><label>Custom club logo (PNG, JPG or WEBP)</label>' +
          '<div class="logo-upload-box"><div class="logo-preview">' + previewMarkup + '</div>' +
          '<div style="flex:1;min-width:0"><div class="sub">' + (st.customLogo ? 'Custom logo uploaded, cropped and ready across all screens.' : 'Optional. Upload a PNG, JPG or WEBP emblem or keep the auto-generated club monogram.') + '</div>' +
          '<div class="row" style="margin-top:6px">' + U.btn(st.customLogo ? 'Replace logo' : 'Upload logo', 'pickSetupLogo', { cls: 'sm ghost' }) +
          (st.customLogo ? U.btn('Remove logo', 'removeSetupLogo', { cls: 'sm danger' }) : '') + '</div></div></div></div>' +
          '</div><div class="warnbox">New clubs start with a competitive budget, five generated players (clearly marked SIM) and a clean slate. You are not a 2027 partner: the Open Qualifier is your route in.</div>';
      }
    } else {
      var org = st.mode === 'existing' ? DB.ORGS.filter(function (o) { return o.id === st.clubId; })[0] : null;
      var newLogoPreview = st.customLogo
        ? '<img src="' + st.customLogo + '" alt="Club logo" style="width:56px;height:56px;object-fit:cover;border:1px solid var(--line2);border-radius:3px">'
        : C.monogram(st.orgShort || st.orgName || 'NEW', st.colors[0], 56);
      content = '<div class="hr-label">STEP 3 OF 3 · CONFIRM</div><div class="grid g2">' +
        '<div>' + U.panel('MANAGER', '<div class="statline"><span>Name</span><b>' + h(st.managerName) + '</b></div>' +
          '<div class="statline"><span>Nationality</span><b>' + C.countryName(st.managerNat) + '</b></div>' +
          '<div class="statline"><span>Age</span><b>' + st.managerAge + '</b></div>' +
          '<div class="statline"><span>Difficulty</span><b>' + h(st.difficulty) + '</b></div>' +
          '<div class="statline"><span>Guidance</span><b>' + (st.guided ? 'Beginner mode' : 'Reduced') + '</b></div>') + '</div>' +
        '<div>' + U.panel('PROJECT', (org ?
          '<div class="row" style="gap:9px">' + C.logoMarkup(org, 'crest-lg', 56) + '<div><div class="page-title" style="font-size:27px">' + h(org.name) + '</div>' +
          '<div class="tiny">' + h(org.region + ' · ' + org.sub) + '</div></div></div>' +
          '<div class="statline" style="margin-top:7px"><span>Status</span><b>' + (org.partner ? 'VCT Partner' : 'Open circuit') + '</b></div>' +
          '<div class="statline"><span>Reputation</span><b>' + Math.round(org.rep) + '</b></div>' +
          '<div class="statline"><span>Roster confidence</span><b>' + h(org.rosterStatus || 'UNKNOWN') + '</b></div>' +
          '<div class="statline"><span>Starting budget</span><b>' + C.money(Math.round(org.budget * (C.DIFFICULTY[st.difficulty] || C.DIFFICULTY.Normal).money)) + '</b></div>'
          : '<div class="row" style="gap:9px">' + newLogoPreview + '<div><div class="page-title" style="font-size:27px">' + h(st.orgName) + '</div><div class="tiny">' + h(st.region + ' · ' + st.sub) + '</div></div></div>' +
          '<div class="statline" style="margin-top:7px"><span>Status</span><b>New non-partner</b></div><div class="statline"><span>Route</span><b>Open Qualifier</b></div>' +
          '<div class="statline"><span>Starting budget</span><b>' + C.money(Math.round(280000 * (C.DIFFICULTY[st.difficulty] || C.DIFFICULTY.Normal).money)) + '</b></div>')) + '</div>' +
        '</div>' +
        '<div class="guidance" style="margin-top:12px"><h4>Your first week</h4><p>Set a training focus, check the tactical style against your roster, then advance to your first fixture. The board objectives and the assistant recommendations on the dashboard always explain the next highest-value action.</p></div>' +
        '<div class="muted-box" style="margin-top:10px"><div class="tiny">DATA HONESTY</div><div class="sub">Rosters are a 17 November 2026 snapshot. OFFICIAL means confirmed; REPORTED, LIKELY and RUMORED are not official. Fictional fillers are marked SIM/FICTIONAL and can be replaced.</div></div>';
    }

    var leftSaves = saveCards();
    el.innerHTML = '<div class="setup-left">' +
      '<div class="setup-logo">VALORANT<br><span>MANAGER</span> 2027</div>' +
      '<div class="setup-tag">THE ESPORTS MANAGEMENT SIMULATION</div>' +
      '<div class="setup-h">RUN THE<br>ECOSYSTEM.</div>' +
      '<div class="setup-p">Build a roster. Master the 2027 VCT calendar. Explain every result. From the Open Qualifier to Champions, every decision compounds across a career that can last twenty seasons.</div>' +
      '<div class="setup-list">' +
      '<div class="setup-step on"><span class="snum">01</span><div><b>Real 2027 ecosystem</b><br>32 partners, Open Qualifiers, China visitors, Pacific LCQ and the full international calendar.</div></div>' +
      '<div class="setup-step"><span class="snum">02</span><div><b>Deep but legible</b><br>Every rating decomposes. Every defeat explains why and links the fix to the right page.</div></div>' +
      '<div class="setup-step"><span class="snum">03</span><div><b>Careers that persist</b><br>Transfers, contracts, academies, retirements, history and hall of fame across 20+ seasons.</div></div>' +
      '</div>' +
      '<div style="flex:1"></div>' +
      '<div class="row" style="margin-bottom:9px"><button class="btn sm ghost wide" data-act="openLanguageModal">🌐 ' + h(I18N.langMeta(I18N.get()).native) + ' · ' + h(I18N.text('Language')) + '</button></div>' +
      '<div class="hr-label">SAVED CAREERS</div>' + leftSaves +
      '<div class="row" style="margin-top:7px"><button class="btn sm ghost wide" data-act="importClick">Import save file</button></div>' +
      '<div class="tiny" style="margin-top:8px">v' + C.VERSION + ' · data ' + C.DB_SNAPSHOT + '</div>' +
      '</div>' +
      '<div class="setup-right"><div class="setup-panel">' +
      '<div style="padding:16px 16px 0"><div class="row between"><div class="row">' +
      ['PROFILE', 'CLUB', 'CONFIRM'].map(function (x, i) {
        return '<span class="tag ' + (step === i + 1 ? 'red' : '') + '">' + (i + 1) + ' ' + x + '</span>';
      }).join('') + '</div><button class="btn sm ghost" data-act="landingReset">Reset</button></div></div>' +
      '<div style="padding:6px 16px 16px">' + content + '</div>' +
      '<div class="setup-foot"><div class="sub">' + (step === 1 ? 'Profile and challenge settings.' : step === 2 ? 'Pick an existing project or found your own.' : 'Review and begin. You can change most settings later.') + '</div>' +
      '<div class="row">' + (step > 1 ? '<button class="btn ghost" data-act="setupBack">Back</button>' : '') +
      (step < 3 ? '<button class="btn primary" data-act="setupNext">Continue</button>' : '<button class="btn primary" data-act="startCareer">' + icon('play') + ' START CAREER</button>') + '</div></div>' +
      '</div></div>';
    var file = document.getElementById('importFile');
    if (!file) {
      file = document.createElement('input');
      file.type = 'file'; file.id = 'importFile'; file.accept = '.json,application/json'; file.style.display = 'none';
      document.body.appendChild(file);
      file.addEventListener('change', function () {
        var f = file.files && file.files[0];
        if (!f) return;
        var reader = new FileReader();
        reader.onload = function () {
          try {
            Game.importSave(String(reader.result));
            U.start();
            U.toast('Save imported', 'Career restored successfully.', 'good');
          } catch (e) { U.toast('Import failed', String(e.message || e), 'bad'); }
        };
        reader.onerror = function () { U.toast('Import failed', 'Could not read the selected file.', 'bad'); };
        reader.readAsText(f);
        file.value = '';
      });
    }
    I18N.apply(el);
    U.renderAudioDock();
  };

  U.start = function () {
    var landing = document.getElementById('landing');
    if (landing) landing.remove();
    document.getElementById('app').hidden = false;
    U.route('dashboard');
  };

  U.loadAndStart = function (id) {
    var st = Game.load(id);
    if (!st) { U.toast('Save not found', 'The career could not be loaded.', 'bad'); return; }
    U.start();
    U.toast('Career loaded', st.orgs[st.clubId].name + ' · ' + st.date, 'good');
  };

  /* ------------------------------------------------------------------
     CONTEXTUAL HELP GUIDE, TIME-SKIP & SEASON REVIEW MODALS
  ------------------------------------------------------------------ */
  var HELP_TOPICS = {
    dashboard: {
      title: 'Overview & Player Attributes', page: 'dashboard',
      what: 'The dashboard aggregates Team Rating, Role Balance, Chemistry, Finance Health, Next Match, and Board Objectives.',
      why: 'Match outcomes come directly from these eight components — Skill, Chemistry, Role Balance, Agent Fit, Coaching, Map Preparation, Form, Morale, minus Fatigue.',
      how: 'Check "What to do next" each week. Keep Aim, Mechanics, Gamesense, and Communication sharp while fielding all four natural roles.',
      consequence: 'Ignoring fatigue above 55% or a missing role silently drops your effective rating by 3 to 6 points per series.'
    },
    squad: {
      title: 'Squad, Roles, Injuries & Contracts', page: 'squad',
      what: 'Manage your starting five, bench, role balance, injury recovery, contract expirations, and transfer listings.',
      why: 'A legal lineup requires five healthy players covering Duelist, Initiator, Controller, and Sentinel.',
      how: 'Rotate tired players onto the bench, renew expiring contracts before November, and transfer-list surplus players from their profile.',
      consequence: 'Expiring players leave for free at season end; forcing an injured player into the lineup reduces their series output.'
    },
    tactics: {
      title: 'Tactics, Map Pool & Veto', page: 'tactics',
      what: 'Configure tactical style, primary agents, map pool (7 competitive maps), and veto picks/bans.',
      why: 'In 2027, only the 7 competitive maps are legal in brackets. Preparation decides close BO3 maps and veto bans let you dodge weak maps.',
      how: 'Pick a tactical style matching your Duelist/Sentinel core, assign meta agents with high familiarity, and set up to 3 Pick & 3 Ban preferences.',
      consequence: 'Using a high-aggression style with a passive roster leaks defensive rounds and overtime comebacks.'
    },
    training: {
      title: 'Training, Chemistry & Fatigue', page: 'training',
      what: 'Every Monday the staff executes your Primary focus, Secondary focus, and Intensity plan across first-team and academy players.',
      why: 'Young players grow fastest when potential > OVR. Chemistry raises trading and utility coordination across all maps.',
      how: 'Use Team Coordination after roster changes, Map Control before key events, and switch to Light before tournaments or if fatigue passes 55%.',
      consequence: 'Intense schedules above 60% fatigue risk minor wrist/hand strains that sideline starters for 4 to 10 days.'
    },
    recruitment: {
      title: 'Scouting & Recruitment', page: 'recruitment',
      what: 'Browse free agents and contracted targets across every region, scout true demands, and submit contract offers.',
      why: 'Scouting ($12K) removes uncertainty and reveals exact wage demands and transfer fees before negotiation.',
      how: 'Filter by Role, OVR, Age, or Free Agents Only. Prioritize secondary roles for flexibility and potential stars on long contracts.',
      consequence: 'Overpaying above your wage structure squeezes future renewals and weakens board confidence.'
    },
    transfers: {
      title: 'Transfer Market & Selling Players', page: 'transfers',
      what: 'List your own players with custom asking prices, respond to incoming AI bids (Accept / Counter / Reject), and buy listed targets.',
      why: 'Selling surplus or ageing players raises transfer income and frees up annual payroll before contracts expire for free.',
      how: 'Open any player profile and click Transfer List. Incoming bids arrive in Transfers; counter reasonably to squeeze 10–25% extra cash.',
      consequence: 'Demanding well above a buyer ceiling ends talks; selling without a 5th replacement or academy graduate is blocked to protect lineup legality.'
    },
    competitions: {
      title: 'Competitions & VCT Qualification', page: 'competitions',
      what: 'Track Open Qualifiers, Kickoff (12 teams), Cup 1, Cup 2, Masters 1 & 2, Pacific LCQ, and Champions.',
      why: 'Top 3 at Kickoff reach Masters 1; Cup 1 top 4 reach Masters 2; Cup 2 top 4 reach Champions.',
      how: 'Partners enter Kickoff directly. Non-partners must win Open Qualifiers to qualify and earn $100K–$400K qualification bonuses.',
      consequence: 'Missing Kickoff or Cup 1 locks you out of international prize money ($1M Masters, $2.25M Champions) and sponsor bonuses.'
    },
    calendar: {
      title: 'Time Controls & Multi-Season Flow', page: 'calendar',
      what: 'Advance 1 Day, 1 Week, to Next Match, to Next Event, to End of Split, or to End of Season.',
      why: 'Every day simulated updates training, fatigue recovery, injuries, sponsor instalments, weekly wages, transfers, and AI brackets.',
      how: 'Use +1D/+1W for fine-grained fatigue prep, or Skip to Split/Season for faster pacing with a detailed post-skip summary.',
      consequence: 'At season completion, open Season Review to process retirements, youth intakes, map rotation, and transition smoothly into the next year.'
    },
    finances: {
      title: 'Finances, Sponsorships & Payroll Rules', page: 'finances',
      what: 'Monitor Available Budget, Monthly Income vs Expenses, Remaining Payroll Budget, Sponsorship Contracts, and Financial Warnings.',
      why: 'Keeping positive cash and sustainable payroll prevents board pressure and funds facility upgrades and star buyouts.',
      how: 'Maintain active sponsors, negotiate up to once per offer, hit sponsor milestone objectives, and keep player payroll inside the sustainable cap.',
      consequence: 'Sustained deficits reduce cash below zero, trigger board warnings, and block buyout transfers.'
    },
    objectives: {
      title: 'Board Objectives & Confidence', page: 'objectives',
      what: 'Track season-long sporting and financial targets assigned by club leadership.',
      why: 'Board Confidence drives manager XP, reputation, and job security at each end-of-season review.',
      how: 'Focus on CRITICAL objectives first. Each objective links directly to the page where you can influence it.',
      consequence: 'Failing critical targets slashes confidence by 10+ points and hurts sponsor renewal values.'
    },
    academy: {
      title: 'Academy Pipeline', page: 'academy',
      what: 'Develop 16–21 year-old prospects at a discounted youth wage and promote them when ready.',
      why: 'Academy graduates provide inexpensive bench cover and zero-fee replacements when starters retire or are sold.',
      how: 'Upgrade the Academy facility for stronger annual intakes; promote ready players (OVR 70+) or send young subs down for development.',
      consequence: 'Neglecting youth leaves you forced into expensive transfer fees when veterans decline.'
    },
    staff: {
      title: 'Coaching Staff & Support', page: 'staff',
      what: 'Appoint Head Coaches, Analysts, Performance Coaches, and Scouts from the market.',
      why: 'Your highest-graded coach directly boosts match Coaching rating and multiplies weekly Training gains; Analysis boosts Map Prep.',
      how: 'Compare Coaching, Development, and Analysis scores before hiring. Release low-grade staff to recover weekly salary.',
      consequence: 'Operating without a Head Coach caps development at a weak baseline and lowers team rating.'
    },
    facilities: {
      title: 'Club Facilities', page: 'facilities',
      what: 'Invest in Training Centre, Recovery Suite, Analysis Lab, and Academy (Levels 1–5).',
      why: 'Permanent passive multipliers across player growth, daily fatigue healing, map prep, and youth intake ceiling.',
      how: 'Upgrade Training or Recovery first if you have a young or fatigued squad; keep enough cash reserve for weekly wages.',
      consequence: 'Each level increases weekly upkeep; over-spending on level-4/5 buildings before securing sponsors strains cashflow.'
    },
    history: {
      title: 'Career History & Hall of Fame', page: 'history',
      what: 'Explore season-by-season archives, trophies, MVP awards, champions, and retired legends.',
      why: 'Tracks long-term continuity across 20+ seasons without losing player season stats or club milestones.',
      how: 'Finish seasons via Season Review to record placements, player stat archives, and seasonal map pool changes.',
      consequence: 'Every transfer, title, and retirement remains permanently linked in club records.'
    },
    news: {
      title: 'News & Inbox', page: 'news',
      what: 'Central log for incoming transfer bids, injuries, sponsor expiries, contract warnings, and tournament results.',
      why: 'Critical alerts warn you weeks before contracts or sponsor deals expire.',
      how: 'Filter by Transfer, Squad, or Finance tabs to spot urgent decisions quickly.',
      consequence: 'Missing expiry warnings costs free-agent departures or unrenewed commercial income.'
    },
    rosters: {
      title: 'Live Team Rosters', page: 'rosters',
      what: 'Browse every active organization using the players, lineups, staff and contracts in this career save.',
      why: 'Transfers, releases, academy promotions, retirements and calendar progression update this directory from the simulation.',
      how: 'Filter by organization, region, league or competition, then expand a team to inspect starters, reserves, agents and contract status.',
      consequence: 'The directory is rebuilt from the current save each time it opens, so it follows the in-game date and roster changes.'
    },
    settings: {
      title: 'Settings, Custom Logo & Saves', page: 'settings',
      what: 'Upload/replace your club logo, switch EN/FR language cleanly without data loss, export/import JSON saves, and run multi-season diagnostics.',
      why: 'Protects career saves across sessions and lets you customize club branding anytime.',
      how: 'Upload PNG/JPG/WEBP emblems directly here, export backups before risky windows, or run Self-Test to verify multi-season stability.',
      consequence: 'Custom logos and language settings save immediately and persist across reloads.'
    }
  };

  U.helpModal = function (topicKey) {
    var key = HELP_TOPICS[topicKey] ? topicKey : (HELP_TOPICS[U.current] ? U.current : 'dashboard');
    var t = HELP_TOPICS[key];
    var tabs = Object.keys(HELP_TOPICS).map(function (k) {
      return '<button class="btn xs ' + (k === key ? 'primary' : 'ghost') + '" data-act="pickHelp" data-value="' + k + '">' + h(k.toUpperCase()) + '</button>';
    }).join('');
    U.modal({
      title: t.title, sub: 'MANAGEMENT GUIDE · WHAT · WHY · HOW', size: 'wide',
      body: '<div class="help-nav">' + tabs + '</div>' +
        '<div class="help-section"><h4>What It Does</h4><p>' + h(t.what) + '</p></div>' +
        '<div class="help-section"><h4>Why It Matters</h4><p>' + h(t.why) + '</p></div>' +
        '<div class="help-section"><h4>How To Use It</h4><p>' + h(t.how) + '</p></div>' +
        '<div class="help-section"><h4>Consequences & Risks</h4><p>' + h(t.consequence) + '</p></div>',
      footer: U.btn('Open ' + t.page, 'goClose', { page: t.page, cls: 'primary' }) + U.btn('Close', 'closeModal', { cls: 'ghost' })
    });
  };

  U.skipMenuModal = function () {
    var st = s();
    if (!st) return;
    var split = Game.splitInfo(st);
    U.modal({
      title: 'Advance Time', sub: 'CURRENT DATE · ' + C.fmtDateLong(st.date) + ' · ' + split.name, size: 'wide',
      body: '<div class="skip-grid">' +
        '<button class="skip-opt" data-act="doSkip" data-value="day"><b>+1 Day</b><span>Simulate training recovery, injuries, daily sponsorship and competition dates.</span></button>' +
        '<button class="skip-opt" data-act="doSkip" data-value="week"><b>+1 Week</b><span>Advance 7 days with weekly wages, Monday training, and market checks. Pauses on matches.</span></button>' +
        '<button class="skip-opt" data-act="doSkip" data-value="match"><b>Next Match</b><span>Advance day by day until your next scheduled series is ready to play.</span></button>' +
        '<button class="skip-opt" data-act="doSkip" data-value="event"><b>Next Important Event</b><span>Advance until a match, incoming transfer bid, injury, or competition completion.</span></button>' +
        '<button class="skip-opt" data-act="confirmSkip" data-value="split"><b>End of Current Split (' + h(C.fmtDate(split.endDate)) + ')</b><span>Full simulation of all matches, training, finances and AI transfers until ' + h(split.name) + ' finishes.</span></button>' +
        '<button class="skip-opt" data-act="confirmSkip" data-value="season"><b>End of Entire Season (' + st.season + ')</b><span>Full-season simulation through Champions. Prepares Season Review and transitions to ' + (st.season + 1) + '.</span></button>' +
        '</div>' +
        '<div class="sub" style="margin-top:10px">Every skip runs full day-by-day logic: matches, training, player growth, fatigue, injuries, transfers, wages, sponsors, contracts and news are always simulated.</div>',
      footer: U.btn('Close', 'closeModal', { cls: 'ghost' })
    });
  };

  U.skipConfirmModal = function (mode) {
    var st = s();
    var split = Game.splitInfo(st);
    var label = mode === 'season' ? 'End of Season ' + st.season : split.name + ' (' + C.fmtDate(split.endDate) + ')';
    U.modal({
      title: 'Confirm Long Simulation', sub: label.toUpperCase(), size: 'narrow',
      body: '<div class="warnbox">All intermediate days, matches, training weeks, injuries, contracts, weekly salaries and sponsorship payments will be simulated automatically. Any pending fixtures during this window will be simulated with your active lineup and tactics.</div>' +
        '<div class="sub" style="margin-top:9px">Simulation pauses automatically if severe club insolvency occurs. You will receive a complete summary afterwards.</div>',
      footer: U.btn('Cancel', 'openSkipMenu', { cls: 'ghost' }) + U.btn('Simulate now', 'doSkipConfirmed', { value: mode, cls: 'primary' })
    });
  };

  U.skipSummaryModal = function (sum) {
    if (!sum) return;
    var matchRows = (sum.userMatches || []).map(function (m) {
      return '<div class="scout-line"><span class="dotp ' + (m.won ? 'known' : '') + '"></span><div style="flex:1"><b>' + h(m.comp) + ' · vs ' + h(m.oppName) + '</b><div class="tiny">' + C.fmtDate(m.date) + ' · ' + h(m.stage) + '</div></div>' +
        '<span class="tag ' + (m.won ? 'green' : 'red') + '">' + (m.won ? 'W ' : 'L ') + h(m.score) + '</span></div>';
    }).join('');
    var injText = (sum.injuries || []).length ? sum.injuries.map(function (i) { return i.nick + ' (' + i.days + 'd)'; }).join(', ') : 'None';
    var offerText = (sum.offersReceived || []).length ? sum.offersReceived.map(function (o) { return o.buyerName + ' → ' + o.nick + ' (' + C.money(o.fee) + ')'; }).join('; ') : 'None';
    var foot = U.btn('Close', 'closeModal', { cls: 'ghost' });
    if (sum.seasonComplete) foot = U.btn('Open Season Review', 'seasonReview', { cls: 'primary' }) + foot;
    else if (sum.pendingMatch) foot = U.btn('Open Match Day', 'goClose', { page: 'matchday', cls: 'primary' }) + foot;
    else if ((sum.offersReceived || []).length) foot = U.btn('Review Offers', 'goClose', { page: 'transfers', cls: 'primary' }) + foot;

    U.modal({
      title: 'Simulation Summary', sub: C.fmtDate(sum.fromDate) + ' → ' + C.fmtDate(sum.toDate) + ' (' + sum.days + ' DAYS)', size: 'wide',
      body: '<div class="grid g4" style="margin-bottom:10px">' +
        U.kpi('Days simulated', String(sum.days), h(sum.stopReason || 'Completed'), '') +
        U.kpi('Your series', String((sum.userMatches || []).length), sum.aiMatchesCount + ' world matches', '') +
        U.kpi('Training weeks', String(sum.trainingRuns || 0), 'Injuries: ' + h(injText), (sum.injuries || []).length ? 'amber' : '') +
        U.kpi('Net finances', (sum.netFinance >= 0 ? '+' : '') + C.money(sum.netFinance), 'Balance ' + C.money(sum.budgetEnd), sum.netFinance >= 0 ? 'green' : 'red') +
        '</div>' +
        ((sum.offersReceived || []).length ? '<div class="warnbox" style="margin-bottom:8px"><b>Incoming Transfer Bids:</b> ' + h(offerText) + '</div>' : '') +
        ((sum.completions || []).length ? '<div class="goodbox" style="margin-bottom:8px"><b>Completed Competitions:</b> ' + sum.completions.map(function (c) { return h(c.name + (c.championName ? ' (' + c.championName + ')' : '')); }).join(', ') + '</div>' : '') +
        '<div class="hr-label">YOUR MATCHES DURING SKIP</div>' +
        (matchRows || '<div class="sub">No user series played during this interval.</div>'),
      footer: foot
    });
  };

  U.seasonReviewModal = function () {
    var st = s();
    if (!st) return;
    if (!Competition.seasonComplete(st) && !st.lastSeasonSummary) {
      U.toast('Season still active', 'Complete or skip to the end of the season first.', 'warn');
      return;
    }
    if (Competition.seasonComplete(st)) {
      Game.seasonTransition();
      st = s();
      U.updateCal();
    }
    var sum = st.lastSeasonSummary;
    if (!sum) { U.render(); return; }
    U.modal({
      title: 'Season ' + sum.season + ' Complete — Welcome to ' + sum.nextSeason, sub: 'END-OF-SEASON SUMMARY · WORLD PROGRESSION', size: 'wide',
      body: '<div class="grid g4" style="margin-bottom:10px">' +
        U.kpi('World Champion', h(sum.championName || '—'), 'Champions ' + sum.season, 'amber') +
        U.kpi('Trophies Won', String((sum.userTrophies || []).length), (sum.userTrophies || []).map(function (t) { return t.name; }).join(', ') || 'No title', (sum.userTrophies || []).length ? 'green' : '') +
        U.kpi('Board Objectives', sum.objsDone + '/' + (sum.objsDone + sum.objsFailed), 'Confidence ' + sum.confidence + '/100', sum.confidence >= 60 ? 'green' : 'amber') +
        U.kpi('Carryover Budget', C.money(sum.budget), 'Payroll ' + C.money(sum.payroll) + '/yr', sum.budget >= 0 ? 'green' : 'red') +
        '</div>' +
        (sum.mapRotation ? '<div class="guidance" style="margin-bottom:9px"><h4>Competitive Map Pool Update</h4><p>' + h(sum.mapRotation.out) + ' rotated out of the 7-map competitive circuit and ' + h(sum.mapRotation.in) + ' entered active duty for ' + sum.nextSeason + '. Visit Tactics to train your new map.</p></div>' : '') +
        '<div class="statline"><span>World retirements processed</span><b>' + sum.retiredCount + '</b></div>' +
        '<div class="statline"><span>Academy youth prospects recruited</span><b>' + sum.youthCount + '</b></div>' +
        '<div class="statline"><span>Roster, finances, history & custom logo</span><b class="green">Preserved</b></div>',
      footer: U.btn('Start Season ' + sum.nextSeason, 'closeModalRefresh', { cls: 'primary' })
    });
  };

  /* ------------------------------------------------------------------
     ACTIONS
  ------------------------------------------------------------------ */
  U.act = function (act, el) {
    var st = s();
    var id = el ? el.getAttribute('data-id') : null;
    var page = el ? el.getAttribute('data-page') : null;
    var value = el ? el.getAttribute('data-value') : null;
    var days = el ? el.getAttribute('data-days') : null;
    if (!st && ['go', 'loadSave', 'deleteSave', 'startCareer', 'setupNext', 'setupBack', 'setupMode', 'setupRegion', 'setupClub', 'setupDiff', 'landingReset', 'importClick', 'loadAutosave', 'pickLanguage', 'confirmLanguage', 'openLanguageModal', 'applyLanguage', 'pickSetupLogo', 'removeSetupLogo', 'toggleAudioPanel', 'toggleMusic', 'toggleSfx', 'dismissTrophies', 'nextTrophyCelebration'].indexOf(act) < 0) {
      U.landing(); return;
    }
    switch (act) {
      case 'go': U.route(page || 'dashboard'); break;
      case 'goClose': U.closeModal(); U.route(page || 'dashboard'); break;
      case 'applyRosterFilters': U.render(); break;
      case 'resetRosterFilters':
        U.filters.rosters = { org: 'all', region: 'all', league: 'all', competition: 'all', search: '' };
        U.render();
        break;
      case 'closeModal': U.closeModal(); break;
      case 'toggleAudioPanel': U.audioPanelOpen = !U.audioPanelOpen; U.renderAudioDock(); break;
      case 'dismissTrophies': U.trophyQueue = []; U.trophyCelebrationShowing = false; U.closeModal(); break;
      case 'nextTrophyCelebration': U.trophyQueue.shift(); U.trophyCelebrationShowing = false; U.closeModal(); U.showNextTrophy(); break;
      case 'closeModalRefresh': U.closeModal(); U.render(); break;
      case 'openHelp': U.helpModal(value || U.current); break;
      case 'pickHelp': U.helpModal(value); break;
      case 'openSkipMenu': U.skipMenuModal(); break;
      case 'confirmSkip': U.skipConfirmModal(value); break;
      case 'doSkip':
      case 'doSkipConfirmed': {
        U.closeModal();
        var isLong = (value === 'split' || value === 'season');
        var sum = Game.skipTime(value, { autoResolveMatches: isLong });
        U.updateCal();
        if (sum.pendingMatch && !isLong) {
          U.route('matchday');
          if (value === 'event') U.skipSummaryModal(sum);
          else U.toast('Match ready', 'Your fixture is waiting. Confirmed tactics and lineup will be used.', 'warn');
        } else {
          U.current = U.current === 'matchday' ? 'dashboard' : U.current;
          U.render();
          U.skipSummaryModal(sum);
        }
        break;
      }
      case 'seasonReview': U.seasonReviewModal(); break;
      case 'pickSetupLogo': {
        U.openLogoPicker(function (dataUrl) {
          if (!U.setup) U.setup = U.setupDefaults();
          U.setup.customLogo = dataUrl;
          U.landing();
          U.toast('Logo uploaded', 'Custom club emblem ready.', 'good');
        });
        break;
      }
      case 'removeSetupLogo': {
        if (U.setup) U.setup.customLogo = null;
        U.landing();
        break;
      }
      case 'setClubLogo': {
        U.openLogoPicker(function (dataUrl) {
          Game.setOrgLogo(dataUrl);
          U.render();
          U.toast('Club logo updated', 'Custom emblem applied across all screens.', 'good');
        });
        break;
      }
      case 'removeClubLogo': {
        Game.setOrgLogo(null);
        U.render();
        U.toast('Logo removed', 'Reverted to default club badge.', 'good');
        break;
      }
      case 'resetMapPool2027': {
        Game.setMapPool(Core.ACTIVE_MAP_POOL_2027.slice());
        U.render();
        U.toast('2027 Map Pool restored', 'Active 7-map competitive rotation applied.', 'good');
        break;
      }
      case 'listPlayerModal': U.listPlayerModal(id); break;
      case 'submitListPlayer': {
        var ask = parseInt((document.getElementById('listAsk') || {}).value || '0', 10);
        var lr2 = Game.listPlayer(id, true, ask);
        U.closeModal();
        U.render();
        U.toast(lr2.ok ? 'Transfer listed' : 'Action failed', lr2.ok ? 'Asking price set to ' + C.money(lr2.askingPrice) + '.' : lr2.reason, lr2.ok ? 'good' : 'bad');
        break;
      }
      case 'unlistPlayer': {
        var ur = Game.listPlayer(id, false);
        U.closeModal();
        U.render();
        U.toast(ur.ok ? 'Removed from transfer list' : 'Failed', ur.ok ? 'Player is no longer transfer listed.' : ur.reason, ur.ok ? 'good' : 'bad');
        break;
      }
      case 'acceptIncoming': {
        var ac = Game.respondIncomingOffer(id, 'accept');
        U.render();
        U.toast(ac.ok ? 'Player sold' : 'Cannot complete sale', ac.ok ? ac.player.nick + ' joins ' + ac.buyer + ' for ' + C.money(ac.fee) + '.' : ac.reason, ac.ok ? 'good' : 'bad');
        break;
      }
      case 'rejectIncoming': {
        Game.respondIncomingOffer(id, 'reject');
        U.render();
        U.toast('Offer rejected', 'Transfer bid declined.', 'warn');
        break;
      }
      case 'counterOfferModal': U.counterOfferModal(id); break;
      case 'submitCounterOffer': {
        var cf = parseInt((document.getElementById('counterFeeInp') || {}).value || '0', 10);
        var cr = Game.respondIncomingOffer(id, 'counter', cf);
        U.closeModal();
        U.render();
        if (cr.ok && cr.decision === 'accept') U.toast('Counter accepted — SOLD', cr.player.nick + ' sold for ' + C.money(cr.fee) + '.', 'good');
        else if (cr.ok && cr.decision === 'revised') U.toast('Counter-offer received', cr.reason, 'warn');
        else U.toast('Negotiation ended', cr.reason, 'bad');
        break;
      }
      case 'pickLanguage': {
        U.langChoice = value;
        if (document.getElementById('langgate')) U.languageGate();
        else U.languageModal(true);
        break;
      }
      case 'confirmLanguage': {
        I18N.set(U.langChoice || I18N.detect());
        var gate = document.getElementById('langgate');
        if (gate) gate.remove();
        U.landing();
        U.toast('Language saved', I18N.langMeta(I18N.get()).native + ' · you can change it in Settings.', 'good');
        break;
      }
      case 'openLanguageModal': U.languageModal(); break;
      case 'applyLanguage': {
        I18N.set(U.langChoice || I18N.get());
        U.closeModal();
        U.refreshLanguage();
        U.toast('Language changed', I18N.langMeta(I18N.get()).native, 'good');
        break;
      }
      case 'advance': {
        if (st.pendingMatch) { U.route('matchday'); break; }
        var daysN = days === 'match' ? 'match' : parseInt(days || '1', 10);
        var r = Game.advance(daysN);
        U.updateCal();
        if (r.pending) { U.toast('Match ready', 'Your fixture is waiting. Confirmed tactics and lineup will be used.', 'warn'); U.route('matchday'); }
        else {
          U.current = U.current === 'matchday' ? 'dashboard' : U.current;
          U.render();
          U.toast('Time advanced', r.days + ' day(s). ' + (r.completions && r.completions.length ? r.completions.length + ' competition(s) completed.' : 'No results requiring your attention.'), 'good');
        }
        break;
      }
      case 'toMatch': {
        if (st.pendingMatch) { U.route('matchday'); break; }
        Game.advanceToMatch();
        U.updateCal();
        if (st.pendingMatch) U.route('matchday');
        else { U.render(); U.toast('No fixture found', 'Advanced to the end of the available calendar. Check Competitions and Calendar.', 'warn'); }
        break;
      }
      case 'playMatch': {
        if (!st.pendingMatch) { U.toast('No pending match', 'Advance time first.', 'warn'); break; }
        var series = Game.resolveMatch();
        if (!series) { U.toast('Match could not be played', 'Check the roster and try again.', 'bad'); break; }
        U.lastSeries = series;
        U.route('report');
        U.toast(series.winner === st.clubId ? 'Victory' : 'Defeat', (st.comps[st.pendingCompId] ? '' : '') + (series.analysis ? series.analysis.headline : ''), series.winner === st.clubId ? 'good' : 'bad');
        break;
      }
      case 'openPlayer': U.playerModal(id); break;
      case 'playerPhoto': {
        var target = s() && s().players[id];
        if (!target) break;
        var input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        input.style.display = 'none';
        document.body.appendChild(input);
        input.addEventListener('change', function () {
          var f = input.files && input.files[0];
          if (!f) { input.remove(); return; }
          var reader = new FileReader();
          reader.onload = function () {
            var img = new Image();
            img.onload = function () {
              var dim = 224;
              var cv = document.createElement('canvas');
              cv.width = dim; cv.height = dim;
              var ctx = cv.getContext('2d');
              var scale = Math.max(dim / img.width, dim / img.height);
              var w = img.width * scale, h = img.height * scale;
              ctx.drawImage(img, (dim - w) / 2, (dim - h) / 2, w, h);
              try {
                target.photo = cv.toDataURL('image/jpeg', 0.82);
                Game.save(true);
                U.playerModal(id);
                U.toast('Photo updated', target.nick + ' now uses your image.', 'good');
              } catch (err) {
                U.toast('Photo failed', 'The image could not be processed.', 'bad');
              }
              input.remove();
            };
            img.onerror = function () { U.toast('Photo failed', 'Unsupported image file.', 'bad'); input.remove(); };
            img.src = String(reader.result);
          };
          reader.onerror = function () { U.toast('Photo failed', 'Could not read this file.', 'bad'); input.remove(); };
          reader.readAsDataURL(f);
        });
        input.click();
        break;
      }
      case 'openOrg': U.orgModal(id); break;
      case 'openNews': U.newsModal(id); break;
      case 'offerModal': U.offerModal(id); break;
      case 'renewModal': U.renewModal(id); break;
      case 'scoutPlayer': {
        var sc = Game.scoutPlayer(id);
        if (sc.ok) U.toast('Scouting report ready', 'Wage demand ' + C.money(sc.report.wage) + ' · asking price ' + C.money(sc.report.fee), 'good');
        else U.toast('Scouting unavailable', sc.reason, 'bad');
        U.render(); break;
      }
      case 'releaseModal': {
        var p0 = st.players[id];
        U.confirm('Release ' + (p0 ? p0.nick : 'player'), 'This removes the player from your roster and pays a severance of 22% of the annual wage. The player becomes a free agent. Continue?', 'confirmRelease', id, true);
        break;
      }
      case 'confirmRelease': {
        var rr = Game.releasePlayer(id);
        U.closeModal(); U.render();
        U.toast(rr.ok ? 'Player released' : 'Release failed', rr.ok ? 'Severance ' + C.money(rr.severance) : rr.reason, rr.ok ? 'good' : 'bad');
        break;
      }
      case 'promotePlayer': {
        var pr = Game.promoteAcademy(id); U.closeModal(); U.render();
        U.toast(pr.ok ? 'Promoted to first team' : 'Promotion failed', pr.ok ? 'The player is now available for selection.' : pr.reason, pr.ok ? 'good' : 'bad');
        break;
      }
      case 'demotePlayer': {
        var dm = Game.demoteToAcademy(id); U.closeModal(); U.render();
        U.toast(dm.ok ? 'Assigned to academy' : 'Cannot assign', dm.ok ? 'Development minutes secured.' : dm.reason, dm.ok ? 'good' : 'bad');
        break;
      }
      case 'submitOffer': {
        var fee = parseInt(document.getElementById('offFee').value || '0', 10);
        var wage = parseInt(document.getElementById('offWage').value || '0', 10);
        var years = parseInt(document.getElementById('offYears').value || '2', 10);
        var role = document.getElementById('offRole').value;
        var res = Game.makeOffer(id, { fee: fee, wage: wage, years: years, playingTime: role });
        if (res.ok) {
          U.closeModal(); U.render();
          U.toast('Transfer complete', res.player.nick + ' signs until ' + res.player.contractEnd + '.', 'good');
        } else {
          U.modal({
            title: 'Offer rejected', sub: 'THE RESPONSE EXPLAINS WHY', size: 'narrow',
            body: '<div class="badbox">' + h(res.reason) + '</div>' + (res.counter ? '<div class="guidance" style="margin-top:9px"><h4>Counter-offer</h4><p>The camp would accept a wage around ' + C.money(res.counter.wage) + (res.counter.fee ? ' and a fee around ' + C.money(res.counter.fee) : '') + '.</p></div>' : ''),
            footer: U.btn('Close', 'closeModal', { cls: 'ghost' }) + U.btn('Try again', 'offerModal', { id: id, cls: 'primary' })
          });
        }
        break;
      }
      case 'submitRenew': {
        var w = parseInt(document.getElementById('renWage').value || '0', 10);
        var y = parseInt(document.getElementById('renYears').value || '2', 10);
        var rn = Game.renewContract(id, w, y);
        U.closeModal();
        U.render();
        U.toast(rn.ok ? 'Contract signed' : 'Renewal rejected', rn.ok ? 'The player is committed to the project.' : rn.reason, rn.ok ? 'good' : 'bad');
        break;
      }
      case 'saveLineup': {
        var ids = [];
        for (var i = 0; i < 5; i++) ids.push(document.getElementById('lineup' + i).value);
        var lr = Game.setLineup(ids);
        U.closeModal();
        if (!lr.ok) U.toast('Lineup not saved', lr.reason, 'bad');
        else { U.render(); U.toast('Lineup saved', 'The starting five is set.', 'good'); }
        break;
      }
      case 'autoLineup': {
        Game.autoLineup(); U.closeModal(); U.render();
        U.toast('Lineup auto-selected', 'Best available player per role.', 'good'); break;
      }
      case 'openLineup': U.lineupModal(); break;
      case 'setCaptain': Game.setCaptain(id); U.render(); U.toast('Captain set', 'Leadership now weights the squad.', 'good'); break;
      case 'setStyle': {
        Game.setPlaystyle(value); U.render();
        U.toast('Tactical style updated', value + ' — review the strengths and weaknesses in the panel.', 'good'); break;
      }
      case 'toggleMap': {
        var pool = st.settings.mapPool.slice();
        if (pool.indexOf(value) >= 0) pool = pool.filter(function (m) { return m !== value; });
        else pool.push(value);
        var mr = Game.setMapPool(pool);
        if (!mr.ok) U.toast('Map pool not changed', mr.reason, 'bad');
        U.render(); break;
      }
      case 'agentModal': U.agentModal(id); break;
      case 'submitAgent': {
        var ag = document.getElementById('agentPick').value;
        var ar = Game.setAgent(id, ag); U.closeModal(); U.render();
        U.toast(ar.ok ? 'Agent assigned' : 'Cannot assign agent', ar.ok ? ag + ' is now the primary pick.' : ar.reason, ar.ok ? 'good' : 'bad');
        break;
      }
      case 'setTrainPrimary': {
        Game.setTrainingPlan({ primary: value }); U.render();
        var trObj = C.TRAINING.filter(function (x) { return x.id === value; })[0];
        U.toast('Training focus set', trObj ? trObj.name : value.toUpperCase(), 'good');
        break;
      }
      case 'setTrainSecondary': Game.setTrainingPlan({ secondary: value }); U.render(); break;
      case 'setIntensity': Game.setTrainingPlan({ intensity: value }); U.render(); break;
      case 'runTraining': {
        var rep = Game.runTrainingWeek(); U.render();
        U.toast('Training session complete', (rep.team.best[0] ? rep.team.best[0].nick + ' +' + rep.team.best[0].delta + ' · ' : '') + 'Fatigue ' + rep.team.avgFatigue + '%', 'good');
        break;
      }
      case 'advanceWeek': {
        var aw = Game.advance(7); U.updateCal();
        if (aw.pending) U.route('matchday');
        else { U.render(); U.toast('Week complete', 'Training and results processed.', 'good'); }
        break;
      }
      case 'upgradeFacility': {
        var up = Game.upgradeFacility(value);
        U.render();
        U.toast(up.ok ? 'Facility upgraded' : 'Upgrade failed', up.ok ? 'Investment ' + C.money(up.cost) + ' completed.' : up.reason, up.ok ? 'good' : 'bad');
        break;
      }
      case 'hireStaff': {
        var hs = Game.hireStaff(id); U.render();
        U.toast(hs.ok ? 'Staff appointed' : 'Appointment failed', hs.ok ? 'The backroom team is stronger.' : hs.reason, hs.ok ? 'good' : 'bad');
        break;
      }
      case 'fireStaff': {
        var fs = Game.fireStaff(id); U.render();
        U.toast(fs.ok ? 'Staff released' : 'Release failed', fs.ok ? 'Compensation paid.' : fs.reason, fs.ok ? 'good' : 'bad');
        break;
      }
      case 'signSponsor': {
        var sp = Game.signSponsor(id); U.render();
        U.toast(sp.ok ? 'Sponsorship active' : 'Sponsorship failed',
          sp.ok ? C.money(sp.annual) + '/yr · ' + C.money(sp.payment) + ' due ' + C.fmtDate(sp.nextPayment) : sp.reason,
          sp.ok ? 'good' : 'bad');
        break;
      }
      case 'negotiateSponsor': {
        var ng = Game.negotiateSponsor(id); U.render();
        U.toast(ng.ok ? 'Better terms secured' : (ng.withdrawn ? 'Sponsor withdrew' : 'Negotiation failed'),
          ng.ok ? 'Annual value raised from ' + C.money(ng.before) + ' to ' + C.money(ng.value) + '.' : ng.reason,
          ng.ok ? 'good' : 'bad');
        break;
      }
      case 'refreshSponsors': Game.refreshSponsors(); U.render(); U.toast('Sponsor market refreshed', 'New offers generated.', 'good'); break;
      case 'newsFilter': U.filters.news = value; U.render(); break;
      case 'markAllRead': Game.markNewsRead('all'); U.render(); break;
      case 'recFilter': {
        var key = el.getAttribute('data-key');
        U.filters.recruitment[key] = value === 'true' ? true : value === 'false' ? false : value;
        U.render(); break;
      }
      case 'recSearch': {
        U.filters.recruitment.search = (document.getElementById('recSearch') || {}).value || '';
        U.render(); break;
      }
      case 'compTab': U.compTab = value; U.render(); break;
      case 'compRegion': U.compRegion = value; U.compId = null; U.render(); break;
      case 'openComp': U.compId = U.compId === id ? null : id; U.render(); break;
      case 'toggleGuided': st.guided = !st.guided; st.settings.tips = st.guided; Game.save(true); U.render(); break;
      case 'mainMenu': U.landing(); break;
      case 'loadAutosave': {
        var au = Game.loadAutosave();
        if (au) { U.start(); U.toast('Autosave loaded', au.orgs[au.clubId].name + ' · ' + au.date, 'good'); }
        else U.toast('No autosave found', 'Start a new career or import a backup.', 'bad');
        break;
      }
      case 'calPrev': U.calendar.month--; if (U.calendar.month < 0) { U.calendar.month = 11; U.calendar.year--; } U.render(); break;
      case 'calNext': U.calendar.month++; if (U.calendar.month > 11) { U.calendar.month = 0; U.calendar.year++; } U.render(); break;
      case 'calToday': U.updateCal(); U.render(); break;
      case 'saveNow': {
        var ok = Game.save();
        U.render();
        U.toast(ok ? 'Game saved' : 'Save failed', ok ? 'Local save updated.' : 'Local storage is unavailable or full. Export a backup.', ok ? 'good' : 'bad');
        break;
      }
      case 'exportSave': Game.exportSave(); U.toast('Export started', 'A JSON save file is downloading.', 'good'); break;
      case 'importClick': {
        var f = document.getElementById('importFile');
        if (!f) { U.landing(); setTimeout(function () { document.getElementById('importFile').click(); }, 30); }
        else f.click();
        break;
      }
      case 'toggleAutoSave': st.settings.autoSave = !st.settings.autoSave; Game.save(true); U.render(); break;
      case 'toggleTips': st.settings.tips = !st.settings.tips; Game.save(true); U.render(); break;
      case 'toggleNotif': st.settings.notifications = !st.settings.notifications; Game.save(true); U.render(); break;
      case 'toggleMusic': {
        var musicPrefs = VgmAudio.getSettings();
        VgmAudio.configure({ musicEnabled: !musicPrefs.musicEnabled });
        if (s()) U.render(); else U.renderAudioDock();
        break;
      }
      case 'toggleSfx': {
        var sfxPrefs = VgmAudio.getSettings();
        VgmAudio.configure({ sfxEnabled: !sfxPrefs.sfxEnabled });
        if (s()) U.render(); else U.renderAudioDock();
        break;
      }
      case 'importMusic': {
        var musicFileInput = document.getElementById('customMusicFile');
        if (musicFileInput) musicFileInput.click();
        break;
      }
      case 'removeCustomMusic':
        VgmAudio.clearCustomTrack().then(function () {
          U.render();
          U.toast('Custom music removed', 'The built-in instrumental score is active again.', 'good');
        });
        break;
      case 'previewSfx': VgmAudio.playFeedback('good'); break;
      case 'selfTest': {
        U.toast('Self-test running', 'Simulating multiple seasons. This may take a few seconds.', 'warn');
        setTimeout(function () {
          U.selfTestResult = Game.selfTest(2);
          U.render();
          U.toast(U.selfTestResult.ok ? 'Self-test passed' : 'Self-test found issues', U.selfTestResult.checks.filter(function (c) { return c.pass; }).length + '/' + U.selfTestResult.checks.length + ' checks passed.', U.selfTestResult.ok ? 'good' : 'bad');
        }, 40);
        break;
      }
      case 'newCareerConfirm': {
        U.confirm('Start a new career', 'Your current career remains in the save list. A new one will be created separately. Continue?', 'newCareerNow');
        break;
      }
      case 'newCareerNow': {
        U.closeModal();
        U.setup = U.setupDefaults();
        U.setupStep = 1;
        U.landing();
        break;
      }
      case 'deleteSaveConfirm': U.confirm('Delete save', 'This permanently removes the career from local storage. Export it first if you want a backup.', 'deleteSaveNow', id, true); break;
      case 'deleteSaveNow': Game.remove(id); U.closeModal(); U.render(); U.toast('Save deleted', 'Local career removed.', 'warn'); break;
      case 'loadSave': U.loadAndStart(id); break;
      case 'deleteSave': U.confirm('Delete save', 'Permanently remove this career?', 'deleteSaveNow', id, true); break;
      case 'landingReset': U.setup = U.setupDefaults(); U.setupStep = 1; U.landing(); break;
      case 'setupNext': {
        if (U.setupStep === 1 && !U.setup.managerName.trim()) { U.toast('Name required', 'Enter a manager name.', 'bad'); break; }
        if (U.setupStep === 2 && U.setup.mode === 'new' && !U.setup.orgName.trim()) { U.toast('Club name required', 'Enter an organisation name.', 'bad'); break; }
        if (U.setupStep === 3) { startCareer(); break; }
        U.setupStep++; U.landing(); break;
      }
      case 'setupBack': U.setupStep = Math.max(1, U.setupStep - 1); U.landing(); break;
      case 'setupMode': U.setup.mode = value; if (value === 'new') U.setup.clubId = null; else U.setup.clubId = U.setup.clubId || 'sentinels'; U.landing(); break;
      case 'setupRegion': {
        U.setup.region = value;
        var first = DB.ORGS.filter(function (o) { return o.status !== 'inactive' && o.region === value; })[0];
        U.setup.clubId = first ? first.id : null;
        U.setup.sub = (C.REGIONS.filter(function (r) { return r.id === value; })[0] || C.REGIONS[0]).subs[0];
        U.landing(); break;
      }
      case 'setupClub': U.setup.clubId = id; U.landing(); break;
      case 'setupDiff': U.setup.difficulty = value; U.landing(); break;
      case 'startCareer': startCareer(); break;
      case 'gotoFix': {
        var focus = el.getAttribute('data-focus');
        if (focus) {
          var t = C.TRAINING.filter(function (x) { return x.id === focus || x.attrs.indexOf(focus) >= 0; })[0];
          if (t) Game.setTrainingPlan({ primary: t.id });
        }
        U.route(page || 'dashboard');
        break;
      }
      case 'closeTip': document.getElementById('tip').hidden = true; break;
      default: break;
    }
  };

  var runAction = U.act;
  U.act = function (act, el) {
    var beforeState = s();
    var startAt = beforeState && beforeState.manager && beforeState.manager.trophies ? beforeState.manager.trophies.length : 0;
    try { return runAction.call(U, act, el); }
    finally {
      var afterState = s();
      if (beforeState && beforeState === afterState && afterState.manager && afterState.manager.trophies) {
        U.enqueueTrophies(afterState.manager.trophies.slice(startAt));
      }
    }
  };

  function startCareer() {
    var st = U.setup;
    try {
      Game.newCareer({
        managerName: st.managerName || 'Alex Mercer', managerNat: st.managerNat, managerAge: st.managerAge,
        difficulty: st.difficulty, guided: st.guided, mode: st.mode, clubId: st.clubId,
        region: st.region, sub: st.sub, orgName: st.orgName, orgShort: st.orgShort,
        city: st.city, colors: st.colors, customLogo: st.customLogo || null,
        saveName: (st.managerName || 'Manager') + ' · ' + (st.mode === 'new' ? st.orgName : (DB.ORGS.filter(function (o) { return o.id === st.clubId; })[0] || {}).short)
      });
      U.current = 'dashboard';
      U.updateCal();
      U.start();
      U.toast('Career started', 'Welcome to ' + Game.org().name + '. Check Objectives and Tactics first.', 'good');
    } catch (e) {
      U.toast('Could not start career', String(e.message || e), 'bad');
      if (window.console) console.error(e);
    }
  }

  U.updateCal = function () {
    if (!s()) return;
    var d = C.parseDate(s().date);
    U.calendar.year = d.getUTCFullYear();
    U.calendar.month = d.getUTCMonth();
  };

  U.change = function (kind, el) {
    var st = s();
    if (kind === 'audioVolume') {
      var audioKind = el.getAttribute('data-audio');
      var volumeChange = {};
      if (audioKind === 'music' || audioKind === 'sfx') {
        volumeChange[audioKind === 'music' ? 'musicVolume' : 'sfxVolume'] = Number(el.value) / 100;
        VgmAudio.configure(volumeChange);
        var label = document.getElementById(audioKind + 'VolumeValue');
        if (label) label.textContent = el.value + '%';
        var dockLabel = document.getElementById(audioKind === 'music' ? 'audioDockMusicValue' : 'audioDockSfxValue');
        if (dockLabel) dockLabel.textContent = el.value + '%';
      }
      return;
    }
    if (kind && kind.indexOf('setup:') === 0) {
      var key = kind.slice(6);
      var val = el.type === 'checkbox' ? el.checked : el.value;
      if (key === 'color0' || key === 'color1') {
        U.setup.colors[key === 'color0' ? 0 : 1] = val;
      } else if (key === 'guided') {
        U.setup.guided = val === 'true';
      } else if (key === 'managerAge') {
        U.setup.managerAge = parseInt(val, 10) || 34;
      } else if (key === 'region') {
        U.setup.region = val;
        var reg = C.REGIONS.filter(function (r) { return r.id === val; })[0];
        U.setup.sub = reg ? reg.subs[0] : 'Europe';
      } else {
        U.setup[key] = val;
      }
      return;
    }
    if (kind === 'recSearchInput') {
      U.filters.recruitment.search = el.value;
      return;
    }
    if (kind === 'rosterFilter') {
      var key = el.getAttribute('data-roster-filter');
      if (key && Object.prototype.hasOwnProperty.call(U.filters.rosters, key)) {
        U.filters.rosters[key] = el.value;
        U.render();
      }
      return;
    }
    if (!st) return;
    if (kind === 'filterRole') { U.filters.recruitment.role = el.value; U.render(); }
    else if (kind === 'filterSort') { U.filters.recruitment.sort = el.value; U.render(); }
    else if (kind === 'filterAge') { U.filters.recruitment.maxAge = parseInt(el.value, 10) || 40; U.render(); }
    else if (kind === 'filterMin') { U.filters.recruitment.min = parseInt(el.value, 10) || 0; U.render(); }
    else if (kind === 'filterFree') { U.filters.recruitment.freeOnly = el.checked; U.render(); }
    else if (kind === 'mapPrefPick') {
      var picks = [].slice.call(document.querySelectorAll('[data-pref=pick]:checked')).map(function (x) { return x.value; });
      Game.setMapPrefs('picks', picks);
    } else if (kind === 'mapPrefBan') {
      var bans = [].slice.call(document.querySelectorAll('[data-pref=ban]:checked')).map(function (x) { return x.value; });
      Game.setMapPrefs('bans', bans);
    } else if (kind === 'setupSelect') {
      // generic setup select handled above
    }
  };

  /* ------------------------------------------------------------------
     EVENTS
  ------------------------------------------------------------------ */
  U.init = function () {
    U.renderAudioDock();
    document.addEventListener('click', function (e) {
      var el = e.target.closest('[data-act]');
      if (!el) return;
      var act = el.getAttribute('data-act');
      if (!act) return;
      e.preventDefault();
      try { U.act(act, el); }
      catch (err) {
        if (window.console) console.error(err);
        U.toast('Action failed', String(err.message || err), 'bad');
      }
    });
    function syncSetup(el) {
      if (!U.setup || !el) return;
      var key = el.getAttribute('data-setup');
      if (!key) return;
      var val = el.type === 'checkbox' ? el.checked : el.value;
      if (key === 'guided') {
        U.setup.guided = val === true || val === 'true';
      } else if (key === 'managerAge') {
        U.setup.managerAge = parseInt(val, 10) || 34;
      } else if (key === 'color0' || key === 'color1') {
        U.setup.colors[key === 'color0' ? 0 : 1] = val;
      } else if (key === 'region') {
        U.setup.region = val;
        var reg = C.REGIONS.filter(function (r) { return r.id === val; })[0] || C.REGIONS[0];
        U.setup.region = reg.id;
        // A sub-region is only valid inside its own main region. Reset it
        // immediately so the dependent dropdown can never show stale options.
        if (reg.subs.indexOf(U.setup.sub) < 0) U.setup.sub = reg.subs[0];
        U.landing();
        return;
      } else if (key === 'sub') {
        var active = C.REGIONS.filter(function (r) { return r.id === U.setup.region; })[0] || C.REGIONS[0];
        U.setup.sub = active.subs.indexOf(val) >= 0 ? val : active.subs[0];
      } else {
        U.setup[key] = el.type === 'number' ? parseInt(val, 10) : val;
      }
    }
    document.addEventListener('change', function (e) {
      var setupEl = e.target.closest('[data-setup]');
      if (setupEl) syncSetup(setupEl);
      var el = e.target.closest('[data-change]');
      if (!el) return;
      U.change(el.getAttribute('data-change'), el);
    });
    document.addEventListener('input', function (e) {
      var audioRange = e.target.closest('input[data-change="audioVolume"]');
      if (audioRange) U.change('audioVolume', audioRange);
      var el = e.target.closest('[data-setup]');
      if (el) syncSetup(el);
      var search = e.target.closest('[data-change="recSearchInput"]');
      if (search) U.filters.recruitment.search = search.value;
      var rosterSearch = e.target.closest('[data-change="rosterFilter"][data-roster-filter="search"]');
      if (rosterSearch) U.filters.rosters.search = rosterSearch.value;
    });
    document.addEventListener('mouseover', function (e) {
      var el = e.target.closest('[data-tip]');
      if (el) tipFor(el);
    });
    document.addEventListener('mouseout', function (e) {
      var el = e.target.closest('[data-tip]');
      if (el) document.getElementById('tip').hidden = true;
    });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { U.closeModal(); document.getElementById('tip').hidden = true; }
      if (e.key === '?' && e.target.tagName !== 'INPUT' && e.target.tagName !== 'TEXTAREA') {
        U.modal({
          title: 'Keyboard and workflow', sub: 'QUICK REFERENCE', size: 'narrow',
          body: '<div class="checkline">A — advance one day</div><div class="checkline">W — advance one week</div><div class="checkline">M — advance to next match</div>' +
            '<div class="checkline">Esc — close modal</div><div class="checkline">Space — open match day when pending</div>' +
            '<div class="sub" style="margin-top:8px">Every important mechanical result in this game has an explanation and a page-linked fix. Use the info icons for definitions.</div>',
          footer: U.btn('Close', 'closeModal', { cls: 'ghost' })
        });
      }
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') return;
      if (!s() || document.getElementById('modal-root').classList.contains('open')) return;
      if (e.key === 'a' || e.key === 'A') U.act('advance', { getAttribute: function () { return '1'; } });
      if (e.key === 'w' || e.key === 'W') U.act('advance', { getAttribute: function (k) { return k === 'data-days' ? '7' : null; } });
      if (e.key === 'm' || e.key === 'M') U.act('toMatch', { getAttribute: function () { return null; } });
      if (e.key === ' ' && s() && s().pendingMatch) { U.act('playMatch', { getAttribute: function () { return null; } }); }
    });
  };

  U.C = C;
  return U;
})();
