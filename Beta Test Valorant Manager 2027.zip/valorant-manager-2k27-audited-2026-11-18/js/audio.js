/* =====================================================================
   VALORANT MANAGER 2027 — ORIGINAL AUDIO
   User-supplied VALORANT instrumental, generated fallback score and short
   interface sounds. Audio is played locally without an external stream.
   ===================================================================== */
var VgmAudio = (function () {
  'use strict';

  var STORE_KEY = 'vgm27.audio.v1';
  var BUNDLED_TRACK_PATH = 'assets/audio/if-the-sun-burns-out-tonight-instrumental.mp3';
  var BUNDLED_TRACK_NAME = 'If The Sun Burns Out Tonight (Official Instrumental)';
  var prefs = {
    musicEnabled: true,
    sfxEnabled: true,
    musicVolume: 0.30,
    sfxVolume: 0.45
  };
  var ctx = null, master = null, musicBus = null, sfxBus = null, musicFilter = null;
  var timer = null, step = 0, nextTime = 0, unlocked = false, installed = false, lastClick = 0;
  var customAudio = null, customUrl = null, customTrackName = '', bundledAudio = null, bundledAudioFailed = false, trackDbPromise = null;
  var bpm = 78;
  var progression = [
    { root: 38, chord: [50, 57, 60, 64] }, // D minor add9
    { root: 34, chord: [46, 53, 57, 62] }, // B-flat major 7
    { root: 41, chord: [53, 60, 65, 67] }, // F add9
    { root: 36, chord: [48, 55, 59, 62] }  // C add9
  ];
  var lead = [null, 74, null, 77, 79, null, 81, null];

  function clamp(value, min, max) {
    value = Number(value);
    return isFinite(value) ? Math.max(min, Math.min(max, value)) : min;
  }
  function loadPrefs() {
    try {
      var saved = JSON.parse(window.localStorage.getItem(STORE_KEY) || 'null');
      if (!saved || typeof saved !== 'object') return;
      if (typeof saved.musicEnabled === 'boolean') prefs.musicEnabled = saved.musicEnabled;
      if (typeof saved.sfxEnabled === 'boolean') prefs.sfxEnabled = saved.sfxEnabled;
      if (saved.musicVolume != null) prefs.musicVolume = clamp(saved.musicVolume, 0, 1);
      if (saved.sfxVolume != null) prefs.sfxVolume = clamp(saved.sfxVolume, 0, 1);
    } catch (e) { }
  }
  function savePrefs() {
    try { window.localStorage.setItem(STORE_KEY, JSON.stringify(prefs)); } catch (e) { }
  }
  function getSettings() {
    return {
      musicEnabled: prefs.musicEnabled,
      sfxEnabled: prefs.sfxEnabled,
      musicVolume: prefs.musicVolume,
      sfxVolume: prefs.sfxVolume,
      customTrackName: customTrackName,
      currentTrackName: customTrackName || BUNDLED_TRACK_NAME
    };
  }
  function ensureContext() {
    if (ctx) return true;
    var AudioContextType = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextType) return false;
    try {
      ctx = new AudioContextType();
      master = ctx.createGain();
      musicBus = ctx.createGain();
      sfxBus = ctx.createGain();
      musicFilter = ctx.createBiquadFilter();
      master.gain.value = 0.78;
      musicFilter.type = 'lowpass';
      musicFilter.frequency.value = 4600;
      musicBus.connect(musicFilter);
      musicFilter.connect(master);
      sfxBus.connect(master);
      master.connect(ctx.destination);
      applyVolumes();
      return true;
    } catch (e) {
      ctx = null;
      return false;
    }
  }
  function applyVolumes() {
    if (!ctx || !musicBus || !sfxBus) return;
    var now = ctx.currentTime;
    musicBus.gain.setTargetAtTime(prefs.musicEnabled ? prefs.musicVolume * 0.82 : 0, now, 0.08);
    sfxBus.gain.setTargetAtTime(prefs.sfxEnabled ? prefs.sfxVolume * 0.72 : 0, now, 0.025);
  }
  function configure(changes) {
    changes = changes || {};
    if (typeof changes.musicEnabled === 'boolean') prefs.musicEnabled = changes.musicEnabled;
    if (typeof changes.sfxEnabled === 'boolean') prefs.sfxEnabled = changes.sfxEnabled;
    if (changes.musicVolume != null) prefs.musicVolume = clamp(changes.musicVolume, 0, 1);
    if (changes.sfxVolume != null) prefs.sfxVolume = clamp(changes.sfxVolume, 0, 1);
    savePrefs();
    if (customAudio) customAudio.volume = prefs.musicEnabled ? prefs.musicVolume : 0;
    if (ensureContext()) applyVolumes();
    if (!prefs.musicEnabled) stopMusic();
    else if (unlocked) startMusic();
    return getSettings();
  }
  function unlock() {
    unlocked = true;
    if (!ensureContext()) {
      if (prefs.musicEnabled) startMusic();
      return null;
    }
    try {
      var resumed = ctx.resume();
      if (resumed && typeof resumed.then === 'function') {
        return resumed.then(function () { if (prefs.musicEnabled) startMusic(); }).catch(function () { });
      }
      if (prefs.musicEnabled) startMusic();
      return null;
    } catch (e) { }
    return null;
  }
  function frequency(midi) { return 440 * Math.pow(2, (midi - 69) / 12); }
  function tone(freq, when, duration, type, peak, bus, attack, detune) {
    if (!ctx || !bus || ctx.state !== 'running') return;
    try {
      var osc = ctx.createOscillator();
      var amp = ctx.createGain();
      var start = Math.max(when, ctx.currentTime + 0.006);
      var end = start + duration;
      osc.type = type || 'sine';
      osc.frequency.setValueAtTime(freq, start);
      if (detune) osc.detune.setValueAtTime(detune, start);
      amp.gain.setValueAtTime(0.0001, start);
      amp.gain.linearRampToValueAtTime(Math.max(0.0002, peak), start + Math.min(attack || 0.018, duration * 0.45));
      amp.gain.setTargetAtTime(0.0001, end, Math.max(0.018, duration * 0.22));
      osc.connect(amp);
      amp.connect(bus);
      osc.start(start);
      osc.stop(end + 0.12);
    } catch (e) { }
  }
  function playClick() {
    if (!prefs.sfxEnabled || !ctx || ctx.state !== 'running') return;
    var now = ctx.currentTime;
    tone(1180, now, 0.034, 'triangle', 0.13, sfxBus, 0.003, -3);
    tone(1760, now + 0.006, 0.022, 'sine', 0.045, sfxBus, 0.002, 2);
  }
  function actionSeed(action) {
    var seed = 0;
    for (var i = 0; i < action.length; i++) seed = (seed * 31 + action.charCodeAt(i)) >>> 0;
    return seed;
  }
  function playAction(action) {
    if (!prefs.sfxEnabled || !ctx || ctx.state !== 'running') return;
    action = String(action || 'generic');
    var now = ctx.currentTime, seed = actionSeed(action), pitch = seed % 120;
    var isTime = /^(advance|advanceWeek|toMatch|doSkip|doSkipConfirmed|confirmSkip)$/.test(action);
    var isCalendarNav = /^(calNext|calPrev|calToday)$/.test(action);
    var isMatch = action === 'playMatch' || action === 'seasonReview';
    var isDanger = /^(rejectIncoming|confirmRelease|deleteSaveNow|deleteSave|deleteSaveConfirm|fireStaff|removeClubLogo|removeSetupLogo|removeCustomMusic)$/.test(action);
    var isMarket = /^(submitOffer|submitCounterOffer|acceptIncoming|signSponsor|negotiateSponsor|refreshSponsors)$/.test(action);
    var isTraining = /^(runTraining|setTrainPrimary|setTrainSecondary|setIntensity)$/.test(action);
    var isRoster = /^(promotePlayer|demotePlayer|saveLineup|autoLineup|setCaptain|setStyle|submitAgent)$/.test(action);
    var isCommit = /^(startCareer|saveNow|submitOffer|submitRenew|acceptIncoming|signSponsor|hireStaff|promotePlayer|upgradeFacility|saveLineup|confirmLanguage)$/.test(action);
    var isNavigation = /^(go|goClose|gotoFix|mainMenu|closeModal|closeModalRefresh|openPlayer|openOrg|openNews|openHelp|pickHelp|openComp)$/.test(action);
    var isModal = /^(offerModal|renewModal|counterOfferModal|agentModal|openLineup|openSkipMenu|openLanguageModal|listPlayerModal|scoutPlayer|releaseModal|importMusic|setClubLogo)$/.test(action);
    var isSelection = /^(toggle|set|pick|setup|compTab|compRegion|recFilter|newsFilter|rosterFilter|applyRosterFilters|resetRosterFilters|toggleMusic|toggleSfx|toggleGuided|toggleAutoSave|toggleTips|toggleNotif|filter)/.test(action);
    if (isMatch) {
      tone(196, now, 0.18, 'triangle', 0.15, sfxBus, 0.012, 0);
      tone(392 + pitch, now + 0.06, 0.20, 'sine', 0.10, sfxBus, 0.012, 0);
    } else if (isTime) {
      tone(245 + pitch, now, 0.075, 'sine', 0.09, sfxBus, 0.006, 0);
      tone(490 + pitch, now + 0.055, 0.045, 'triangle', 0.055, sfxBus, 0.004, 0);
    } else if (isCalendarNav) {
      tone(580 + (pitch % 90), now, 0.028, 'sine', 0.055, sfxBus, 0.003, 0);
    } else if (isDanger) {
      tone(310 + pitch, now, 0.055, 'triangle', 0.09, sfxBus, 0.004, -2);
    } else if (isMarket) {
      tone(660 + pitch, now, 0.045, 'triangle', 0.075, sfxBus, 0.004, 0);
      tone(990 + pitch, now + 0.035, 0.075, 'sine', 0.06, sfxBus, 0.004, 0);
      tone(1480, now + 0.052, 0.025, 'sine', 0.025, sfxBus, 0.002, 0);
    } else if (isTraining) {
      tone(290 + (pitch % 50), now, 0.08, 'triangle', 0.07, sfxBus, 0.01, 0);
      tone(440 + (pitch % 60), now + 0.045, 0.055, 'sine', 0.045, sfxBus, 0.005, 0);
    } else if (isRoster) {
      tone(620 + pitch, now, 0.028, 'triangle', 0.065, sfxBus, 0.002, 0);
      tone(760 + pitch, now + 0.034, 0.035, 'sine', 0.04, sfxBus, 0.003, 0);
    } else if (isCommit) {
      tone(650 + pitch, now, 0.045, 'sine', 0.075, sfxBus, 0.004, 0);
      tone(820 + pitch, now + 0.025, 0.055, 'sine', 0.052, sfxBus, 0.004, 0);
    } else if (isNavigation) {
      tone(470 + pitch, now, 0.045, 'sine', 0.065, sfxBus, 0.004, 0);
      tone(630 + pitch, now + 0.028, 0.055, 'sine', 0.044, sfxBus, 0.004, 0);
    } else if (isModal) {
      tone(880 + (pitch % 70), now, 0.032, 'triangle', 0.065, sfxBus, 0.003, 0);
    } else if (isSelection) {
      tone(560 + (pitch * 2), now, 0.026, 'triangle', 0.058, sfxBus, 0.002, (seed % 2 ? 2 : -2));
    } else {
      playClick();
    }
  }
  function playFeedback(kind) {
    if (!prefs.sfxEnabled || !ctx || ctx.state !== 'running') return;
    var now = ctx.currentTime;
    if (kind === 'good') {
      tone(740, now, 0.105, 'sine', 0.12, sfxBus, 0.008, 0);
      tone(988, now + 0.045, 0.13, 'sine', 0.085, sfxBus, 0.008, 0);
    } else if (kind === 'bad') {
      tone(294, now, 0.105, 'triangle', 0.085, sfxBus, 0.009, 0);
      tone(220, now + 0.045, 0.12, 'triangle', 0.065, sfxBus, 0.009, 0);
    }
  }
  function scheduleBar(bar, when) {
    var part = progression[bar % progression.length];
    part.chord.forEach(function (note, index) {
      tone(frequency(note), when, 2.65, index === 0 ? 'triangle' : 'sine', index === 0 ? 0.11 : 0.072, musicBus, 0.32, (index % 2 ? 3 : -3));
    });
  }
  function scheduleStep(index, when) {
    var local = index % 8;
    var bar = Math.floor(index / 8);
    var part = progression[bar % progression.length];
    if (local === 0) scheduleBar(bar, when);
    if (local === 0 || local === 4) {
      var bassNote = local === 0 ? part.root : part.root + 7;
      tone(frequency(bassNote), when, 0.34, 'triangle', 0.16, musicBus, 0.014, 0);
    }
    if (lead[local] != null) tone(frequency(lead[local]), when, 0.22, 'sine', 0.075, musicBus, 0.012, 0);
  }
  function tick() {
    if (!ctx || ctx.state !== 'running' || !prefs.musicEnabled) return;
    var eighth = 30 / bpm;
    while (nextTime < ctx.currentTime + 0.16) {
      scheduleStep(step, nextTime);
      nextTime += eighth;
      step = (step + 1) % 32;
    }
  }
  function startMusic() {
    if (!unlocked || !prefs.musicEnabled || prefs.musicVolume <= 0) return;
    var audioTrack = customAudio || getBundledAudio();
    if (audioTrack) {
      if (timer) { window.clearInterval(timer); timer = null; }
      audioTrack.volume = prefs.musicVolume;
      try {
        var audioPlay = audioTrack.play();
        if (audioPlay && audioPlay.catch) audioPlay.catch(function () {
          if (!customAudio) { bundledAudioFailed = true; startGeneratedMusic(); }
        });
      } catch (e) {
        if (!customAudio) { bundledAudioFailed = true; startGeneratedMusic(); }
      }
      return;
    }
    startGeneratedMusic();
  }
  function getBundledAudio() {
    if (bundledAudioFailed || !window.Audio) return null;
    if (!bundledAudio) {
      bundledAudio = new window.Audio(BUNDLED_TRACK_PATH);
      bundledAudio.loop = true;
      bundledAudio.preload = 'auto';
      bundledAudio.volume = prefs.musicVolume;
      bundledAudio.onerror = function () {
        bundledAudioFailed = true;
        if (prefs.musicEnabled && unlocked) startGeneratedMusic();
      };
    }
    return bundledAudio;
  }
  function startGeneratedMusic() {
    if (!unlocked || !prefs.musicEnabled || prefs.musicVolume <= 0) return;
    if (!ctx || ctx.state !== 'running' || timer) return;
    applyVolumes();
    nextTime = ctx.currentTime + 0.08;
    timer = window.setInterval(tick, 70);
  }
  function stopMusic() {
    if (timer) { window.clearInterval(timer); timer = null; }
    if (customAudio) { try { customAudio.pause(); } catch (e) { } }
    if (bundledAudio) { try { bundledAudio.pause(); } catch (e) { } }
    if (ctx && musicBus) musicBus.gain.setTargetAtTime(0, ctx.currentTime, 0.07);
  }
  function triggerActionSound(action) {
    if (!unlocked) {
      var resumed = unlock();
      if (resumed && typeof resumed.then === 'function') {
        resumed.then(function () { playAction(action); });
        return;
      }
    }
    playAction(action);
  }
  function trackDatabase() {
    if (trackDbPromise) return trackDbPromise;
    if (!window.indexedDB) return Promise.reject(new Error('Local audio storage is unavailable.'));
    trackDbPromise = new Promise(function (resolve, reject) {
      var request;
      try { request = window.indexedDB.open('vgm27-audio', 1); }
      catch (e) { reject(e); return; }
      request.onupgradeneeded = function () {
        if (!request.result.objectStoreNames.contains('tracks')) request.result.createObjectStore('tracks');
      };
      request.onsuccess = function () { resolve(request.result); };
      request.onerror = function () { reject(request.error || new Error('Could not open local audio storage.')); };
    });
    return trackDbPromise;
  }
  function useTrack(file, name) {
    stopMusic();
    if (customUrl && window.URL && window.URL.revokeObjectURL) window.URL.revokeObjectURL(customUrl);
    customUrl = window.URL && window.URL.createObjectURL ? window.URL.createObjectURL(file) : null;
    customTrackName = name || 'Custom instrumental';
    customAudio = customUrl && window.Audio ? new window.Audio(customUrl) : null;
    if (customAudio) {
      customAudio.loop = true;
      customAudio.preload = 'auto';
      customAudio.volume = prefs.musicVolume;
    }
    if (unlocked && prefs.musicEnabled) startMusic();
  }
  function setCustomTrack(file) {
    if (!file) return Promise.reject(new Error('Choose an audio file first.'));
    var validType = /^audio\//i.test(file.type || '');
    var validName = /\.(mp3|wav|ogg|oga|m4a|aac|flac|webm)$/i.test(file.name || '');
    if (!validType && !validName) return Promise.reject(new Error('Choose a supported audio file such as MP3, WAV, OGG or M4A.'));
    if (file.size > 40 * 1024 * 1024) return Promise.reject(new Error('Audio files must be 40 MB or smaller.'));
    var name = file.name || 'Custom instrumental';
    return trackDatabase().then(function (db) {
      return new Promise(function (resolve, reject) {
        var transaction = db.transaction('tracks', 'readwrite');
        transaction.objectStore('tracks').put({ blob: file, name: name }, 'selected');
        transaction.oncomplete = function () { resolve(true); };
        transaction.onerror = function () { reject(transaction.error || new Error('Could not save the audio file.')); };
      });
    }).then(function (saved) {
      useTrack(file, name);
      return { saved: saved, name: name };
    }).catch(function () {
      useTrack(file, name);
      return { saved: false, name: name };
    });
  }
  function restoreTrack() {
    trackDatabase().then(function (db) {
      var transaction = db.transaction('tracks', 'readonly');
      var request = transaction.objectStore('tracks').get('selected');
      request.onsuccess = function () {
        var stored = request.result;
        if (stored && stored.blob) useTrack(stored.blob, stored.name);
      };
    }).catch(function () { });
  }
  function clearCustomTrack() {
    stopMusic();
    if (customUrl && window.URL && window.URL.revokeObjectURL) window.URL.revokeObjectURL(customUrl);
    customUrl = null;
    customAudio = null;
    customTrackName = '';
    if (unlocked && prefs.musicEnabled) startMusic();
    return trackDatabase().then(function (db) {
      return new Promise(function (resolve) {
        var transaction = db.transaction('tracks', 'readwrite');
        transaction.objectStore('tracks').delete('selected');
        transaction.oncomplete = function () { resolve(true); };
        transaction.onerror = function () { resolve(false); };
      });
    }).catch(function () { return false; });
  }
  function handleTrackFile(event) {
    var input = event.target;
    if (!input || input.id !== 'customMusicFile') return;
    var file = input.files && input.files[0];
    if (!file) return;
    setCustomTrack(file).then(function (result) {
      if (window.UI) {
        UI.render();
        UI.toast(result.saved ? 'Instrumental loaded' : 'Instrumental loaded for this session', result.saved ? result.name + ' · stored on this device.' : result.name + ' · local browser storage is unavailable.', result.saved ? 'good' : 'warn');
      }
    }).catch(function (error) {
      if (window.UI) UI.toast('Could not load audio', error.message || String(error), 'bad');
    });
    input.value = '';
  }
  function handleClick(event) {
    var control = event.target && event.target.closest ? event.target.closest('[data-act],button,[role="button"]') : null;
    if (!control || control.disabled || control.getAttribute('aria-disabled') === 'true') return;
    var now = Date.now();
    if (now - lastClick < 70) return;
    lastClick = now;
    triggerActionSound(control.getAttribute('data-act'));
  }
  function handleChange(event) {
    var control = event.target;
    if (!control || !control.matches || !control.matches('select[data-change],input[type="checkbox"][data-change]')) return;
    triggerActionSound('selection');
  }
  function handleKey(event) {
    if (event.target && /^(INPUT|TEXTAREA|SELECT)$/.test(event.target.tagName)) return;
    if (['a', 'A', 'w', 'W', 'm', 'M'].indexOf(event.key) < 0) return;
    triggerActionSound(event.key === 'a' || event.key === 'A' ? 'advance' : event.key === 'w' || event.key === 'W' ? 'advanceWeek' : 'toMatch');
  }
  function visibilityChanged() {
    if (!unlocked) return;
    if (document.hidden) {
      if (timer) { window.clearInterval(timer); timer = null; }
      if (customAudio) { try { customAudio.pause(); } catch (e) { } }
      if (bundledAudio) { try { bundledAudio.pause(); } catch (e) { } }
      if (ctx) { try { ctx.suspend(); } catch (e) { } }
      return;
    }
    if (prefs.musicEnabled) startMusic();
    if (!ctx) return;
    try {
      var resumed = ctx.resume();
      if (resumed && typeof resumed.then === 'function') resumed.then(function () { if (prefs.musicEnabled) startMusic(); }).catch(function () { });
      else if (prefs.musicEnabled) startMusic();
    } catch (e) { }
  }
  function init() {
    if (installed) return;
    installed = true;
    loadPrefs();
    document.addEventListener('click', handleClick, true);
    document.addEventListener('change', handleChange, true);
    document.addEventListener('change', handleTrackFile);
    document.addEventListener('keydown', handleKey, true);
    document.addEventListener('visibilitychange', visibilityChanged);
    restoreTrack();
  }

  return { init: init, getSettings: getSettings, configure: configure, playFeedback: playFeedback, clearCustomTrack: clearCustomTrack };
})();
