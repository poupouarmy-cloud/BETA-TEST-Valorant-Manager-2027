/* =====================================================================
   VALORANT MANAGER 2027 — BOOT
   Classic scripts only: the game must run from file:// with no server.
   ===================================================================== */
(function () {
  'use strict';

  function hideBoot() {
    var b = document.getElementById('boot');
    if (!b) return;
    b.classList.add('boot-out');
    setTimeout(function () { if (b && b.parentNode) b.parentNode.removeChild(b); }, 420);
  }

  function boot() {
    try {
      I18N.apply(document.getElementById('boot'));
    } catch (e) { }
    try { VgmAudio.init(); } catch (e) { }
    try {
      UI.init();
    } catch (e) {
      if (window.console) console.error('UI init failed', e);
    }
    try {
      if (!I18N.hasChosen()) UI.languageGate();
      else UI.landing();
    } catch (e) {
      if (window.console) console.error('Landing failed', e);
      var view = document.getElementById('view');
      if (view) view.innerHTML = '<div class="badbox" style="margin:20px">The interface failed to start: ' + String(e && e.message || e) + '</div>';
      var app = document.getElementById('app');
      if (app) app.hidden = false;
    }
    setTimeout(hideBoot, 520);
  }

  /* Global handle for debugging and automated verification. */
  window.VGM27 = {
    Game: Game,
    UI: UI,
    Views: Views,
    DB: DB,
    I18N: I18N,
    Engine: Engine,
    Competition: Competition,
    Core: Core,
    version: Core.VERSION,
    snapshot: Core.DB_SNAPSHOT,
    test: function (seasons) {
      var r = Game.selfTest(seasons || 2);
      if (window.console) {
        console.log('SELF-TEST ' + (r.ok ? 'PASSED' : 'FAILED'));
        r.checks.forEach(function (c) { console.log((c.pass ? 'PASS ' : 'FAIL ') + c.name + (c.detail ? ' — ' + c.detail : '')); });
        r.errors.forEach(function (e) { console.error(e); });
      }
      return r;
    },
    newCareer: function (opts) { return Game.newCareer(opts || { mode: 'existing', clubId: 'sentinels', noSave: true }); },
    state: function () { return Game.state; }
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
